<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
		<link rel="canonical" href="http://<?=$domain?>/<?=str_replace('.php','',basename($_SERVER['PHP_SELF']))?>" />
		<meta name="robots" content="index, follow" />
        <title><?php echo $title?></title>
        <meta name="description" content="<?php echo stripcslashes($description)?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="css/bootstrap.css" />
        <link rel="stylesheet" href="css/custom.css" />
        <link rel="stylesheet" href="css/bootstrap-responsive.css" />
        <link rel="stylesheet" href="css/jquery.fileupload-ui.css">
        <link href="js/jquery.counter-analog.css" media="screen" rel="stylesheet" type="text/css" />
        <link href="js/jquery.counter-analog2.css" media="screen" rel="stylesheet" type="text/css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
		<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />		
        <script type="text/javascript">

		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', '<?php echo $account_ga?>']);
		  _gaq.push(['_trackPageview']);
		
		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		
		</script>
		<style>
		.content-wrap-bg {
			background: linear-gradient(rgba(0, 0, 0, 0.6),rgba(0, 0, 0, 0.6)),url("https://d2qcctj8epnr7y.cloudfront.net/images/jayson/challenge-framework/tired-bike.jpg") no-repeat fixed !important;
			border-top: 1px solid #CCCCCC;
			background-size: cover;
			background-position: 50% 50%;
		}
		.media-body, .media-left, .media-right {
			display: table-cell;
			vertical-align: top;
		}
		.media-left, .media > .pull-left {
			padding-right: 10px;
		}
		.media-right, .media > .pull-right {
			padding-left: 10px;
		}
		.contrib-task-container .media-heading {
			margin: 10px;
		}
		.contrib-task-container .media-right .btn-danger {
			margin-top: 5px;
		}
		</style>
		
		<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$piwik_id?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
    </head>
    <body>
	
	<? if($forsale=='1'){ ?>
		<div style="padding:10px 0 10px 0; margin:0; color: #fff; background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
            <?=$forsaletext?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$domain?>" target="_blank" style="color:blue;">Inquire now</a>.
        </div>
	<? } ?>
    