<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
		<link rel="canonical" href="http://<?=$domain?>/<?=str_replace('.php','',basename($_SERVER['PHP_SELF']))?>" />
		<meta name="robots" content="index, follow" />
        <title><?php echo $title?></title>
        <meta name="description" content="<?php echo stripcslashes($description)?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="css/bootstrap.css" />
        <link rel="stylesheet" href="css/custom.css" />
        <link rel="stylesheet" href="css/bootstrap-responsive.css" />
        <link rel="stylesheet" href="css/jquery.fileupload-ui.css">
        <link href="js/jquery.counter-analog.css" media="screen" rel="stylesheet" type="text/css" />
        <link href="js/jquery.counter-analog2.css" media="screen" rel="stylesheet" type="text/css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
        <script type="text/javascript">

		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', '<?php echo $account_ga?>']);
		  _gaq.push(['_trackPageview']);
		
		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		
		</script>
		<style>
		.content-wrap-bg {
			background: url("<?php echo $background_image ?>") no-repeat fixed !important;
			border-top: 1px solid #CCCCCC;
		}
		</style>
		
    </head>
    <body>
	
	<? if($forsale=='1'){ ?>
		<div style="padding:10px 0 10px 0; margin:0; color: #fff; background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
            <?=$forsaletext?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$domain?>" target="_blank" style="color:blue;">Inquire now</a>.
        </div>
	<? } ?>
    