<?php include 'includes/config.php'?>
<?php include 'header.php'?>
<?php $page="referral"?>
<style>
.blur-box {
	border-bottom: 1px solid rgb(221, 221, 221);
padding: 15px 0px;
}

    #container2 p{text-align:justify !important}

    .input-block-level {
        display: block;
        width: 100%;
        min-height: 30px;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    h3{
        margin: 10px 0;
        font-family: inherit;
        font-weight: bold;
        line-height: 20px;
        color: inherit;
        text-rendering: optimizelegibility;
    }
    dl {
        margin-bottom: 20px;
    }
    
    dt,
    dd {
        line-height: 20px;
    }
    
    dt {
        font-weight: bold;
    }
    
    dd {
        margin-left: 10px;
    }
    
    .dl-horizontal {
        *zoom: 1;
    }
    
    .dl-horizontal:before,
    .dl-horizontal:after {
        display: table;
        line-height: 0;
        content: "";
    }
    
    .dl-horizontal:after {
        clear: both;
    }
    
    .dl-horizontal dt {
        float: left;
        width: 160px;
        overflow: hidden;
        clear: left;
        text-align: right;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .dl-horizontal dd {
        margin-left: 180px;
    }
    .padd-banner{
        padding: 10px 20px;
    }
    .banner-main{
        margin-bottom: 30px;
        padding-bottom:10px;
        border-bottom: 1px solid #fff;
    }
    .banner-main textarea{
        resize:none;
        border-radius: 4px;
        border: 1px solid #000000;
    }
    .banner-main:last-child{
        border-bottom: none;
    }
    .banner-header{
        font-weight: 300;
        color: #fff;
        border-bottom: 1px solid #fff;
        line-height: 65px;
        margin:0 0 30px;
    }
    .banner-img-cont{
        margin-bottom: 25px;
    }
    .banner-source{
        color: #fff;
        font-size:18px;
    }
    .banner-info{
        color: #fff;
    }
    /*
    ==============================================
    tossing
    ==============================================
    */
    
    .tossing{
        animation-name: tossing;
        -webkit-animation-name: tossing;	
        
        animation-duration: 2.5s;	
        -webkit-animation-duration: 2.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes tossing {
        0% {
            transform: rotate(-4deg);	
        }
        50% {
            transform: rotate(4deg);
        }
        100% {
            transform: rotate(-4deg);	
        }						
    }
    
    @-webkit-keyframes tossing {
        0% {
            -webkit-transform: rotate(-4deg);	
        }
        50% {
            -webkit-transform: rotate(4deg);
        }
        100% {
            -webkit-transform: rotate(-4deg);	
        }				
    }
    /*
    ==============================================
    floating
    ==============================================
    */
    
    .floating{
        animation-name: floating;
        -webkit-animation-name: floating;
        
        animation-duration: 1.5s;	
        -webkit-animation-duration: 1.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes floating {
        0% {
            transform: translateY(0%);	
        }
        50% {
            transform: translateY(8%);	
        }	
        100% {
            transform: translateY(0%);
        }			
    }
    
    @-webkit-keyframes floating {
        0% {
            -webkit-transform: translateY(0%);	
        }
        50% {
            -webkit-transform: translateY(8%);	
        }	
        100% {
            -webkit-transform: translateY(0%);
        }			
    }
    .text-center{
        text-align:center;
    }
    #container2 p{
        text-align: center !important;
    }
	
	
	/* Add New 2 banner */
    .wrap-allbanner{
        background: url(http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-728x90-1.png)no-repeat scroll;
        height: 90px;
        width: 728px;
        position: relative;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    .bannerType1{
        text-decoration: none;
    }
    .bannerType1, .bannerType1:focus,.bannerType1:hover{
        outline: none;
    }
    .wrap-bannerLeft, .wrap-bannerRight{
        display: inline-block;
        float: left;
    }
    /* Left COntainer */
    .wrap-bannerLeft{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        height: 90px;
        vertical-align: top;
        padding: 15px 5px 20px 10px;
        width: 245px;
        overflow: hidden;
		
    }
    /*Link Domain*/
    .ellipsis {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .aBnnrP{
        display: block;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        font-weight: bold;
        font-size: 22px;
        line-height: normal;
        margin: 0;
        color: #0088CC;
        text-align: center;
        text-transform: capitalize;
        text-decoration: none;
    }

    /* Right Container */
    .wrap-bannerRight{
        color: #FFFFFF;
        height: 90px;
        margin-left: 84px;
        width: 397px;
    }
    .content-rightText{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 350px;
        padding-top: 16px;
        margin: auto;
    }
    .content-rightText span{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
    }
    .content-rightText span, .content-rightText p{
        font-size: 25px;
        text-align: center;
        text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
    }
    .content-rightText p{
        padding: 12px 0 8px;
        margin: 0;
    }
    /*Image*/
    .logo-banners1{
        max-width: 100%;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
		max-height: 58px;
    }

    /*Second Bannder*/
    .wrapBanner-2{
        background: url(http://d2qcctj8epnr7y.cloudfront.net/images/jayson/180x150-1.png) no-repeat scroll;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        margin: auto;
        position: relative;
        height: 150px;
        width: 180px;
        overflow: hidden;
    }
    .bannerType2{
        color: #fff;
        text-decoration: none;
    }
    .bannerType2,.bannerType2:hover,.bannerType2:focus{
        outline: none;
    }

    /*Top banner*/
    .wrap-topBanner{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        position: relative;
        display: block;
        width: 118px;
        margin: 37px auto 0;
    }
    .wrap-contentTop{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        font-size: 20px;
        letter-spacing: 0.01em;
        line-height: 1.1em;
        text-align: center;
        text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
        text-align: center;
    }
    .wrap-contentTop p{
        margin: 0;
    }
    .wrap-contentTop span{
        display: block;
    }

    /*Down banner*/
    .wrap-downBanner{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
        height: 37px;
        margin: 5px 0 0;
        overflow: hidden;
    }
    .wrap-contentDown{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 125px;
        height: 35px;
        margin: auto;
		padding: 1px 0;
    }
    .wrap-contentDown img{
        max-width: 100%;
		max-height: 32px;
		text-align:center;
    }
    .wrap-contentDown p{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
        margin: 0;
        color: #0088CC;}
.blck2-box {
	background:#555;
	padding:20px;
}
.wrapBanner-3 {
    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-160x600-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 600px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 180px;
}
.wrap-topBanner3 {
    box-sizing: border-box;
    display: block;
    margin: 130px 18px 0;
    position: relative;
    width: 120px;
}


.wrapBanner-4 {
    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-250x250-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 250px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 250px
}
.wrap-topBanner4 {
    box-sizing: border-box;
    display: block;
    margin: 76px 18px 0;
    position: relative;
    
}
</style>
<section class="wow fadeIn">
	<div id="content-wrap" class="container-fluid content-wrap-bg">
		<div lang="row-fluid">
            <div class="container">
				<div class="row-fluid">
						<?php include 'navbar.php'?>
					</div><!--end navbar-->				
                <div class="row-fluid">
				<div class="span12">
					<iframe width="100%" height="800px" frameborder="0" seamless="" scrolling="auto" src="http://referrals.contrib.com/aff_index.php?affiliate=<?php echo $domain?>"></iframe>
                    <div class="blck2-box">
                        <div class="block-group">
                            <dl class="dl-horizontal">
                                <dt>Marketing Group</dt><dd>Contrib</dd>
                                <dt>Banner Size</dt><dd>728 x 90</dd>
                                <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                            </dl>
                            <div class="floating text-center banner-img-cont">
                                <div class="wrap-allbanner">
                                    <div class="wrap-bannerLeft">
                                        <p class="aBnnrP ellipsis" href="">
                                            <img alt="<?php echo $domain?>" src="<?echo $logo?>" class="logo-banners1">
                                        </p>
                                    </div>
                                    <div class="wrap-bannerRight ">
                                        <div class="content-rightText ">
                                            <span class="">Follow , Join and</span>
                                            <p class="ellipsis">Partner with Contrib.com</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br />
                            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                            <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                            <div class="clearfix"></div>
                        </div>
                        <div class="block-group">
                            <dl class="dl-horizontal">
                                <dt>Marketing Group</dt><dd>Contrib</dd>
                                <dt>Banner Size</dt><dd>180 x 150</dd>
                                <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                            </dl>
                            <div class="floating text-center banner-img-cont">
                                <div class="wrapBanner-2">
                                    <div class="wrap-topBanner ">
                                        <div class="wrap-contentTop">
                                            <span>Follow, Join</span>
                                            <span>and Partner with</span>
                                        </div>
                                    </div>
                                    <div class="wrap-downBanner">
                                        <div class="wrap-contentDown">
                                            <p class="ellipsis" href="">
                                                <img alt="<?php echo $domain?>" src="<?echo $logo?>">
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br />
                            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                            <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                            <div class="clearfix"></div>
                        </div>
                        <div class="block-group">
                            <dl class="dl-horizontal">
                                <dt>Marketing Group</dt><dd>Contrib</dd>
                                <dt>Banner Size</dt><dd>728 x 90</dd>
                                <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                            </dl>
                            <div class="floating text-center banner-img-cont">
                                <div class="wrapBanner-3">
                                    <div class="wrap-topBanner3 ">
                                        <div class="wrap-contentTop">
                                            <span>Follow, Join</span>
                                            <span>and Partner with</span>
                                        </div>
                                    </div>
                                    <div class="wrap-downBanner">
                                        <div class="wrap-contentDown">
                                            <p class="ellipsis" href="">
                                                <img alt="<?php echo $domain?>" src="<?echo $logo?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br />
                            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                            <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/verticalbanner<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                        </div>
						
						<div class="block-group">
                            <dl class="dl-horizontal">
                                <dt>Marketing Group</dt><dd>Contrib</dd>
                                <dt>Banner Size</dt><dd>250 x 250</dd>
                                <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                            </dl>
                            <div class="floating text-center banner-img-cont">
                                <div class="wrapBanner-4">
                                    <div class="wrap-topBanner4 ">
                                        <div class="wrap-contentTop">
                                            <span>Follow, Join</span>
                                            <span>and Partner with</span>
                                        </div>
                                    </div>
                                    <div class="wrap-downBanner">
                                        <div class="wrap-contentDown">
                                            <p class="ellipsis" href="">
                                                <img src="<?echo $logo?>" alt="<?php echo $domain?>" src="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br />
                            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                            <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/squarebanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                        </div>						
                    </div>
					</div>
				</div>
			</div>
		</div>
	</div>
		</section>
<?php include 'footer.php'?>