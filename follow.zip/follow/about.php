<?php include 'includes/config.php'?>
<?php include 'header.php'?>
<?php $page="about"?>
        <div id="content-wrap" class="container-fluid content-wrap-bg">
			<div lang="row-fluid">
				<div class="container">
					<div class="row-fluid">
						<?php include 'navbar.php'?>
					</div><!--end navbar-->
					<div class="row-fluid">
						<div class="span12 follow-desc">
							
							<h1 class="rght-ttle text-center">About <?php echo ucfirst($domain)?></h1>
							<br>
							<?php if ($about != ""):?>
								 <h2 class="rght-content"><?=stripcslashes($about)?></h2>
							<?php endif;?>
									
							<h2 class="rght-content"><?=ucwords($domain)?> is a venture of Global Ventures, LLC.</h2>										  
									
							<h2 class="rght-content">Global Ventures, LLC, established in 1996, is a Real Estate and Technology company focused on building and leveraging electronic corporations (eCorp) within the Domain Name System.  Premium domains and companies such as Referrals.com,Staffing.com, Mergers.com, Domain Holdings, VentureCamp, Handyman.com, DSL.com and over 20,000 others are the core digital asset and building blocks of Global Ventures.</h2>
							 
							<h2 class="rght-content">With over 1,000,000 targeted unique monthly visitors, Global Ventures utilizes both virtual and physical real estate with effective business models, streamlined policy and procedures with a balanced and optimal productivity and management platform for the global economy.</h2>
							 
							<h2 class="rght-content">Learn more about joining our team, becoming an iPartner, or leveraging one of our premium domain assets or companies to help grow your business.</h2>
															
														
						</div>
					</div>
				</div>
			</div>
		</div><!--End of content-->
<?php include 'footer.php'?>