<?php include 'includes/config.php'?>
<?php include 'header.php'?>
<?php $page="index"?>
        <div id="content-wrap" class="container-fluid content-wrap-bg">
			<div lang="row-fluid">
				<div class="container">
					<div class="row-fluid">
						<?php include 'navbar.php'?>
					</div><!--end navbar-->
					<div class="row-fluid">
						<div class="span12">
							<?php include 'register-form.php'?>
							<div class="span4 follow-desc">
								<div class="wrap-rght">
								   <h1 class="rght-ttle text-center">Follow, Build and Help Launch <?=ucwords($domain)?></h1>
								   <?php if ($introduction != ""):?>
								   <h2 class="rght-content"><?php echo stripcslashes($introduction)?></h2>							
								   <?php endif;?>
								  									
									<h2 class="rght-content"><b>Follow</b> <?=ucwords($domain)?>, a proud member in the <a href="http://globalventures.com">Global Ventures Network</a>.</h2>
									<h2 class="rght-content"><b>Work for Equity<b>, remotely and globally with other like minded and talented professionals interested in <?=ucwords($domain)?>.</h2>
									<h2 class="rght-content">Have an Idea or Opportunity for <?=ucwords($domain)?>, would love to hear from you.</h2> 

									<center style="margin: 15px 30px 20px 30px;">
									  <span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999" data-stop="<?=$follow_count?>">0</span>
									</center>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!--End of content-->
<?php include 'footer.php'?>