<?php include 'includes/config.php'?>
<?php include 'header.php'?>
<?php $page="index"?>
        <div id="content-wrap" class="container-fluid content-wrap-bg">
			<div class="bg-overlay"></div>
				<div class="container" style="position: relative;">
					<div class="row-fluid">
						<?php include 'navbar.php'?>
					</div><!--end navbar-->
					<div class="row-fluid head-domain-box">
						<div class="span12 text-center head-domain-title"><h1><?=ucwords($domain)?></h1></div>
						<p class="text-center head-domain-desc">Join our exclusive community of like minded people on <?=ucwords($domain)?></p>
					</div>
					<div class="row-fluid lander-box">						
						<?php include 'register-form.php'?>
						<div class="span6">
							<div class="follow-desc2">
							   <h1 class="rght-ttle text-center">Follow, Build and Help Launch <?=ucwords($domain)?></h1>
								<h2 class="rght-content"><b>Follow</b> <?=ucwords($domain)?>, a proud member in the <a href="http://globalventures.com">Global Ventures Network</a>.</h2>
								<h2 class="rght-content"><b>Work for Equity</b>, remotely and globally with other like minded and talented professionals interested in <?=ucwords($domain)?>.</h2>
								<h2 class="rght-content">Have an Idea or Opportunity for <?=ucwords($domain)?>, would love to hear from you.</h2> 
								<center style="margin: 15px 30px 20px 30px;">
								  <span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999" data-stop="<?=$follow_count?>">0</span>
								</center>
							</div>
						</div>
					</div>					
				</div>
		</div><!--End of content-->
		<div class="fbh-wrap" style="display:none;">
			<div class="container">
				<div class="row-fluid">
					
				</div>
			</div>
		</div>
<?php include 'footer.php'?>