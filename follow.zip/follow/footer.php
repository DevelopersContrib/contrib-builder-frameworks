<div class="clearfix"></div>
		<footer class="footer-two">
			<div class="container">
				<div class="row-fluid">
					<p class="p-footer-two">&copy; 2013-2014 Global Ventures | All Rights Reserved</p>
				</div>
			</div>
		</footer>
<input type="hidden" name="user_ip" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">		
<script src="js/jquery.counter.js" type="text/javascript"></script>
<script src="js/jquery.fileupload.js"></script>
<script src="/js/jquery.rating-short.js" type="text/javascript" language="javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/clear_textbox.js"></script>
<script type="text/javascript" src="js/noty/jquery.noty.js"></script>
<script type="text/javascript" src="http://www.contrib.com/js/global.js"></script>
<!-- layouts -->
<script type="text/javascript" src="js/noty/layouts/bottom.js"></script>
<script type="text/javascript" src="js/noty/layouts/bottomCenter.js"></script>
<script type="text/javascript" src="js/noty/layouts/bottomLeft.js"></script>
<script type="text/javascript" src="js/noty/layouts/bottomRight.js"></script>
<script type="text/javascript" src="js/noty/layouts/center.js"></script>
<script type="text/javascript" src="js/noty/layouts/centerLeft.js"></script>
<script type="text/javascript" src="js/noty/layouts/centerRight.js"></script>
<script type="text/javascript" src="js/noty/layouts/inline.js"></script>
<script type="text/javascript" src="js/noty/layouts/top.js"></script>
<script type="text/javascript" src="js/noty/layouts/topCenter.js"></script>
<script type="text/javascript" src="js/noty/layouts/topLeft.js"></script>
<script type="text/javascript" src="js/noty/layouts/topRight.js"></script>
<!-- themes -->
<script type="text/javascript" src="js/noty/themes/default.js"></script>
<script src="http://www.contrib.com/js/bootstrap/bootstrap.min.js"></script> 

		<script>
			$(function () {
				'use strict';
				// Change this to the location of your server-side upload handler:
				var url = 'http://www.contrib.com/signup/uploadpic';
				$('#fileupload').fileupload({
					url: url,
					dataType: 'json',
					done: function (e, data) {
						$.each(data.result.files, function (index, file) {
							if(file.error){
								$('#saved_status').text("Ooops! You uploaded a file alright but it's not in the correct format. We only accept .jpg, .jpeg, or .png files");
							}else{
								$('#saved_status').text("Please wait while we are saving your image..");
								$('<p/>').text(file.name).appendTo('#files');
								$('#userimage').attr('src','http://www.contrib.com/uploads/profile/'+file.name);
								//automatically save user profile image
									$.post('http://www.contrib.com/signup/saveprofileimage',{filename:file.name},function(data){
										if(data == "OK"){
												var filename = file.name;
												var ext = filename.split('.').pop().toLowerCase();
												if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
													$('#saved_status').text("The file you are trying to upload is invalid.");
												}else{
													$('#saved_status').text("Your image has been saved.");
												}
										}else{
											$('#saved_status').text("An error occurred while uploading your image. Please try again.");
										}
									});
							}
						});
					},
					progressall: function (e, data) {
						var progress = parseInt(data.loaded / data.total * 100, 10);
						$('#progress .bar').css(
							'width',
							progress + '%'
						);
					}
				}).prop('disabled', !$.support.fileInput)
					.parent().addClass($.support.fileInput ? undefined : 'disabled');
			});
		</script>

		<script>
		$(function() {
			$('#accordion').accordion({collapsible: true});
			$('#email').tooltip({'trigger':'focus','title':'proper format your@email.com','placement':'right',});
			$('#website').tooltip({'trigger':'focus','title':'enter your website name here','placement':'right',});
			$('#password').tooltip({'trigger':'focus','title':'password must be alphanumeric,4 to 20 characters','placement':'right',}); 
			//$(".users").popover({trigger:'hover'}); 
			$('.counter').counter();
			
			
			$('#follow_step1_btn').click(function(){
				var initial_email = $('#initial_email').val();
				var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				
				$('#follow_warning1').html('');
				
				if (initial_email == ""){
					$('#follow_warning1').html('* Please provide an e-mail *');
					$('#initial_email').focus();
				}else if(!emailfilter.test(initial_email)){
					$('#follow_warning1').html('* Invalid e-mail format *');
					$('#initial_email').focus();
				}else {
					$("#follow_step1_btn").attr('disabled', true); 
					$.post('http://www.contrib.com/forms/fullcontactdetails',
						   {initial_email:initial_email}
						   ,function(data){
								if(data.photo!=''){
									$('#userimage').attr('src',data.photo);
									$('#default_photo').val(data.photo);
								}
							   
							   $('#firstname').val(data.fname);
							   $('#lastname').val(data.lname);							   
							   $('#email').val(initial_email);
							   $('#follow_step1').hide();
							   $('#follow_step2').show();
						   }
					);
				}		
			});
			
			$('#follow_step2_btn').click(function(){
				var email = $('#email').val();
				var firstname = $('#firstname').val();
				var lastname = $('#lastname').val();
				var password = $('#password').val();
				var password2 = $('#password2').val();				
				var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				var letters = /^[a-zA-Z ]+$/;
				
				$('#follow_warning2').html('');
				
				if (email == ""){
					$('#follow_warning2').html('* Please provide an e-mail *');
					$('#email').focus();
				}else if(!emailfilter.test(email)){
					$('#follow_warning2').html('* Invalid e-mail format *');
					$('#email').focus();
				}else if (firstname == ""){
					$('#follow_warning2').html('* First name is required *');
					$('#firstname').focus();
				}else if(!letters.test(firstname)){				
					$('#follow_warning2').html('* Accepts letters only *');
					$('#firstname').focus();
				}else if(firstname.length > 25){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *');
					$('#firstname').focus();               
				}else if(firstname.length < 3 ){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *'); 
					$('#firstname').focus();  
				}else if (lastname == ""){
					$('#follow_warning2').html('* Last name is required *');
					$('#lastname').focus();
				}else if(!letters.test(lastname)){				
					$('#follow_warning2').html('* Accepts letters only *');
					$('#lastname').focus();
				}else if(lastname.length > 25){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *');
					$('#lastname').focus();               
				}else if(lastname.length < 3 ){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *'); 
					$('#lastname').focus();  
				}else if (password == ""){
					$('#follow_warning2').html('* Password is required *');
					$('#password').focus();
				}else if(password.length < 5){				
					$('#follow_warning2').html('* Password should have atleast 5 characters *'); 
					$('#password').focus();  
				}else if (password2 == ""){
					$('#follow_warning2').html('* Confirm Password is required *');
					$('#password2').focus();
				}else if(password!=password2){				
					$('#follow_warning2').html('* Password not match *'); 
					$('#password2').focus();
				}else{
					$('#follow_step2').hide();
					$('#follow_step3').show();
					$('#follow_warning2').html('');
				}
				
			});
						
			$('#follow_step3_btn').click(function(){
				var country_id = $('#country_id').val();
				var city = $('#city').val();
			
				if (country_id == ""){
					$('#follow_warning3').html('* Please select your country *');
					$('#country_id').focus();
				}else if (city == ""){
					$('#follow_warning3').html('* Please enter your city *');
					$('#city').focus();
				}else{
					$('#follow_step3').hide();
					$('#follow_step4').show();
					$('#follow_warning3').html('');
				}			
			});
			
			$('#social_select').change(function(){
				var social = $(this).val();
				
				$('.social_reg'+social).show();
				
				$("#social_select option[value='"+social+"']").remove();
			});
			
			$('.social_remove').click(function(){
				var id = $(this).attr('id');
				var social = id.replace('social_remove_','');
				var text = $(this).attr('alt');
				
				$('.social_reg'+social).hide();
				
				$('#social_select').append( new Option(text,social) );
				
			});
			
			$('#follow_step4_btn').click(function(){
				$('#follow_step4').hide();
				$('#follow_step5').show();
			});
			
			/*BACK EVENTS*/
			$('#follow_step3_back').click(function(){
				$('#follow_step3').hide();
				$('#follow_step2').show();
				$('#follow_warning3').html('');
			});
			
			$('#follow_step4_back').click(function(){
				$('#follow_step4').hide();
				$('#follow_step3').show();
			});
			
			$('#follow_step5_back').click(function(){
				$('#follow_step5').hide();
				$('#follow_step4').show();
				$('#follow_warning5').html('');
			});
			
			/*SAVE DATA*/
			$('#follow_step5_btn').click(function(){
				
				var firstname = $('#firstname').val();
				var lastname = $('#lastname').val();
				var email = $('#email').val();
				var password = $('#password').val();
				var password2 = $('#password2').val();
				var country_id =  $('#country_id').val();
				var city = $('#city').val();
				var country = $("#country_id option:selected").text();
				var phone = $('#phone').val();
				var website =  $('#website').val();
				var intention = $('#intention').val();
				var role_id = $('#role_id').val();
				var role_name = $("#role_id option:selected").text();
				var industry_id = $('#industry_id').val();
				var industry_name = $("#industry_id option:selected").text();
				var default_photo = $('#default_photo').val();
				var domain = $('#domain').val();
				var user_ip = $('#user_ip').val();
				var experiences = "";
				var rating = "";
				var socials = "";
				var social_values = "";
				var pics = "";
				
				$('.files p').each(function() {
					pics = $(this).text();
				});
				
				$('.social_register').each(function() {
					var id = $(this).attr('id');
					social_id  = id.replace('contact_','');  
					social_values += $(this).val()+";;";
					socials += social_id + ",";
				});
				
				$('.ratetable .ratetr .ratetd .rateinput').each(function() {
					var id = $(this).attr('id');
					experience  = id.replace('rate_','');  
					rating += $(this).val()+";;";
					experiences += experience + ",";
				});
				
				if(role_id == ""){
					$('#follow_warning5').html('* Please select your expertise *');
					$('#city').focus();
				}else if(industry_id == "" || industry_name == "Select your industry"){
					$('#follow_warning5').html('* Please select your industry *');
					$('#industry_id').focus();
				}else{
				
					showloading();
					$("#follow_step5_back").attr('disabled', true);
					$("#follow_step5_btn").attr('disabled', true);
					$('#follow_warning5').html('');
					
					$.post("http://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){

						if (data.status == 0){
						
							$.post("http://www.contrib.com/signup/saveall",
								{
								 firstname:firstname,
								 lastname:lastname,
								 email:email,
								 password:password,
								 website:website,
								 country_id:country_id,
								 city:city,
								 country:country,
								 phone:phone,
								 website:website,
								 intention:intention,
								 role_id:role_id,
								 role_name:role_name,
								 industry_id:industry_id,
								 industry_name:industry_name,
								 experiences:experiences,
								 rating:rating,
								 socials:socials,
								 social_values:social_values,
								 pics:pics,
								 default_photo:default_photo,
								 domain:domain,
								 user_ip:user_ip
								}
								,function(data){
									if (data.status){
									
										 if (domain==""){
											 domain = "contrib.com";
										 }
									 
										$.post("http://www.manage.vnoc.com/salesforce/addlead",
											 {
												 'firstName':firstname,
												 'lastName':lastname,
												 'title':'',
												 'email':email,
												 'phone':phone,
												 'street':'',
												 'city':city,
												 'country':country,
												 'state':'',
												 'zip':'',
												 'domain':domain,
												 'role':role_name,
												 'form_type':'Contrib User'
											 }
											 ,function(data2){										  
												   _gaq.push(['_trackEvent', 'Domains', 'Signup', domain]);
												  $('#follow_step5').hide();
												  $('#autologin').html('Please check the verification email that we have just sent you. Check out our top followed sites or continue viewing your account by <a target="_blank" href="http://www.contrib.com/account/autologinforms?email='+data.email+'">clicking here</a>.');
												 $('#follow_topsites').show();
											 }
										);
									 
									}else {
										$('#follow_warning5').html('* Registration error occured. Please try again later. *'); 				 
									}
								}
							);	 
						}else{
							$('#follow_warning5').html('* Email already have an account. * <a href="http://www.contrib.com" target="_top">Please LOGIN here.</a>');
							$("#follow_step5_back").attr('disabled', false);
							$("#follow_step5_btn").attr('disabled', false);
							hideloading();
						}
					
					});
				}
			});
			
		});		
		
			function showloading(){
				var html = "<div style='text-align:center;padding-top:50px'><img src='/img/loadingAnimation.gif'></div>";
				$('#reg_loading').html(html);
			}
			function hideloading(){
				$('#reg_loading').html('');
			}
		
		</script>

</body>
</html>