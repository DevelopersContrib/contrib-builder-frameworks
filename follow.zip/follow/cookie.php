<?php include 'includes/config.php';?>
<?php include 'header.php';?>
<?php $page="cookie";?>
        <div id="content-wrap" class="container-fluid content-wrap-bg">
			<div lang="row-fluid">
				<div class="container">
					<div class="row-fluid">
						<?php include 'navbar.php';?>
					</div><!--end navbar-->
					<div class="row-fluid">
						<div class="span12 follow-desc">
							
							
							<?php 
								  $api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
								  $url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=cookie';
								  $result =  createApiCall($url, 'GET', $headers, array());
								  $data_domain = json_decode($result,true);
								  if (isset($data_domain['data']['content'])){
								   $cookie =   $data_domain['data']['content'];
								  }else {
								  	$cookie = "";
								  }

								  echo $cookie;
			                ?>
								
							
						</div>
					</div>
				</div>
			</div>
		</div><!--End of content-->
<?php include 'footer.php'?>