<?php

function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}

$api_url = "http://api2.contrib.co/request/";
$headers = array('Accept: application/json');
$domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
$error = 0;

if(stristr($domain,'~') ===FALSE) {
	$domain = $_SERVER["HTTP_HOST"];
    $domain = str_replace("http://","",$domain);
	$domain = str_replace("www.","",$domain);
	$key = md5($domain);
}else {
   $key = md5('vnoc.com');
   $d = explode('~',$domain);
   $user = str_replace('/','',$d[1]);
   
   $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
   $result =  createApiCall($url, 'GET', $headers, array());
   $data_ = json_decode($result,true);
   $domain =   $data_[0]['domain'];
}

$url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key; //main attributes
$result = createApiCall($url, 'GET', $headers, array());
$data_domain = json_decode($result,true);

if (!$data_domain['error'])
       {
            $domainid = $data_domain['data']['DomainId'];
            $domainname = $data_domain['data']['DomainName'];
            $memberid = $data_domain['data']['MemberId'];
            $title = $data_domain['data']['Title'];
            $logo = $data_domain['data']['Logo'];
            $description = $data_domain['data']['Description'];
            $account_ga = $data_domain['data']['AccountGA'];
			
			$url2 = $api_url.'getdomainattributes?domain='.$domainname.'&key='.$key; //dynamic attributes
			$result2 = createApiCall($url2, 'GET', $headers, array());
			$data_domain2 = json_decode($result2,true);
						
			if(!$data_domain2['data']['error']){
				$introduction = $data_domain2['data']['introduction'];
				$background_image = $data_domain2['data']['background_image_url'];
				$about = $data_domain2['data']['about'];
				
				$forsale = $data_domain2['data']['show_for_sale_banner'];
				$forsaletext = $data_domain2['data']['for_sale_text'];
	
			}
			$forsale = 1;
			if($forsaletext=='') $forsaletext = 'This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.';
	
      	}else {
      		$error++;
}


$url = $api_url.'getfollowedsites?key='.$key;
$result = createApiCall($url, 'GET', $headers, array());
$data_domains = json_decode($result,true);



$url = $api_url.'getdomainfollowcount?domain='.$domain.'&key='.$key;
$result = createApiCall($url, 'GET', $headers, array());
$data_follow_count = json_decode($result,true);
if (!$data_follow_count['error']){
	$follow_count = ($data_follow_count['data']['leads'] + 1 ) * 25;
}else {
	$follow_count = 1 * 25;
}


if ($background_image == ""){
	$background_image = "http://d5p5ew3nz670e.cloudfront.net/uploads/follow-bg2.jpg";
}


$url = $api_url.'getsignupformdata';
$result = createApiCall($url, 'GET', $headers, array());
$data_signup = json_decode($result,true);
if (!$data_signup['error']){
	$roles = $data_signup['roles'];
	$intentions = $data_signup['intentions'];
	$industries = $data_signup['industries'];
	$experiences = $data_signup['experiences'];
	$ages = array('Below 18 years old','18 to 24 years old','25 to 35 years old','36 to 55 years old','Above 56 years old');
}

/**
	generate robots.txt if not exist
**/
$filename = '/robots.txt';
if(!(file_exists($filename))) {
    $my_file = 'robots.txt';
	$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
	$data = '---BEGIN ROBOTS.TXT ---
User-Agent: *
Disallow:

Sitemap: http://'.$domain.'/sitemap.html
--- END ROBOTS.TXT ----';
	fwrite($handle, $data);
}



$__page = $_SERVER['PHP_SELF'];

if($__page =='/about.php')
	$title = 'About '.ucwords($domain);
else if($__page =='/terms.php')
	$title = ucwords($domain).' - Terms of Use';
else if($__page =='/privacy.php')
	$title = ucwords($domain).' - Privacy & Policy';


?>