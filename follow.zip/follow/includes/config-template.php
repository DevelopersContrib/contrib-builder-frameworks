<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
    $footer_html = "{{FOOTER_HTML}}";
    $forsale = "{{SHOW_FOR_SALE}}";
    $forsaletext = "{{FOR_SALE_TEXT}}";
    $footer_banner = "{{FOOTER_BANNER}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $affiliate_id = "{{AFF_ID}}";
    $piwik_id = '{{PIWIK_ID}}';
    $partners = {{PARTNERS}};
    $roles = {{ROLES}};
    $intentions = {{INTENTIONS}};
    $industries = {{INDUSTRIES}};
    $experiences  = {{EXPERIENCE}};
    $ages = array('Below 18 years old','18 to 24 years old','25 to 35 years old','36 to 55 years old','Above 56 years old');
?>