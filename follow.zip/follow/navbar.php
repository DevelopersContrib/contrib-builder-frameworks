<div class="navbar">
							<div class="navbar-inner">
								<a href="http://www.<?php echo $domain?>" class="brand"><?php echo ucfirst($domain)?></a>
							    <ul class="nav">
							      	<li <?php if ($page=="index") echo 'class="active"'?>>
								  		<a href="http://www.<?php echo $domain?>">Contact </a>
									</li>
							      	<li <?php if ($page=="about") echo 'class="active"'?>>
										<a href="http://www.<?php echo $domain?>/about">About</a>			
									</li>
									<li <?php if ($page=="terms") echo 'class="active"'?>>
										<a href="http://www.<?php echo $domain?>/terms">Terms </a>			
									</li>
									<li <?php if ($page=="privacy") echo 'class="active"'?>>
										<a href="http://www.<?php echo $domain?>/privacy">Privacy</a>			
									</li>
							    </ul>
						  	</div>
						</div>