<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("home");
	
	 $(document).ready(function(){
		 var domain = $('#domain').val();
			
		$('#email').click(function(){
			$(this).attr("placeholder","");
		});
		
       $('#pagesubmit').hide();
       $('#pagesubmit').removeClass('hidden');
       $('#signupform').submit(function(){
            $.ajax( { async : false } );
			 
			var email = $('#email').val();
			var user_ip = $('#user_ip').val();
			var indexof = email.indexOf("@");
			var name = email.slice(0,indexof);
			
			$('#information').html('');
		   
           if(email==''){
                alert('Email is Required.');
                $('#email').focus();
                return false;
            }else if(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test(email)==false){
                alert('Please enter a valid email address.');
                $('#email').focus();
                return false;
            }
			
           
           
				
			//VNOC CAMPAIGN RESPONSE
			 $.post("http://manage.vnoc.com/campaignresponse/addContact",
			  { domain:domain,
				contact_name:name,
				contact_email:email
			  }
			  ,function(data){ console.log(data) });
				
			//VNOC LEADS
			$.post("http://manage.vnoc.com/subscribersubmit/add",
				{
					type:'LEADS',
					domain:domain,
					name: name,
					email: email
				}
				,function(data){}
			);
			
			 /*jQuery.ajax({
                type: "post",url: "leads_post.php",
                data: {'email':email, 'domain':domain},
                success: function(html){
                    $("#emailbox").slideUp('slow');
                   $("#pagesubmit").slideDown('normal');
                   // $('#response').append(html);
                    window.location.replace("/talk.php?subscribe=1");
                }});*/
				
				
				$.post("http://domaindirectory.com/leadpost.php",
				{ domain:domain,email:email,user_ip:user_ip},function(data){
					//if(data=='success'){
						//window.location.replace("/talk.php?subscribe=1");
						$('#information').html('<p style="color: green;font-weight: bold;">You successfully joined our exclusive invite list!</p>');
					//}else{
						//$('#information').html(data);
					//}
				});
				
				$('#information').html('<p style="color: green;font-weight: bold;">You successfully joined our exclusive invite list!</p>');
			return false;

       });
	   
		
        
    });
	
</script>



<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
			<div id="content2">
        	<div id="actionbox">
			<div class="pages" id="pagestart">

				<div id="emailbox">
				<p><em> Learn more about Joining our Partner Network.</em></p>
					<div id="lead_content">
						<form id="signupform" action="">
							<input type="text" id="email" placeholder="your@email.com">
							<input type="hidden" id="refid" value="0">
												<input type="hidden" id="domain" value="<?php echo $sitename?>">
												<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
							<!-- <input type="submit"> --> 
							<input type="image" style="vertical-align: middle;" src="images/Submit-Button.png">
						</form>
					</div>
					<div id="information" style="text-align: left !important;float: left;color: red;"></div>
				</div><!-- emailbox -->
				<br />
				<div class="cleaner"></div>
				<br />
							<div id="social">
										<table style="border:0px;width:100%;">
										<tr>
									
								  <td valign='top' style='width:15%;'>
								  <script src="http://platform.linkedin.com/in.js" type="text/javascript"></script>
							<script type="IN/Share" data-url="http://www.linked.com"></script>
							</td>
										<td valign='top' style='width:85%;'>

								<!-- AddThis Button BEGIN -->
							<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
							<a class="addthis_button_preferred_1"></a>
							<a class="addthis_button_preferred_2"></a>
							<a class="addthis_button_preferred_3"></a>
							<a class="addthis_button_preferred_4"></a>
							<a class="addthis_button_compact"></a>
							<a class="addthis_counter addthis_bubble_style"></a>
							</div>
							<script type="text/javascript">var addthis_config = {"data_track_clickback":true,"data_track_addressbar":true};</script>
							<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=mypagenetwork"></script>
							<!-- AddThis Button END -->
										</td>
								  
						  
						  </tr></table>
						  </div><!-- social -->
				
				
			</div><!-- pages -->
				
			</div><!-- actionbox -->
            </div><!-- content2 -->
            <div class="cleaner"></div>
			 <div style="clear:both"></div>
				<!-- verticals -->
			<?php if (count($related_domains)>0):?>
			<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
			<div class="verb">
				<h2><i class="fa fa-globe"></i>&nbsp; Other Brands On <?php echo $vertical?> Vertical</h2>
					<div class="vertical-list">
					  <ul class="list-unstyled">
					  <?php foreach ($related_domains as $key=>$val):?>
						<li class="odd"><a href="http://<?php echo $val['domain_name']?>"><i class="fa fa-arrow-right"></i>&nbsp;<?php echo ucfirst($val['domain_name'])?></a></li>
					 <?php endforeach;?>	
					  </ul>
					  <div class="clearfix"><br></div>
					</div>
					<p></p>
					<div class="vmore"><a href="http://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" target="_blank" class="btn btn-success">View More</a></div>
			 </div>
			<?php endif;?>
        </div>
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>