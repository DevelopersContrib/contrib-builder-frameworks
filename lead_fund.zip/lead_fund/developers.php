<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("developers");
</script>
<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
        	
			<div class="container devpage">
				<div class="row">
					<div class="col-md-12">
						<h2><i class="fa fa-code"></i>&nbsp;Are you a Developer?</h2>
						<div class="devbox">
							<p class="devdesc"><i class="fa fa-rocket"></i>&nbsp;Do you have code or an app that could run this brand? Interpricing.com is connected with Contrib. </p>
							<p class="devdesc"><i class="fa fa-rocket"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run Interpricing.com? </p>
							<p class="proceedto"><a href="/contact.php" class="btn btn-success">Inquire Here</a></p>
						</div>
					</div>
				</div>
			</div>
            
        </div><!-- column_w530 -->
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>

<style>
.arrw-rela {
	display:none;
}
</style>