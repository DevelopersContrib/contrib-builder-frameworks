<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("sponsors");
</script>
<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
        	<div class="header_02">Sponsor <?=ucfirst($sitename)?></div>
			<p>
				Interested In Sponsoring, Partnering Or Supporting Vendormarketplace.Com, Join Free Today!
			</p>
			
			<iframe src="http://domaindirectory.com/servicepage/offer_form.php?domain=<?=$sitename?>" frameborder="0" width="565" height="570"></iframe>
            
        </div><!-- column_w530 -->
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>