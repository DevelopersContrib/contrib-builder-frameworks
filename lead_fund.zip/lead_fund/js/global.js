$(document).ready(function(){
	
});


function currentmenu(menu_now){
	var menuArr = new Array("home","contact","sponsors","staffing","services");
	for(var i = 0 ; i < menuArr.length ; i++){
		if(menuArr[i] == menu_now){
			var menu_to_current = menu_now+"_menu";
			$('#'+menu_to_current).attr("class","current");
		}
	}
}