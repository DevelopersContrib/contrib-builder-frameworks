<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("home");
</script>
<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
			<?php $domain_ext = array(".com",".net",".org");
					$chat_title = str_replace($domain_ext,"",$sitename); ?>
        	<div class="header_02">#<?=$chat_title?></div>
			<?php
				if(isset($_GET['subscribe']) == "1"){
					echo '<p>You successfully joined out exclusive invite list!</p><br />';
				}
			?>
			<div id="chatIFrame">
				<iframe src="http://ajchat.contrib.com/chat/<?=$chat_title?>" height="400" width="500" frameborder="0"></iframe>
            </div>
        </div><!-- column_w530 -->
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>