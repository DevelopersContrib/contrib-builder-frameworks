<?php
		function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}
		
    $api_url = "http://api3.contrib.co/request/";
    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $key = md5('vnoc.com');

    if(stristr($domain, '~') ===FALSE) {
			$domain = $_SERVER["HTTP_HOST"];
		    $domain = str_replace("http://","",$domain);
			$domain = str_replace("www.","",$domain);
			$key = md5($domain);
		}else {
		    $key = md5('vnoc.com');
            $d = explode('~',$domain);
            $user = str_replace('/','',$d[1]);
            $host = $_SERVER["HTTP_HOST"];
		    $host = str_replace("http://","",$host);
		    $host = str_replace("www.","",$host);
		    $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key.'&host='.$host;
            $result =  createApiCall($url, 'GET', $headers, array());
            $data_domain = json_decode($result,true);
            $error = 0;
            $domain =   $data_domain['data']['domain'];
		}
		
		$sitename = $domain;
		$data_domain = NULL;
        while ($data_domain == NULL){
           $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
           $result = createApiCall($url, 'GET', $headers, array());
           $data_domain = json_decode($result,true);
        }
        
		$error = 0;

		if ($data_domain['success']){
            $domainid = $data_domain['data']['DomainId'];
            $domainname = $data_domain['data']['DomainName'];
            $memberid = $data_domain['data']['MemberId'];
            $title = $data_domain['data']['Title'];
            $logo_url = $data_domain['data']['Logo'];
            $description = $data_domain['data']['Description'];
            $account_ga = $data_domain['data']['AccountGA'];
			
		
		    $url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
            $result2 = createApiCall($url2, 'GET', $headers, array());
       	    $data_domain2 = json_decode($result2,true);
    	
			
       	       if($data_domain2['success']){
				$facebook_page = $data_domain2['data']['fb_page'];
				$twitter_page = $data_domain2['data']['twitter_page'];
				$meta_description = $data_domain2['data']['meta_description'];
				$meta_keywords = $data_domain2['data']['meta_keywords'];
				
				$forsale = $data_domain2['data']['show_for_sale_banner'];
				$forsaletext = $data_domain2['data']['for_sale_text'];

				
				if($forsaletext=='') $forsaletext = 'This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.';
			}
				
				
				$url3 = $api_url.'getfeaturedDomains?domainid='.$domainid.'&key='.$key.'&limit=10'; // limit = 10
				$result3 = createApiCall($url3, 'GET', $headers, array());
       	        $data_rand_domains = json_decode($result3,true);
				
				if($data_rand_domains['success']){
					$rand_domain = array();
					foreach($data_rand_domains['data'] as $data){						
						$rand_domain[] = array(
										"DomainName"=>ucwords($data['DomainName']),
										"Description"=>$data['Description'],
										"Logo"=>$data['Logo']
										);
					}
					//var_dump($rand_domain);
				}
				
		  $url3 = $api_url.'GetPiwikId?domain='.$domain.'&key='.$key;
      $result3 = createApiCall($url3, 'GET', $headers, array());
    	$data_domain3 = json_decode($result3,true);
      $piwik_id = $data_domain3['data']['idsite'];
			
		}else {
      		$error++;
		}
		
  //get monetize ads from vnoc
    $url = $api_url.'getbannercode?d='.$domain.'&p=footer';
    $result = createApiCall($url, 'GET', $headers, array());
    $data_ads = json_decode($result,true);
    $footer_banner = html_entity_decode(base64_decode($data_ads['data']['content']));
	
	//get related domains
    $url = $api_url.'getrelateddomains?domain='.$domain.'&limit=15';
    $result = createApiCall($url, 'GET', $headers, array());
	$data_domains = json_decode($result,true);
	if ($data_domains['success']){
		$related_domains = $data_domains['data'];
	}
	 
	//get fund campaigns
	$url = $api_url.'getfundcampaigns';
	$result = createApiCall($url, 'GET', $headers, array()); 
	$items = json_decode($result,true);
	if ($items['success']){
		$campaigns = $items['data'];
	}
?>