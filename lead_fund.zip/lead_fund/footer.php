<div id="templatemo_footer_wrapper">
    <?php if ($footer_banner !=""):?>
    <br>
	<div style="width:780px;margin:0px auto;">
	   <?php echo $footer_banner?>
	</div>
	<?php endif?>
	<div id="templatemo_footer">
        <div class="margin_bottom_20"></div>
        Copyright &copy; <?=date('Y');?> <a href="http://globalventures.com">GlobalVentures</a> | <a href="about.php"> About </a><!--| <a href="talk.php">Talk</a-->
		<?if($facebook_page!=''){?><a href="<?=$facebook_page?>" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/sheina/social_icons/icon-social-facebook.png" style="margin: 0px 5px 0 10px;"/></a><? } ?>
		<?if($twitter_page!=''){?><a href="<?=$twitter_page?>" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/sheina/social_icons/icon-social-twitter.png"  style="margin: 0px 5px 0 0;"/></a><? } ?>
        <div class="cleaner"></div>
    </div> <!-- end of footer -->
    <!--  Free CSS Templates by TemplateMo.com  
	http://all-free-download.com/templates/templates_preview.php?url=http://images.all-free-download.com/free-website-templates-preview/simple_gray_621/
	-->
</div> <!-- end of footer -->
</body>
</html>