<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("home");
</script>
<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
        	<div class="header_02">About <?=ucfirst($sitename)?></div>
			
			<p>Vendor Marketplace is a venture of <a href="http://ecorp.com">eCorp.com Inc.</a></p>
			<br />
			<p><?=$description?></p>
			<br />
			<p>
				<a href="http://ecorp.com">eCorp</a> is the worlds largest virtual domain development incubator on the planet.
				Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms.
				We build and manage world class web-based, domain centric operating businesses for clients and internal ventures. 
				Learn more about <a href="http://ecorp.com/sponsor.php">our ventures, staffing opportunites and partnership models.</a>
			</p>
            
        </div><!-- column_w530 -->
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>