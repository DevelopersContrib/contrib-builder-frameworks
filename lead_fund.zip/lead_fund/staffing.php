<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("staffing");
</script>
<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
        	<div class="header_02">Our Staffing Needs At <?=ucfirst($sitename)?></div>
			<p>
				We are looking for the best of the best, Full-Time, Part-Time, Moonlighting, Contractual and Freelance.
			</p>
			
			  <div class="content_section_01">
				We consult and manage over 100,000 domain name ventures and are always seeking Strategic Partnerships, Applications, Domains, Engineers, Developers, Specialist and just cool smart people around the Globe.
				Learn more about openings and opportunities with our partner companies and send us your resume or examples to accelerate the process.
			</div>
			<br />
			<p class="em_text">
				Learn more about openings and opportunities with our partner companies.
			</p>
			
			<iframe src="http://domaindirectory.com/servicepage/staffing_form.php?domain=<?=$sitename?>" frameborder="0" width="565" height="570"></iframe>
            
        </div><!-- column_w530 -->
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>