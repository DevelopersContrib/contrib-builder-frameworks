<div id="templatemo_header_wrapper">
<!--  Free Web Templates by TemplateMo.com  -->
  <div id="templatemo_header">
    
   	<div id="site_logo"><img class="site_logo" src="<?=$logo_url?>"></div>
        
		<div id="templatemo_menu">
      		<div id="templatemo_menu_left"></div>
            <ul>
                  <li><a href="http://<?=$sitename?>" id="home_menu">Home</a></li>
                  <li><a href="contact.php" id="contact_menu">Contact</a></li>
                  <li><a href="sponsors.php" id="sponsors_menu">Partners</a></li>
                  <li><a href="staffing.php" id="staffing_menu">Staffing</a></li>
                  <li><a href="services.php" id="services_menu">Services</a></li>
                  <li><a href="developers.php">Developers</a></li>
				  <li><a href="fund.php" class="last">Fund</a></li>
            </ul>    	
		</div> <!-- end of menu -->
    
    </div>  <!-- end of header -->
</div> <!-- end of header wrapper -->

<div class="dev-wanted rotate">
<a href="http://www.developers.contrib.com" target="_blank">Developers Wanted<i>!</a></i>
</div>
