<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("services");
</script>
<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
        	<div class="header_02"><?=ucfirst($sitename)?> Services</div>
			<p>
				We're in the business of domain life cycle development, management and monetization of domain names.
				For over 15 years we have been making domains a valuable technology asset that leverages the latest in real-time,
				interactive web-based communications and technology to rapidly build business within descriptive domain names.
			</p>
			<ul class="content_list_01">
			<li>Venture Creation and Financing</li>
			<li>Applications Development and Management</li>
			<li>WebManagement</li>
			<li>Business Management</li>
			<li>Marketing Services</li>
			<li>Product/Service Branding</li>
			<li>E-Commerce</li>
			<li>Design Services</li> 
			<li>Consultation</li>
			<li>Domain Acquisition and Divestments</li>
			</ul>
			
			<p>
				There is absolutely no obligation when filling out the form, it is for informational exchange purposes only.
				So please take a few moments to fill out the form and we will get back with you within 2 business days.
			</p>
			
			<iframe src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?=$sitename?>" frameborder="0" width="370" height="535"></iframe>
            
        </div><!-- column_w530 -->
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>