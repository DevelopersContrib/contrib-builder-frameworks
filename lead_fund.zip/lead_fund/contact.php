<?php include('header.php');?>

<?php include('menu.php'); ?>
<script type="text/javascript">
	currentmenu("contact");
</script>
<div id="templatemo_content_wrapper">
	
	<div id="templatemo_content">
    
    	<div id="column_w530">
        	<div class="header_02">Contact <?=ucfirst($sitename)?></div>
			
			<iframe src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?=$sitename?>" frameborder="0" width="370" height="535"></iframe>
            
        </div><!-- column_w530 -->
        
        <?php include('checkdomains.php'); ?>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<?php include('footer.php');?>