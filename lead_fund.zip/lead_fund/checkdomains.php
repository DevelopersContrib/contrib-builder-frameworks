<div id="column_w300">
        
		<div class="header_03" style="text-transform: uppercase;font-family: sans-serif;font-weight: bold;">Other domains to check</div>
		<div style="padding:10px">
		<? $rand_cnt =0 ;?>
		<? foreach($rand_domain as $data){ ?>
			<!--div class="column_w300_section_01"-->
            	<!--div class="news_image_wrapper <?=($rand_cnt%2)?'even_color':''?>"-->
                	<a href="http://<?=$data['DomainName']?>" target="_blank" title="<?=$data['DomainName']?>" class="rand_domains"><img src="<?=$data['Logo']?>" alt="image" style="height: 30px;margin:3px;background: white;padding: 4px !important;width: 44% !important;"/></a>
                <!--/div-->
                
                <!--div class="news_content" >
                	<div class="news_date">OCT 29, 2048</div>
                    <div class="header_04"><a href="#"><?=$data['DomainName']?></a></div>
                    <p><?=$data['Description']?></p>
				</div-->
                                
                <!--div class="cleaner"></div-->
            <!--/div-->
			<? $rand_cnt++;?>
		<? } ?>
		</div>
		<div class="cleaner"></div>
		
</div>
<style>
a.rand_domains img:hover{box-shadow: 0px 1px 10px black;}
</style>