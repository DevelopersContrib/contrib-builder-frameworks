<?php 
if (isset($_REQUEST['category'])){
	
	 $temp_url = $api_consultants.'getcategoryinfo?api_key='.$api_key.'&field=slug&value='.$_REQUEST['category'];
														$result_temp = createApiCall($temp_url, 'GET', $headers, array());
														$tcat = json_decode($result_temp,true);
	
	
	
	if (sizeof ($tcat) > 0){
	   foreach ($tcat as $cat){
	               $cat_name = $cat['name'];
	               $cat_id = $cat['category_id'];
	   }
	}
}else {
	$cat_name = "";
}
?>

<div class="row-fluid rw-pd">
				<div class="span5">
					<span class="bws-tit">&nbsp;Browse <?=$cat_name?> Tools</span>
				</div>
				<form method="Post" action="<?=$sitename?>tools" id="orderform">
				<p align="right">
					 <select name="order" id="order">
					  <option value="">Show by</option>
					  <option value="latest">Latest</option>
					  <option value="popular">Popular</option>
					</select>
				
				</p>
				<input type="hidden" name="mode" value="">
				<input type="hidden" name="searchkey" value="">
				<input type="hidden" name="category_id" value="">
				
			</form>
							</div>
			
			<div class="main-search">
    <div class="main-search-inner">
    <div>
   <form action="<?=$sitename?>tools" id="searchform" method="POST">
		<fieldset>
		<div class="search-left">
			<span>Search Tools</span>
			<input class=" " name="searchkey" type="text" id="searchkey" value=""  />
		</div>
		<div class="search-mid">
			<span>Select Category</span>
			<div class="search-mid-select">                       
      <?
		$temp_url = $api_consultants.'getcategories?api_key='.$api_key;
			$result_temp = createApiCall($temp_url, 'GET', $headers, array());
			$categories = json_decode($result_temp,true);
			//var_dump($categories);
		//$categories = json_decode(@file_get_contents($main_site.'api/getcategories?api_key='.$api_key));
	 ?>
				<select name="category" id="category_id">
					<option value=""></option>
			  <?
          if(sizeof($categories) > 0):
                  foreach ($categories as $row):
         ?>							    			 
                    <option value="<?=$row['slug']?>"><?=$row['name']?></option>
					    					       
                  <?endforeach;?>             
           <?endif;?>                    
					    									</select>
		   </div>
		</div>
		<input type="hidden" name="mode" value="search">
		<input name="" type="Submit" class="search-btn" id="searchbtn" value=""/>
		</fieldset>
  </form>
  </div>
  </div>
  </div><!--main-search -->