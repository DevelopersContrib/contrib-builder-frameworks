<div id="sub-head-wrap">
<div id="sub-head-inner">
	<a href="<?=$sitename?>" id="logo">
	<? if($logo!=''){ ?>
		<img src="<?=$logo?>">
	<?}else{?>
		<div style="font-size: 30px;padding-top: 30px;display: inline;float: left;font-weight: 600;"><?=ucwords($domain)?></div>
	<?}?>
	</a>
    <h1><?=$introduction?>
<!-- a href="http://iconsultants.com/signup" class="button"> Claim Your Consultant Profile </a -->
	<p style="margin-top:10px;">
	<a href="<?=$main_site?>signup/?domain=<?=$domain?>"><img src="http://d2qcctj8epnr7y.cloudfront.net/uploads/btn-signup-home.jpg" alt="Claim Your Consultant Profile" ></a>
&nbsp;<a href="<?=$main_site?>about/why_join_consultants"><img src="http://d2qcctj8epnr7y.cloudfront.net/uploads/btn-learn-home.jpg" /></a>
	</p>
</h1>
</div><!--sub-head-inner -->
</div><!--sub-head-wrap -->