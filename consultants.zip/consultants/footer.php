<?php global $footer_html?>
<div id="footer-wrap">	
	<div id="footer-inner">
		<div class="foot-col-1">
			<span><a href="index.php"><?=$domain?></a></span>
			<p><?=$description?></p>
			<!-- span>TEL. 780.999.2566<br>FAX. 780.999.3333</span -->
		</div><!--foot-col-1 -->
		<div class="foot-col-2">
		<span>GET STARTED </span>
			<ul class="info">
				<li><a href="/services">Services</a></li>
				<li><a href="/partner">Partnership</a></li>
			</ul>
		</div><!--foot-col-2 -->
		<div class="foot-col-3">
		<span>COMPANY </span>
			<ul class="info">
				<li><a href="<?=str_replace('http:','https:',$sitename)?>about">About</a></li>
				<li><a href="<?=str_replace('http:','https:',$sitename)?>terms">Terms and Condition</a></li>
				<li><a href="<?=str_replace('http:','https:',$sitename)?>privacy">Privacy Policy</a></li>
				<li><a href="<?=str_replace('http:','https:',$sitename)?>cookie.php">Cookie Policy</a></li>
				<li><a href="https://www.domaindirectory.com/policypage/unsubscribe?domain=<?=$domain?>">Unsubscribe</a></li>
				<li><a href="<?=str_replace('http:','https:',$sitename)?>contact">Contact Us</a></li>
				<li><a href="<?=str_replace('http:','https:',$sitename)?>sitemap">Sitemap</a></li>
			</ul>
		</div><!--foot-col-3 -->
		<div class="foot-col-4">
		<span>PARTNERS</span>
			<?if($footer_html != ""):?>
				<?php
					$footer_html = str_replace('http:','https:',base64_decode($footer_html));
					$footer_html = str_replace('https://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png','https://cdn.vnoc.com/banner/codero-logo-HostingOnDemand.png',$footer_html);
					echo $footer_html;
				?>
				<?php else:?>
				<a href="https://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="https://cdn.vnoc.com/banner/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
			<?endif;?>
		<div style="clear:both"></div>
		<span>FOLLOW US </span>
			<ul class="social-links">
				<li><a href="https://www.facebook.com/pages/Consultantscom/226640447480160?ref=hl" class="soc-fb"></a></li>
				<li><a href="https://www.linkedin.com/company/consultants" class="soc-ln"></a></li>
				<li><a href="https://twitter.com/consultantscom" class="soc-tw"></a></li>
				<li><a href="https://plus.google.com/115849092850531808245/posts" class="soc-gp"></a></li>
			</ul>
		</div><!--foot-col-4 -->
	</div><!--footer-inner -->
	
</div><!--footer-wrap -->
<div id="footer-wrap-3">
	<div class="footer-lower">
		<div class="foot-col-l1">
			<span><?=date("Y")." ".ucfirst($domain)?>. All Rights Reserved.</span>
		</div>
		<div class="foot-col-l2">
			<ul>
				<li><a href="<?=$sitename?>about">About</a></li>
				<li><a href="/terms">Terms and Condition</a></li>
				<li><a href="/privacy">Privacy Policy</a></li>
				<li><a href="/cookie.php">Cookie Policy</a></li>
				<li><a href="https://www.domaindirectory.com/policypage/unsubscribe?domain=<?=$domain?>">Unsubscribe</a></li>
				<li><a href="/contact">Contact Us</a></li>
			</ul>
		</div>
	</div>
</div>
</div><!--main-wrap -->    
</body>
</html>
