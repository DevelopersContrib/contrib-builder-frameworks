<div id="footer-wrap">
	
<div id="footer-inner">
	<div class="foot-col-1">
		<a href="#" class="foot-logo">Consultant</a>
        <span>2700 N. Federal Highway 510 <br>Boynton Beach, FL 433435<br>33435</span>
        <!-- span>TEL. 780.999.2566<br>FAX. 780.999.3333</span -->
    </div><!--foot-col-1 -->
    <div class="foot-col-2">
	&nbsp;
	<!-- span>ABOUT US </span>
     	<p>Consultants.com is in the alpha stage, and we are working hard to give you tools that you need to get your consulting business off the ground. </p>

    	<p><a href="http://ecorp.com">eCorp</a> is the worlds largest virtual domain development incubator on the planet. Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms. We build and manage world class web-based, domain centric operating businesses for clients and internal ventures. Learn more about our <a href="http://ecorp.com/sponsor.php">ventures, staffing opportunites and partnership models.</a></p>
		<p>Consultants.com is a proud project of <a href="http://globalventures.com">Global Ventures, LLC.</a></p -->
		<ul class="info">
			<li><a href="<?=$sitename?>about">About</a></li>
			<li><a href="/terms">Terms and Condition</a></li>
			<li><a href="/privacy">Privacy Policy</a></li>
			<li><a href="/services">Services</a></li>
			<li><a href="/partner">Partnership</a></li>
			<li><a href="/contact">Contact Us</a></li>
		</ul>
	</div><!--foot-col-2 -->
    <div class="foot-col-3">
    <span>FOLLOW US </span>
    	<ul class="social-links">
        	<li><a href="http://www.facebook.com/pages/Consultantscom/226640447480160?ref=hl" class="soc-fb"></a></li>
            <li><a href="http://www.linkedin.com/company/consultants" class="soc-ln"></a></li>
            <li><a href="https://twitter.com/consultantscom" class="soc-tw"></a></li>
            <li><a href="https://plus.google.com/115849092850531808245/posts" class="soc-gp"></a></li>
        </ul>
    </div><!--foot-col-3 -->
</div><!--footer-inner -->
</div><!--footer-wrap -->
  
</div><!--main-wrap -->    


 

</body>
</html>