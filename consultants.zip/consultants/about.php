<?include('header.php')?>
<script>
$(document).ready(function(){
  	activateHeaderMenuPublic("about_tab");
});
</script>
<?include('header-menu.php')?> 
<?include('header-sub.php')?>
<div id="container-wrap">
     <div id="container-inner">
          <div id="inner-body">
              <div class="sign-up-box">
	<h2><span>About <?=ucfirst($domain)?></span></h2>
    <p>
		<?=ucfirst($domain)?> is in the alpha stage, and we are working hard to give you tools that you need to get your consulting business off the ground.
	<br /><br /><br />
eCorp is the worlds largest virtual domain development incubator on the planet. 
Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms.
We build and manage world class web-based, domain centric operating businesses for clients and internal ventures.
Learn more about our ventures, staffing opportunites and partnership models.
	</p>
	
	<p><?=ucfirst($domain)?> is a proud project of <a href="http://globalventures.com">Global Ventures, LLC.</a></p>
</div><!--sign-up-box -->
    
<div class="sign-up-box-linkedin">
	<h2><span>Connect to Linkedin</span></h2>
    
   <div class="sign-linkedin-button">
    	<a href="<?=$main_site?>login/linkedin" class="sl-btn"></a>
        <!-- span>Lorem ipsum dolores magnes shaaknes<br> kanin panis</span -->
    </div>
    
</div><!--sign-up-box-linkedin -->


	<div class="clear"></div>  
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('footer.php')?>