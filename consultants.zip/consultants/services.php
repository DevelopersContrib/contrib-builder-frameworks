<?include('header.php')?>
<?include('header-menu.php')?> 
<?include('header-sub.php')?>
<div id="container-wrap">
     <div id="container-inner">
          <div id="inner-body">
          <div style="text-align:center;">
		  
<div class="sign-up-box">
	<h2><span>Services - <?=$domain?></span></h2>
	<p>
Consultants.com offers customized consultant systems and solutions for enterprise, associations, organizations and networks.
 We use the latest in web-based platforms, Mobile and application technology to custom build and integrate easy to use, effective and valuable tools for customers. From the 10,000 attorney network to the 10 realtors, we offer a full solution set to help build customer value around their most valuable asset.. their customers.


<a href="/contact">Contact us</a> today to get a free consultation.</p>

</div><!--sign-up-box -->

 <div class="clear"></div>  
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('footer.php')?>