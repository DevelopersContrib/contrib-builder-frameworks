<div class="button-front">
    	  <a href="<?=$sitename?>consultants">Free Consultant Search - All Industries</a>
        <a href="<?=$main_site?>ask">Ask a Consultant a Question</a>
        <a href="<?=$main_site?>signup" class="no-margin-right">Claim Your Free Consultant Apps</a>
</div> 