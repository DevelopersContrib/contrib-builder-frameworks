<?//$industries = json_decode(file_get_contents($main_site.'api/getindustries?api_key='.$api_key.'&ids='.$ids));?>
<div class="front-block-left">
        <div class="front-block-inner">
            <div class="front-block-inner-head"><h3><span>BY</span> INDUSTRY</h3></div>
            <div class="front-block-inner-body">
            <?php 
            
            	if(sizeof($industries) > 0):
				$i=0;
				//$slice = floor($industries->num_rows)/2;
				
	        ?>	
				<div class="front-block-inner-col-1">
            	<ul class="list-arrow">
            	<?php foreach ($industries as $row):
		    	?>
                	<li><a href="skills/<?php echo $row['slug']?>"><?php echo $row['name']?></a></li>
                	<?php if ($i == 8):?>
                </ul>
				</div>
				<div class="front-block-inner-col-2">
					<ul class="list-arrow">
					<?php endif?>
						<?php 
						$i++;
						endforeach;?>
					</ul>
				</div>
				
                <?php endif;?>
            </div>
 </div>
</div><!--front-block-left -->