<?include('header.php')?>
<?include('header-menu.php')?> 
<?include('header-sub.php')?>
<div id="container-wrap">
	<?php if ($left_banner!=""):?>
	<div style="position:absolute; left: 0;">
	  <?php echo $left_banner?>
	</div><!-- banner --->
	<?php endif;?>
     <div id="container-inner">
          <div id="inner-body">
              <?include('index-button.php')?>   
              <?include('index-search.php')?>   
               <div class="front-block">
                   <?include('index-industry.php')?>       	
                   <?include('index-domain.php')?>
              </div><!--front-block -->
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('subscribe.php')?>
<?include('footer.php')?>