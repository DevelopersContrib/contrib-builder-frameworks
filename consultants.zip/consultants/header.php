<?include('config.php')?>
<!DOCTYPE html>
<html>
<head>
<title><?=$title?></title>
<meta name="title" content ="<?=$title?>" >
<meta name="description" content ="<?=$description?>" >
<meta name="keywords" content ="<?=$keywords?>" >
<meta name="author" content="<?=$sitename?>">
<meta name="robots" content="noindex" />
<link href="<?=$sitename?>css/custom.css" rel="stylesheet" media="screen">
<link href="<?=$sitename?>css/public.css" rel="stylesheet" media="screen">
<link href='http://fonts.googleapis.com/css?family=Quattrocento+Sans:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="<?=$sitename?>css/owl.carousel.css">
<script type="text/javascript" src="<?=$sitename?>js/jquery-1.7.min.js"></script>
<script type="text/javascript" src="<?=$sitename?>js/public_general.js" ></script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?=$account_ga?>']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$piwik_id;?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id;?>" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->

</head>
<body>
<div id="main-wrap">
