$(document).ready(function(){

});

function activateHeaderMenuPublic(activemenu){
	var menu_list = new Array('about_tab','tools_tab','consultants_tab');
	for(var i = 0; i < menu_list.length ; i++){
		if(menu_list[i] == activemenu){
			$("#"+menu_list[i]).attr("class","activepublicmenu");
		}else{
			$("#"+menu_list[i]).removeClass();
		}
	}
}