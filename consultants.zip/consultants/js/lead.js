$(function(){
	$('.fancybox').fancybox({
		//autoSize:false,
		width:750,
		minWidth:750,
		modal:true,
		padding : 0
	});
	setTimeout(function(){
		$(".fancybox").eq(0).trigger('click');
	},5000);
	
	$('#leadform').submit(function(){
		submitLead();
		return false;
	});
	
	$('#submitLead').click(function(){
		submitLead();
	});
	
	$('#closep').click(function(){
		$.fancybox.close();
	});
	

	
	$('#showSubscribe').click(function(){
		$('#frm-subscribe').show();
		$('#frm-login').hide();
		$('#warning').remove();
	});
	
	
	$('.fancybox2').fancybox({
		//autoSize:false,
		width:750,
		minWidth:750,
		padding : 0
	});
	

	

});

function submitLead(){	 
	var email = $('#email').val();
	var secret = $('#secret').val();
	var user_ip = $('#user_ip').val();
	var indexof = email.indexOf("@");
	var name = email.slice(0,indexof);
	var domain = $('#domain').val();
	$('#warning').remove();
			
	if(email==''){
		$('#leadcontent').append('<div class="warningprompt text-center" id="warning">* Email is required *</div>');
		$('#email').focus();
		return false;
	}else if(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test(email)==false){
		$('#leadcontent').append('<div class="warningprompt text-center" id="warning">* Please enter a valid email address *</div>');
		$('#email').focus();
		return false;
	}else if(secret != '' && secret != 'undefined' && secret != null){
		$("#leadform").hide();	
		$('#leadcontent').prepend('<div class="" style="text-align:center;margin:20px 0 35px 0;color:white;min-height:20px;font-size:18px;" id="loading">Processing . . . Please wait . . .</div>');
		setTimeout(function(){
			 $('#loading').hide(); 
			 	$('#leadcontent').append('<div class=" text-center" id="response">Thanks for showing your interest on '+domain+'!<br><br>Your email will never be sold and kept strictly for notification when we launch!<br><br> Please check your e-mail for further info. Thank You! <br><br>'+
				'<form target="_blank" action="http://www.contrib.com/signup/follow/'+domain+'" method="post">'+
				'<input type="hidden" id="pemail" name="email" value="'+email+'"/>'+
				'<button class="btn btn-warning">Continue to Follow '+domain+' Brand</button></form><br>'+
				'<div style="padding:10px;width:50%;opacity:.9;margin:0px auto;background:#fafafa;border-radius:8px;color:#000 !important;"><p>To share with your friends, click &ldquo;Share&rdquo; and &ldquo;Tweet&rdquo;:</p>'+
				'<a href="http://twitter.com/share" class="twitter-share-button" data-count="none">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>'+
				'<iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2F'+domain+'%2F&amp;layout=standard&amp;show_faces=true&amp;width=450&amp;action=like&amp;font&amp;colorscheme=light&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>'+
				'<div id="sharebuttons"><span id="facebook" style="margin:0 0 10px 60px"></span><span id="twitter"></span></div></div><div class="clearfix"></div>'+
				'<p><small>Your email will never be sold and kept strictly for notification when we launch!</small></p></div>');
				$('#addrss').show();							
				$('#closep').show();
		  },2000);

		return false;
	}else{	
		$("#leadform").hide();	
		$('#leadcontent').prepend('<div class="" style="text-align:center;margin:20px 0 35px 0;color:white;min-height:20px;font-size:18px;" id="loading">Processing . . . Please wait . . .</div>');
		
			$.post("http://www.contrib.com/forms/saveleads",
				{   domain:domain,
					email:email,
					secret:secret,
					user_ip:user_ip
				},function(res){
					console.log(res);							
					$("#loading").hide();		
					if(res.success=='false'){
						$('#leadcontent').append('<div class=" text-center" id="response">Something went wrong. Sorry for the inconvenience. Please reload the page or try again later.</div>');
					}else if(res.success=='success'){
						$('#leadcontent').append('<div class=" text-center" id="response">Thanks for showing your interest on '+domain+'!<br><br>Your email will never be sold and kept strictly for notification when we launch!<br><br> Please check your e-mail for further info. Thank You! <br><br>'+
						'<form target="_blank" action="http://www.contrib.com/signup/follow/'+domain+'" method="post">'+
						'<input type="hidden" id="pemail" name="email" value="'+email+'"/>'+
						'<button class="btn btn-warning">Continue to Follow '+domain+' Brand</button></form><br>'+
						'<div style="padding:10px;width:50%;opacity:.9;margin:0px auto;background:#fafafa;border-radius:8px;color:#000 !important;"><p>To share with your friends, click &ldquo;Share&rdquo; and &ldquo;Tweet&rdquo;:</p>'+
						'<a href="http://twitter.com/share" class="twitter-share-button" data-count="none">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>'+
						'<iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2F'+domain+'%2F&amp;layout=standard&amp;show_faces=true&amp;width=450&amp;action=like&amp;font&amp;colorscheme=light&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>'+
						'<div id="sharebuttons"><span id="facebook" style="margin:0 0 10px 60px"></span><span id="twitter"></span></div></div><div class="clearfix"></div>'+
						'<p><small>Your email will never be sold and kept strictly for notification when we launch!</small></p></div>');
						$('#addrss').show();							
						$('#closep').show();
					}else{
						$('#leadcontent').append('<div class=" text-center" id="response">'+res.success+'<br><br>Visit our <a href="http://www.contrib.com/brand/details/'+domain+'" target="_blank">'+domain.toUpperCase()+' brand page</a> for further details. <br><br>Thank you! <br><br></div>');
						$('#frm-subscribe').hide();
						$("#leadform").show();
					}
				}
			);
			
			//$.post("/post/leads.php",{email:email},function(){$('#addrss').show();});
			
				// SALESFORCE LEAD
				$.post("http://www.manage.vnoc.com/salesforce/addlead",
				{
					 'firstName':name,
					 'lastName':name,
					 'title':'',
					 'email':email,
					 'phone':'',
					 'street':'',
					 'city':'',
					 'country':'',
					 'state':'',
					 'zip':'',
					 'domain':domain,
					 'form_type':'Contrib Lead Version 2'
					 
				},function(data2){
						//console.log(data2);
					}
				);
				
			
			return false;
	}		
	return false;

}