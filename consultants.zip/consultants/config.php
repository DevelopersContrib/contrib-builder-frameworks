<?php
$api_url = "http://api3.contrib.co/request/";
$api_url1 = "http://api1.contrib.co/request/";
$monetize_url = "http://manage.vnoc.com/monetize/getcode";
$api_consultants = 'http://consultants.com/api/';
$headers = array('Accept: application/json');

function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}


$domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www

if(stristr($domain, '~') ===FALSE) {
	$domain = $_SERVER["HTTP_HOST"];
    $domain = str_replace("http://","",$domain);
	$domain = str_replace("www.","",$domain);
	$key = md5($domain);
}else {
    $key = md5('vnoc.com');
    $d = explode('~',$domain);
    $user = str_replace('/','',$d[1]);
    $host = $_SERVER["HTTP_HOST"];
	$host = str_replace("http://","",$host);
	$host = str_replace("www.","",$host);
	$url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key.'&host='.$host;
    $result =  createApiCall($url, 'GET', $headers, array());
    $data_domain = json_decode($result,true);
    $error = 0;
    $domain =   $data_domain['data']['domain'];
}

$title = "Find Top Rated Consultants. Expand your consultancy with our top tools, widgets and free profile: Consultants.com";
$description = "Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy.";
$main_site = "http://consultants.com/";
$sitename = "http://{$domain}/";
$introduction = "Consultants Choose Us to Organize Their Tools, Create Web Apps For Their Business and Expand Your Consultant Presence Online for Free.";
$logo = $main_site."img/logo-consultants4_310x40.png";
$ids = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19";
$api_key = '93724d7f979a8166';
$account_ga = "UA-29789463-1";


 $data_domain = NULL;
        while ($data_domain == NULL){
           $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
           $result = createApiCall($url, 'GET', $headers, array());
           $data_domain = json_decode($result,true);
        }
$error = 0;
if ($data_domain['success']){
       
    $domainid = $data_domain['data']['DomainId'];
	$domainname = $data_domain['data']['DomainName'];
	$memberid = $data_domain['data']['MemberId'];
	$title = $data_domain['data']['Title'];
	$logo = $data_domain['data']['Logo'];
	$description = $data_domain['data']['Description'];
	$account_ga = $data_domain['data']['AccountGA'];
	
	$description = stripslashes(str_replace('\n','<br>',$description));
	
			$url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
            $result2 = createApiCall($url2, 'GET', $headers, array());
            $data_domain2 = json_decode($result2,true);
			
			if(!$data_domain2[0]['error']){
				$introduction = $data_domain2['data']['introduction'];
				$ids =  $data_domain2['data']['industry'];
				
				if($introduction=='')
				$introduction = "Consultants Choose Us to Organize Their Tools, Create Web Apps For Their Business and Expand Your Consultant Presence Online for Free.";
				if($ids=='')
				$ids = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19";
			}else{
				$introduction = "Consultants Choose Us to Organize Their Tools, Create Web Apps For Their Business and Expand Your Consultant Presence Online for Free.";
				$ids = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19";
			}
			
			
			$industries = NULL;
			while ($industries == NULL){
				$c_url = $api_consultants.'getindustries?api_key='.$api_key.'&ids='.$ids;
				$result3 = createApiCall($c_url, 'GET', $headers, array());
				$industries =json_decode($result3,true);
			}
			
		
			
      	}else {
      		$error++;
		}
/*
//get monetize ads from vnoc
$url = $monetize_url.'?d='.$domain.'&p=cleft';
 $result = createApiCall($url, 'GET', $headers, array());
$data_ads = json_decode($result,true);
$left_banner = html_entity_decode(base64_decode($data_ads[0]['code']));
//$left_banner = "";*/

//get monetize ads from vnoc
    $url4 = $api_url1.'getbannercode?d='.$domain.'&p=cleft';
    $result4 = createApiCall($url4, 'GET', $headers, array());
    $data_ads4 = json_decode($result4,true);
    $left_banner = html_entity_decode(base64_decode($data_ads4['data']['content']));


//get number of domain leads for counter
$url = $api_url.'getdomainleadscount?domain='.$domain.'&key='.$key;
$result =  createApiCall($url, 'GET', $headers, array());
//$data_ads = json_decode($result,true);
$data_follow_count = json_decode($result,true);
if ($data_follow_count['success'])
       {
       	$follow_count = ($data_follow_count['data']['leads'] + 1 ) * 25;
       }else {
       	$follow_count = 1 * 25;
       }

	   
$url3 = $api_url.'GetPiwikId?domain='.$domain.'&key='.$key;
$result3 = createApiCall($url3, 'GET', $headers, array());
$data_domain3 = json_decode($result3,true);
$piwik_id = $data_domain3['data']['idsite'];
?>                                                                                 