<div class="front-block-right">
           <style type="text/css">
	.industries a{background:#138496;color:#fff;padding:5px;margin:2px;float:left;border-radius:5px;}	
</style>

<div class="front-block-inner">
             <div class="front-block-inner-head"><h3><span>FEATURED</span> CONSULTANT SITES</h3></div>
            <div class="front-block-inner-body">
            
              			<div class="industries">	
										<a href="https://projectconsultant.net">PROJECTCONSULTANT.NET</a>
											<a href="https://CtConsultant.com">CTCONSULTANT.COM</a>
											<a href="https://insuranceconsultant.com">INSURANCECONSULTANT.COM</a>
											<a href="https://SohoConsultants.com">SOHOCONSULTANTS.COM</a>
											<a href="https://enviroconsultant.com">ENVIROCONSULTANT.COM</a>
											<a href="https://healthconsultants.com">HEALTHCONSULTANTS.COM</a>
											<a href="https://intranetconsultant.com">INTRANETCONSULTANT.COM</a>
											<a href="https://woodconsultants.com">WOODCONSULTANTS.COM</a>
											<a href="https://propertyconsultant.com">PROPERTYCONSULTANT.COM</a>
											<a href="https://fundconsultants.net">FUNDCONSULTANTS.NET</a>
											<a href="https://CampusConsultant.com">CAMPUSCONSULTANT.COM</a>
											<a href="https://techconsultant.com">TECHCONSULTANT.COM</a>
											<a href="https://nursingconsultants.com">NURSINGCONSULTANTS.COM</a>
											<a href="https://skincareconsultant.net">SKINCARECONSULTANT.NET</a>
					
			</div><!-- industries -->
			
			
                        </div><!--front-block-inner-body -->
            </div><!--front-block-inner -->	
        	</div><!--front-block-right -->