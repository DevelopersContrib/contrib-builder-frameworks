<div class="front-block-right">
           <style type="text/css">
	.industries a{background:#138496;color:#fff;padding:5px;margin:2px;float:left;border-radius:5px;}	
</style>

<div class="front-block-inner">
             <div class="front-block-inner-head"><h3><span>FEATURED</span> CONSULTANT SITES</h3></div>
            <div class="front-block-inner-body">
            
              			<div class="industries">	
										<a href="http://projectconsultant.net">PROJECTCONSULTANT.NET</a>
											<a href="http://CtConsultant.com">CTCONSULTANT.COM</a>
											<a href="http://insuranceconsultant.com">INSURANCECONSULTANT.COM</a>
											<a href="http://SohoConsultants.com">SOHOCONSULTANTS.COM</a>
											<a href="http://enviroconsultant.com">ENVIROCONSULTANT.COM</a>
											<a href="http://healthconsultants.com">HEALTHCONSULTANTS.COM</a>
											<a href="http://intranetconsultant.com">INTRANETCONSULTANT.COM</a>
											<a href="http://woodconsultants.com">WOODCONSULTANTS.COM</a>
											<a href="http://propertyconsultant.com">PROPERTYCONSULTANT.COM</a>
											<a href="http://fundconsultants.net">FUNDCONSULTANTS.NET</a>
											<a href="http://CampusConsultant.com">CAMPUSCONSULTANT.COM</a>
											<a href="http://techconsultant.com">TECHCONSULTANT.COM</a>
											<a href="http://nursingconsultants.com">NURSINGCONSULTANTS.COM</a>
											<a href="http://skincareconsultant.net">SKINCARECONSULTANT.NET</a>
					
			</div><!-- industries -->
			
			
                        </div><!--front-block-inner-body -->
            </div><!--front-block-inner -->	
        	</div><!--front-block-right -->