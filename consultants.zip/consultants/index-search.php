<script src="<?=$main_site?>js/search.js"></script>

<div class="main-search">
    <div class="main-search-inner">
    <div>
   <form action="<?=$main_site?>consultants/search" id="searchform" method="POST">
		<fieldset>
		<div class="search-left">
			<span>Search Our Consultant Database</span>
			<input class=" " name="searchkey" type="text" id="searchkey" value="Enter search key" onfocus="clearText(this)" onblur="clearText(this)"  />
		</div>
		<div class="search-mid">
			<span>Select Filters</span>
			<div class="search-mid-select">
			<select name="searchby" id="searchby">
				<option value="industry">By Industry</option>
				<option value="name">By Name</option>
				<option value="location">By Location</option>
			</select>
			</div>
		</div>
		<input name="" type="button" class="search-btn" id="searchbtn" value=""/>
		</fieldset>
  </form>
  </div>
  </div>

</div><!--main-search -->  