<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $introduction = "{{INTRODUCTION}}";
    $keywords = "{{KEYWORDS}}";
    $footer_html = "{{FOOTER_HTML}}";
    $ids = "{{IDS}}";
    $main_site = "http://consultants.com/";
    $sitename = "http://{$domain}/";
    $api_key = '93724d7f979a8166';
    $footer_banner = "{{FOOTER_BANNER}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $affiliate_id = "{{AFF_ID}}";
    $piwik_id = '{{PIWIK_ID}}';
    $industries = {{INDUSTRIES}};
    $partners = {{PARTNERS}};
    $featuredsites = {{FEATUREDSITES}};
?>