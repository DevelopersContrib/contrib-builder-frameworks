<?include('header.php')?>
<script>
$(document).ready(function(){
  	activateHeaderMenuPublic("consultants_tab");
});
</script>    
<?include('header-menu.php')?> 
<?include('header-sub.php')?>
<div id="container-wrap">
     <div id="container-inner">
          <div id="inner-body">
              <?include('index-button.php')?>   
              <?include('index-search.php')?>   
               <link href="<?=$sitename?>css/styleA.css" rel="stylesheet">    
               <link href="<?=$sitename?>css/styleB.css" rel="stylesheet">
	             <link href="<?=$sitename?>css/work.css" rel="stylesheet">
	             <link href="<?=$sitename?>css/style_consultants_directory.css" rel="stylesheet">
               <div class="directory-whole">
        			<div class="front-block">
            	<div class="front-block-full">
            	  <div class="front-block-inner-full">
        	              <?include('consultant-category.php')?>  
                  </div>
            	</div>
            </div><!--front-block -->			
			<br class="clear">
			<div class="directory-left">
		                         <?include('consultant-list.php')?>  
		  </div><!-- directory-left -->
		  <div class="directory-right">
			   		              <?include('consultant-leaderboard.php')?>  
     </div><!-- directory-right -->
    	</div><!-- directory whole -->
               
               
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('footer.php')?>