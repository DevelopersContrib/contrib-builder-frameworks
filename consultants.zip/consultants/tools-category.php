     
      <?$categories = json_decode(file_get_contents($main_site.'api/getcategories?api_key='.$api_key));?>
     <?php  if (sizeof($categories) > 0):
            	 $i=1;
	            ?>
	               <div class="front-block-inner-col-full">
            	<ul class="list-arrow">
            	 <?php foreach ($categories as $row):?>
		    	
                	<li><a href="<?=$sitename?>tools/<?php echo $row->slug?>"><?php echo $row->name?></a></li>
                	<?php if (($i%6)==0):?>
                </ul>
            </div>
            <div class="front-block-inner-col-full">
            	<ul class="list-arrow">
            	<?php endif?>
                	<?php 
                	$i++;
                	endforeach;?>
                </ul>
            </div>
            <?php endif;?>
     