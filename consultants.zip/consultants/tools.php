<?include('header.php')?>
<script>
$(document).ready(function(){
  	activateHeaderMenuPublic("tools_tab");
});
</script>  
<style type="text/css">
	.directory-whole{width:100%;float:left;}
	.toolflipbtn:hover{cursor:pointer}
	.largeProfileCard:hover{ border:3px solid #004993; padding: 8px; }
</style>
<script type="text/javascript" src="<?=str_replace('http:','https:',$main_site);?>js/tools_manager.js"></script>
<?include('header-menu.php')?> 
<?include('header-sub.php')?>
<div id="container-wrap">
     <div id="container-inner">
          <div id="inner-body">
          <input type="hidden" name="base_url" id="base_url" value="<?=str_replace('http:','https:',$main_site);?>" />
               <link href="<?=$sitename?>css/styleA.css" rel="stylesheet">    
               <link href="<?=$sitename?>css/styleB.css" rel="stylesheet">
	             <link href="<?=$sitename?>css/work.css" rel="stylesheet">
	             <link href="<?=$sitename?>css/style_consultants_directory.css" rel="stylesheet">
               <script src="<?=$sitename?>js/jquery-ui-1.7.2.custom.min.js"></script>
	             <script src="<?=$sitename?>js/jquery.flip.min.js"></script>
               <?include('tools-search.php')?>			
  
  <br class="clear" />
			
			<div class="directory-whole">
			<div class="front-block">
    	<div class="front-block-full">
    	  <div class="front-block-inner-full">
	            <div class="front-block-inner-body">
	           	          <?include ('tools-category.php')?>
            	</div>
          </div>
    	</div>
    </div><!--front-block -->						<div class="row-fluid">
				<div class="span12 cons-box" style="padding: 10px 10px 20px 10px;">	
					<div style="clear:both"><br></div>
					
					<div style="margin-left: 2px;">						
						
								<?include('tools-list.php')?>
												
					</div>
					
					<div style="clear:both"><br></div>
					
					 
				</div>
			</div>
						
			</div><!-- directory whole -->
		
			
	<script type="text/javascript">
	$(function(){	

		var base_url = $('#base_url').val(); 
	
		$(document).on("click",".toolflipbtn",function(){
			var btn_id = $(this).attr('id'); 
			var tool_id = btn_id.replace('toolflip_btn_','');
			var content = '';
			
			$.post(base_url+'tools/toolsdetailsflip',{tool_id:tool_id},function(data){
				content = data;
				$("#toolflip_"+tool_id).flip({
					direction: 'lr',
					content: content,
					color:'rgb(107, 209, 248)'
				});
			});
			return false;
		});
		
		$(document).on("click",".toolflip_back",function(){
			
			var btn_id = $(this).attr('id'); 
			var tool_id = btn_id.replace('toolflip_back_','');
				
			$("#toolflip_"+tool_id).revertFlip();
			return false;
		});
		
	});
	</script>
               
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('footer.php')?>