<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<style type="text/css">
    
  /* carousel css here */

    .wrap-marketplace-box-item {
		background-color: #dbe8ed;
		border-radius: 3px;
		border: none;
		box-shadow: none;
		display: block;
		padding: 15px;
		text-align: center;
		word-wrap: break-word;
		color: #000;
		text-shadow: none;
		margin-bottom: 25px;
	}
    /* Logo Found */
    .wmbi-img-logo {
        display: block;
        margin-bottom: 15px;
    }
    .wmbi-img-logo img {
        display: inline-block;
        max-height: 60px;
    }
    /* Title Brand */
    .wmbi-ttle {
        background-color: #f5f5f5;
        color: #2e9f3e;
        font-size: 1.3em;
        font-weight: bold;
        padding: 10px 5px;
    }
    .marg-m-ttlTop {
        margin-top: 0;
    }
    .p-marg-btm {
        margin-bottom: 0;
    }
    .ul-wmbi-zero li {
       list-style: outside none none;
        padding: 0;
    }
    .ul-wmbi-zero li .btn{
        margin: 0;
    }
    /* Carousel Custom Brands */
    #brandsCarousel .owl-item{
        padding:15px;
    }
    #brandsCarousel .owl-prev::before,#brandsCarousel .owl-next::before{
        background-color: #e1e1e1;
    }

   /* ===================================
      Owl carousel
  ====================================== */

  .owl-carousel { overflow: hidden; }
  .owl-buttons { position: static; }
  .owl-prev, .owl-next { color: #111; display: block; font-size: 16px; height: 105px; line-height: 105px; margin-top:-35px; opacity: 0; position: absolute; text-align: center; top: 50%; width: 105px; z-index: 6; }
  .owl-prev {left: -70px;}
  .owl-next {right: -70px;}
  .owl-prev:before, .owl-next:before { background-color:#fff; border-radius:2px; box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1); content: ""; display: block; height: 66%; left: 0; position: absolute; width: 66%; }
  .owl-next:before { left: auto; right: 0; }
  .owl-prev .fa, .owl-next .fa {color: #000; font-size: 24px; position: relative; top: -15%;}
  .owl-prev .fa{ right: 4%}
  .owl-next .fa { left: 4%;}
  .owl-carousel:hover .owl-prev {left: -35px; opacity: 1; }
  .owl-carousel:hover .owl-next { opacity: 1; right: -35px; }
  .owl-pagination { bottom: 30px; display: block; left: 0; position: absolute; text-align: center; width: 100%; z-index: 100 !important; }
  .owl-page { display: inline-block; padding: 6px 5px; }
  .owl-page span { background: none repeat scroll 0 0 rgba(255, 255, 255, 0.7); border-radius: 4px; box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1); display: block; height: 7px; transition: all 0.27s cubic-bezier(0, 0, 0.58, 1) 0s; width: 7px; }
  .owl-page:hover span { background: none repeat scroll 0 0 rgba(255, 255, 255, 1); }
  .owl-page.active span { background: none repeat scroll 0 0 transparent; border: 1px solid rgba(255, 255, 255, 0.8); transform: scale(1.33333); }
  .owl-bg-img { background-position: center center; background-repeat: no-repeat; background-size: cover; display: block; overflow: hidden; position: relative; width: 100%; }
  .owl-subtitle { font-size: 14px; letter-spacing: 10px; text-transform: uppercase; font-weight: 400; line-height: 80px; display:block}
  .owl-title { font-size: 35px; font-weight: 600; text-transform: uppercase; display: block; letter-spacing: 7px;}
  .owl-title-big { background: rgba(0, 0, 0, 0.5); display: inline-block; font-size: 25px; font-weight: 600; letter-spacing: 7px; line-height: 40px; padding: 35px 50px; text-transform: uppercase; width: 60% }
  .dark-pagination .owl-page span { background: none repeat scroll 0 0 rgba(0, 0, 0, 1); box-shadow: none }
  .dark-pagination .owl-page.active span {background:transparent; border: 1px solid rgba(0, 0, 0, 1); }
  .dark-pagination .owl-prev, .owl-next { opacity: 1; }
  .dark-pagination .owl-next:before { left: auto; right: 0; }
  .dark-pagination .owl-prev {left: -35px; opacity: 1; }
  .dark-pagination .owl-next { opacity: 1; right: -35px; }
  .light-pagination .owl-page.active span {background: transparent; border: 1px solid rgba(255, 255, 255, 1); }


#featured-wrap {
    background: #fff none repeat scroll 0 0;
    float: left;
    width: 100%;
}

#featured-wrap h1 {
    color: #A1A1A1;
    font-weight: 700;
    line-height: 45px;
    margin: 0;
    padding: 0;
    padding-top: 20px;
    text-transform: uppercase;
}
#brandsCarousel,
#brandsCarousel:before,
#brandsCarousel:after ,
#featured-wrap,
#featured-wrap:before,
#featured-wrap:after,
.owl-item,
.owl-item:before,
.owl-item:after{
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
}

</style>
<br/>
<div id="featured-wrap">
    <div class="text-center">
        <h1>Our Top Brands</h1>
        <div class="row-fluid">
            <div id="brandsCarousel" class="owl-carousel">
                <?php foreach($featuredsites as $featuredsites): ?>
                     <div>
                          <div class="wrap-marketplace-box-item">
                                <a class="wmbi-img-logo" href="https://<?php echo $featuredsites['domain_name']; ?>">
                                <?php if(!empty($featuredsites['logo'])): ?>
                                <?php 
                                    if(strpos($featuredsites['logo'],'cdn.vnoc.com') < -1) {
                                        $logo = "https://cdn.vnoc.com/logos".substr($featuredsites['logo'],strrpos($featuredsites['logo'],'/'));
                                    } else {
                                        $logo = str_replace('http:','https:',$featuredsites['logo']);
                                    }
                                ?>
                                    <img src="<?php echo $logo; ?>" class="img-responsive" alt="<?php echo $featuredsites['domain_name']; ?>" title="<?php echo $featuredsites['domain_name']; ?>">
                                <?php else: ?>
                                    <img src="https://cdn.vnoc.com/logos/logo-contrib-brand2.png" class="img-responsive">
                                <?php endif; ?>
                                </a>
                                  <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
                                      <?php echo $featuredsites['domain_name']; ?>
                                  </h3>
                                  <p class="p-marg-btm">
                                      Join our exclusive community of like minded people on 
                                  </p>
                                  <p>
                                      <a target="_blank" href="https://<?php echo $featuredsites['domain_name']; ?>"><?php echo $featuredsites['domain_name']; ?></a>
                                  </p>
                                  <ul class="inline ul-wmbi-zero">
                                      <li>
                                          <a class="btn btn-success btn" target="_blank" href="https://<?php echo $featuredsites['domain_name']; ?>">Visit</a>
                                      </li>
                                      <li>
                                          <a class="btn btn-success btn" target="_blank" href="https://contrib.com/brand/details/<?php echo $featuredsites['domain_name']; ?>">Details</a>
                                      </li>
                                  </ul>
                              </div>
                          </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<script  src="https://code.jquery.com/jquery-3.0.0.min.js" integrity="sha256-JmvOoLtYsmqlsWxa7mDSLMwa6dZ9rrIdtrrVYRnDRH0="crossorigin="anonymous"></script>
<script type="text/javascript" src="<?=str_replace('http:','https:',$sitename);?>js/owl.carousel.min.js"></script>

<script>
    jQuery(document).ready(function(){
        jQuery("#brandsCarousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            items: 3,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        });
    }); 
</script>