<?include('header.php');?>
<?include('header-menu.php');?> 
<?include('header-sub.php');?>
<div id="container-wrap">
     <div id="container-inner">
          <div id="inner-body">
          <div style="text-align:center;">
          		<?php 
					   $api_content_url = "https://api3.contrib.co/announcement/";                 //get terms
					  $url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=terms';
					  $result =  createApiCall($url, 'GET', $headers, array());
					  $data_domain = json_decode($result,true);
					  if (isset($data_domain['data']['content'])){
					   $terms =   $data_domain['data']['content'];
					  }else {
					  	$terms = "";
					  }

					  echo $terms;
                ?>

         
	        <div class="clear"></div>  
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('footer.php')?>