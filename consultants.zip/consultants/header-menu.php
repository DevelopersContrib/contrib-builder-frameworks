<div id="header-wrap">
	<div id="header-inner">
    	<ul class="top-nav">
              <li id="indexpage_tab"><a href="<?=$sitename?>"> <span class="top-nav-home"></span> Home</a></li>
              <li><span class="top-nav-line"></span></li>       
              <li id="about_tab" ><a href="<?=$sitename?>about">ABOUT</a></li> 
              <li><span class="top-nav-line"></span></li>        
              <li id="tools_tab"><a href="<?=$sitename?>tools">TOOLS DIRECTORY</a> </li>
              <li><span class="top-nav-line"></span></li>        
              <li id="consultants_tab"><a href="<?=$sitename?>consultants">CONSULTANTS</a> </li>
			  <li><span class="top-nav-line"></span></li>
			  <li id="apps_tab"><a href="<?=$sitename?>apps">APPS</a> </li>
            </ul>
    </div><!--header-inner -->
</div><!--header-wrap -->