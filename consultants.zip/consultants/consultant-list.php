<?
if (isset($_REQUEST['skill'])){

	$temp_skill = $api_consultants.'getskillinfo?api_key='.$api_key.'&field=slug&value='.$_REQUEST['skill'];
	$result_temp = createApiCall($temp_skill, 'GET', $headers, array());
	$skill = json_decode($result_temp,true);
	
 // $skill = json_decode(file_get_contents($main_site.'api/getskillinfo?api_key='.$api_key.'&field=slug&value='.$_REQUEST['skill']));
  if (sizeof ($skill) > 0){
     foreach ($skill as $s){
                 $skill_name = $s['name'];
                 $skill_id = $s['skill_id'];
     }
	 
	$temp_consultants = $api_consultants.'getconsultants?api_key='.$api_key.'&skill='.$skill_id;
	$result_temp = createApiCall($temp_consultants, 'GET', $headers, array());
	$consultants = json_decode($result_temp,true);
	 
   // $consultants = json_decode(file_get_contents($main_site.'api/getconsultants?api_key='.$api_key.'&skill='.$skill_id)); 
  }
}else {
  $skill_name = "Consultants Directory";
  
	$temp_consultants = $api_consultants.'getconsultants?api_key='.$api_key.'&ids='.$ids;
	$result_temp = createApiCall($temp_consultants, 'GET', $headers, array());
	$consultants = json_decode($result_temp,true);
	
  //$consultants = json_decode(file_get_contents($main_site.'api/getconsultants?api_key='.$api_key.'&ids='.$ids));
}
?>

  <div class="row-fluid">
		<div class="span12 cons-box" style="padding: 10px 10px 20px 10px;">	
		  <h3><?echo $skill_name?></h3>
		  <br class="clear">
     <?
    if(sizeof($consultants) > 0):
    $i=1;
   ?>
        	<?php 	foreach($consultants as $row):?>
          <?if (!array_key_exists('success',$row)):?>
          <?
			
			
			$temp_leads = $api_consultants.'getcountleads?api_key='.$api_key.'&consultant='.$row->consultant_id;
			$result_temp = createApiCall($temp_leads, 'GET', $headers, array());
			$leads = json_decode($result_temp,true);
	
	
            //$leads = json_decode(file_get_contents($main_site.'api/getcountleads?api_key='.$api_key.'&consultant='.$row->consultant_id));
            
			if(sizeof($leads) > 0){
                  foreach ($leads as $l){
                    $lead_count = $l['total'];
                  }
            }
            
          
          ?>
          <div class="syn-profile-grid syn-profile-grid-2x4 bodybody" style="opacity: 1;  visibility: visible; zoom: 1;">
									<div class="largeProfileCard">
										<div class="corner-leaf"></div>
										<div class="top-section">
											<div class="left-section">
												<div class="largeProfileCard-icon"><img src="<?echo $main_site?>images/users/<?echo $row['consultant_id']?>.png" width="70px" alt="http://iconsultants.com/img/avatar.png" /></div>
											</div>
											<div class="right-section">
												<div class="largeProfileCard-title">
													<div class="largeProfileCard-name" title="<?echo $row['firstname']." ".$row['lastname']?>"><?echo $row['firstname']." ".$row['lastname']?></div>
													<span class="largeProfileCard-skills"><?echo $row['tagline']?></span>
													<span class="largeProfileCard-location"><? if ($row['city']) {echo $row['city'].", ";}?> <?echo $row['country']?></span>
												</div>
											</div>
											<div class="clear"></div>
										</div>
										<div class="bottom-section">
											<div class="left-section" id="">
												<div class="largeProfileCard-invite"><a href="<?echo $main_site?><?echo $row['username']?>" target="_blank" class="inviteOne">View More</a></div>
											</div>
											<div class="right-section" id="">
												<div class="largeProfileCard-rating">
													<div class="rating"><div class="eol-rating-stars-small" title="<?=$row['score']?>"><div class="eol-scale" style="width: <?echo ($row['score']/5)?>px;"><!-- --></div></div></div>
													<div class="eol-rate-txt greytxt">score rating</div>
												</div>
												<div class="largeProfileCard-jobs"><div class="job-count"><?=$lead_count?></div><div class="eol-jobcount-txt greytxt">leads</div></div>
												<div class="largeProfileCard-rate"><div class="rate-value"><?echo $row->rate?></div><div class="eol-rate-txt greytxt">rate</div></div>
											</div>
											<div class="clear"></div>
										</div>
									</div>
								</div>
                  <?else:?>
                   No consultants found.
                <?endif;?>  
                <?endforeach;?>
						  <?endif;?>  			   			
				</div>
			</div>
      
        
      