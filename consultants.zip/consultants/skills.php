<?include('header.php')?>
<?include('header-menu.php')?> 
<?include('header-sub.php')?>
<div id="container-wrap">
     <div id="container-inner">
          <div id="inner-body">
              <?include('index-button.php')?>   
              <?include('index-search.php')?>   
               <div class="front-block">
                   <?include('skills-list.php')?>       	
              </div><!--front-block -->
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('footer.php')?>