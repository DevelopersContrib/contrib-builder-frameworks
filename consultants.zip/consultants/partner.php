<?include('header.php')?>
<?include('header-menu.php')?> 
<?include('header-sub.php')?>
<div id="container-wrap">
     <div id="container-inner">
          <div id="inner-body">
          <div style="text-align:center;">
          <h3>Contact <?=ucfirst($domain)?></h3>
			    <iframe width="380px" height="515px" style="margin-left: 20px;" src="http://www.contrib.com/forms/partner/<?=$domain?>"></iframe>
          </div>
	        <div class="clear"></div>  
          </div><!--inner-body -->
      </div><!--container-inner -->
</div><!--container-wrap -->
<?include('footer.php')?>