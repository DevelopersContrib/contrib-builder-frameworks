<?
if (isset($_REQUEST['category'])){
	$temp_url = $api_consultants.'gettools?api_key='.$api_key.'&field=tool_category.slug&value='.$_REQUEST['category'];
	$result_temp = createApiCall($temp_url, 'GET', $headers, array());
	$tools = json_decode($result_temp,true);
			
 }
else {
    $temp_url = $api_consultants.'gettools?api_key='.$api_key;
	$result_temp = createApiCall($temp_url, 'GET', $headers, array());
	$tools = json_decode($result_temp,true);
}
?>

 <?
    if(sizeof($tools) > 0):
            foreach ($tools as $row):
     
   ?>
<div id="toolflip_<?=$row['tool_id']?>" class="syn-profile-grid syn-profile-grid-2x4 bodybody" style="opacity: 1;  visibility: visible; zoom: 1;background-color:rgb(107, 209, 248)">
									<div class="largeProfileCard" >
										<div class="corner-leaf"></div>
									
										<div class="top-section toolflipbtn" id="toolflip_btn_<?=$row['tool_id']?>">
											<div class="left-section">
												<div class="largeProfileCard-icon"><img src="<?=str_replace('http:','https:',$main_site);?>images/tools/link<?=$row['tool_id']?>.jpg" width="70px"></div>
											</div>
											<div class="right-section">
												<div class="largeProfileCard-title">
													<div class="largeProfileCard-name" title="Codrops"><?=$row['name']?></div>
													<span class="largeProfileCard-skills"><?
                                   $string = stripcslashes($row['description']);
								                   $string = (strlen($string) > 60) ? substr($string,0,60).'...' : $string;
								                   echo $string;
								                  
                          ?></span>
													<span class="largeProfileCard-location"><?=$row['category']?></span>
												</div>
											</div>
											<div class="clear"></div>
										</div>
										<div class="bottom-section">
											<div class="left-section" id="">
												<div class="largeProfileCard-invite"><a href="<?=str_replace('http:','https:',$main_site);?>tools/details/<?=$row['slug']?>" class="inviteOne">View More</a></div>
											</div>
											<div class="right-section" id="">
												<div class="largeProfileCard-rating">
													<? 
													
														 $temp_url = $api_consultants.'getratings?api_key='.$api_key.'&tool='.$row['tool_id'];
														$result_temp = createApiCall($temp_url, 'GET', $headers, array());
														$ratings = json_decode($result_temp,true);
	
														//$ratings = json_decode(@file_get_contents($main_site.'api/getratings?api_key='.$api_key.'&tool='.$row['tool_id']));?>
														
														
													
													<?if(sizeof($ratings) > 0):?>
															<?
															  
															   foreach ($ratings as $rate){
																 $r = $rate['rating'];
																 $w = $rate['width'];
															   }
															?>
																						<div class="rating"><div class="eol-rating-stars-small" title="<?=$r?>"><div class="eol-scale" style="width: <?=$w?>;"><!-- --></div></div></div>
																						<div class="eol-rate-txt greytxt">avg. rating</div>
																					</div>
																					<div class="largeProfileCard-jobs toolflipbtn" id="toolflip_btn_<?=$row['tool_id']?>"><div class="job-count"><?=$row['shared']?></div><div class="eol-jobcount-txt greytxt">shared</div></div>
													<?endif;?>							
											</div><!--right-section --> 
											<div class="clear"></div>
										</div>
									</div>
								</div>
		         					
        <?endforeach;?>  

		<?php else:?>
		    <p>No tools found.</p>						
		<?php endif;?>						