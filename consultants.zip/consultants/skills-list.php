<?
$indust = json_decode(file_get_contents($main_site.'api/getindustryinfo?api_key='.$api_key.'&field=slug&value='.$_REQUEST['industry']));
if (sizeof ($indust) > 0){
   foreach ($indust as $ind){
               $industry_name = $ind->name;
               $industry_id = $ind->industry_id;
   }
}


$skills = json_decode(file_get_contents($main_site.'api/getskills?api_key='.$api_key.'&industry='.$industry_id));

?>
<div class="front-block-full">
    	  <div class="front-block-inner-full">
    	       
    	        <div class="front-block-inner-head"><h3><span>INDUSTRY:</span> <?php echo $industry_name?></h3></div>
    	      
	            <div class="front-block-inner-body">
	            <?php 
               $limit = ceil(sizeof($skills)/3);
            	 if(sizeof($skills) > 0):
            	 $i=1;
	            ?>
	               <div class="front-block-inner-col-full">
            	<ul class="list-arrow">
            	<?php 	foreach($skills as $row):
		    	?>
                	<li><a href="<?=$sitename?>consultants/<?php echo $row->slug?>"><?php echo $row->name?></a></li>
                	<?php if (($i%$limit)==0):?>
                </ul>
            </div>
            <div class="front-block-inner-col-full">
            	<ul class="list-arrow">
            	<?php endif?>
                	<?php 
                	$i++;
                	endforeach;?>
                </ul>
            </div>
            <?php endif;?>
	           
	            </div>
	              
          </div>
    	</div>