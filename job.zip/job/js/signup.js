$(document).ready(function(){

	$('#follow_step1_btn').click(function(){
		var initial_email = $('#initial_email').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				
		$('#follow_warning1').html('');
				
		if (initial_email == ""){
			$('#follow_warning1').html('* Please provide an e-mail *');
			$('#initial_email').focus();
		}else if(!emailfilter.test(initial_email)){
			$('#follow_warning1').html('* Invalid e-mail format *');
			$('#initial_email').focus();
		}else {
			$("#follow_step1_btn").attr('disabled', true); 
			$.post('http://www.contrib.com/forms/fullcontactdetails',
			{initial_email:initial_email}
			,function(data){
				if(data.photo!=''){
					$('#userimage').attr('src',data.photo);
					$('#default_photo').val(data.photo);
				}
							   
				$('#firstname').val(data.fname);
				$('#lastname').val(data.lname);							   
				$('#email').val(initial_email);
				$('#follow_step1').addClass('hide');
				$('#follow_step2').removeClass('hide');
			}
			);
		}		
	});
	
	$('#follow_step2_btn').click(function(){
		var email = $('#email').val();
		var firstname = $('#firstname').val();
		var lastname = $('#lastname').val();
		var password = $('#password').val();
		var password2 = $('#password2').val();				
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var letters = /^[a-zA-Z ]+$/;
				
		$('#follow_warning2').html('');
				
		if (email == ""){
					$('#follow_warning2').html('* Please provide an e-mail *');
					$('#email').focus();
		}else if(!emailfilter.test(email)){
					$('#follow_warning2').html('* Invalid e-mail format *');
					$('#email').focus();
		}else if (firstname == ""){
					$('#follow_warning2').html('* First name is required *');
					$('#firstname').focus();
		}else if(!letters.test(firstname)){				
					$('#follow_warning2').html('* Accepts letters only *');
					$('#firstname').focus();
		}else if(firstname.length > 25){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *');
					$('#firstname').focus();               
		}else if(firstname.length < 3 ){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *'); 
					$('#firstname').focus();  
		}else if (lastname == ""){
					$('#follow_warning2').html('* Last name is required *');
					$('#lastname').focus();
		}else if(!letters.test(lastname)){				
					$('#follow_warning2').html('* Accepts letters only *');
					$('#lastname').focus();
		}else if(lastname.length > 25){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *');
					$('#lastname').focus();               
		}else if(lastname.length < 3 ){				
					$('#follow_warning2').html('* Name should have 3 to 25 characters *'); 
					$('#lastname').focus();  
		}else if (password == ""){
					$('#follow_warning2').html('* Password is required *');
					$('#password').focus();
		}else if(password.length < 5){				
					$('#follow_warning2').html('* Password should have atleast 5 characters *'); 
					$('#password').focus();  
		}else if (password2 == ""){
					$('#follow_warning2').html('* Confirm Password is required *');
					$('#password2').focus();
		}else if(password!=password2){				
					$('#follow_warning2').html('* Password not match *'); 
					$('#password2').focus();
		}else{
					$('#follow_step2').addClass('hide');
					$('#follow_step3').removeClass('hide');
					$('#follow_warning2').html('');
		}
				
	});
	
	$('#follow_step3_btn').click(function(){
		var country_id = $('#country_id').val();
		var city = $('#city').val();
		var website = $('#website').val();
		var letters = /^[a-zA-Z ]+$/;
			
		if (country_id == ""){
					$('#follow_warning3').html('* Please select your country *');
					$('#country_id').focus();
		}else if (city == ""){
					$('#follow_warning3').html('* Please enter your city *');
					$('#city').focus();
		}else if(!letters.test(city)){	
					$('#follow_warning3').html('* Please enter a valid city *');
					$('#city').focus();
		}else if(website!='' && validateURL(website)===false){
			$('#follow_warning3').html('* Please enter a valid url/link *');
					$('#website').focus();
		}else{
					$('#follow_step3').addClass('hide');
					$('#follow_step4').removeClass('hide');
					$('#follow_warning3').html('');
		}			
	});
	
	$('#follow_step4_btn').click(function(){
				$('#follow_step4').addClass('hide');
				$('#follow_step5').removeClass('hide');
	});
	
	/*SAVE DATA*/
	$('#follow_step5_btn').click(function(){
				
				var firstname = $('#firstname').val();
				var lastname = $('#lastname').val();
				var email = $('#email').val();
				var password = $('#password').val();
				var country_id =  $('#country_id').val();
				var city = $('#city').val();
				var country = $("#country_id option:selected").text();
				var phone = $('#phone').val();
				var website =  $('#website').val();
				var intention = $('#intention').val();
				var role_id = $('#role_id').val();
				var role_name = $("#role_id option:selected").text();
				var industry_id = $('#industry_id').val();
				var industry_name = $("#industry_id option:selected").text();
				var default_photo = $('#default_photo').val();
				var domain = $('#reg_domain').val();
				var user_ip = $('#user_ip').val();
				var experiences = "";
				var rating = "";
				var socials = "";
				var social_values = "";
				
				$('.social_register').each(function() {
					var id = $(this).attr('id');
					social_id  = id.replace('contact_','');  
					social_values += $(this).val()+";;";
					socials += social_id + ",";
				});
								
				$('.ratetable .ratetr .ratetd .rateinput').each(function() {
					var id = $(this).attr('id');
					experience  = id.replace('rate_','');  
					rating += $(this).val()+";;";
					experiences += experience + ",";
				});
								
				if(role_id == ""){
					$('#follow_warning5').html('* Please select your expertise *');
					$('#role_id').focus();
				}else if(intention == ""){
					$('#follow_warning5').html('* Please select what are you looking for *');
					$('#intention').focus();
				}else if(industry_id == ""){
					$('#follow_warning5').html('* Please select your industry *');
					$('#industry_id').focus();
				}else{
				
					$("#follow_step5_back").attr('disabled', true);
					$("#follow_step5_btn").attr('disabled', true);
					$('#follow_warning5').html('* Please wait while we process . . .*');
					
					$.post("http://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){

						if (data.status == 0){
						
							$.post("http://www.contrib.com/signup/saveall",
								{
								 firstname:firstname,
								 lastname:lastname,
								 email:email,
								 password:password,
								 website:website,
								 country_id:country_id,
								 city:city,
								 country:country,
								 phone:phone,
								 website:website,
								 intention:intention,
								 role_id:role_id,
								 role_name:role_name,
								 industry_id:industry_id,
								 industry_name:industry_name,
								 experiences:experiences,
								 rating:rating,
								 socials:socials,
								 social_values:social_values,
								 pics:'',
								 default_photo:default_photo,
								 domain:domain,
								 user_ip:user_ip
								}
								,function(data){
									if (data.status){
									
										 if (domain==""){
											 domain = "contrib.com";
										 }
									 
										$.post("http://www.manage.vnoc.com/salesforce/addlead",
											 {
												 'firstName':firstname,
												 'lastName':lastname,
												 'title':'',
												 'email':email,
												 'phone':phone,
												 'street':'',
												 'city':city,
												 'country':country,
												 'state':'',
												 'zip':'',
												 'domain':domain,
												 'role':role_name,
												 'form_type':'Contrib User'
											 }
											 ,function(data2){										  
												 console.log(data2);
											 }
										);
										
										$('#follow_warning5').html('');
										$('#follow_final').removeClass('hide');
										$('#follow_step5').addClass('hide');
									 
									}else {
										$('#follow_warning5').html('* Registration error occured. Please try again later. *'); 				 
									}
								}
							);					
							
								 
						}else{
							$('#follow_warning5').html('* Email already have an account. * <a href="http://www.contrib.com" target="_top">Please LOGIN here.</a>');
							$("#follow_step5_back").attr('disabled', false);
							$("#follow_step5_btn").attr('disabled', false);							
						}
					
					});
				}
	});

		
	
	/*BACK EVENTS*/
	$('#follow_step3_back').click(function(){
				$('#follow_step3').addClass('hide');
				$('#follow_step2').removeClass('hide');
				$('#follow_warning3').html('');
	});
			
	$('#follow_step4_back').click(function(){
				$('#follow_step4').addClass('hide');
				$('#follow_step3').removeClass('hide');
	});
			
	$('#follow_step5_back').click(function(){
				$('#follow_step5').addClass('hide');
				$('#follow_step4').removeClass('hide');
				$('#follow_warning5').html('');
	});

});

function validateURL(url){
	return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
}

