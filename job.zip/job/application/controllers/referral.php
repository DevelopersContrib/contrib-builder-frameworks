<?php

class Referral extends Controller {
	
	public function index(){
		$helper = $this->loadHelper('Url_helper');
		
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$job = $api->getjobdetails(null,$info['domain']);
		
		$partners = $api->getapprovedpartners($info['domain']);
		
		$template = $this->loadView('jobs/referral');
		$template->set('page', 'makemoney');
		$template->set('info', $info);
		$template->set('site', $info['domain']);
		
		$template->set('partners', $partners['data']);
		$template->render();
	}
	
}?>