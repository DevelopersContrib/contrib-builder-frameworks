<?php

class Privacy extends Controller {
	
	function index()
	{
		
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$template = $this->loadView('jobs/privacy');
		$template->set('page','about');
		$template->set('info',$info);
		$template->render();
	}
    
}

?>