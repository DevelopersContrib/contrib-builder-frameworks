<?php

class Terms extends Controller {
	
	function index()
	{
		
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$template = $this->loadView('jobs/terms');
		$template->set('page','about');
		$template->set('info',$info);
		$template->render();
	}
    
}

?>