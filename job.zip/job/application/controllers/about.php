<?php

class About extends Controller {
	
	public function index(){
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$template = $this->loadView('jobs/about');
		$template->set('page','about');
		$template->set('info',$info);
		$template->render();
	}
	
}?>