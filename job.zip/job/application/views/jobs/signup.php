
<link rel="stylesheet" type="text/css" href="css/jquery.rating.css">
<link rel="stylesheet" type="text/css" href="css/jquery.fileupload-ui.css">

<style>
.brdr{
	border: 1px solid;
}
.header-signup span {
	color: #009900;
}
.SignUpWrap label{
	color: #009933;
	text-transform: capitalize;
}
.FormsSocialLinks .form-control{
	display: inline-block;
	margin-bottom: 10px;
}
.FormsSocialLinks .form-control:last-child{
	margin-bottom: 15px;
}
.text-error{
	color: red;
	font-size: 12px;
	font-weight: bold;
	margin: 10px 0 10px 0;
}
.userphoto {
	height: 170px;
	width: 170px;
	border: 1px solid #D7D7D7;
	padding: 9px;
	position: relative;
	margin-left: 20px;
}
.mrgn-botm{
	margin-top: 15px;
}
.wrap-content-final {
	box-shadow: 1px 1px 1px #ccc;
	background: white;
	padding: 10px;
	margin-bottom: 15px;
	margin-left: 40px !important;
}
</style>
    
  

                <!-- Modal -->
                <div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h3 class="modal-title" id="signupModalLabel">Sign Up</h3>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div id="follow_step1" class="col-lg-12 text-center SignUpWrap">
                                        <h3 class="header-signup">
                                            <b>Follow, Join, Partner with <span><?php echo ucwords($info['domain']);?></span></b>
                                        </h3>
                                        <h4>
                                            Join Free, Help Build, Manage and Monetize Great Companies Today.
                                        </h4>
                                        <div class="row">
											<form onsubmit="return false;"> 
												<div class="col-lg-6 col-lg-offset-3">
													<div class="form-group mrgn-botm">
														<label for="" class="control-label suCcess">Your Official Email:</label>
														<input type="text" id="initial_email" value="" class="form-control col-lg-6" />
													</div>
													<div class="form-group">
														<br>
														<div class="text-error" id="follow_warning1" ></div>
														<button type="submit" class="btn btn-success btn-lg" style="margin-top: 10px;" id="follow_step1_btn">Next <i class="fa fa-angle-right"></i></button>
													</div>
													<small>
														<span class="help-block fnt-styl">Your email will not be published on your profile page. We promise not to share your email with anyone else. Please check our <a href="privacy" class="step-prvcy">Privacy Policy</a> and <a href="terms" class="step-terms">Terms &amp;Conditions.</a> </span>
													</small>
												</div>
											</form>
                                        </div>
                                    </div>
                                    <div id="follow_step2" class="col-lg-12 text-center SignUpWrap hide">
                                        <h2 class="">
                                            Create A Free Account
                                        </h2>
                                        <h4>
                                            Create your free account and build or join your first Startup Company.
                                        </h4>
                                        <div class="row">
                                            <div class="col-lg-8 col-lg-offset-2 text-left">
                                                <form onsubmit="return false;"> 
													<div class="row">
														<div class="span12">
															<div class="col-lg-6 mrgn-botm">
																<label>Your Official Email:</label>
																<input type="text" name="email" id="email" value="" class="form-control" data-original-title="" title="">
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-lg-6 mrgn-botm">
															<label>Your first Name:</label>
															<input type="text" name="firstname" id="firstname" value="" class="form-control" data-original-title="" title="">
														</div>
														<div class="col-lg-6 mrgn-botm">
															<label>Your last name:</label>
															<input type="text" name="lastname" id="lastname" value="" class="form-control" data-original-title="" title="">
														</div>
														<div class="col-lg-6 mrgn-botm">
															<label>Password:</label>
															<input type="password" name="password" id="password" value="" class="form-control" data-original-title="" title="">
														</div>
														<div class="col-lg-6 mrgn-botm">
															<label>confirm Password:</label>
															<input type="password" name="password2" id="password2" value="" class="form-control" data-original-title="" title="">
														</div>
														<div class="col-lg-12">
															<div class="text-error" id="follow_warning2" ></div>
															<button type="submit" class="pull-right btn btn-lg btn-success" style="margin-top: 10px;" id="follow_step2_btn">Next <i class="fa fa-angle-right"></i></button>
														</div>
													</div>
												</form>
												<small>
                                                    <span class="help-block fnt-styl">
                                                    Your email will not be published on your profile page. We promise not to share your email with anyone else. Please check our <a href="privacy" class="step-prvcy">Privacy Policy</a> and <a href="terms" class="step-terms">Terms &amp;Conditions.</a>
                                                    </span>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="follow_step3" class="col-lg-12 text-center SignUpWrap hide">
										<h2 class="">
                                            We want to know more about you
                                        </h2>
                                        <h4>
                                            We want to attract talented and gifted people like you so please take the time to upload a picture or add your current country of residence.
                                        </h4>
                                        <br>
										<div class="row">
											<div class="col-lg-8 col-lg-offset-2 text-left">												
												<form onsubmit="return false;"> 
													<div class="row">
														<div class="col-lg-6 mrgn-botm">
															<label>Country:</label>
															<? include('country_select.php'); ?> 
														</div>
														<div class="col-lg-6 mrgn-botm">
															<label>City:</label>
															<input type="text" name="city" id="city" value="" class="form-control" data-original-title="" title="">
														</div>	
														<div class="col-lg-6 mrgn-botm">
															<label>Phone:</label>
															<input type="text" name="phone" id="phone" value="" class="form-control" data-original-title="" title="">
														</div>	
														<div class="col-lg-6 mrgn-botm">
															<label>Website:</label>
															<input type="text" name="website" id="website" value="" class="form-control" data-original-title="" title="">
														</div>												
													</div>	
													<div class="row">
														<div class="col-lg-12">
															<div class="text-error" id="follow_warning3" ></div>
															<button type="submit" class="btn btn-lg btn-primary pull-right" id="follow_step3_btn">Next <i class="fa fa-angle-right"></i></button>
															<button type="submit" class="btn btn-lg btn-success pull-left" id="follow_step3_back"><i class="fa fa-angle-left"></i> Back</button>															
														</div>
													</div>
												</form>
											</div>													
										</div>
									</div>
									<div id="follow_step4" class="col-lg-12 text-center SignUpWrap hide">
                                        <h2 class="">
                                            Your Social Details
                                        </h2>
                                        <h4>
                                            If you're going to be a part of something big, then you must have social profiles everywhere.<br>Please take the time to at least add one.
                                        </h4>
                                        <br>
                                        <div class="row">
                                            <div class="col-lg-8 col-lg-offset-2 text-left">                                            
                                                <div class="row">
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/facebook.png">
                                                        <input type="text" placeholder="link to your facebook profile" value="" id="contact_1" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/css/img/twitter.png">
                                                        <input type="text" placeholder="link to your twitter profile" value="" id="contact_10" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/linkedin.png">
                                                        <input type="text" placeholder="link to your linkedin profile" value="" id="contact_2" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/github.png">
                                                        <input type="text" placeholder="link to your github account" value="" id="contact_9" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/skype.png">
                                                        <input type="text" placeholder="your skype id" value="" id="contact_4" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/yahoo.png">
                                                        <input type="text" placeholder="your yahoo id" value="" id="contact_5" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/gtalk.png">
                                                        <input type="text" placeholder="your gtalk id" value="" id="contact_6" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/aol.png">
                                                        <input type="text" placeholder="your AOL id" value="" id="contact_7" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                    <div class="col-lg-10 col-lg-offset-2 FormsSocialLinks">
                                                        <img src="http://www.contrib.com/images/icons/windows.png">
                                                        <input type="text" placeholder="your windows live id" value="" id="contact_8" class="form-control social_register" style="width: 310px;">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                         <button type="submit" class="btn btn-lg btn-primary pull-right" id="follow_step4_btn">Next <i class="fa fa-angle-right"></i></button>
														 <button type="submit" class="btn btn-lg btn-success pull-left" id="follow_step4_back"><i class="fa fa-angle-left"></i> Back</button>                                                       
                                                    </div>
                                                </div>
                                                <small>
                                                    <span class="help-block fnt-styl">
                                                    Your email will not be published on your profile page. We promise not to share your email with anyone else. Please check our <a href="privacy" class="step-prvcy">Privacy Policy</a> and <a href="terms" class="step-terms">Terms &amp;Conditions.</a>
                                                    </span>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="follow_step5" class="col-lg-12 text-center SignUpWrap hide">
                                        <h2 class="">
                                            Your Industry Details
                                        </h2>
                                        <h4>
                                            We have 15 vertical industries and over 20,000 assets,domains that you could <br> choose for your next venture and we need to know what your experience is.
                                        </h4>
                                        <br>
                                        <div class="row">
                                            <div class="col-lg-8 col-lg-offset-2 text-left">
                                                <div class="form-horizontal">
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-lg-5 control-label">Im Best Describe as: </label>
                                                        <div class="col-lg-7">
															<select name="role_id" id="role_id" class="form-control">
																<option value="">Choose your expertise</option>
																<?php if (count($formdata['data']['roles']) > 0): foreach ($formdata['data']['roles'] as $row): ?>
																<option value="<?php echo $row['role_id']?>"><?php echo $row['role_name']?></option>
																<?php endforeach; endif; ?>
															</select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-lg-5 control-label">what are you looking for: </label>
                                                        <div class="col-lg-7">
															<select name="intention" id="intention" class="form-control">
																<option value=""></option>
																<?php foreach ($formdata['data']['intentions'] as $int):?>
																<option value="<?php echo $int?>"><?php echo $int?></option> 
																<?php endforeach;?>
															</select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-lg-5 control-label">select your industry: </label>
                                                        <div class="col-lg-7">
															<select name="industry_id" id="industry_id" class="form-control">
																<option value=""></option>
																<?php if (count($formdata['data']['industries']) > 0): foreach ($formdata['data']['industries'] as $row): ?>
																<option value="<?php echo $row['IndustryId']?>"  ><?php echo $row['Name']?></option>
																<?php endforeach; endif; ?>
															</select>
                                                        </div>
                                                    </div>
													<br> 
													<h4 style="color: #3a87ad;margin: 0 5% 10px;">Experience level</h4>
                                                    <table width="90%" cellspacing="0" cellpadding="0" border="0" align="center" style=" border:1px solid #D7D7D7;" class="ratetable">				
														<?php if (count($formdata['data']['experiences']) > 0): foreach ($formdata['data']['experiences'] as $row): ?>
														<tr id="skill_<?php echo $row['skill_id']?>" class="ratetr">
															<td align="center" style="border-left:1px solid #D7D7D7; border-right:1px solid #D7D7D7;">
																<span style="font-weight:bold;"><?php echo $row['experience'] ?></span>
															</td>
															<td align="center" style="padding-left:50px;" class="ratetd">					  
																<?php for ($i=1;$i<6;$i++):?>
																<input name="star-skill<?php echo $row['skill_id']?>" type="radio" class="star" value="<?php echo $i?>" />   
																<?php endfor;?>
																<input type="hidden" name="ex_<?php echo $row['skill_id']?>" class="rateinput" id="rate_<?php echo $row['skill_id']?>" value="">
															 </td>
														</tr>            
														<?php endforeach; endif; ?>
													</table>
													<br>
                                                    <div class="form-group">
														<div class="text-error" id="follow_warning5" style="text-align: center;"></div>
														<button type="submit" class="btn btn-primary btn-lg pull-right" id="follow_step5_btn">Next <i class="fa fa-angle-right"></i></button>
                                                        <button type="submit" class="btn btn-success btn-lg pull-left" id="follow_step5_back"><i class="fa fa-angle-left"></i> Back</button>                                                        
                                                    </div>
                                                </div>
                                                <small>
                                                    <span class="help-block fnt-styl">
                                                    Your email will not be published on your profile page. We promise not to share your email with anyone else. Please check our <a href="privacy" class="step-prvcy">Privacy Policy</a> and <a href="terms" class="step-terms">Terms &amp;Conditions.</a>
                                                    </span>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
									<div id="follow_final" class="col-lg-12 text-center SignUpWrap hide">
										<h2 style="color:red">Thank you for your registration!</h2>
										<p style="background: rgba(255, 173, 0, 0.2);padding: 5px;">
											Please check the verification email that we have just sent you. Check out our top followed sites or continue viewing your account by <a target="_blank" href="http://www.contrib.com/network/account">clicking here</a>.
										</p>
										<div class="row-fluid">
											<div class="col-lg-11 wrap-content-final">
												<div class="col-lg-4 text-center">
													<img style="margin-bottom: 10px;width: 100%;" src="http://contrib.com/uploads/logo/image_logo-gventures10-420x60.png" class="follow-img">
													<a class="btn btn-info" target="_blank" href="http://www.contrib.com/brand/details/globalventures.com"><b>Follow</b></a>
												</div>
												<div class="col-lg-7">
													<div class="row-fluid">
														<a href="http://www.contrib.com/brand/details/globalventures.com" class="follow-name"><b>Globalventures.com</b></a>
													</div>
													<div class="row-fluid">
														<p>Global Ventures, LLC, established in 1996, is a Real Estate and Technology company focused on building and leveraging electronic corporations (eCorp) within the Domain Name System.</p>
													</div>
												</div>
											</div>
										</div>
										<div class="row-fluid">
											<div class="col-lg-11 wrap-content-final">
												<div class="col-lg-4 text-center">
													<img style="margin-bottom: 10px;width: 100%;" src="http://contrib.com/uploads/logo/goingglobal.png" class="follow-img">
													<a class="btn btn-info" target="_blank" href="http://www.contrib.com/brand/details/goingglobal.com"><b>Follow</b></a>
												</div>
												<div class="col-lg-7">
													<div class="row-fluid">
														<a href="http://www.contrib.com/brand/details/goingglobal.com" class="follow-name"><b>Goingglobal.com</b></a>
													</div>
													<div class="row-fluid">
														<p>Taking Your Business and Services Globally. Be a part of our global community when we launch!</p>
													</div>
												</div>
											</div>
										</div>
										<div class="row-fluid">
											<div class="col-lg-11 wrap-content-final">
												<div class="col-lg-4 text-center">
													<img style="margin-bottom: 10px;width: 100%;" src="http://contrib.com/uploads/logo/microblog.png" class="follow-img">
													<a class="btn btn-info" target="_blank" href="http://www.contrib.com/brand/details/microblog.com"><b>Follow</b></a>
												</div>
												<div class="col-lg-7">
													<div class="row-fluid">
														<a href="http://www.contrib.com/brand/details/microblog.com" class="follow-name"><b>Microblog.com</b></a>
													</div>
													<div class="row-fluid">
														<p>MicroBlog allows you to publish your updates and manage your profiles across multiple social media networks or micro blog sites in one dashboard.</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

     
		<input type="hidden" id="reg_domain" value="<?php echo $info['domain'];?>">
		<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
		<script type="text/javascript" src="js/jquery.rating.js" language="javascript"></script>  
        <script type="text/javascript" src="js/signup.js" ></script>
