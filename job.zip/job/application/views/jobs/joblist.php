<?php  
    include 'header.php';
?>
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php include('navigation.php');?>
			
        </div>
        
        <div class="wrapPage2All">
            <div class="container margDown">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="col-lg-6">
							<form method="post" action="<?php echo BASE_URL?>jobs/search">
                                <input type="text" class="form-control" placeholder="search jobs" name="search">
                            </form>
                        </div>
                        <div class="col-md-6">
							
							<div class="btn-group">
							
							  <div class="btn-group">
								<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
								  Apply Today
								  <span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
								<?foreach($sites AS $key=>$val):?>
									 <li><a href="http://www.contrib.com/signup/firststep?domain=<?echo $val['domain']?>"><?php echo ucfirst($val['domain'])?></a></li>
								<?endforeach;?>
								
								</ul>
							  </div>
							</div>
							
						</div>
                    </div>
                </div>
            </div>
            
            <div class="wrapSecondSectn">
                <div class="container margNgtvUp">
                    <div class="row">
						 <h5 class="text-info" style="font-weight:bold;color:white"><?echo count($other_jobs)?> results found.</h5>
                       <?php if (count($other_jobs)>0):?>
                         <?php foreach ($other_jobs as $key=>$val):?>
                        <div class="col-lg-12 whteS1">
                            <div class="row">
                                <a href="<?php echo BASE_URL?>jobs/details/<?php echo $val['slug']?>/<?php echo $val['job_id']?>">
                                    <div class="col-lg-8 bckgrnds1">
                                        <h3><?php echo $val['title']?></h3>
                                        <p>
                                            <?php echo $val['category']?>
                                        </p>
                                        <p>
                                           <?php echo stripcslashes($val['summary'])?>
                                        </p>
                                    </div>
                                </a>
								<div class="col-lg-4 rght4s1">
                                    <p class="team ellipsis">
                                      <?php if ($val['logo'] != ""):?>
                                      <img src="<?php echo $val['logo']?>" class="team-logo img-responsive">
                                         <?php else:?>
                                         <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png" class="team-logo img-responsive"> 
                                      <?php endif;?>
                                        
                                    </p>
                                    <p class="location"> <i class="fa fa-map-marker"></i> <?php echo $val['domain_category']?></p>
                                    <p class="tagline">
										<?php echo ucfirst($val['domain'])?>
                                        <? // echo $val['domain_title']?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
						<?else:?>
							<div class="col-lg-12 whteS1">
								<div class="row">
									<h5 class="text-center text-danger">No match found.</h5>
								</div>
							</div>
                      <?php endif?>  
                        
                   
                    </div>
                </div>
            </div>
        </div>
              <?php include ('footer.php')?>
