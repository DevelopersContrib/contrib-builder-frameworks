		<div class="panel-footer" style="display:none;">
			<center>
				<ul class="nav navbar-nav" style="float: none;width: 480px;">
					<li><a href="<?php echo BASE_URL?>about">About</a></li>
					<li><a href="<?php echo BASE_URL?>">Teams</a></li>
					<li><a href="<?php echo BASE_URL?>jobs">Jobs</a></li>
					<li><a href="<?php echo BASE_URL?>contact">Contact</a></li>
					<li><a href="<?php echo BASE_URL?>partners">Partner With Us</a></li>
					<li><a href="<?php echo BASE_URL?>terms">Terms</a></li>
					<li><a href="<?php echo BASE_URL?>privacy">Privacy</a></li>
				</ul>
				<div style="clear:both"></div>
				<p class="credits">Copyright @ 2014 <?php echo $info['domain']?>. All rights reserved.</p>
			
				<?php echo $info['footer_banner'];?>
			</center>
        </div>
		<!-- new footer-->
<div class="footer-top">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-3">
			<h3><?php echo $info['domain']?></h3>
			<p>is a proud venture of Global Ventures, LLC. Join our network of performance based companies using <?php echo $info['domain']?>.</p>
		  </div>
		  <div class="border col-md-3">
			<h3>Get Started</h3>
			<ul class="list-unstyled">
				<li><a href="/partners">Partner With Us</a></li>
				<li><a href="/staffing">Apply Now</a></li>
				<li><a href="/referral">Referral</a></li>
				<li><a href="/fund">Fund</a></li>
				<li><a href="/developers">Developers</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3>Company</h3>
			<ul class="list-unstyled">
				<li><a href="/about">About Us</a></li>
				<li><a href="/terms">Terms</a></li>
				<li><a href="/privacy">Privacy</a></li>
				<li><a href="/contact">Contact Us</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3>Partners</h3>
				<a href=""><img src="http://c15162226.r26.cf2.rackcdn.com/Rackspace_Cloud_Company_Logo_clr_300x109.jpg" style="height:45px;"></a>
			<h3>Social</h3>
			<ul class="list-inline socials-ul">
											<li>
												<a title="facebook" class="icon-button facebook" href="#">
													<i class="fa fa-facebook-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="google-plus" class="icon-button google-plus" href="#">
													<i class="fa fa-google-plus-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="youtube" class="icon-button youtube" href="#">
													<i class="fa fa-youtube-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="linkedin" class="icon-button linkedin" href="#">
													<i class="fa fa-linkedin-square"></i>
													<span></span>
												</a>
											</li>
			</ul>
		  </div>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-6"><span style="color:#fff">&copy; <?php echo $info['domain']?>. All Rights Reserved.</span></div>
		  <div class="border col-md-6">
			  <ul class="list-inline">			
				<li><a href="/about"><i class="fa fa-bookmark-o"></i> About Us</a></li>
				<li><a href="/terms"><i class="fa fa-book"></i> Terms</a></li>
				<li><a href="/privacy"><i class="fa fa-cube"></i> Privacy</a></li>
				<li><a href="/contact"><i class="fa fa-phone-square"></i> Contact Us</a></li>
			  </ul>
		  </div>
		</div>
	</div>
</div>
<!-- new footer-->
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://code.jquery.com/jquery.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
    </body>
</html>