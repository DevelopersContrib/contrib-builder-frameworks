		<div class="panel-footer">
			<center>
				<ul class="nav navbar-nav" style="float: none;width: 480px;">
					<li><a href="<?php echo BASE_URL?>about">About</a></li>
					<li><a href="<?php echo BASE_URL?>">Teams</a></li>
					<li><a href="<?php echo BASE_URL?>jobs">Jobs</a></li>
					<li><a href="<?php echo BASE_URL?>contact">Contact</a></li>
					<li><a href="<?php echo BASE_URL?>partners">Partner With Us</a></li>
					<li><a href="<?php echo BASE_URL?>terms">Terms</a></li>
					<li><a href="<?php echo BASE_URL?>privacy">Privacy</a></li>
				</ul>
				<div style="clear:both"></div>
				<p class="credits">Copyright @ 2014 <?php echo $info['domain']?>. All rights reserved.</p>
			
				<?php echo $info['footer_banner'];?>
			</center>
        </div>

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://code.jquery.com/jquery.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
    </body>
</html>