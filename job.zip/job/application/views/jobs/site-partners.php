<?php  
    include 'header.php';
?>
		<style type="text/css">
			.HeaderPartnerWith{
				margin-bottom: 20px;
			}
			.HeaderPartnerWith img{
				display: inline-block;
			}
			.wrapPage2All{background:none repeat scroll 0% 0% #F0F0F0 !important;}
			.blckBckgrnd{
				background: none repeat scroll 0 0 #000;
				-webkit-box-shadow: 0 0 3px rgba(255, 255, 255, 0.4);
				box-shadow: 0 0 3px rgba(255, 255, 255, 0.4);
				color: #fff;
				margin-bottom: 10px;
				padding-top: 20px;
				padding-bottom: 20px;
			}
			.blckBckgrnd a{
				color: #e9e9e9;
			}
		</style>
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php include('navigation.php');?>
        </div>
        <div class="wrapPage2All">
        <div class="container thirdPadTop">
           <div class="row">
                <div class="col-lg-12 text-center HeaderPartnerWith">
                    <!--a href="http://<?//echo $info['domain']?>">
                        <img class="img-responsive" border="0" style="max-width:500px" title="<?//echo $info['domain']?>" alt="<?//echo $info['domain']?>" src="<?//echo $info['logo']?>">
                    </a-->
                    <h2 style="margin-top: -20px;">Learn more about Joining our Partner Network</h2>
                    <!--<button data-target="#form-container" data-toggle="modal" class="btn btn-large btn-primary btn-lg" id="show_partner_dialog" type="button">
                        Join Our Partner Network
                    </button>-->
					<!-- Button trigger modal -->
					<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
					  Join Our Partner Network
					</button>
					
                </div>
				
				<!-- approved partners -->
					<?foreach($partners AS $partner):?>
						<div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
							<div class="row">
								<div class="col-lg-4">
									<a href="<?echo $partner['url']?>">
										<img alt="<?echo $partner['company_name']?>" src="<?echo $partner['image']?>">
									</a>
								</div>
								<div class="col-lg-8">
									<h3><a href="<?echo $partner['url']?>"><?echo $partner['company_name']?></a></h3>
									<p>
										<?echo $partner['summary']?>
									</p>
									<p>
										<?echo $partner['description']?>
									</p>
								</div>
							</div>
						</div>
					<?endforeach;?>
				<!-- approved partners -->
				
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://contrib.com">
                                <img alt="Contrib.com" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png">
                            </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://contrib.com">Contrib.com</a></h3>
                            <p>
                                Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://globalventures.com">
                                <img alt="GlobalVentures.com" src="http://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png">
                            </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://globalventures.com">GlobalVentures.com</a></h3>
                            <p>
                                Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly.
                                Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://ifund.com">
                                <img class="img-responsive" alt="iFund.com" src="http://www.contrib.com/uploads/logo/ifund.png">
                            </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://ifund.com">iFund.com</a></h3>
                            <p>
                                iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
                                advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
                                investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
                                iFund receives no compensation in connection with the purchase or sale of securities.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://ichallenge.com">
                                <img class="img-responsive" alt="iChallenge.com" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png">
                            </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://ichallenge.com">iChallenge.com</a></h3>
                            <p>
                                The best internet challenges. Solve and win online prizes.
                            </p>
                        </div>
                    </div>
                </div>
				
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                             <a href="http://socialid.com">
                                  <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-socialid1.png" alt="SocialId.com" />
                             </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://socialid.com">SocialId.com</a></h3>
                            <p>
                                SocialId helps you get the social name for all major social networking websites.
                            </p>
                        </div>
                    </div>
                </div>				
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                             <a href="http://virtualinterns.com">
                                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png" alt="Virtualinterns.com" />
                             </a>
                        </div>
                        <div class="col-lg-8">
                             <h3><a href="http://socialid.com">Virtualinterns.com</a></h3>
                             <p>
                                Join our exclusive community of like minded people on virtualinterns.com
                             </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                             <a href="http://referrals.com">
                                  <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png" alt="Referrals.com" />
                             </a>
                        </div>
                        <div class="col-lg-8">
                             <h3><a href="http://referrals.com">Referrals.com</a></h3>
                             <p>
                                 Most effective Business Referral Program and Tools Available. Find and share referrals locally.
                             </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://bidtellect.com">
                                <img class="img-responsive" src="http://www.bidtellect.com/wp-content/uploads/2014/10/logo-nav1-171x53.png" alt="bidtellect.com" />
                            </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://bidtellect.com">Bidtellect.com</a></h3>
                            <p>
                                The First Open, Multi-format, Multi-device Native Exchange Connecting Advertisers and Publishers to Deliver Native Advertising at Scale.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://consultants.com">
                                 <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png" alt="consultants.com" />
                            </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://consultants.com">Consultants.com</a></h3>
                            <p>
                                Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://domainholdings.com">
                                 <img class="img-responsive" src="http://www.domainholdings.com/wp-content/uploads/2014/03/dh-logo-medium-31.png" alt="domainholdings.com" />
                            </a>
                        </div>
                        <div class="col-lg-8">
                            <h3><a href="http://domainholdings.com">Domainholdings.com</a></h3>
                            <p>
                                Domain Holdings is an award winning domain brokerage company specializing in premium domain sales and stealth brand acquisitions.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-lg-offset-1 blckBckgrnd">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="http://handyman.com">
                                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png" alt="handyman.com" />
                            </a>
                        </div><!-- span4 -->
                        <div class="col-lg-8">
                            <h3><a href="http://handyman.com">Handyman.com</a></h3>
                            <p>
                                Handyman.com is the best place to find a professional contractor.
                            </p>
                        </div><!-- span8 -->
                    </div>
                </div>
				
				
                
            </div>
        </div>
</div>
		
		<style type="text/css">
			.modal-body {
				max-height: 480px !important;
				padding-left:20% !important;
			}
		</style>
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Submit Partnership Application</h4>
			  </div>
			  <div class="modal-body">
			  <div id="form-container-inquire" style="display:block;">
				<? include 'service_partner.php'; ?>
				</div>
				<div class="clearfix"></div>
			  </div>
			 <div class="modal-footer">
				&nbsp;
			 </div>
			</div>
		  </div>
		</div>
		
        <?php include ('footer.php')?>
