				<div class="row">
                    <div class="col-lg-12">
                        <div class="wrap-scndLevel-2">
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="form-group inputStyleIcon inputleft">
                                        <form method="post" action="<?php echo BASE_URL?>jobs/search">
                                        <input type="text" class="form-control" placeholder="search jobs" name="search">
                                        </form>
                                        <span class="fa fa-search form-control-feedback"></span>
                                    </div>
                                </div>
                                <div class="col-lg-9 text-right">
                                    <a href="http://www.contrib.com/home/signin" target="_blank" class="btn btn-warning">Login</a>
                                    <a href="javascript:void();" class="btn btn-info" data-toggle="modal" data-target="#signupModal">Signup</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				<!-- Signup Modal -->
				<? include 'signup.php'; ?>
			