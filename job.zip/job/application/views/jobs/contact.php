<?php  
    include 'header.php';
?>

		<style>
		.chooseCat .radio{ margin: 25px 0; font-size: 16px; }
		</style>

        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php include('navigation.php');?>
        </div>
        
        <div class="wrapPage2All">
            <div class="container margDown">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="col-lg-6">
                            <h2 class="pageTitle">Contact <?=ucwords($info['domain'])?></h2>
                        </div>
                        <div class="col-md-6">
                            
                           
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="wrapSecondSectn">
                <div class="container margNgtvUp">
                    <div class="row">
                      
                        <div class="col-lg-12 whteS1" style="padding-bottom: 50px;">
                            <div class="row" >
								<div class="col-lg-7" >
									<div class="wrapContactUs" style="margin: 30px;">
										<h4> Please choose any of the options that interests you : </h4>
										<br/>
										<div class="chooseCat">
											<div class="radio">
												<label>
													<input type="radio" name="optionsRadios" id="partner" value="option1">
													Partner / Develop with <?echo ucfirst($info['domain'])?>
												</label>
											</div>
											<div class="radio">
												<label>
													<input type="radio" name="optionsRadios" id="staffing" value="option2">
													Staffing Opportunities with <?echo ucfirst($info['domain'])?>
												</label>
											</div>
											<div class="radio">
												<label>
													<input type="radio" name="optionsRadios" id="offer" value="option3">
													Submitting an Offer for <?echo ucfirst($info['domain'])?>
												</label>
											</div>
											<div class="radio">
												<label>
													<input type="radio" name="optionsRadios" id="inquiry" value="option4">
													Inquire / Sponsor with <?echo ucfirst($info['domain'])?>
												</label>
											</div>
										</div>     
                                        
									</div>
								</div>
                                
                                <div class="col-lg-5"> 
									<div id="show_logo">
										<img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-ecorp2.png" style="margin: -65px 0 0 -50px;"/>
									</div>
									<div id="show_partner" class="form_include">
										<? include 'service_partner.php'; ?>
									</div>
									<div id="show_staffing" class="form_include">
										<? include 'service_staffing.php'; ?>
									</div>
									<div id="show_offer" class="form_include">
										<? include 'service_offer.php'; ?>
									</div>
									<div id="show_inquiry" class="form_include">
										<? include 'service_inquiry.php'; ?>
									</div>
                                </div>
                            </div>
                        </div>
                        
                        
                   
                    </div>
                </div>
            </div>
        </div>	
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('.form_include').hide();

				$('input[type="radio"][name="optionsRadios"]').change(function() {
					$('#show_logo').hide();
					$('.form_include').hide();
					
					var id = $(this).attr('id');					
					$("#show_"+id).show();
				});
			});
		</script>
              <?php include ('footer.php')?>
