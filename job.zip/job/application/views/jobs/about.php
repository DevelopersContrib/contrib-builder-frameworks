<?php  
    include 'header.php';
?>
<style>
.bckgrnds1,.bckgrnds1:hover p:first-child{
	background:none;
	color:#fff !important;
}
.wrapPage2All {background:none repeat scroll 0% 0% #F0F0F0 !important;}

</style>
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php include('navigation.php');?>
        </div>
        
        <div class="wrapPage2All">
            <div class="container margDown">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="col-lg-6">
                            <h2 class="">About <?=ucwords($info['domain'])?></h2>
                        </div>
                        <div class="col-md-6">
                            
                           
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="wrapSecondSectn">
                <div class="container margNgtvUp">
                    <div class="row">
                      
                        <div class="col-lg-12 whteS1" style="background-color: #000000;">
                            <div class="row" style="background: rgba(0,0,0,0.4);">
                               
                                    <div class="col-lg-8 bckgrnds1" >
                                          <p class="p-desc stripe-text right text-left" style="font-size:17px">
                                                <span class="p-intro"><?=ucwords($info['domain'])?></span>
                                                Platform is part of the Global Ventures Network.											
                                                
                                                <?//=$description?> 
                                                <br>
                                                <br>
                                                Founded in 1996, Global Ventures is the worlds largest virtual Domain Development Incubator on the planet.
                                                <br>
                                                <br>
                                                We create and match great domain platforms with talented people, applications and resources to build successful, value driven, web-based businesses. Join the fastest growing Virtual Business Network and earn Equity and Cowork with other great people making a difference.
                                            </p>
                                            <br />
                                            <p class="p-desc stripe-text left text-left">
                                                <a href="http://globalventures.com" target="_blank" class="btn btn-primary btn-large">
                                                    Learn about this site
                                                </a>
                                            </p>
                                    </div>
                                
                                <div class="col-lg-4 rght4s1">
                                    <img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-ecorp2.png" style="margin: -110px 0 0 -50px;"/>
                                </div>
                            </div>
                        </div>
                        
                        
                   
                    </div>
                </div>
            </div>
        </div>
              <?php include ('footer.php')?>
