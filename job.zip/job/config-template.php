<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $introduction = "{{INTRODUCTION}}";
    $piwik_id = "{{PIWIK_ID}}";
    $footer_banner = "{{FOOTER_BANNER}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $data_widget_users = {{WIDGETS}};
    $data_widget_jobs = {{JOBS}};
    $related_domains = {{RELATED_DOMAINS}};
    $vertical_domains = {{VERTICAL_DOMAINS}};
    $vertical_domains_nologo = {{VERTICAL_DOMAINS_NOLOGO}};
    $rolesarray = {{ROLES}};
	$countriesarray = {{COUNTRIES}};
	$industriesarray = {{INDUSTRIES}};
	$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
    $partners = {{PARTNERS}};
    $sites = {{SITES}};
    $formdata = {{FORMDATA}};
    
?>