<?php 
function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}

if (!file_exists('config-framework.php')) {
     
    $file = file_get_contents('config-template.php');
    $api_url = "http://api3.contrib.co/request/";
    $headers = array('Accept: application/json');
    
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    //$domain = 'http://www.ladyhub.com';
    
    if(stristr($domain, '~') ===FALSE) {
    	$domain = $_SERVER["HTTP_HOST"];
      $domain = str_replace("http://","",$domain);
    	$domain = str_replace("www.","",$domain);
    	$key = md5($domain);
    }else {
       $key = md5('vnoc.com');
       $d = explode('~',$domain);
       $user = str_replace('/','',$d[1]);
        $host = $_SERVER["HTTP_HOST"];
		$host = str_replace("http://","",$host);
		$host = str_replace("www.","",$host);
		$url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key.'&host='.$host;
       $result =  createApiCall($url, 'GET', $headers, array());
       $data_domain = json_decode($result,true);
       $error = 0;
       $domain =   $data_domain['data']['domain'];
    	
    }
    
    
    
    
    
    $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
    $result =  createApiCall($url, 'GET', $headers, array());
    $data_domain = json_decode($result,true);
    
    $error = 0;
     if ($data_domain['success']){	
     	
           
                $domainid = $data_domain['data']['DomainId'];
                $domainname = $data_domain['data']['DomainName'];
                $memberid = $data_domain['data']['MemberId'];
                $title = $data_domain['data']['Title'];
                $logo = $data_domain['data']['Logo'];
                $description = $data_domain['data']['Description'];
                $account_ga = $data_domain['data']['AccountGA'];
    			
    			
    			$url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
    			 $result2 =  createApiCall($url2, 'GET', $headers, array());
    			$data_domain2 = json_decode($result2,true);
    			
    			if($data_domain2['success']){
    				$background_image = $data_domain2['data']['background_image_url'];
    				$introduction = $data_domain2['data']['introduction'];
    				$about = $data_domain2['data']['about'];
    				$forsale = $data_domain2['data']['show_for_sale_banner'];
    				$forsaledefault = $data_domain2['data']['show_for_sale_banner_DefaultValue'];
    				$forsaletext = $data_domain2['data']['for_sale_text'];
    				if($forsaletext=='') $forsaletext = 'This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.';
    	
            $url3 = $api_url.'GetPiwikId?domain='.$domain.'&key='.$key;
            $result3 = createApiCall($url3, 'GET', $headers, array());
    	      $data_domain3 = json_decode($result3,true);
            $piwik_id = $data_domain3['data']['idsite'];
     
    			}
    			
          	}else {
          		$error++;
    }
    
    
    
 
    
    
    $url = $api_url.'getdomainleadscount?domain='.$domain.'&key='.$key;
		    $result = createApiCall($url, 'GET', $headers, array());
		    $data_follow_count = json_decode($result,true);
			 if ($data_follow_count['success']){
			    	$follow_count = ($data_follow_count['data']['leads'] + 1 ) * 25;
			    }else {
			    	$follow_count = 1 * 25;
			}
    
    
    $url = $api_url.'getsignupformdata';
     $result =  createApiCall($url, 'GET', $headers, array());
    $data_signup = json_decode($result,true);
   
    	$roles = $data_signup['data']['roles'];
    	$intentions = $data_signup['data']['intentions'];
    	$industries = $data_signup['data']['industries'];
    	$experiences = $data_signup['data']['experiences'];
    
    //get domain affiliate id
    $url = $api_url.'getdomainaffiliateid?domain='.$domain.'&key='.$key;
     $result =  createApiCall($url, 'GET', $headers, array());
    $data_domain_affiliate = json_decode($result,true);
    if ($data_domain_affiliate['success']){
		    	$domain_affiliate_id = $data_domain_affiliate['data']['affiliate_id'];
		    }else {
		    	$domain_affiliate_id = '391'; //contrib.com affiliate id
	   }
    
   
    $domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$domain;

	//partners
	$url = $api_url.'getpartners?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $partners_result = json_decode($result,true);
    
    if ($partners_result['success']){
		$approved_partner = $partners_result;
    }	
	
	//get related domains with logos only and with category slug
	$url = $api_url.'getrelateddomains?domain='.$domain.'&limit=20';
	$result = createApiCall($url, 'GET', $headers, array());
	$data = json_decode($result,true);
	$vertical_domains = array();
	if ($data['success']){
		$vertical_domains = $data['data'];
	}
	
	//get related domains with nologos and with category slug
	$url4 = $api_url.'getrelateddomainsnologo?domain='.$domain.'&limit=20';
	$result4 = createApiCall($url4, 'GET', $headers, array());
	$data4 = json_decode($result4,true);
	$vertical_domains_nologo = array();
	if ($data4['success']){
		$vertical_domains_nologo = $data['data'];
	}

	//get fund campaigns
	$url = $api_url.'getfundcampaigns';
	$result = createApiCall($url, 'GET', $headers, array());
	$data = json_decode($result,true);
	$fundcampaigns = array();
	if ($data['success']){
		$fundcampaigns = $data['data'];
	}
	
	
	
	//create file
  $file = str_replace('{{DOMAIN}}',$domain , $file);
  $file = str_replace('{{DOMAIN_ID}}',$domainid , $file);
  $file = str_replace('{{MEMBER_ID}}',$memberid, $file);
  $file = str_replace('{{TITLE}}',$title, $file);
  $file = str_replace('{{LOGO}}',$logo, $file);
  $file = str_replace('{{DESCRIPTION}}',$description, $file);
  $file = str_replace('{{ACCOUNT_GA}}',$account_ga, $file);
  $file = str_replace('{{PIWIK_ID}}',$piwik_id, $file);
  $file = str_replace('{{BACKGROUND_IMAGE}}',$background_image, $file);
  $file = str_replace('{{INTRODUCTION}}',$introduction, $file);
  $file = str_replace('{{ABOUT}}',$about, $file);
  $file = str_replace('{{SHOW_FOR_SALE}}',$forsale, $file);
  $file = str_replace('{{SHOW_FOR_SALE_DEFAULT}}',$forsaledefault, $file);
  $file = str_replace('{{FOR_SALE_TEXT}}',$forsaletext, $file);
  $file = str_replace('{{FOLLOW_COUNT}}',$follow_count, $file);
  $file = str_replace('{{AFF_LINK}}',$domain_affiliate_link, $file);
  $file = str_replace('{{ROLES}}',var_export($roles, true), $file);
  $file = str_replace('{{INTENTIONS}}',var_export($intentions, true) , $file);
  $file = str_replace('{{INDUSTRIES}}',var_export($industries, true), $file);
  $file = str_replace('{{EXPERIENCES}}',var_export($experiences, true), $file);
  $file = str_replace('{{PARTNERS}}',var_export($approved_partner, true), $file);
  $file = str_replace('{{VERTICAL_DOMAINS}}',var_export($vertical_domains, true), $file);
  $file = str_replace('{{VERTICAL_DOMAINS_NOLOGO}}',var_export($vertical_domains_nologo, true), $file);
  $file = str_replace('{{FUND_CAMPAIGNS}}',var_export($fundcampaigns, true), $file);
  file_put_contents('config-framework.php', $file);
}

include "./config-framework.php";

if(defined('ENV')){
$config['base_url'] = 'http://localhost/leadv5/'; // Base URL including trailing slash (e.g. http://localhost/)
}else{
$config['base_url'] = '/';	
}
$config['default_controller'] = 'home'; // Default controller to load
$config['error_controller'] = 'error'; // Controller used for errors (e.g. 404, 500 etc)

$config['db_host'] = ''; // Database host (e.g. localhost)
$config['db_name'] = ''; // Database name
$config['db_username'] = ''; // Database username
$config['db_password'] = ''; // Database password
?>