<?php

class Developers extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		if ($formdata['success']){
		     $roles = $formdata['data']['roles'];
	    	 $intentions = $formdata['data']['intentions'];
	    	 $industries = $formdata['data']['industries'];
	    	 $experiences = $formdata['data']['experiences'];
        }	
		$template = $this->loadView('developers');
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('follow_count',$api->getleadscount());
		$template->set('roles',$roles);
		$template->set('intentions',$intentions);
		$template->set('industries',$industries);
		$template->set('experiences',$experiences);
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
    
}

?>
