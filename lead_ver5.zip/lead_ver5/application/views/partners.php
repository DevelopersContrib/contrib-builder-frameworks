<?include('header.php')?>
<?	
	$partners_list = array();
	if(!$partners == ""):
		$partners_list = $partners['data'];
	endif;
?>
<style type="text/css">
	.blckBckgrnd{
		background: rgba(0,0,0,.8);
		padding: 20px 15px;
		margin-bottom: 10px;
		box-shadow: 0 0 3px rgba(255, 255, 255, 0.4);
		color: #fff;
	}
</style>

<div class="container-fluid lead-reset-padd"  style="background: url(/img/bg-socialholdings.jpg) repeat;">
    <div class="row-fluid">
        <div class="wrap-ad">
            <div class="container overflow-ad">
                <div class="row-fluid">
                    
                    <div class="content-ad" style="text-align: justify;">
                        
                        <a name="top"></a>


                        <div class="row-fluid text-center">
                        	<a href="/contact" class="btn btn-large btn-primary">
                        		Join Our Partner Network
                        	</a>
                        	<br/>
                        </div>
                        <br/>
                        <div class="padd-banner">
                            <div class="row-fluid">
                                <div class="span2">
                                    &nbsp;
                                </div>
                                <div class="span8">
                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://contrib.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png" alt="Contrib.com" title="Contrib.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://contrib.com">Contrib.com</a></h3>
                                            <p>
                                                Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>

                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://globalventures.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png" alt="GlobalVentures.com" title="GlobalVentures.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://globalventures.com">GlobalVentures.com</a></h3>
                                            <p>
                                                Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly.
                                                Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.
                                            </p>
                                            <p>
                                                With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>

                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://ifund.com">
                                                <img src="http://www.contrib.com/uploads/logo/ifund.png" alt="iFund.com" title="iFund.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://ifund.com">iFund.com</a></h3>
                                            <p>
                                                iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
                                                advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
                                                investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
                                                iFund receives no compensation in connection with the purchase or sale of securities.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>

                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://ichallenge.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png" alt="iChallenge.com" title="iChallenge.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://ichallenge.com">iChallenge.com</a></h3>
                                            <p>
                                                The best internet challenges. Solve and win online prizes.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                       <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://socialid.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-socialid1.png" alt="SocialId.com" title="socialid.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://socialid.com">SocialId.com</a></h3>
                                            <p>
                                                SocialId helps you get the social name for all major social networking websites.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                      <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://virtualinterns.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png" alt="Virtualinterns.com" title="virtualinterns.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://socialid.com">Virtualinterns.com</a></h3>
                                            <p>
                                               Join our exclusive community of like minded people on virtualinterns.com
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://referrals.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png" alt="Referrals.com" title="referrals.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://referrals.com">Referrals.com</a></h3>
                                            <p>
                                               Most effective Business Referral Program and Tools Available. Find and share referrals locally.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>

                                     <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://bidtellect.com">
                                                <img src="https://d1p6j71028fbjm.cloudfront.net/logos/Bidtellect_logoH.png" alt="bidtellect.com" title="bidtellect.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://bidtellect.com">Bidtellect.com</a></h3>
                                            <p>
                                              The First Open, Multi-format, Multi-device Native Exchange Connecting Advertisers and Publishers to Deliver Native Advertising at Scale.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://consultants.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png" alt="consultants.com" title="consultants.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://consultants.com">Consultants.com</a></h3>
                                            <p>
                                              Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                      <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://domainholdings.com">
                                                <img src="https://www.domainholdings.com/wp-content/uploads/dh-logo-medium-31.png" alt="domainholdings.com" title="domainholdings.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://domainholdings.com">Domainholdings.com</a></h3>
                                            <p>
                                              Domain Holdings is an award winning domain brokerage company specializing in premium domain sales and stealth brand acquisitions.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>

                                      <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://handyman.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png" alt="handyman.com" title="handyman.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://handyman.com">Handyman.com</a></h3>
                                            <p>
                                              Handyman.com is the best place to find a professional contractor.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>



                                    <!-- start dynmic partners -->


                                    <?foreach($partners_list AS $partner_detail):?>
										<div class="row-fluid blckBckgrnd">
											<div class="span4">
												<a href="<?echo $partner_detail['url'];?>">
													<img src="<?echo $partner_detail['image'];?>" alt="<?echo $partner_detail['company_name'];?>" title="<?echo $partner_detail['company_name'];?>">
												</a>
											</div><!-- span4 -->
											<div class="span8">
												<h3><a href="<?echo $partner_detail['url'];?>"><?echo $partner_detail['company_name'];?></a></h3>
												<p><?echo $partner_detail['summary'];?></p>
												<p><?echo $partner_detail['description'];?></p>
											</div><!-- span8 -->
										</div>
                                    <?endforeach;?>
                                    <!-- dynamic partners -->
                                </div>
                                <div class="span2">
                                    &nbsp;
                                </div>
                            </div><!-- row-fluid -->
                        </div><!-- padd-banner -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!--3rd section-->

<?include('footer.php');?>