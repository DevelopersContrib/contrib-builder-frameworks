<?php global $footer_html?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet" />
					</div><!-- span12 -->
                </div><!-- row-fluid -->
            </div>
            <div class="clearfix" style="margin-top:190px;"></div>
        </div>
       <div class="clearfix"></div> 
	   <br />
       
		
		<? if(sizeof($vertical_domains)>0){ ?>
		<style>
		.u-vr2 li{
			margin-bottom: 30px;
		}
		.u-vr2 li img{
			max-height: 50px;
		}
		.u-vr2.text-2 li{
			margin-bottom: 10px;
			font-size: 18px;
		}
		.u-vr2.text-2 i{
			font-size: 14px;
		}
		.brdr-lead:before{
			content: "";
			border-bottom: 1px solid #404040;
			height: 15px;
			width: 500px;
			position: absolute;
		}
		.brdr-lead:before{
			left: -482px;
		}
		.brdr-lead:after{
			content: "";
			border-bottom: 1px solid #404040;
			height: 15px;
			width: 500px;
			position: absolute;
		}
		.brdr-lead:after{
			right: -485px;
		}
		.brdr-lead{
			padding: 0 30px;
			display: inline;
			font-size: 18pt;
			line-height: 30px;
			position: relative;
			text-transform: uppercase;

		}
		.lead-ttle-top{
			margin-top: 40px;
			margin-bottom: 20px;
			clear: both;
			overflow: hidden;
		}
		.credits {
			color:#ccc !important;
		}
		</style>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<div class="container-fluid" style="background:none repeat scroll 0 0 #fafafa; padding: 50px 0px 90px;">
			<div class="row-fluid">
				<div class="container">
					<div class="row-fluid">
						<div class="row-fluid text-center lead-ttle-top">
							<h1 class="brdr-lead">
								Other Brands on <?=str_replace('-',' ',$vertical_domains[0]['slug'])?> Vertical
							</h1>
						</div>
						<div class="row-fluid">
							<div class="span-12">
								<div class="row-fluid">
									<div class="span6">
										<div class="row-fluid">
											<div class="span6">
												<ul class="unstyled u-vr2">
													<? $row_cnt = 0; ?>
													<? shuffle($vertical_domains); ?>
													<? foreach($vertical_domains as $row){ ?> 
														<li>
															<a href="http://<?=$row['domain_name']?>" target="_blank">
																<img src="<?=$row['logo']?>" alt="<?=$row['domain_name']?>" title="<?php echo $row['domain_name'];?>">
															</a>
														</li>
														<? $row_cnt++; ?>
														<? if($row_cnt==6) break; ?>
														<? if($row_cnt%3==0){ ?>
																</ul>
															</div>
														<div class="span6">
															<ul class="unstyled u-vr2">
														<? }?> 
													<? } ?>
												</ul>
											</div>
										</div>
									</div>
									<div class="span6">
										<div class="row-fluid" style="background: none repeat scroll 0 0 #fff;border: 1px solid #ddd;padding: 10px 0 10px 15px;border-radius:4px;">
											<div class="span6">
												<ul class="unstyled u-vr2 text-2">
													<? $row_cnt1 = 0; ?>
													<? shuffle($vertical_domains_nologo); ?>
													<? foreach($vertical_domains_nologo as $row1){ ?>
														<li>
															<i class="icon-star-empty"></i>
															<a href="http://<?=$row1['domain_name']?>" target="_blank">
																<?=ucwords($row1['domain_name'])?>
															</a>
														</li>
														<? $row_cnt1++; ?>
														<? if($row_cnt1==12) break; ?>
														<? if($row_cnt1%6==0){ ?>
																</ul>
															</div>
														<div class="span6">
															<ul class="unstyled u-vr2 text-2">
														<? } ?>
													<? } ?>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="row-fluid text-center">
							<div class="span12">
								<a href="https://www.contrib.com/verticals/news/<?=$vertical_domains[0]['slug']?>" target="_blank" class="btn btn-primary">
									<i class="icon-search"></i>
									View more
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<? } ?>
        <br>
		 <div class="container">
            <section class="text-center">
                <img alt="Applications.com Consultants.com, Globalventures.com, Referrals.com, Venturecamp.com" title="Applications.com Consultants.com, Globalventures.com, Referrals.com, Venturecamp.com" src="https://www.contrib.com/img/logos-gray-colored.png" />
            </section>
        </div>
		
        <!-- new footer-->
<div class="footer-top">
	<div class="container">
		<div class="border row-fluid">
		  <div class="border span3">
			<h3><?php echo ucfirst($info['domain']);?></h3>
			<p>is a proud venture of Global Ventures, LLC. Join our network of performance based companies using <?php echo $domain?>.</p>
		  </div>
		  <div class="border span3">
			<h3>Get Started</h3>
			<ul class="list-unstyled">
				<li><a href="/partners">Partner With Us</a></li>
				<!-- <li><a href="/staffing">Apply Now</a></li> -->
				<li><a href="/referral">Referral</a></li>
				<li><a href="/fund">Fund</a></li>
				<li><a href="/developers">Developers</a></li>
			</ul>
		  </div>
		  <div class="border span3">
			<h3>Company</h3>
			<ul class="list-unstyled">
				<li><a href="/about">About Us</a></li>
				<li><a href="/terms">Terms</a></li>
				<li><a href="/privacy">Privacy</a></li>
				<li><a href="/contact">Contact Us</a></li>
				<li><a href="/apps">Apps</a></li>
			</ul>
		  </div>
		  <div class="border span3">
			<h3>Partners</h3>
			<?if($footer_html != ""):?>
				<?echo base64_decode($footer_html)?>
				<?php else:?>
				<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
			<?endif;?>		
			<h3>Social</h3>
			<?php global $social_fb, $social_gplus,$social_twitter,$social_linkedin, $social_gtube?>
			<ul class="list-inline socials-ul">
											<li>
												<a title="facebook" class="icon-button facebook" alt="facebook" href="<?php echo $social_fb?>">
													<i class="fa fa-facebook-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="google-plus" class="icon-button google-plus" alt="google plus" href="<?php echo $social_gplus?>">
													<i class="fa fa-google-plus-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="youtube" class="icon-button youtube" alt="youtube" href="<?php echo $social_gtube?>">
													<i class="fa fa-youtube-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="linkedin" class="icon-button linkedin" alt="linkedin" href="<?php echo $social_linkedin?>">
													<i class="fa fa-linkedin-square"></i>
													<span></span>
												</a>
											</li>
			</ul>
		  </div>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class="border row">
		  <div class="border span6"><span class="credits">&copy; <?php echo date("Y")." ".ucfirst($info['domain']);?>. All Rights Reserved.</span></div>
		  <div class="border span6">
			  <ul class="list-inline">			
				<li><a href="/about"><i class="fa fa-bookmark-o"></i> About Us</a></li>
				<li><a href="/terms"><i class="fa fa-book"></i> Terms</a></li>
				<li><a href="/privacy"><i class="fa fa-cube"></i> Privacy</a></li>
				<li><a href="/contact"><i class="fa fa-phone-square"></i> Contact Us</a></li>
			  </ul>
		  </div>
		</div>
	</div>
</div>
<!-- new footer-->
		
        <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
		<script src="<?php echo $base_url?>js/jquery.counter.js" type="text/javascript"></script>
    </body>
</html>