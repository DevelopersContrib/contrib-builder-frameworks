					</div><!-- span12 -->
                </div><!-- row-fluid -->
            </div>
            <div class="clearfix" style="margin-top:190px;"></div>
        </div>
       <div class="clearfix"></div> 
	   <br />
       
		
		<? if(sizeof($vertical_domains)>0){ ?>
		<style>
		.u-vr2 li{
			margin-bottom: 30px;
		}
		.u-vr2 li img{
			max-height: 50px;
		}
		.u-vr2.text-2 li{
			margin-bottom: 10px;
			font-size: 18px;
		}
		.u-vr2.text-2 i{
			font-size: 14px;
		}
		.brdr-lead:before{
			content: "";
			border-bottom: 1px solid #404040;
			height: 15px;
			width: 500px;
			position: absolute;
		}
		.brdr-lead:before{
			left: -482px;
		}
		.brdr-lead:after{
			content: "";
			border-bottom: 1px solid #404040;
			height: 15px;
			width: 500px;
			position: absolute;
		}
		.brdr-lead:after{
			right: -485px;
		}
		.brdr-lead{
			padding: 0 30px;
			display: inline;
			font-size: 18pt;
			line-height: 30px;
			position: relative;
			text-transform: uppercase;

		}
		.lead-ttle-top{
			margin-top: 40px;
			margin-bottom: 20px;
			clear: both;
			overflow: hidden;
		}
		</style>
		<div class="container-fluid" style="background:none repeat scroll 0 0 #F2F2F2;padding-bottom:25px;">
			<div class="row-fluid">
				<div class="container">
					<div class="row-fluid">
						<div class="row-fluid text-center lead-ttle-top">
							<h1 class="brdr-lead">
								Other Brands on <?=str_replace('-',' ',$vertical_domains[0]['slug'])?> Vertical
							</h1>
						</div>
						<div class="row-fluid">
							<div class="span-12">
								<div class="row-fluid">
									<div class="span6">
										<div class="row-fluid">
											<div class="span6">
												<ul class="unstyled u-vr2">
													<? $row_cnt = 0; ?>
													<? shuffle($vertical_domains); ?>
													<? foreach($vertical_domains as $row){ ?> 
														<li>
															<a href="http://<?=$row['domain_name']?>" target="_blank">
																<img src="<?=$row['logo']?>" alt="<?=$row['domain_name']?>">
															</a>
														</li>
														<? $row_cnt++; ?>
														<? if($row_cnt==6) break; ?>
														<? if($row_cnt%3==0){ ?>
																</ul>
															</div>
														<div class="span6">
															<ul class="unstyled u-vr2">
														<? }?> 
													<? } ?>
												</ul>
											</div>
										</div>
									</div>
									<div class="span6">
										<div class="row-fluid" style="background: none repeat scroll 0 0 #fff;border: 1px solid #ddd;padding: 10px 0 10px 15px;border-radius:4px;">
											<div class="span6">
												<ul class="unstyled u-vr2 text-2">
													<? $row_cnt1 = 0; ?>
													<? shuffle($vertical_domains_nologo); ?>
													<? foreach($vertical_domains_nologo as $row1){ ?>
														<li>
															<i class="icon-star-empty"></i>
															<a href="http://<?=$row1['domain_name']?>" target="_blank">
																<?=ucwords($row1['domain_name'])?>
															</a>
														</li>
														<? $row_cnt1++; ?>
														<? if($row_cnt1==12) break; ?>
														<? if($row_cnt1%6==0){ ?>
																</ul>
															</div>
														<div class="span6">
															<ul class="unstyled u-vr2 text-2">
														<? } ?>
													<? } ?>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="row-fluid text-center">
							<div class="span12">
								<a href="http://www.contrib.com/verticals/news/<?=$vertical_domains[0]['slug']?>" target="_blank" class="btn btn-primary">
									<i class="icon-search"></i>
									View more
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<? } ?>
        <br>
		 <div class="container">
            <section class="text-center">
                <img alt="Applications.com Consultants.com, Globalventures.com, Referrals.com, Venturecamp.com" src="http://www.contrib.com/img/logos-gray-colored.png" />
            </section>
        </div>
		
        <footer class="footer-two">
            <div class="container">
                <div class="row-fluid text-center">
                    <p class="p-footer-two">&copy; 2013-2016 Global Ventures | All Rights Reserved</p>
                         <?php echo $footer_banner?>
                </div>
            </div>
        </footer>
        <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
		<script src="<?php echo $base_url?>js/jquery.counter.js" type="text/javascript"></script>
    </body>
</html>