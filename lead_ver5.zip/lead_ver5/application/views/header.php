<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $info['title']?></title>		
		<link rel="canonical" href="http://<?=$info['domain']?>/<?=str_replace('.php','',basename($_SERVER['PHP_SELF']))?>" />
		<meta charset="utf-8">
		<meta name="robots" content="index, follow" />       
        <meta name="description" content="<?php echo ucfirst($info['domain'])?> - <?php echo stripcslashes($info['description'])?>">
        <meta name="keywords"  content="<? echo $info['keywords']?>"/>        
        <meta name="author" content="<?php echo $info['domain']; ?>">

        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css">
		<link rel="stylesheet" href="<?php echo $base_url?>css/jquery.fileupload-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url?>js/jquery.counter-analog.css" media="screen" type="text/css" />
        <link rel="stylesheet" href="<?php echo $base_url?>js/jquery.counter-analog2.css" media="screen" type="text/css" />
        <link rel="stylesheet" href="<?php echo $base_url?>css/custom.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
		<script type="text/javascript">
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', '<?php echo $info['account_ga']?>']);
		  _gaq.push(['_trackPageview']);		
		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		</script>
    <!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->


		<style>	
		<? if($attr['background_image']==""){?>
		.background-rep{ background: url("https://d1p6j71028fbjm.cloudfront.net/backgrounds/biz-wallpaper.jpg") no-repeat scroll center bottom rgba(0, 0, 0, 0) !important; 
		}
		<?}else{?>
		.background-rep{ background: url(https://d1p6j71028fbjm.cloudfront.net/backgrounds/biz-wallpaper.jpg) no-repeat fixed; background-size: cover;background-attachment: fixed; background-position: center center;
		}
		<? } ?>
		body{
		    padding-top: 0;
		}
		.navbr-radius .navbar-inner{
		    border-radius: 0;
		}
		.navbr-radius{
		    margin-bottom: 0;
		}
		.background-rep{
			position: relative;
			margin-bottom: -20px;
		    padding-top: 100px;
		}
		.navbar .container{
		    width: 1170px;
		}
		.bg-overlay {
			background-color: rgba(0, 0, 0, 0.80);
			bottom: 0;
			left: 0;
			position: absolute;
			right: 0;
			top: 0;
		}
		.media-body, .media-left, .media-right {
			display: table-cell;
			vertical-align: top;
		}
		.media-left, .media > .pull-left {
			padding-right: 10px;
		}
		.media-right, .media > .pull-right {
			padding-left: 10px;
		}
		.contrib-task-container .media-heading {
			margin: 10px;
		}
		.contrib-task-container .media-right .btn-danger {
			margin-top: 5px;
		}
		</style>
    </head>
    <body>
		<? if($attr['forsale']=='1' || $attr['forsaledefault']=='1'){ ?>
		<div style="padding:10px 0 10px 0; margin:0; color: #fff; background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
            <?=$attr['forsaletext']?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$info['domain']?>" target="_blank" style="color:blue;">Inquire now</a>.
        </div>
		<? } ?>
		<div style="position:relative;">
			<div style="position: absolute; z-index: 10; top: 0; right: 30px;" class="animated rotateIn r-d">
			   <a href="<?=$domain_affiliate_link;?>" target="_blank" alt="Contrib">
					<img alt="Contrib" title="Contrib Badge" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-3.png">
				</a>
			</div>
		</div>
	
        <div class="navbar navbar-inverse navbr-radius">
            <div class="navbar-inner">
                <div class="container">
                    
                    <!-- .btn-navbar is used as the toggle for collapsed navbar content -->
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    
                    <!-- Be sure to leave the brand out there if you want it shown -->
					<? if($info['logo']==''){ ?>
						<a class="brand" href="http://www.<?php echo $info['domain'];?>"><?php echo ucfirst($info['domain']);?></a>
                    <? }else{ ?>
						<a class="brand" href="http://www.<?php echo $info['domain'];?>/" style="padding: 5px;"><img src="<?php echo $info['logo'];?>" alt="<?php echo ucfirst($info['domain']);?>" title="<?php echo ucfirst($info['domain']);?>" style="height:30px;"></a>
                    <? } ?>                    
                    <!-- Everything you want hidden at 940px or less, place within here -->
                    <div class="nav-collapse collapse">
                        <ul class="nav navbar-nav">
                            <!--li><a href="/contact.html"><i class="icon-home icon-white"></i> Contact</a></li-->
                            <li><a href="<?php echo $base_url?>contact"><i class="icon-home icon-white"></i> We are Hiring!</a></li>                            
							<li><a href="<?php echo $base_url?>about"><i class="icon-tags icon-white"></i> About</a></li>
                            <li><a href="<?php echo $base_url?>terms"><i class="icon-inbox icon-white"></i> Terms</a></li>
                            <li><a href="<?php echo $base_url?>privacy"><i class="icon-wrench icon-white"></i> Privacy</a></li>
                            <li><a href="<?php echo $base_url?>partners"><i class="icon-group icon-white"></i> Partners</a></li>
                            <li><a href="<?php echo $base_url?>referral"><i class="icon-signin icon-white"></i> Referral</a></li>
                            <li><a href="<?php echo $base_url?>fund"><i class="icon-briefcase icon-white"></i> Fund our venture</a></li>
                            <li><a href="<?php echo $base_url?>developers"><i class="icon-code icon-white"></i> Developers</a></li>
							<li><a href="<?php echo $base_url?>apps"><i class="icon-rocket icon-white"></i> Apps</a></li>
                        </ul>
                    </div>
                    
                </div>
            </div>
        </div><!--Menu Navigation-->
		
		
        <div class="background-rep">
			<div class="bg-overlay"></div>
            <div class="container" style="position:relative;">
			
			
                <div >
                    <div >