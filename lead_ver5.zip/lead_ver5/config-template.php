<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $piwik_id = '{{PIWIK_ID}}';
    $description = stripslashes(str_replace('\n','<br>',$description));
    
    $background_image = "{{BACKGROUND_IMAGE}}";
    $introduction =  "{{INTRODUCTION}}";
    $about =  "{{ABOUT}}";
    $forsale = "{{SHOW_FOR_SALE}}";
    $forsaledefault = "{{SHOW_FOR_SALE_DEFAULT}}";
	$forsaletext = "{{FOR_SALE_TEXT}}";
    
    
    $follow_count = "{{FOLLOW_COUNT}}";
    
    $domain_affiliate_link = "{{AFF_LINK}}";
   
	$vertical_domains = {{VERTICAL_DOMAINS}};
    $vertical_domains_nologo = {{VERTICAL_DOMAINS_NOLOGO}};
    $fundcampaigns = {{FUND_CAMPAIGNS}};
   
    $roles = {{ROLES}};
    $intentions = {{INTENTIONS}};
    $industries = {{INDUSTRIES}};
    $experiences = {{EXPERIENCES}};
    $partners = {{PARTNERS}};
?>