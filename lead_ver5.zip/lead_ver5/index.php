<?php
/*
 * PIP v0.5.3
 */

//Start the Session
//session_start(); 

// Defines
define('ROOT_DIR', realpath(dirname(__FILE__)) .'/');
define('APP_DIR', ROOT_DIR .'application/');
// Includes
require(APP_DIR .'config/config.php');
require(ROOT_DIR .'system/model.php');
require(ROOT_DIR .'system/view.php');
require(ROOT_DIR .'system/controller.php');
require(ROOT_DIR .'system/pip.php');

// Define base URL
global $config;
global $domain;
global $domainid;
global $title;
global $logo;
global $description;
global $account_ga;
global $description;
global $background_image;
global $introduction;
global $about;
global $forsale;
global $forsaletext;
global $follow_count;
global $domain_affiliate_link;
global $roles;
global $intentions;
global $industries ;
global $experiences;
global $partners;

define('BASE_URL', $config['base_url']);
pip();

?>
