<?php if (!defined('APPLICATION')) exit();

WriteComment($Comment, $this, $Session, $CurrentOffset);