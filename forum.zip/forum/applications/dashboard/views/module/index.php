<?php if (!defined('APPLICATION')) exit();
$this->Data('_Module')->Render();