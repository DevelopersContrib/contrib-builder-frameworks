<?php if (!defined('APPLICATION')) exit();
$PluginInfo['AdsenseBetweenThreads'] = array(
   'Name' => 'AdSense Between Threads',
   'Description' => "Inserts your 728 x 90 AdSense code randomly between Threads in FrontPage. check out my other plugins @ http://www.goodoldmemories.com",
   'Version' => '1.0.1',   
   'Author' => "Adrian Lee",
   'AuthorUrl' => 'http://www.goodoldmemories.com',
   'AuthorEmail' => 'l33.adrian@gmail.com',
   'RegisterPermissions' => FALSE,
   'SettingsPermission' => FALSE,
   'Requires' => FALSE,
   'HasLocale' => FALSE
);
class GoogleAdSenseAfterDiscussionPlugin implements Gdn_IPlugin{
	private $NUM = 0;
	private $NUMPos;
	public function __construct(){		
		$max = (Gdn::Config('Vanilla.Discussions.PerPage')?Gdn::Config('Vanilla.Discussions.PerPage'):30);		
		$this->NUMPos = rand(1,$max);
		//If you dont want to randomize it
		/**
			comment the 
			//$this->NUMPos = rand(1,$max);
			and replace the rand function with the position number you want it to appear
			$this->NUMPos = 10 //means after every 10th thread
		**/
	}
	public function DiscussionsController_BetweenDiscussion_Handler(&$Sender) {
		$this->NUM++;
		if($this->NUM == $this->NUMPos){
echo '
			<script type="text/javascript"><!--
				google_ad_client = "ca-pub-XXXXXXXXXXXXXXXX";
				google_ad_slot = "XXXXXXXXXX";
				google_ad_width = 728;
				google_ad_height = 90;
				//-->
				</script>
				<script type="text/javascript"
					src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>';
			}
	}
	public function Setup(){	
	}
}
?>