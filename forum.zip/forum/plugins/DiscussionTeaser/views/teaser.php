<div class="Info">
<?php echo '<p><span class="TeaserTitle">'.sprintf(T('"DiscussionTeaserTitle"','%s ...'),$this->Data['Name']);?>
<?php echo sprintf(T('DiscussionTeaserIntro','&nbsp;</span>Welcome to %s. You are probably seeing this because a member wished share this discussion with you.</p><p>This forum category is for private members. If you wish to apply you are welcome to <a href="%s" target="_blank">register</a>.</p>'),C('Garden.Title'),$this->Data['RegisterUrl']); ?>
</div>
