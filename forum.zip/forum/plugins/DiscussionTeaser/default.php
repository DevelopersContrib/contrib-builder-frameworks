<?php if (!defined('APPLICATION')) exit();
/**
* # Discussion Teaser #
* 
* ### About ###
* When viewing discussions with redirect to a teaser if viewer is guest without the category view permissions. Use for plugins like ShareThis on a private forum
* 
* ### Sponsor ###
* Special thanks to ryanopaz & Vrazon (http://vrazon.com) for making this happen.
*/
$PluginInfo['DiscussionTeaser'] = array(
	'Name' => 'Discussion Teaser',
	'Description' => 'When viewing discussions with redirect to a teaser if viewer is guest with private community. Use for plugins like Share on a private forum',
	'Version' => '0.1.1b',
	'Author' => "Paul Thomas",
	'AuthorEmail' => 'dt01pqt_pt@yahoo.com	',
	'AuthorUrl' => 'http://vanillaforums.org/profile/x00'
);



class DiscussionTeaser extends Gdn_Plugin {
	
	public function DiscussionController_Teaser_Create($Sender,$Args){
		if(count($Args)<2){
			throw PermissionException();
		}
		//make sure no superfluous text, so the right stuff get scraped. 
		unset($Sender->Assets);
		$DiscussionID = $Args[0];
		$DiscussionModel = new DiscussionModel();
		$Discussion = $DiscussionModel->GetID($DiscussionID);
		$Sender->SetData('Name',Gdn_Format::Text($Discussion->Name));
		if(Gdn_Format::Url($Discussion->Name)!=Gdn_Format::Url($Args[1])){
			throw PermissionException();
		}
		$RegisterUrl=Url(C('Plugins.DiscussionTeaser.RegisterUrl',C('Garden.Authenticator.RegisterUrl')));
		$Sender->SetData('RegisterUrl',$RegisterUrl);
		$Sender->AddCssFile('teaser.css','plugins/DiscussionTeaser/');
		$ThemeViewLoc = CombinePaths(array(
			PATH_THEMES, $Sender->Theme,'views', 'discussionteaser'
		));
		if(file_exists($ThemeViewLoc.DS.strtolower($Sender->RequestMethod).'.php')){
			$Sender->Render('Teaser','discussionteaser','');
		}else{
			$Sender->Render('Teaser','','plugins/DiscussionTeaser');
		}
		
		
	}
	
	public function Base_BeforeBlockDetect_Handler($Sender,&$Args){
			$ParsedRequest = Gdn::Request()->Export('Parsed');
			$Path = strtolower($ParsedRequest['Path']);
			if(preg_match('/^discussion\/*([0-9]+)(\/.*)?$/',$Path, $Match)){
				if(C('Garden.PrivateCommunity')   && !Gdn::Session()->IsValid()){
					Redirect(str_replace('discussion/','discussion/teaser/',$Path ),301);
				}else{;
					$DiscussionID = $Match[1];
					$DiscussionModel = new DiscussionModel();
					$Discussion = $DiscussionModel->GetID($DiscussionID);
					if(!Gdn::Session()->CheckPermission('Vanilla.Discussions.View', TRUE, 'Category', $Discussion->PermissionCategoryID))
						Redirect(str_replace('discussion/','discussion/teaser/',$Path ),301);
				}
			}
		$Args['BlockExceptions']['/discussion\/teaser\/d+(\/.*)?$/']=Gdn_Dispatcher::BLOCK_NEVER;
	}
	

    /* setup spec*/
    
	public function Base_BeforeDispatch_Handler($Sender){
		if(C('Plugins.DiscussionTeaser.Version')!=$this->PluginInfo['Version'])
			$this->Structure();
	}
    
	public function Setup() {
		$this->Structure();
	}

	public function Structure() {
		//Save Version for hot update

		SaveToConfig('Plugins.DiscussionTeaser.Version', $this->PluginInfo['Version']);
	}
    /* setup spec*/
}
