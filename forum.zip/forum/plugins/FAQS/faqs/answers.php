<!--README-->
<!--
Change my-forum-theme-name to name of your theme 
-->

<li style="display:none;">
	<p><span class="plus_icon">+</span><a class="faq" href="javascript:;">Where is blah blah blah Located ?</a></p>
		<div class="answer">
			<h5 class="question">Where is blah blah blah Located ?</h5>
			<p>Find us at 1 letsbe avenue</p><br />
			<p>Check us out <a href="/my-forum-theme-name/location">here</a></p>
		</div>
</li>

<li style="display:none;">
	<p><span class="plus_icon">+</span><a class="faq" href="javascript:;">Contact Us ?</a></p>
		<div class="answer">
			<h4 class="question">Contact Us ?</h4>
			<p>You can contact us by hitting the contact link in the menu, or clicking <a href="/my-forum-theme-name/contact">here</a></p>
			
		</div>
</li>


					

					<!-- this is format of an answer below 
					<li style="display:none;">
						<p><span class="plus_icon">+</span><a class="faq" href="javascript:;"> ?</a></p>
							<div class="answer">
								<h4 class="question"> ?</h4>
								<p></p>
							</div>
					</li>
					-->

				<!--to use numbers -->
					<!--
					<span class="number">1</span>blah blah blah<br />
					<span class="number">2</span>blah blah blah<br />
					<span class="number">3</span>blah blah blah<br />
					<span class="number">4</span>blah blah blah<br />
					<span class="number">5</span>blah blah blah<br />
					-->

					<!--to add an image use this -->
					<!-- <p><img src="themes/my-forum-theme-name/faqs/images/my-score.png"></p> -->