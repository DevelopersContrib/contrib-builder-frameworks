<?php if (!defined('APPLICATION')) exit();
/*
Copyright 2008, 2009 Vanilla Forums Inc.
This file is part of Garden.
Garden is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
Garden is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with Garden.  If not, see <http://www.gnu.org/licenses/>.
Contact Vanilla Forums Inc. at support [at] vanillaforums [dot] com
*/

// Define the plugin:
$PluginInfo['AddThis'] = array(
   'Name' => 'AddThis',
   'Description' => 'This plugin adds AddThis (http://addthis.com) buttons to the bottom of each post.',
   'Version' => '1.2',
   'RequiredApplications' => FALSE,
   'RequiredTheme' => FALSE, 
   'RequiredPlugins' => FALSE,
   'SettingsUrl' => '/dashboard/plugin/addthis',
   'SettingsPermission' => 'Garden.AdminUser.Only',
   'HasLocale' => TRUE,
   'RegisterPermissions' => FALSE,
   'Author' => "Huy (modified from ShareThis of digibomb)",
   'AuthorEmail' => 'huy@bh8.vn',
   'AuthorUrl' => 'http://www.bh8.vn'
);


class AddThisPlugin extends Gdn_Plugin {

	public function DiscussionController_AfterComment_Handler($Sender) {
	
		/* Add CSS  for share div */
		
		$Sender->AddCSSFile('plugins/addthis/design/addthis.css');
	
		/* Get the addthis publisher number. */
	$imgurl = C('Plugin.AddThis.imgurl', 'Image Url');
      $PublisherNumber = C('Plugin.AddThis.PublisherNumber', 'Publisher Number');
      $Lang = C('Plugin.AddThis.lang', 'Language);
      $Style = C('Plugin.AddThis.Style', 'AddThis Style');

		if ($Style == 1) {
      $AddThisCode = '<div class="addthis_toolbox addthis_default_style Share">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
</div>';
		} elseif ($Style == 2) {
	  $AddThisCode = '<div class="addthis_toolbox addthis_default_style addthis_32x32_style Share">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
</div>'; 
		} elseif ($Style == 3) {
	  $AddThisCode = '<div class="addthis_toolbox addthis_default_style Share">
<a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
<a class="addthis_button_tweet"></a>
<a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
<a class="addthis_counter addthis_pill_style"></a>
</div>'; 
		} elseif ($Style == 4) {
	  $AddThisCode = '<div class="addthis_toolbox addthis_default_style Share">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;pubid=ra-4f2d3eb91a96ddbc" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
</div>'; 
		} elseif ($Style == 5) {
	  $AddThisCode = '<div class="addthis_toolbox addthis_default_style Share">
<a class="addthis_counter addthis_pill_style"></a>
</div>'; 
		} elseif ($Style == 6) {
	  $AddThisCode = '<div class="Share"><a class="addthis_button" href="http://www.addthis.com/bookmark.php?v=250&amp;pubid=ra-4f2d3eb91a96ddbc"><img src="http://s7.addthis.com/static/btn/v2/lg-share-en.gif" width="125" height="16" alt="Bookmark and Share" style="border:0"/></a>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4f2d3eb91a96ddbc"></script></div>'; 
		} else {
	$AddThisCode = '<div class="Share"><a class="addthis_button" href="http://www.addthis.com/bookmark.php?v=250&amp;pubid=ra-4f2d3eb91a96ddbc"><img src="http://s7.addthis.com/static/btn/sm-share-en.gif" width="83" height="16" alt="Bookmark and Share" style="border:0"/></a>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4f2d3eb91a96ddbc"></script></div>'; 
		}

	   /* Add javascript for AddThis */
    	      $Sender->Head->AddTag('meta', array('content' => '{$imgurl}', 'property' => 'og:image'));
			$Sender->Head->AddTag('meta', array('content' => Gdn_Format::Text($Sender->Discussion->Name), 'property' => 'og:title'));
			$Sender->Head->AddTag('meta', array('content' => Gdn_Url::Request(true, true, true), 'property' => 'og:url'));
			$Sender->Head->AddTag('meta', array('content' => C('Garden.Title'), 'property' => 'og:site_name'));
			$Sender->Head->AddTag('meta', array('content' => 'article', 'property' => 'og:type'));
			$Sender->AddJsFile('http://connect.facebook.net/vi_VN/all.js#xfbml=1');
		$Sender->Head->AddString("<script type=\"text/javascript\" src=\"http://s7.addthis.com/js/250/addthis_widget.js#pubid={$PublisherNumber}\"></script>
						  <script type=\"text/javascript\">
    									var addthis_config = {\"data_track_clickback\":true, ui_language: \"{$lang}\",data_ga_property: \"UA-27795362-1\", data_ga_social: true};
								  </script>");

		/* Display AddThis buttons. */
		if (GetValue('Type', $Sender->EventArguments) != 'Comment') {
			echo $AddThisCode;
		}
	}		

   public function Setup() {
      // Nothing to do here!
   }
   
   public function Structure() {
      // Nothing to do here!
   }
   
  /*Add to dashboard side menu. */ 
  
   public function Base_GetAppSettingsMenuItems_Handler($Sender) {
      $Menu = $Sender->EventArguments['SideMenu'];
      $Menu->AddLink('Add-ons', T('AddThis'), 'plugin/addthis', 'Garden.Settings.Manage');
   }

   public function PluginController_AddThis_Create($Sender) {
   	$Sender->Permission('Garden.AdminUser.Only');
   	$Sender->Title('AddThis');
      $Sender->AddSideMenu('plugin/AddThis');
      $Sender->Form = new Gdn_Form();
      $this->Dispatch($Sender, $Sender->RequestArgs);
   }
   
   /* Define variables for settings page. */
   
   public function Controller_Index($Sender) {
      $PublisherNumber = C('Vanilla.Plugin.PublisherNumber', 'Publisher Number');
      
      $Validation = new Gdn_Validation();
      $ConfigurationModel = new Gdn_ConfigurationModel($Validation);
      
      $ConfigArray = array(
         'Plugin.AddThis.PublisherNumber',
	     'Plugin.AddThis.Style'
      );
      if ($Sender->Form->AuthenticatedPostBack() === FALSE)
         $ConfigArray['Plugin.AddThis.PublisherNumber'] = $PublisherNumber;
      
      $ConfigurationModel->SetField($ConfigArray);
      
      // Set the model on the form.
      $Sender->Form->SetModel($ConfigurationModel);
      
      // If seeing the form for the first time...
      if ($Sender->Form->AuthenticatedPostBack() === FALSE) {
         // Apply the config settings to the form.
         $Sender->Form->SetData($ConfigurationModel->Data);
      } else {
         // Define some validation rules for the fields being saved
         $ConfigurationModel->Validation->ApplyRule('Plugin.AddThis.PublisherNumber', 'Required');
         
         if ($Sender->Form->Save() !== FALSE) {
            $Sender->StatusMessage = T("Your changes have been saved.");
         }
      }
      
      $Sender->Render($this->GetView('addthis.php'));
   }
      
}