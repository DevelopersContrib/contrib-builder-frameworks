<?php if (!defined('APPLICATION')) exit();
$Definition['this is for debugging'] = 'debugging blah blah blah';