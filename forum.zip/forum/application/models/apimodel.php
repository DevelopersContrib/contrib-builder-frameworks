<?php
include("php_fast_cache.php");

class ApiModel extends Model {
	// private $api_url = "https://api1.contrib.co/forum/";
	//private $api_url = "https://184.107.160.133/forum/";
	private $api_url = "https://api2.contrib.co/forum/";
	private $headers = array('Accept: application/json');
	private $api_content_url = "https://api3.contrib.co/announcement/";

	function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null){
    if(($method == 'PUT') || ($method=='DELETE')) {
      $headers[] = 'X-HTTP-Method-Override: '.$method;
    }

    $handle = curl_init();
    curl_setopt($handle, CURLOPT_URL, $url);
    curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);

		if($user) {
    	curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
    }

    switch($method) {
			case 'GET':
				break;
			case 'POST':
				curl_setopt($handle, CURLOPT_POST, true);
				curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
				break;
			case 'PUT':
				curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
				curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
				break;
			case 'DELETE':
				curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
				break;
    }

    $response = curl_exec($handle);
    return $response;
	}

	function getdomain() {
		global $domain;
		return $domain;
	}

	function getkey() {
		return md5($this->getdomain());
	}

	function getdomaininfo() {
		global $domainid;
		global $title;
		global $logo;
		global $description;
		global $account_ga;
		global $domain;
		global $piwik_id;
		global $logo;
		global $forum_topics;
		global $social_fb;
		  global $social_gplus;
		  global $social_twitter;
		  global $social_linkedin;
		  global $social_gtube;
		global $categoryid;
		
		global $background_image;
		global $additional_html;
		
		global $keywords;
		$offers = $this->getOffers($domain);
		$offers = json_encode($offers['offers']);
		
		$ads = $this->getAds($domain);
		$ads = json_encode($ads['ads']);

		$info['background_image']   = $background_image;
		$info['additional_html'] = $additional_html;
		
		$socials = array('fb'=>$social_fb,'gplus'=>$social_gplus,'twitter'=>$social_twitter,'linkedin'=>$social_linkedin,'gtube'=>$social_gtube);
		
		if(isset($_SESSION['user'])){
			$info['member_info'] = $this->getMemberInfo($_SESSION['user'],$domain);
		}

		$info['domainid']    = $domainid;
		$info['domain']      = $domain;
		$info['title']       = $title;
		$info['logo']        = $logo;
		$info['description'] = $description;
		$info['account_ga']  = $account_ga;
		$info['description'] = stripslashes(str_replace('\n','<br>',$info['description']));
		$info['piwik_id']    = $piwik_id;
		$info['forum_topics'] = $forum_topics;
		$info['domain_socials'] = $socials;
		$info['ajax'] = 'https://api2.contrib.co';
		$info['offers'] = $offers;
		$info['ads'] = $ads;
		$info['categoryid'] = $categoryid;
		$info['keywords'] = $keywords;
		
		return $info;
	}

	function getattributes() {
		global $background_image;
		global $additional_html;

		$info['background_image']   = $background_image;
		$info['additional_html'] = $additional_html;

		return $info;
  }

	// function getSocials() {
	// 	global $social_fb;
	//   global $social_gplus;
	//   global $social_twitter;
	//   global $social_linkedin;
	//   global $social_gtube;
	//
	//
	// 	$info['fb']   = $social_fb;
	// 	$info['gplus'] = $social_gplus;
	// 	$info['twitter'] = $social_twitter;
	// 	$info['linkedin'] = $social_linkedin;
	// 	$info['gtube'] = $social_gtube;
	//
	// 	return $info;
	// }

	function createrobots() {
		//	generate robots.txt if not exist
		$filename = ROOT_DIR .'/robots.txt';
		$my_file  = ROOT_DIR .'/robots.txt';
		$handle   = fopen($my_file, 'w') or die('Cannot open file: '.$my_file);
		$data     = '---BEGIN ROBOTS.TXT ---
								User-Agent: *
								Disallow:
								Sitemap: https://'.$this->getdomain().'/sitemap
								--- END ROBOTS.TXT ----';
		fwrite($handle, $data);
	}

	function getPost($slug)
	{
		$url = 'https://api2.contrib.co/forum2/GetPostrow?slug='.$slug;
		$result = $result = $this->createApiCall($url, 'GET', $this->headers, array());
		$data = json_decode($result,true);

		if($data['success']){
			$value = $data['data'];
		}
		return $value;
	}

	function getTopic($slug)
	{
		$url = 'https://api2.contrib.co/forum2/GetTopicrow?slug='.$slug;
		$result = $result = $this->createApiCall($url, 'GET', $this->headers, array());
		$data = json_decode($result,true);

		if($data['success']){
			$value = $data['data'];
		}
		return $value;
	}

	function login($username, $password, $domain){
	    $url = 'https://api2.contrib.co/forum2/login';
	    $result = $this->createApiCall($url, 'POST', $this->headers, array('username'=>$username, 'password'=>$password, 'domain'=>$domain));
	    $data = json_decode($result,true);
		if($data['success']){
			$isLoggedin = $data['data'];
		}
		return $isLoggedin;
	}

	function verifycode($code, $domain) {
		$url = 'https://api2.contrib.co/forum2/verifycode?code='.$code.'&domain='.$domain;
		$result = $result = $this->createApiCall($url, 'GET', $this->headers, array());
		$data = json_decode($result,true);

		if($data['success']){
			$value = $data['data'];
		}
		return $value;
	}

	function signup($username, $email, $password, $domain, $avatar) {
		$url = 'https://api2.contrib.co/forum2/signup';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('username' => $username, 'email' => $email, 'password' => $password, 'domain' => $domain, 'avatar' => $avatar));
		$data = json_decode($result,true);

		if($data['success']) {
			$value = $data['data'];
		}
		return $value;
	}

	// function getCategories($domain) {
	// 	$url = 'https://api2.contrib.co/forum2/getcategories';
	// 	$result = $this->createApiCall($url, 'POST', $this->headers, array('domain'=>$domain));
	// 	$data = json_decode($result, TRUE);
	//
	// 	if($data['success']) {
	// 		$topics = $data['data'];
	// 	}
	//
	// 	return $topics;
	// }

	function addMemberTopics($topics, $username, $domain) {
		$url = 'https://api2.contrib.co/forum2/AddMemberTopics';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('topics'=>$topics, 'username'=>$username, 'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$isTopicAdded = $data['data'];
		}

		return $isTopicAdded;
	}

	function getMemberInfo($username, $domain) {
		$url = 'https://api2.contrib.co/forum2/GetMemberInfo';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('username'=>$username, 'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$member_info = $data['data'];
		}
		return $member_info;
	}

	function updateMemberInfo($username, $email, $avatar, $member_id, $domain) {
		$url = 'https://api2.contrib.co/forum2/UpdateMemberInfo';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('username'=>$username, 'email'=>$email, 'avatar'=>$avatar, 'member_id'=>$member_id, 'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$profile = $data['data'];
		}

		return $profile;
	}

	function changeAccountPassword($password, $member_id) {
		$url = $this->api_url.'ChangeAccountPassword';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('password'=>$password, 'member_id'=>$member_id));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$isPasswordChanged = $data['data'];
		}

		return $isPasswordChanged;
	}

	function loginViaContrib($email, $domain) {
		$url = 'https://api2.contrib.co/forum2/LoginViaContrib';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('email'=>$email, 'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$isLoggedIn = $data['data'];
		}

		return $isLoggedIn;
	}

	function checkIfEmailExists($email, $domain) {
		$url = 'https://api2.contrib.co/forum2/CheckIfEmailExists';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('email'=>$email,'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$isExists = $data['data'];
		}

		return $isExists;
	}
	
	function getuserdetails($email, $domain) {
		$url = 'https://api2.contrib.co/forum2/GetUserDetails';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('email'=>$email,'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$isExists = $data['data'];
		}

		return $isExists;
	}

	function sitemap($domain) {
		//$url = "https://api2.contrib.co/forum2/sitemap?domain=".$domain;
		$url = "https://e7lq80c199.execute-api.us-west-2.amazonaws.com/api1?key=5c1bde69a9e783c7edc2e603d8b25023&request=forum-sitemap&domain=$domain";
		$result = $this->createApiCall($url, 'GET', $this->headers, []);

		return $result;
	}

	function checkUsernameById($username, $member_id) {
		$url = $this->api_url.'CheckUsernameById';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('username'=>$username, 'member_id'=>$member_id));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$isExists = $data['data'];
		}

		return $isExists;
	}

	function CheckEmailById($email, $member_id) {
		$url = $this->api_url.'CheckEmailById';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('email'=>$email, 'member_id'=>$member_id));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$isExists = $data['data'];
		}

		return $isExists;
	}

	function forgotPassword($user_info, $domain) {
		$url = 'https://api2.contrib.co/forum2/ForgotPassword';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('user_info'=>$user_info, 'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$account_details = $data['data'];
		}

		return $account_details;
	}

	function getCategories($uid, $domain) {
		$url = 'https://api2.contrib.co/forum2/GetCategories';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('uid'=>$uid, 'domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$categories = $data['data'];
		}

		return $categories;
	}
	
	function getOffers($domain){
		$url = 'https://api2.contrib.co/forum2/getoffer';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$offers = $data['data'];
		}

		return $offers;
	}
	
	function getAds($domain){
		$url = 'https://api2.contrib.co/forum2/getads';
		$result = $this->createApiCall($url, 'POST', $this->headers, array('domain'=>$domain));
		$data = json_decode($result, TRUE);

		if($data['success']) {
			$ads = $data['data'];
		}

		return $ads;
	}

	function getcontent($domain,$page){
		$key = '5c1bde69a9e783c7edc2e603d8b25023';
		$url = $this->api_content_url.'GetFooterContents?domain='.$domain.'&key='.$key.'&page='.$page;
		$result =  createApiCall($url, 'GET', $headers, array());
		$data_domain = json_decode($result,true);
		$page = "";

		if (isset($data_domain['data']['content'])){
			$page = $data_domain['data']['content'];
		}

		return $page;
	}

}//end of model
?>
