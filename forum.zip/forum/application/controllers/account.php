<?php
/**
 *
 */
// include 'contribclient.php';
class Account extends Controller {
  function index() {

	}

  function signup(){
    $api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();

		$template = $this->loadView('signup');
		$template->set('title', $title);
		$template->set('info', $info);
		$template->render();
  }

  function login(){
    $api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$client = $this->loadHelper('ContribClient');

		$info = $api->getdomaininfo();

		$template = $this->loadView('login');
		$template->set('title', $title);
		$template->set('info', $info);
    $template->set('client', $client);
		$template->render();
  }

} //end of class
?>
