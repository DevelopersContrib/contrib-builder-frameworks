<?php
class Search extends Controller {
	function index() {
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$attribute = $api->getattributes();
		$search = $helper->segment(2);
		
		$clean_search = preg_replace('/\?/', '', $search);
		if(!empty($_GET)){
			foreach($_GET as $key=>$val){
				$clean_search = preg_replace('/&?'.$key.'=[^&]*/', '', $clean_search);
			}
		}
		
		$page = $_GET['page'];
		$page = empty($page)?1:$page;
		$by = $_REQUEST['by'];
		$member = $_REQUEST['member'];
		$bread_crumbs = [];
		
		$bread_crumbs[] = [
			'title'=>'Home',
			'link'=>'/',
		];
		$bread_crumbs[] = [
			'title'=>'search',
			'link'=>'/search/'.$clean_search,
		];
		
		$title = $info['title'];
		$description = $info['domain'].' '.$info['description'];;
		
		$template = $this->loadView('search/index');
		
		$template->set('title', $title);
		$template->set('description', $description);
		
		$template->set('bread_crumbs', $bread_crumbs);
		$template->set('info', $info);
		$template->set('attr', $attribute);
		$template->set('search', $clean_search);
		$template->set('by', $by);
		$template->set('member', $member);
		$template->set('page',$page);
		$template->render();
	}
}