<?php
/**
 *
 */
class Profile extends Controller {
  function index() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');
    $info = $api->getdomaininfo();

    if(!isset($_SESSION['user'])) {
      header("Location: /");
    } else {
      $member_info = $api->getMemberInfo($_SESSION['user'], $info['domain']);
    }

    $template = $this->loadView('profile');
    $template->set('title', 'Update profile');
    $template->set('info', $info);
    $template->set('member_info', $member_info);
		$template->render();
	}

  function update() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');
    $info = $api->getdomaininfo();

    if(!isset($_SESSION['user'])) {
      header("Location: /");
    } else {
        $username = $_POST['username'];
        $email    = $_POST['email'];
        $avatar   = $_POST['avatar'];
        $member_info = $api->getMemberInfo($_SESSION['user'], $info['domain']);
        $member_id = $member_info['member_id'];

        $isUsernameExists = $api->checkUsernameById($username, $member_id);
        $isEmailExists = $api->checkEmailById($email, $member_id);

        if(!$isUsernameExists['isExists'] && !$isEmailExists['isExists']) {
          $data = $api->updateMemberInfo($username, $email, $avatar, $member_id, $info['domain']);					
					
          if($data['status']) {
            $_SESSION['uid'] = base64_encode(strrev($username));
            $_SESSION['user'] = $data['user']['username'];
            $_SESSION['email'] = $data['user']['email'];
            $_SESSION['avatar'] = $data['user']['avatar'];

            echo json_encode(array('success'=>TRUE, 'username'=>$_SESSION['user'], 'email'=>$_SESSION['email'], 'avatar'=>$_SESSION['avatar'], 'message'=>'You have successfully updated your profile.'));
          } else {
            echo json_encode(array('success'=>FALSE, 'message'=>'Sorry unable to update your profile. Please try again!'));
          }
        } elseif($isUsernameExists['isExists']) {
          echo json_encode(array('success'=>FALSE, 'message'=>'Username is not available!'));
        } elseif($isEmailExists['isExists']) {
          echo json_encode(array('success'=>FALSE, 'message'=>'Email address is not available!'));
        }
    }
  }

  function changePassword() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');
    $info = $api->getdomaininfo();

    $password = $_POST['password'];

    if(!isset($_SESSION['user'])) {
      header("Location: /");
    } else {
      $member_info = $api->getMemberInfo($_SESSION['user'], $info['domain']);
      $member_id = $member_info['member_id'];
      $data = $api->changeAccountPassword($password, $member_id);

      if($data['status']) {
        echo json_encode(array('success'=>TRUE));
      } else {
        echo json_encode(array('success'=>FALSE));
      }
    }

  }

} //end of class

?>
