<?php
class Tag extends Controller {
	function index() {
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$attribute = $api->getattributes();
		$tag = $helper->segment(2);
		
		$clean_tag = preg_replace('/\?/', '', $tag);
		if(!empty($_GET)){
			foreach($_GET as $key=>$val){
				$clean_tag = preg_replace('/&?'.$key.'=[^&]*/', '', $clean_tag);
			}
		}
		
		$bread_crumbs[] = [
			'title'=>'Home',
			'link'=>'/',
		];
		$bread_crumbs[] = [
			'title'=>'Tag',
			'link'=>'/tag',
		];
		$bread_crumbs[] = [
			'title'=>$clean_tag,
			'link'=>'/'.$clean_tag,
		];
		
		$page = $_GET['page'];
		$page = empty($page)?1:$page;
		$title = $info['title'];
		$description = $info['domain'].' '.$info['description'];;
		
		$template = $this->loadView('tag/index');
		$template->set('title', $title);
		$template->set('description', $description);
		$template->set('bread_crumbs', $bread_crumbs);
		$template->set('info', $info);
		$template->set('attr', $attribute);
		$template->set('tag', $clean_tag);
		$template->set('page',$page);
		$template->render();
	}
}