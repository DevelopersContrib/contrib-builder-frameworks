<?php
/**
 *
 */
class Sidebar extends Controller {
  function index() {
    $template = $this->loadView('sidebar');
		$template->render();
	}
} //end of class

?>