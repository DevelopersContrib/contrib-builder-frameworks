<?php
/**
 *
 */
class Onboarding extends Controller {
  function index() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');
    $info = $api->getdomaininfo();
    $attributes = $api->getattributes();

    if(!isset($_SESSION['user'])) {
      header("Location: /");
    } else {
      if(isset($_SESSION['uid'])) {
        $categories = $api->getCategories($_SESSION['uid'], $info['domain']);
        if(count($categories) > 5) {
          header("Location: /");
        } else {
          $topics = $api->getCategories('',$info['domain']);


          $title = 'Forum Topics';
          $template = $this->loadView('onboarding');
          $template->set('title', $title);
          $template->set('info', $info);
          $template->set('attr', $attributes);
          $template->set('topics', $topics);
      		$template->render();
        }
      }
    }
	}

  function addTopics() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');
    $info = $api->getdomaininfo();

    if(!isset($_SESSION['user'])) {
      header("Location: /");
    } else {
      if(isset($_POST['topics'])) {
        $data = $api->addMemberTopics($_POST['topics'], $_SESSION['user'], $info['domain']);

        if($data['status']) {
          echo json_encode(array('status'=>TRUE, 'message'=>$data['message']));
        } else {
          echo json_encode(array('status'=>FALSE, 'message'=>$data['message']));
        }
      }
    }
  }
} //end of class

?>
