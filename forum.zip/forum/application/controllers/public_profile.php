<?php
/**
 *
 */
class Public_profile extends Controller {
  function index() {
    $template = $this->loadView('public_profile');
		$template->render();
	}
} //end of class

?>