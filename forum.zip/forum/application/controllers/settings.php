<?php
/**
 *
 */
class Settings extends Controller {
  function index() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');

    $template = $this->loadView('forgot-password');

		$template->render();
	}

  function forgotPassword() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');
    $info = $api->getdomaininfo();

    if(isset($_POST['user_info'])) {
      $user_info = $_POST['user_info'];
    }

    $data = $api->forgotPassword($user_info, $info['domain']);

    if($data) {
      echo json_encode(array('status'=>$data['status'], 'message'=>$data['message']));
    } else {
      echo var_dump($data);
    }

  }
} //end of class

?>
