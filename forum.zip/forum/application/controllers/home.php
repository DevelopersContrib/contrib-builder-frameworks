<?php
/**
 *
 */
// $path = $_SERVER['DOCUMENT_ROOT'];
// $path .= "/application/views/contribsdk/contribclient.php";
// include_once($path);

class Home extends Controller {
  function index(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
    $attribute = $api->getattributes();

    $page = 'index';
    
    $client = $this->loadHelper('ContribClient');

    if(isset($_GET['code'])) {
      if($client->isLoggedIn()===TRUE) {
        $contrib_profile = $client->getUser();
        $username = $contrib_profile['data']['info']['username'];
        $email = $contrib_profile['data']['info']['email'];
        $avatar = $contrib_profile['data']['info']['image'];
        $location = '/';
        $domain = $info['domain'];

        $account = $api->checkIfEmailExists($email, $domain);

        if($account['isExists']) {
          if(!$account['domain_exists']) {
			  $account = $api->getuserdetails($email, $domain);
			  
            $password = base64_encode($account['details']['password']);
            $isSignedUp = $api->signup($account['details']['username'], $email, $password, $domain, $account['details']['avatar']);
            if($isSignedUp['status']) {
              $location = '/onboarding';
            }
          }
					
          $email = base64_encode(strrev($email));
          $data = $api->loginViaContrib($email, $domain);

          if($data['status']) {
            $this->setSessionData($data);
          }
          header("Location: ".$location);

        } else {
          $page = 'signup';
        }
      }
    }
    
    if(!empty($attribute['background_image']) && strpos($attribute['background_image'],'cdn.vnoc') === FALSE){
      $bg = 'https://cdn.vnoc.com/background'.substr($attribute['background_image'],strrpos($attribute['background_image'],'/'));
      $attribute['background_image'] = $bg;
    }
		
		$title = $info['title'];
		$description = $info['domain'].' '.$info['description'];
		$template = $this->loadView($page);
		$template->set('title', $title);
		$template->set('description', $description);
		$template->set('info', $info);
    $template->set('attr', $attribute);
    $template->set('client', $client);
		// $template->set('member_info', $member_info);
    if($page == 'signup') {
      $template->set('username', $username);
      $template->set('email', $email);
      $template->set('avatar', $avatar);
    }
		$template->render();
	}

  function login() {
    $api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
    $client = $this->loadHelper('ContribClient');
    $info = $api->getdomaininfo();

    if(isset($_POST['login_username'])) {
      $username = $_POST['login_username'];
    } else {
      $username = '';
    }

    if(isset($_POST['login_password'])) {
      $password = base64_encode($_POST['login_password']);
    } else {
      $password = '';
    }

    $data = $api->login($username, $password, $info['domain']);

    if($data['status']) {
      $this->setSessionData($data);
    }
		header("Location: /");
	}

  function logout() {
    $api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
    $client = $this->loadHelper('ContribClient');
    $info = $api->getdomaininfo();

    unset($_SESSION['uid']);
    unset($_SESSION['user']);
    unset($_SESSION['email']);
    unset($_SESSION['avatar']);
		unset($_SESSION['account_type']);

    if($client->isLoggedIn()===true) {
      $client->logout('http://'.$info['domain']);
    } else {
      header("Location: /");
    }
  }

  function signup() {
    $api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');

    $username = $_POST['username'];
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $domain   = $_POST['domain'];
    $avatar   = $_POST['avatar'];

    $isSignedUp = $api->signup($username, $email, $password, $domain, $avatar);

    if($isSignedUp['status']) {
      $data = $api->login($username, $password, $domain);
      if($data['status']){
        $this->setSessionData($data);
      }
    }

    echo $isSignedUp['status'];
  }

  function verifycode() {
    $api = $this->loadModel('ApiModel');
    $helper = $this->loadHelper('Url_helper');
    $info = $api->getdomaininfo();

    $uri = $_SERVER['REQUEST_URI'];
		$segment = explode("/", $uri);
  	$code = $segment[3];

    $code = substr($code, 5);

    $data = $api->verifycode($code, $info['domain']);

    if($data['status']) {
      $this->setSessionData($data);
    }

    header("Location: /");
  }

  function setSessionData($data) {
    $_SESSION['uid'] = base64_encode(strrev($data['user']['username']));
    $_SESSION['user'] = $data['user']['username'];
    $_SESSION['email'] = $data['user']['email'];
    $_SESSION['avatar'] = $data['user']['avatar'];
		$_SESSION['account_type'] = $data['user']['account_type'];	
  }

} //end of class
?>
