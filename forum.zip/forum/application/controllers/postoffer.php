<?php
class Postoffer extends Controller {
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');

		$info = $api->getdomaininfo();
		$attribute = $api->getattributes();
		
		
		$bread_crumbs = [];
		$title = $info['title'];
		$description = $info['description'];
		
		$datatitle = '';
		$datadesc = '';
		
		$template = $this->loadView('postoffer/index');
		
		$bread_crumbs[] = [
			'title'=>'Home',
			'link'=>'/',
		];
		$bread_crumbs[] = [
			'title'=>'Post offer',
			'link'=>'/postoffer'
		];
		
		$template->set('title', $title);
		$template->set('description', $description);
		
		$template->set('bread_crumbs', $bread_crumbs);
		$template->set('info', $info);
		$template->set('attr', $attribute);
		
		if($_SESSION['account_type']=='premium'){
			$template->render();
		}else{
			$this->error404();
		}
	}
	
	function error404()
	{
		echo '<h1>404 Error</h1>';
		echo '<p>Looks like this page doesn\'t exist</p>';
	}
}

?>
