<?php
/**
 *
 */
class Feed extends Controller {
	function index() {
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');

		$info = $api->getdomaininfo();
		$attribute = $api->getattributes();
		
		$bread_crumbs[] = [
			'title'=>'Home',
			'link'=>'/',
		];
		$bread_crumbs[] = [
			'title'=>'Feed',
			'link'=>'/feed',
		];
		
		$page = $_GET['page'];
		
		$template = $this->loadView('feed/index');
		$title = $info['title'];
		$description = $info['domain'].' '.$info['description'];;
		
		$title = $info['title'];
		$description = $info['domain'].' '.$info['description'];;
	
		$template->set('bread_crumbs', $bread_crumbs);
		$template->set('info', $info);
		$template->set('title', $title);
		$template->set('description', $description);
		$template->set('attr', $attribute);
		$template->set('page',$page);
		$template->render();
	}
} //end of class

?>
