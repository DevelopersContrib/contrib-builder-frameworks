<?php
/**
 *
 */
class Terms extends Controller {
  function index() {
   $api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$alert_umsg = 'no-error';
		$alert_pmsg = 'no-error';
		$template = $this->loadView('terms');
		$template->set('title', 'Terms');
		$template->set('info', $info);
		$template->set('alert_umsg', $alert_umsg);
		$template->set('alert_pmsg', $alert_pmsg);
		$template->set('content', $api->getcontent($info['domain'],'terms'));
		$template->render();
	}
} //end of class

?>
