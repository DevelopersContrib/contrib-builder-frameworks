<?php
/**
 *
 */
class Index2 extends Controller {
  function index() {
    $template = $this->loadView('index2');
		$template->render();
	}
} //end of class

?>