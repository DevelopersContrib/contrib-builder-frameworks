<?php
class Members extends Controller {
	function index() {
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$attribute = $api->getattributes();
		$member_username = $helper->segment(2);
		
		$title = $info['title'];
		$description = $info['domain'].' '.$info['description'];
	
		$template = $this->loadView('members/index');
		$template->set('info', $info);
		$template->set('attr', $attribute);
		$template->set('member_username', $member_username);
		
		$bread_crumbs[] = [
			'title'=>'Home',
			'link'=>'/',
		];
		$bread_crumbs[] = [
			'title'=>'Members',
			'link'=>'/members/',
		];
		
		if(!empty($member_username)){
			$bread_crumbs[] = [
				'title'=>''.ucwords($member_username),
				'link'=>'/members/'.$member_username,
			];
		}
		
		$template->set('bread_crumbs', $bread_crumbs);
		$template->set('title', $title);
		$template->set('description', $description);
		$template->render();
	}
}