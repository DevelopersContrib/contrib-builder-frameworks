<?php
class Topic extends Controller {
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');

		$info = $api->getdomaininfo();
		$attribute = $api->getattributes();
		
		$topic_slug = $helper->segment(1);
		$post_slug = $helper->segment(2);
		
		$page = $_GET['page'];
				
		$clean_post_slug = preg_replace('/\?/', '', $post_slug);
		if(!empty($_GET)){
			foreach($_GET as $key=>$val){
				$clean_post_slug = preg_replace('/&?'.$key.'=[^&]*/', '', $clean_post_slug);
			}
		}
		
		$clean_topic_slug = preg_replace('/\?/', '', $topic_slug);
		if(!empty($_GET)){
			foreach($_GET as $key=>$val){
				$clean_topic_slug = preg_replace('/&?'.$key.'=[^&]*/', '', $clean_topic_slug);
			}
		}
		
		$bread_crumbs = [];
		$title = $info['title'];
		$description = $info['description'];
		
		$datatitle = '';
		$datadesc = '';
		if(!empty($clean_topic_slug) && empty($clean_post_slug)){ // main page
			$template = $this->loadView('topic/index');
			$bread_crumbs[] = [
				'title'=>'Home',
				'link'=>'/',
			];
			$bread_crumbs[] = [
				'title'=>$clean_topic_slug,
				'link'=>'/'.$clean_topic_slug,
			];
			$topicinfo = $api->getTopic($clean_topic_slug);
			$title = $topicinfo['topic_name']." - Discuss today at Muscleboard.com";
			$description = $topicinfo['description'];
			
			$datatitle = $topicinfo['topic_name'];
			$datadesc = $topicinfo['description'];
		}else if(!empty($clean_topic_slug) && !empty($clean_post_slug)){ // post page
			$template = $this->loadView('post/index');
			$bread_crumbs[] = [
				'title'=>'Home',
				'link'=>'/',
			];
			$bread_crumbs[] = [
				'title'=>$clean_topic_slug,
				'link'=>'/'.$clean_topic_slug,
			];
			$bread_crumbs[] = [
				'title'=>$clean_post_slug,
				'link'=>'/'.$clean_topic_slug.'/'.$clean_post_slug,
			];
			$post = $api->getPost($clean_post_slug);
			$title = $post['title']." - Discuss today at Muscleboard.com";
			$description = $post['description'];
			
			$datatitle = $post['title'];
			$datadesc = $post['description'];
		}else{
			//$this->error404();
			$template = $this->loadView('index');
		}
		
		$all_slug = "$clean_topic_slug/$clean_post_slug";
		
		
		$template->set('title', $title);
		$template->set('description', $description);
		
		$template->set('datatitle', $datatitle);
		$template->set('datadesc', $datadesc);

		$template->set('bread_crumbs', $bread_crumbs);
		$template->set('info', $info);
		$template->set('attr', $attribute);
		$template->set('all_slug', $all_slug);
		$template->set('topic', $clean_topic_slug);
		$template->set('post', $clean_post_slug);
		$template->set('page',$page);
		
		$template->render();
	}
	
	function error404()
	{
		echo '<h1>404 Error</h1>';
		echo '<p>Looks like this page doesn\'t exist</p>';
	}
}

?>
