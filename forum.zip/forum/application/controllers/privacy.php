<?php
/**
 *
 */
class Privacy extends Controller {
  function index() {
     $api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$alert_umsg = 'no-error';
		$alert_pmsg = 'no-error';
		$template = $this->loadView('privacy');
		$template->set('title', 'Privacy');
		$template->set('info', $info);
		$template->set('alert_umsg', $alert_umsg);
		$template->set('alert_pmsg', $alert_pmsg);
		$template->set('content', $api->getcontent($info['domain'],'privacy'));
		$template->render();
  }
} //end of class

?>
