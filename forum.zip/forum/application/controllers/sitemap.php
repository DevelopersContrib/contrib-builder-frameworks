<?php
class Sitemap extends Controller {
	function index() {
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();

		$sitemap = $api->sitemap($info['domain']);

		$description = $info['domain'].' '.$info['description'];;

		$template = $this->loadView('sitemap/index');

		$template->set('title', 'Sitemap');
		$template->set('description', $description);

		$template->set('info', $info);
		$template->set('sitemap', $sitemap);
		$template->render();
	}
}
