<?php
class Pay extends Controller {

	public $amount = 19.00;
  
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$paypal = $this->loadHelper('Paypal');
		$info = $api->getdomaininfo();
		
		$paypal->apiUsername = 'kjcast_1334370520_biz_api1.gmail.com';
		$paypal->apiPassword = '1334370545';
		$paypal->apiSignature = 'AiPC9BjkCyDFQXbSkoZcgqH3hpacA-zy0RMkCrgmgi2.pBo86NbXQIPz';    
		$paypal->apiLive = false;
		
		$paypal->returnUrl = 'http://'.$info['domain'].'/pay/confirm/';
		$paypal->cancelUrl = 'http://'.$info['domain'].'/premium/';
	
		$paypal->init();
		// set 
		$paymentInfo['Order']['theTotal'] = $this->amount;
		$paymentInfo['Order']['description'] = "Some payment description here";
		$paymentInfo['Order']['quantity'] = '1';
		
		// call paypal 
		$result = $paypal->SetExpressCheckout($paymentInfo); 

		//Detect Errors 
		
		$call = $paypal->isCallSucceeded($result);
		
		
		if(!call){ 
			if($paypal->apiLive === true){
				//Live mode basic error message
				$error = 'We were unable to process your request. Please try again later';
			}else{
				//Sandbox output the actual error message to dive in.
				$error = $result['L_LONGMESSAGE0'];
			}
			echo $error;
			
		}else { 
			// send user to paypal 
			$token = urldecode($result["TOKEN"]); 
			
			$payPalURL = $paypal->paypalUrl.$token; 
			header('Location: '.$payPalURL);
		}		
	}
	
	function cancel()
	{
		//The token of the cancelled payment typically used to cancel the payment within your application
		$token = $_GET['token'];
		echo 'cancel';
	}
	
	function confirm()
	{
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$token = trim($_GET['token']);
		$payerId = trim($_GET['PayerID']);
		
		$paypal = $this->loadHelper('Paypal');
		
		$paypal->apiUsername = 'kjcast_1334370520_biz_api1.gmail.com';
		$paypal->apiPassword = '1334370545';
		$paypal->apiSignature = 'AiPC9BjkCyDFQXbSkoZcgqH3hpacA-zy0RMkCrgmgi2.pBo86NbXQIPz';    
		$paypal->apiLive = false;
		
		$paypal->init();
		
		$result = $paypal->GetExpressCheckoutDetails($token);

		$result['PAYERID'] = $payerId; 
		$result['TOKEN'] = $token; 
		$result['ORDERTOTAL'] = $this->amount;
		
		$token = $token;
		$firstname = $result['FIRSTNAME'];
		$lastname = $result['LASTNAME'];
		$email = $result['EMAIL'];
		
		//Detect errors 
		if(!$paypal->isCallSucceeded($result)){ 
			if($paypal->apiLive === true){
				//Live mode basic error message
				$error = 'We were unable to process your request. Please try again later';
			}else{
				//Sandbox output the actual error message to dive in.
				$error = $result['L_LONGMESSAGE0'];
			}
			
			// $status = 'failed';		
			$summary = json_encode(array('checkout_details'=>$result,'error'=>$error));
			
			$data['error'] = $error;
			$data['status'] = FALSE;
			// echo $error;
		}else{ 
			
			$paymentResult = $paypal->DoExpressCheckoutPayment($result);
			//Detect errors  
			if(!$paypal->isCallSucceeded($paymentResult)){
				if($paypal->apiLive === true){
					//Live mode basic error message
					$error = 'We were unable to process your request. Please try again later';
				}else{
					//Sandbox output the actual error message to dive in.
					$error = $paymentResult['L_LONGMESSAGE0'];
				}
				
				// $status = 'failed';
				$summary = json_encode(array('checkout_details'=>$result,'payment_result'=>$paymentResult,'error'=>$error));
				
				$data['error'] = $error;
				$data['status'] = FALSE;
				// echo $error;
			}else{
				//payment was completed successfully			
				$data['amount'] = $paymentResult['AMT'];
				$data['transaction_id'] = $paymentResult['TRANSACTIONID'];
				$data['currency'] = $paymentResult['CURRENCYCODE'];
				$data['status'] = $paymentResult['PAYMENTSTATUS'];
				$data['description'] = 'Upgraded '.$info['domain'].' account to premium';
				$data['summary'] = json_encode(array('checkout_details'=>$result,'payment_result'=>$paymentResult));		
			}
			$template = $this->loadView('payconfirm');
			$template->set('title', 'Pay Confirm '.$info['domain']);
			$template->set('info', $info);
			$template->set('data', $data);			
			$template->render();
		}
	}
}
?>