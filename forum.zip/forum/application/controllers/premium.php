<?php
/**
 *
 */
// $path = $_SERVER['DOCUMENT_ROOT'];
// $path .= "/application/views/contribsdk/contribclient.php";
// include_once($path);

class Premium extends Controller {
  function index(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
    $attribute = $api->getattributes();

		$title = 'Upgrade to Premium Account';
		$description = $info['domain'].' '.$info['description'];
		
    $template = $this->loadView('premium');
		$template->set('title', $title);
		$template->set('description', $description);
		$template->set('info',$info);
		$template->set('attr', $attribute);
		$template->render();
	}
} //end of class
?>
