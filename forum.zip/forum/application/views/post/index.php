<?php include(dirname(__FILE__).'/../header.php');?>
<?php include(dirname(__FILE__).'/../post-container.php');?>
<style>
#forum-sidebar {
    margin-top: 0px;
}
.forum-container {
	margin-top:-20px;
}
.cforum .forum p {
    font-size: 85%;
}
.vote-box {
	border-radius:0px !important;
}
.label {
	font-size:90%;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<?php include(dirname(__FILE__).'/../bread_crumbs.php');?>
			<div class="for-ad-space">
				<?=base64_decode($info['additional_html']);?>
			</div>
			<div id="post" class="thread-container forum-container">
			</div>
		</div>
		<div class="col-md-4">
			<?php include(dirname(__FILE__).'/../sidebar.php');?>
		</div>
	</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#post').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/getposts',
		<?php if($_SESSION['uid']){?>
			data:{uid:encodeURIComponent('<?=$_SESSION['uid']?>'),domain:jQuery('#domain').val(),slug:'<?=$post?>',req:'c',page:'<?=$page?>',all_slug:'<?=$all_slug?>'},
		<?php }else{?>
			data:{slug:'<?=$post?>',req:'c',page:'<?=$page?>',all_slug:'<?=$all_slug?>'},
		<?php }?>
		error: function(){},
		success: function(response){
			jQuery('#post').loading('stop');
			jQuery('#post').html(response.data.html);
		}
	});
});
</script>

<?php include(dirname(__FILE__).'/../footer.php');?>