<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login to <?php echo $info['domain']; ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet" />
<link href="/static/css/forum.css" rel="stylesheet" />
<style>
body {
	background:#000 url(https://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/dvsup.png);
	color:#fff;
}
.form-login {
	width: 350px;
	margin: 0px auto 0px;
}
hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #333;
}
.login-container {
	margin-top:100px;
}
.login-container .fa-times-circle {
	color:#fff;
	font-size:35px;
	float:right;
}
.form-login p {
	font-size:12px;
	margin: 0 0 5px;
}
.clogo {
	height: 22px;
	vertical-align: -5px;
}
.msg {
	background: rgb(250, 250, 250) none repeat scroll 0% 0%;
	color: rgb(51, 51, 51);
	padding: 3px 6px;
	position: absolute;
	border: 1px solid #F87217;
	right: 120px;
	margin-top: 30px;
}
.form-control {
	border:none;
}
.input-lg {
    height: 50px;
    font-weight: bold;
}
</style>
</head>
<body>
	<div class="container login-container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<a href="/home" id=""><i class="fa fa-times-circle" aria-hidden="true"></i></a>
				<hr>
			</div>
			<div class="col-md-6 col-md-offset-3 text-center">
				<form class="form-login" id="login-form" method="POST" action="/home/login">
					<h1>Log In To Forum</h1>
					<div id="login-user-error-container" class="msg msg-warning msg-danger-text hide">
						<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span class="error-msg" id="login-username-error">Please enter username</span>
					</div>
					<input type="text" id="txt-username" class="form-control input-lg" placeholder="username" name="login_username" />
					</br>
					<div id="login-pwd-error-container" class="msg msg-warning msg-danger-text hide">
						<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span class="error-msg" id="login-pwd-error">Please enter password</span>
					</div>
					<input type="password" id="txt-password" class="form-control input-lg" placeholder="password" name="login_password" />
					<hr>
					<input type="hidden" id="current-domain" value="<?php echo $info['domain']; ?>">
					<div class="wrapper">
						<span class="group-btn">
							<a href="" id="btn-login" class="btn btn-danger btn-lg btn-block">Login <i class="fa fa-sign-in" aria-hidden="true"></i></a>
						</span>
						<br>
						<span class="group-btn">
							<?php
								$login_url = $client->LoginUrl('https://www.'.$info['domain'], 'https://www.'.$info['domain']);
								echo '<a href="'.$login_url.'" class="btn btn-warning btn-lg btn-block">Login via <img src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-174x35.png" class="clogo">
								<i class="fa fa-sign-in" aria-hidden="true"></i>
								</a>' ;
							?>
						</span>
						 <br>
						<p><a href="/settings" class=""><i class="fa fa-key" aria-hidden="true" style="font-size: 15px;"></i>&nbsp;Forgot Password?</a></p>
						<p>New user? <a href="/account/signup"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;Create New Account</a></p>
						<p>By logging in you confirm that you accept the <a href="/terms" target="_blank">Terms and Conditions</a> and <a href="/privacy" target="_blank">Privacy Policy</a></p>
						<div id="loader" class="text-center load-container">
							<div class="load-spinner"></div>
							Submitting your data
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="/static/js/signup.js" charset="utf-8"></script>
<script>
	$(document).ready(function() {
		var loader = $('#loader');
		loader.hide();

		$('#btn-login').on('click', function(e) {
			loader.show();

			if(validateLoginForm()) {
				$('#login-form').submit();
			} else {
				loader.hide();
			}
			e.preventDefault();
		});

		$('.form-control').on('keyup', function(e) {
			var key = e.which || e.keyCode;
			if(key == '13' || key == 13) {
				$('#btn-login').trigger('click');
			}
		});

	});
</script>
</body>
</html>
