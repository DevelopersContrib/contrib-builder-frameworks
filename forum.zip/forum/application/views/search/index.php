<?php include(dirname(__FILE__).'/../header.php');?>
<style>
.s-div {
    border: 1px solid #999;
    padding: 10px;
    font-weight: normal;
}
#search-results table p {
	font-size: 13px;
}
#search-results table b span {
	float: right;
	display: block;
	margin-top: -21px;
	margin-left: 10px;
	font-size: 15px;
}
.forum-container {
    margin-bottom: 10px;
}
.ftags {
  display:inline-block;
}
.ftags a {
  font-size:12px !important;
  text-decoration:none;
}
.ftags a span {
  font-size:88% !important;
  padding: 6px 5px 5px 5px !important;
  margin-left:0px !important;
}
.ftags .label-info {
    background-color: #777;
}
.cforum .updated {
    font-size: 11px !important;
    font-style: italic;
    margin-top: 0px !important;
}
#search-results h2 {
	background: rgb(250, 250, 250) none repeat scroll 0% 0%;
padding: 10px;
border-bottom: 1px solid #ddd;
}
#search-results h2:before {
    content: "\f002";
    font-family: FontAwesome;
	margin-right:8px;
}
#forum-sidebar {
    margin-top: 20px;
}
.brc {
	background: #fafafa;
}
.bread_crumbs_container {
    margin-left: 0px;
	margin-bottom: 0px;
}
</style>

<div class="brc">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php include(dirname(__FILE__).'/../bread_crumbs.php');?>
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			
		</div>
		<div id="search-results" class="col-md-8">
			<!--<p>
				See more:&nbsp;<a href="">lorem network</a><a href="">ipsum social</a><a href="">dolor</a><a href="">set</a>
			</p>-->
		</div>
		<div class="col-md-4">
			<?php include(dirname(__FILE__).'/../sidebar.php');?>
		</div>
	</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#search-results').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/search',
		data:{
			search:encodeURIComponent('<?=$search?>'),
			page:'<?=$page?>',
			domain:jQuery('#domain').val(),
			<?php if(!empty($by)){?>
			by:'<?=$by?>',
			<?php }?>
			<?php if(!empty($member)){?>
			member:'<?=$member?>',
			<?php }?>
		},
		error: function(){},
		success: function(response){
			jQuery('#search-results').loading('stop');
			jQuery('#search-results').append(response.data.html);
		}
	});
});
</script>
<div style="margin-bottom:100px;"></div>
<?php include(dirname(__FILE__).'/../footer.php');?>