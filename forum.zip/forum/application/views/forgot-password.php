<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot Password</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet" />
<link href="/static/css/forum.css" rel="stylesheet" />
<style>
body {
  background: #000 url(https://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/dvsup.png);
  padding: 10px;
  font-family: Arial;
}

a {
  color: #004483;
  transition: all ease-in-out 200ms;
}
a:hover {
  text-decoration: none;
}
.fp-container {
	margin-top:80px;
}
.etc-fp-form {
  color: #717171;
  padding: 10px 20px;
}
.etc-fp-form p {
  margin-bottom: 5px;
}
.fp-heading {
	color:#c1c1c1;
}
.fp-form-1 {
  max-width: 400px;
  border-radius: 5px;
  display: inline-block;
}
.main-fp-form {
  position: relative;
}
.fp-form-1 .form-control {
  border: 0;
  box-shadow: 0 0 0;
  border-radius: 0;
  background: transparent;
  color: #555555;
  padding: 7px 0;
  font-weight: bold;
  height:auto;
}
.fp-form-1 .form-control::-webkit-input-placeholder {
  color: #999999;
}
.fp-form-1 .form-control:-moz-placeholder,
.fp-form-1 .form-control::-moz-placeholder,
.fp-form-1 .form-control:-ms-input-placeholder {
  color: #999999;
}
.fp-form-1 .form-group {
  margin-bottom: 0;
  border-bottom: 2px solid #efefef;
  padding-right: 20px;
  position: relative;
}
.fp-form-1 .form-group:last-child {
  border-bottom: 0;
}
.fp-group {
  background: #ffffff;
  color: #999999;
  border-radius: 8px;
  padding: 10px 20px;
}
.fp-group-checkbox {
  padding: 5px 0;
}
.fp-form-1 .fp-button {
  position: absolute;
  right: -25px;
  top: 50%;
  background: #ffffff;
  color: #999999;
  padding: 11px 0;
  width: 50px;
  height: 50px;
  margin-top: -25px;
  border: 5px solid #efefef;
  border-radius: 50%;
  transition: all ease-in-out 500ms;
}
.fp-form-1 .fp-button:hover {
  color: #333333;
  /*transform: rotate(450deg);*/
}
.fp-form-1 .fp-button.clicked {
  color: #333333;
}
.fp-form-1 .fp-button.clicked:hover {
  transform: none;
}
.fp-form-1 .fp-button.clicked.success {
  color: #2ecc71;
}
.fp-form-1 .fp-button.clicked.error {
  color: #e74c3c;
}
.fa-times-circle {
	font-size:35px;
	float:right;
	color:#fff;
}
hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #333;
}
.fp-container .form-control {
    font-size: 18px;
}
.fp-alert {
	display: inline-block;
	position: absolute;
	margin-top: -60px;
	border: 1px solid red;
	padding: 2px 8px;
	left: 0px;
	border-radius: 6px;
	background: #fff;
	color: #666;
}
.fp-or h3{
	margin:3px 0px 3px;
	color:#717171;
}
</style>
</head>
<body>
	<div class="container fp-container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<a href="/home" id=""><i class="fa fa-times-circle" aria-hidden="true"></i></a>
				<hr>
			</div>
			<div class="col-md-6 col-md-offset-3 text-center">
				<div class="alert alert-success hide" role="alert"></div>
				<div class="alert alert-danger hide" role="alert"></div>
				<div class="text-center">
					<h2 class="fp-heading"><i class="fa fa-unlock-alt" aria-hidden="true"></i>&nbsp;Forgot Password</h2>
					<!-- Main Form -->
					<div class="fp-form-1">
						<form id="forgot-password-form" class="text-center">
							<div class="etc-fp-form">
								<p>When you fill in your registered email address, you will be sent instructions on how to reset your password.</p>
							</div>
							<div class="main-fp-form">
								<div class="fp-group">
									<div class="form-group">
										<label for="fp_email" class="sr-only">Email address</label>
										<input type="text" class="form-control" id="fp_email" name="fp_email" placeholder="email address">
										<span class="fp-alert hide"></span>
									</div>
								</div>
								<button type="submit" class="fp-button"><i class="fa fa-chevron-right"></i></button>
							</div>
							<div class="fp-or"><h3>OR</h3></div>
							<div class="main-fp-form">
								<div class="fp-group">
									<div class="form-group">
										<label for="fp_username" class="sr-only">Username</label>
										<input type="text" class="form-control" id="fp_username" name="fp_userna'" placeholder="username">
										<!-- <span class="fp-alert" id="alert-usr"><i class="fa fa-exclamation-circle" aria-hidden="true"></i>&nbsp;Alert here</span> -->
									</div>
								</div>
								<button type="submit" class="fp-button"><i class="fa fa-chevron-right"></i></button>
							</div>
							<div class="etc-fp-form">
								<p>Already have an account? <a href="/account/login"><i class="fa fa-key" aria-hidden="true"></i>&nbsp;Login Here</a></p>
								<p>New user? <a href="/account/signup"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;Create New Account</a></p>
							</div>
						</form>
					</div>
          <div id="loader" class="text-center load-container hide">
            <div class="load-spinner"></div>
            Submitting your data
          </div>
				</div>
			</div>
		</div>
	</div>
<script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script>
  $(document).ready(function() {
    $('.fp-button').on('click', function(e) {
      var email = $('#fp_email').val();
      var username = $('#fp_username').val();

      $('.alert').html('').addClass('hide');
      $('.fp-alert').html('').addClass('hide');

      if(validateForm()) {
        forgotPassword();
      }
      e.preventDefault();
    });
  });

  function validateForm() {
    var email = $('#fp_email').val();
    var username = $('#fp_username').val();
    var error = 0;

    if(!email && !username) {
      $('.alert-danger').html('Please provide your email or username!').removeClass('hide');
      error++;
    } else if(email) {
      if(!validateEmail(email)) {
        $('.fp-alert').html('<i class="fa fa-exclamation-circle" aria-hidden="true"></i>&nbsp;Please provide a valid email address!').removeClass('hide');
        error++;
      }
    }

    if(error > 0) {
      return false;
    } else {
      return true;
    }
  }

  function validateEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
  }

  function forgotPassword() {
    var loader = $('#loader');
    var url = '/settings/forgotPassword';
    var email = $('#fp_email').val();
    var username = $('#fp_username').val();
    var data = '';

    loader.removeClass('hide');

    if(email) {
      data = email;
    } else {
      data = username;
    }

    $.ajax({
      type: 'POST',
      url: url,
      data: { user_info: data },
      success: function(res) {
        var response = $.parseJSON(res);
        // console.log(response);
        if(response.status) {
          $('.alert-success').html(response.message).removeClass('hide');
        } else {
          $('.alert-danger').html(response.message).removeClass('hide');
        }
        loader.addClass('hide');
      }
    });
  }
</script>
</body>
</html>
