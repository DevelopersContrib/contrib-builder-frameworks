<?php include(dirname(__FILE__).'/../header.php');?>
<style>
.s-div {
    border: 1px solid #999;
    padding: 10px;
    font-weight: normal;
}
#tag-results table p {
	font-size: 13px;
}
#tag-results table b span {
	float: right;
	display: block;
	margin-top: -21px;
	margin-left: 10px;
	font-size: 15px;
}
.forum-container {
    margin-bottom: 10px;
}
.ftags {
  display:inline-block;
}
.ftags a {
  font-size:12px !important;
  text-decoration:none;
}
.ftags a span {
  font-size:88% !important;
  padding: 6px 5px 5px 5px !important;
  margin-left:0px !important;
}
.ftags .label-info {
    background-color: #777;
}
.pull-right a {
	color:#EC971F;
}
#tag-results h2 {
	background: rgb(250, 250, 250) none repeat scroll 0% 0%;
padding: 10px;
border-bottom: 1px solid #ddd;
}
#tag-results h2:before {
    content: "\f02c";
    font-family: FontAwesome;
	margin-right:5px;
}
#forum-sidebar {
    margin-top: 20px;
}
.brc {
	background: #fafafa;
}
.bread_crumbs_container {
    margin-left: 0px;
	margin-bottom: 0px;
}
</style>

<div class="brc">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php include(dirname(__FILE__).'/../bread_crumbs.php');?>
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			
		</div>
		<div id="tag-results" class="col-md-8">
			<!--<p>
				See more:&nbsp;<a href="">lorem network</a><a href="">ipsum social</a><a href="">dolor</a><a href="">set</a>
			</p>-->
		</div>
		<div class="col-md-4">
			<?php include(dirname(__FILE__).'/../sidebar.php');?>
		</div>
	</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#tag-results').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/tag',
		data:{
			tag:encodeURIComponent('<?=$tag?>'),
			page:'<?=$page?>',
			domain:jQuery('#domain').val(),
		},
		error: function(){},
		success: function(response){
			jQuery('#tag-results').loading('stop');
			jQuery('#tag-results').append(response.data.html);
		}
	});
});
</script>
<div style="margin-bottom:100px;"></div>
<?php include(dirname(__FILE__).'/../footer.php');?>