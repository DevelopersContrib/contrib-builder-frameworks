<?php include('header.php');?>

<style>
.page-container {
	background:white;
	padding:20px;
	margin-top:20px;
	margin-bottom:50px;
}
.page-container h3 {
	margin-top: 0px;
}
.page-container .blur-box {
	border-bottom: 1px solid #eee;
	padding: 10px 0px;
	margin-bottom: 15px;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 page-container">
			<h2 class="text-center">Partner <?php echo $info['domain']; ?></h3>
			<hr>
			<!-- dynamic partners-->
            <div class="arrw-rela"><div class="arrw-point-white"></div></div>
                    <div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://contrib.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png" alt="Contrib.com" title="Contrib.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://contrib.com">Contrib.com</a>
                                </h3>
                                <p>
                                    Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://globalventures.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png" title="globalventures.com" alt="globalventures.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://globalventures.com">GlobalVentures.com</a>
                                </h3>
                                <p>
                                    Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.
                                </p>
                                <p>
                                   With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://ifund.com">
                                    <img class="img-responsive" src="http://www.contrib.com/uploads/logo/ifund.png" alt="iFund.com" title="iFund.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://ifund.com">iFund.com</a>
                                </h3>
                                <p>
                                    iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
                                    advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
                                    investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
                                    iFund receives no compensation in connection with the purchase or sale of securities.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://ichallenge.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png" alt="iChallenge.com" title="iChallenge.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://ichallenge.com">iChallenge.com</a>
                                </h3>
                                <p>
                                     The best internet challenges. Solve and win online prizes.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://socialid.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-socialid1.png" alt="socialid.com" title="socialid.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://socialid.com">SocialId.com</a>
                                </h3>
                                <p>
                                     SocialId helps you get the social name for all major social networking websites.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://virtualinterns.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png" alt="virtualinterns.com" title="virtualinterns.com"> 
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://virtualinterns.com">Virtualinterns.com</a>
                                </h3>
                                <p>
                                      Join our exclusive community of like minded people on virtualinterns.com
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://referrals.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png" alt="referrals.com" title="referrals.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://referrals.com">Referrals.com</a>
                                </h3>
                                <p>
                                      Most effective Business Referral Program and Tools Available. Find and share referrals locally.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://adrate.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-adrate-3.png" alt="adrate.com" title="adrate.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://adrate.com">Adrate.com</a>
                                </h3>
                                <p>
                                   Insightful Ad Content Direct To Your Target Market Advertising That Will Reach. Attract. Target. & Engage Your Future Customers
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://consultants.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png" alt="consultants.com" title="consultants.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://consultants.com">Consultants.com</a>
                                </h3>
                                <p>
                                     Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://domaindirectory.com">
                                    <img class="img-responsive" src="http://www.domaindirectory.com/images/logo-domaindirectory300x82.png" alt="domaindirectory.com" title="domaindirectory.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://domaindirectory.com">Domaindirectory.com</a>
                                </h3>
                                <p>
                                       Domain Directory - Buy, Sell, Trade, Develop, Partner with premium domains on the Domain Directory platform.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://handyman.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png" alt="handyman.com" title="handyman.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://handyman.com">Handyman.com</a>
                                </h3>
                                <p>
                                     Handyman.com is the best place to find a professional contractor.
                                </p>
                            </div>
                        </div>
                    </div>
					<?php if (count($partners) > 0):?>
					   <?php $partner_default = array('contrib.com','globalventures.com','ifund.com',
					   'ichallenge.com','socialid.com','virtualinterns.com','referrals.com','adrate.com',
					   'consultants.com','domaindirectory.com','handyman.com')?>
					  <?php foreach ($partners as $partner):?>
					       <?php if (!in_array(strtolower( $partner['company_name']), $partner_default)):?>
					         <?php $url = $partner['url'];
					               $url = str_replace("[affiliate_id]", $affiliate_id , $url);
					               $url = str_replace("[brand]", $domain , $url);
					         ?>
					  		<div class="blur-box text-left">
                           <div class="row">
                            <div class="col-sm-4">
                                <a href="<?php echo $url?>">
                                   <?php if ($partner['image']!=""):?>
	                                    <img class="img-responsive" src="<?php echo $partner['image']?>" alt="<?php echo $partner['company_name']?>" title="<?php echo $partner['company_name']?>">
	                                    <?php else:?>
	                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/contrib/logo-contrib-brand2.png" alt="contrib.com" title="contrib.com">
                                    <?php endif;?>
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="<?php echo $url?>"><?php echo $partner['company_name']?></a>
                                </h3>
                                <p>
                                    <?php echo stripcslashes($partner['description'])?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <?php endif;?>
					  <?php endforeach;?>
					<?php endif?>
		</div>
	</div>
</div>

<?php include('footer.php');?>
<!-- <script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
