<?php $page = 'feed'; include('header.php');?>
<style>
body {
	background:#EFEFEF;
}
.comment-box-img {
	float: left;
	height: 33px;
	position: absolute;
	margin-top: 0px;
	left: 15px;
	z-index: 999;
}
.comment-section table tr {
	margin-bottom:20px;
}
.comment-section .btn {
	width:125px;
}
.comment-section .btn-group > .btn:last-child:not(:first-child), .btn-group > .dropdown-toggle:not(:first-child) {
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
}
.comment-section .btn-group > .btn:first-child:not(:last-child):not(.dropdown-toggle) {
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
}
</style>
<div class="container feed-container">
		<div class="row">
			<div class="col-md-8">
				<div class="feed-left">
					<div id="custom-search-input" data-toggle="modal" data-target="#myModal">
						<div class="input-group col-md-12">
							<input type="text" class="form-control input-lg" placeholder="What do you want to discuss or know about?" />
							<span class="input-group-btn">
								<button class="btn btn-info btn-lg" type="button">
									New Post
								</button>
							</span>
						</div>
					</div>
					<!-- modal -->
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <div class="modal-dialog" role="document">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<img src="http://cdn.warriorforum.com/images/placeholder_avatar.gif?256F" style="height:35px;">
						  </div>
						  <div class="modal-body">
							<input type="text" class="form-control input-lg" placeholder="What do you want to discuss or know about?" />
							<br>							
							<textarea class="form-control" placeholder="Enter Details Here"></textarea>
							<br>
							<select class="form-control">
							  <option>-- Choose a topic --</option>
							  <option>Internet Marketing</option>
							  <option>SEO</option>
							  <option>Web Development</option>
							</select>
						  </div>							
						  <div class="modal-footer">
							<button type="button" class="btn btn-primary">New Post</button>
						  </div>
						</div>
					  </div>
					</div>
					<!-- end modal -->
				</div>
				<div class="feed-left">
					<!-- -->
					<div class="tabbable-panel">
						<div class="tabbable-line">
							<ul class="nav nav-tabs ">
								<li class="active">
									<a href="#tab_default_1" data-toggle="tab">
									Trending </a>
								</li>
								<li>
									<a href="#tab_default_2" data-toggle="tab">
									Most Recent </a>
								</li>
								<li>
									<a href="#tab_default_3" data-toggle="tab">
									Top Voted </a>
								</li>
							</ul>
							<br>
							<div class="tab-content">
								<div class="tab-pane active" id="tab_default_1">
									<div class="f-article">
										<h4><a>How do you track source of Amazon Sales?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Can Women make it in MLM?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Who are your favorite famous marketers?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>How do you track source of Amazon Sales?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Can Women make it in MLM?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Who are your favorite famous marketers?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="clearfix"></div>
									<div class="page-nation pull-right">
										<ul class="pagination pagination-large">
										<li class="active"><span>1</span></li>
										<li><a href="#">2</a></li>
										<li><a href="#">3</a></li>
										<li><a href="#">4</a></li>
										<li><a href="#">6</a></li>
										<li><a href="#">7</a></li>
										<li><a href="#">8</a></li>
										<li><a href="#">9</a></li>
										<li class="disabled"><span>...</span></li><li>
										<li><a rel="next" href="#">Last</a></li>
									 </ul>
									</div>
									<div class="clearfix"></div>
								</div>
								<div class="tab-pane" id="tab_default_2">
									<div class="f-article">
										<h4><a>How do you track source of Amazon Sales?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Can Women make it in MLM?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Who are your favorite famous marketers?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Who are your favorite famous marketers?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Who are your favorite famous marketers?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="clearfix"></div>
									<div class="page-nation pull-right">
										<ul class="pagination pagination-large">
										<li class="active"><span>1</span></li>
										<li><a href="#">2</a></li>
										<li><a href="#">3</a></li>
										<li><a href="#">4</a></li>
										<li><a href="#">6</a></li>
										<li><a href="#">7</a></li>
										<li><a href="#">8</a></li>
										<li><a href="#">9</a></li>
										<li class="disabled"><span>...</span></li><li>
										<li><a rel="next" href="#">Last</a></li>
									 </ul>
									</div>
									<div class="clearfix"></div>
								</div>
								<div class="tab-pane" id="tab_default_3">
									<div class="f-article">
										<h4><a>How do you track source of Amazon Sales?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Can Women make it in MLM?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="f-article">
										<h4><a>Who are your favorite famous marketers?</a></h4>
										<small><a href="">sosoride</a> | 5 hours ago | <a href="">6 comments</a></small>
										<p>Amazon does not have any custom sub-tag that the affiliate can put in order to identify the visitor who made the purchase.</p>
									</div>
									<div class="clearfix"></div>
									<div class="page-nation pull-right">
										<ul class="pagination pagination-large">
										<li class="active"><span>1</span></li>
										<li><a href="#">2</a></li>
										<li><a href="#">3</a></li>
										<li><a href="#">4</a></li>
										<li><a href="#">6</a></li>
										<li><a href="#">7</a></li>
										<li><a href="#">8</a></li>
										<li><a href="#">9</a></li>
										<li class="disabled"><span>...</span></li><li>
										<li><a rel="next" href="#">Last</a></li>
									 </ul>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</div>
					<!-- -->
					<div class="comment-section">
						<h3>How do you track source of Amazon Sales?</h3>
						<div class="row">
							<div class="col-md-6 text-left">
								<img src="http://cdn.warriorforum.com/images/placeholder_avatar.gif?256F" class="img-responsive pull-left" style="margin-right:15px; height:50px;">
								 by <a href="#">sosoride</a><br>Posted: 06/21/2016 
							</div>
							<div class="col-md-6 text-right">
								<div class="btn-group btn-toggle"> 
									<button class="btn btn-default">Unfollow Author</button>
									<button class="btn btn-warning active" style="margin-left: -125px;">Follow Author</button>
								  </div>
							</div>							
							<div class="col-md-12">
							<br>
								<p>
								You want to make some extra income. Things are tight. The economy is bad. Maybe you're unemployed. And if you're working, your company is asking more of you and paying you less. You're struggling to make ends meet. I see dozens of questions from those new to the Internet every week. 
								It seems that the majority are under the impression that making money online is easy. And there are lots of "gurus" out there selling systems that might give you the impression in their sales copy that if you buy their thing the money will just come pouring in.
								</p>
							</div>
							<div class="col-md-12">
								<b><i class="fa fa-comment-o" aria-hidden="true"></i>&nbsp;Comment(20) | <i class="fa fa-heart-o" aria-hidden="true"></i>&nbsp;Subcribe</b>
								<p></p>
							</div>
							<div class="input-group col-md-12" style="padding: 0px 15px;">
								<img src="http://www.warriorforum.com/images/placeholder_avatar.gif?256F" class="comment-box-img">
								<input type="text" class="form-control" placeholder="Write comment" style="padding-left: 40px;" />
								<span class="input-group-btn">
									<button class="btn btn-info" type="button">
										Post
									</button>
								</span>
							</div>
						</div>	
						<br>						
						<table>
							<tr>
								<td style="vertical-align:top">
									<img src="http://cdn.warriorforum.com/images/placeholder_avatar.gif?256F" style="height: 35px; padding-right:10px;">		
								</td>
								<td>
									<p>by:&nbsp;<a href="#">johnnywalker</a>&nbsp;2 days ago</p>
									<p>Excellent tutorial! The problem is that most people are not willing to do that much work to reach success. Many people will read this thread and just move on and not implement this system.</p>
									<p>
										<a href="">Thanks</a>&nbsp;&nbsp;<a href="">Reply</a>
									</p>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:top">
									<img src="http://cdn.warriorforum.com/images/placeholder_avatar.gif?256F" style="height: 35px; padding-right:10px;">		
								</td>
								<td>
									<p>by:&nbsp;<a href="#">johnnywalker</a>&nbsp;2 days ago</p>
									<p>Excellent tutorial! The problem is that most people are not willing to do that much work to reach success. Many people will read this thread and just move on and not implement this system.</p>
									<p>
										<a href="">Thanks</a>&nbsp;&nbsp;<a href="">Reply</a>
									</p>
								</td>
							</tr>
						</table>
					</div>
				</div>				
				<div class="clearfix"></div>
			</div>
			<div class="col-md-4">
				<div class="feed-right">
					<div class="fprofile">
						<div class="row">
							<div class="col-md-4">
								<img src="http://cdn.warriorforum.com/images/placeholder_avatar.gif?256F" class="img-responsive">
							</div>
							<div class="col-md-8">
								<h3>andrecipriano</h3>
								<a href="#" class="btn btn-primary btn-block">Upgrade To Premium</a>
							</div>
						</div>
					</div>
					<div class="card-header">&nbsp;</div>
					<br>
					<h4 class="card-header">Topics</h4>
					<ul class="list-group">
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					  <li class="list-group-item"><a href="">Internet Marketing</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	
	<script src="https://code.jquery.com/jquery-1.12.3.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<script>
	$('.btn-toggle').click(function() {
    $(this).find('.btn').toggleClass('active');  
    
    if ($(this).find('.btn-primary').size()>0) {
    	$(this).find('.btn').toggleClass('btn-primary');
    }
    if ($(this).find('.btn-danger').size()>0) {
    	$(this).find('.btn').toggleClass('btn-danger');
    }
    if ($(this).find('.btn-success').size()>0) {
    	$(this).find('.btn').toggleClass('btn-success');
    }
    if ($(this).find('.btn-info').size()>0) {
    	$(this).find('.btn').toggleClass('btn-info');
    }
    
    $(this).find('.btn').toggleClass('btn-default');
       
});

$('form').submit(function(){
	alert($(this["options"]).val());
    return false;
});
	</script>