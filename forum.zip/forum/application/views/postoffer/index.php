<?php include(dirname(__FILE__).'/../header.php');?>
<style>
.page-container {
	background: white;
	padding: 30px 20px 60px;
	margin-top: 50px;
	margin-bottom: 100px;
	border:1px solid #d6e9c6;
}
.page-container h3 {
	margin-top: 0px;
}
.pg-side {
	border-left:none;
}
.upbox {
	background: rgb(250, 250, 250) none repeat scroll 0% 0%;
padding: 10px 10px 0px 10px;
border: 1px solid rgb(222, 222, 222);
border-radius: 6px;
}
.trashpost {
	position: absolute;
right: 35px;
margin-top: -37px;
color: rgb(255, 255, 255);
}
.custab .btn {    
    font-size: 12px;
    padding: 3px 6px;
}
</style>
<div class="container">
	<div class="row">
		<div id="form" class="col-md-7 page-container text-center">
			<h2 class="text-center">Post Offer <? echo $info['domain']?></h3>
			<div class="form-area">  
				<form role="form">
					<div class="form-group">
					<input id="num" type='hidden' value="">
					<textarea id="txtoffer" class="form-control" type="textarea" id="description" placeholder="Your Offer script" rows="4"></textarea>      
					</div>
				<button type="button" id="submit" name="submit" class="btn btn-warning pull-right">Submit</button>
				<button type="button" style="margin-right:5px;display:none" id="cancel" name="cancel" class="btn btn-primary pull-right">Clear</button>
				</form>
			</div>
		</div>
		<div id="offer" class="col-md-5 page-container pg-side">
			<h2 class="text-center">My Offer</h3>
			<table class="table table-striped custab">
				 <thead>
					  <tr>
							<th>Offer</th>
							<th class="text-center">Action</th>
					  </tr>
				 </thead>
				 <tbody>
				 </tbody>
			</table>
			<!-- Modal -->
			<div class="modal fade" id="deleteAdd" tabindex="-1" role="dialog">
			  <div class="modal-dialog" role="document">
				 <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					  <h4 class="modal-title" id="myModalLabel"><i class="fa fa-trash-o" aria-hidden="true"></i></h4>
					</div>
					<div class="modal-body">
					  Are you sure you want to delete this offer?
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
					  <button id="delete" data-loading-text="Deleting..." type="button" class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;Delete</button>
					</div>
				 </div>
			  </div>
			</div>
			<!-- End Modal -->
		</div>
	</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#num').val('');
	
	jQuery('#cancel').click(function(){
		jQuery('#num').val('');
		jQuery('#txtoffer').val('');
		jQuery('#submit').text('Submit');
		jQuery('#cancel').hide();
	});
	
	jQuery('#submit').click(function(){
		jQuery('#form').loading({
			stoppable: false,
			message: 'Loading...',
		});
		var ajax = jQuery.ajax({
			type: "POST",
			url: '<?=$info['ajax']?>/forum2/postoffer',
			data:{'num':jQuery('#num').val(), offer:jQuery('#txtoffer').val(),uid:encodeURIComponent('<?=$_SESSION['uid']?>'), domain:jQuery('#domain').val()},
			error: function(){},
			success: function(response){
				jQuery('#num').val('');
				jQuery('#txtoffer').val('');
				jQuery('#form').loading('stop');
				load();
				jQuery('#cancel').trigger('click');
			}
		});
	});

	jQuery('#delete').click(function(){
		deleteoffer(jQuery('.delete-selected').attr('data-num'));
	});
	
	load();
});

function load(){
	jQuery('#offer').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/getoffer',
		data:{uid:encodeURIComponent('<?=$_SESSION['uid']?>'), domain:jQuery('#domain').val()},
		error: function(){},
		success: function(response){
			jQuery('#offer').loading('stop');
			jQuery('.custab tbody').html(response.data.html);
			jQuery('.edit').off('click').on('click',function(){
				edit(jQuery(this).attr('data-num'));
			});
			
			jQuery('.delete').off('click').on('click',function(){
				jQuery('.delete').removeClass('delete-selected');
				jQuery(this).addClass('delete-selected');
			});
		}
	});
}

function deleteoffer(num)
{
	var $btn = jQuery('#delete').button('loading');
	jQuery('#offer').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/deleteoffer',
		data:{num:num,uid:encodeURIComponent('<?=$_SESSION['uid']?>'), domain:jQuery('#domain').val()},
		error: function(){},
		success: function(data){
			$btn.button('reset');
			jQuery('#offer').loading('stop');
			jQuery('#deleteAdd').modal('hide');
			load();
		}
	});
}

function edit(num)
{
	jQuery('#cancel').show();
	jQuery('#submit').text('Update');
	jQuery('#num').val(num);
	jQuery('#txtoffer').val(jQuery('tr#'+num+' td').eq(0).text());
}
</script>
<?php include(dirname(__FILE__).'/../footer.php');?>
