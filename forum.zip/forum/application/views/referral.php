<?php $page = 'referral'; include('header.php');?>
<style>
.page-container {
	background:white;
	padding:20px;
	margin-top:20px;
	margin-bottom:50px;
}
.page-container h3 {
	margin-top: 0px;
}
.page-container .blur-box {
	border-bottom: 1px solid #eee;
	padding: 10px 0px;
	margin-bottom: 15px;
}
.blck2-box{
    background-color: #fafafa;
    padding: 25px 15px;
    margin-bottom: 25px;
    text-align: left;
    margin-top: -5px;
}
.wrap-allbanner {
    background: rgba(0, 0, 0, 0) url("https://cdn.vnoc.com/banner/banner-contrib-728x90-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 90px;
    position: relative;
    width: 728px;
}
.wrap-bannerLeft, .wrap-bannerRight {
    display: inline-block;
    float: left;
}
.wrap-bannerLeft {
    box-sizing: border-box;
    height: 90px;
    overflow: hidden;
    padding: 15px 5px 20px 10px;
    vertical-align: top;
    width: 245px;
}
.blck2-box .ellipsis {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.aBnnrP {
    box-sizing: border-box;
    color: #0088cc;
    display: block;
    font-size: 22px;
    font-weight: bold;
    line-height: normal;
    margin: 0;
    text-align: center;
    text-decoration: none;
    text-transform: capitalize;
}
.logo-banners1 {
    box-sizing: border-box;
    max-height: 58px;
    max-width: 100%;
}
.wrap-bannerRight {
    color: #ffffff;
    height: 90px;
    margin-left: 84px;
    width: 397px;
}
.content-rightText {
    box-sizing: border-box;
    margin: auto;
    padding-top: 16px;
    width: 350px;
}
.content-rightText span {
    box-sizing: border-box;
    display: block;
}
.content-rightText span, .content-rightText p {
    font-size: 25px;
    text-align: center;
    text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
}
.block-group{
    border-bottom: 1px solid #fff;
    margin-bottom: 25px;
    padding-bottom: 30px;
}
.block-group:last-child{
    margin-bottom: 0;
    border-bottom: none;
}
.wrapBanner-2 {
    background: rgba(0, 0, 0, 0) url("https://cdn.vnoc.com/banner/180x150-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 150px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 180px;
}
.wrap-topBanner {
    box-sizing: border-box;
    display: block;
    margin: 37px auto 0;
    position: relative;
    width: 118px;
}
.wrap-contentTop {
    box-sizing: border-box;
    color: #fff;
    font-size: 20px;
    letter-spacing: 0.01em;
    line-height: 1.1em;
    text-align: center;
    text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
}

.wrap-contentTop span {
    display: block;
}
.wrap-downBanner {
    box-sizing: border-box;
    display: block;
    height: 37px;
    margin: 5px 0 0;
    overflow: hidden;
}
.wrap-contentDown {
    box-sizing: border-box;
    height: 35px;
    margin: auto;
    padding: 1px 0;
    width: 125px;
}
.wrap-contentDown img {
    max-height: 32px;
    max-width: 100%;
    text-align: center;
}
.wrap-contentDown p {
    box-sizing: border-box;
    color: #0088cc;
    display: block;
    margin: 0;
}
.wrapBanner-3 {
    background: rgba(0, 0, 0, 0) url("https://cdn.vnoc.com/banner/banner-contrib-160x600-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 600px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 180px;
}
.wrap-topBanner3 {
    box-sizing: border-box;
    display: block;
    margin: 130px 18px 0;
    position: relative;
    width: 120px;
}

.wrapBanner-4 {
    background: rgba(0, 0, 0, 0) url("https://cdn.vnoc.com/banner/banner-contrib-250x250-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 250px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 250px
}
.wrap-topBanner4 {
    box-sizing: border-box;
    display: block;
    margin: 76px 18px 0;
    position: relative;

}
.floating {
    animation-duration: 1.5s;
    animation-iteration-count: infinite;
    animation-name: floating;
}
@keyframes floating {
0% {
    transform: translateY(0%);
}
50% {
    transform: translateY(8%);
}
100% {
    transform: translateY(0%);
}
}

</style>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 page-container">
			<center>
				<div id="script-container"></div>
			</center>
		</div>
	</div>
</div>
<script type="text/javascript">
$.ajax({
	url: 'https://api1.contrib.co/request/Getdomainwidget?key=5c1bde69a9e783c7edc2e603d8b25023&domain='+'<?=$info['domain']?>',
	method: 'POST',
	beforeSend: function() {

	},
	success: function(res) {
		if (res.success === true) {
			$('#script-container').html(`<script class="ctb-box" id="referral-script" src="https://www.referrals.com/extension/widget.js?key=${res.data['widget_id']}" type="text/javascript"><\/script>`);                
			console.log(res.data['widget_id']);
		}
	},
	complete: function() {

	},
});
</script>
<?php include('footer.php');?>
<!-- <script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
