<?php $page = 'welcome'; include('header.php');?>
<style>
.welcome-container {
	margin-top:30px;
}
.welcome-container hr {
	margin-top: 10px;
	margin-bottom: 0px;
	border: 0;
	border-top: 1px solid #bbb;
}
</style>
<div class="welcome-container container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3 text-center">
				<div class="welcome-container">
					<h3>Welcome <b style="color:green"><?php echo (isset($_SESSION['user'])) ? $_SESSION['user'] : 'Guest'; ?></b>!</h3>
					<hr>
					<h2 style="text-transform:capitalize"><?php echo $info['domain']; ?> Forum Discussions</h2>
				</div>
				<div class="panel panel-success">
					<div class="panel-heading">
						<h4 class="text-center">
							FREE
						</h4>
					</div>
					<div class="panel-body text-center">
						<p class="lead">
							<strong>$0.00/month</strong>
							<p style="color:green">Free Membership</p>
						</p>
					</div>
					<ul class="list-group list-group-flush text-center">
						<li class="list-group-item"><i class="icon-ok text-danger"></i>Join <?php echo $info['domain']; ?> Forum Discussions </li>
						<li class="list-group-item" style="text-decoration:line-through"><i class="icon-ok text-danger"></i>Allows user to post ads on the right side bar</li>
						<li class="list-group-item" style="text-decoration:line-through"></i>Allows user to post to marketplace</li>
						<li class="list-group-item" style="text-decoration:line-through"></i>Allows user to download free items posted by other users</li>
						<li class="list-group-item" style="text-decoration:line-through"></i>Allows user to access and create private forums</li>
					</ul>
					<div class="panel-footer">
						<a class="btn btn-lg btn-block btn-success" href="/onboarding">
							START FREE!
						</a>
					</div>
				</div>
				<p>Getting <a href="#" data-toggle="modal" data-target="#getPremium"><b>PREMIUM</b></a> is the best way to enjoy using <?php echo $info['domain']; ?> forum </p>
				<!-- modal -->
				<div class="modal fade" id="getPremium" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="row">
							<div class="col-md-12 text-center">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times-circle" aria-hidden="true"></i></button>
							  </div>
							  <div class="modal-body">
									<div class="panel panel-danger">
										<div class="panel-heading">
											<h4 class="text-center">
												30 Days Free Trial
											</h4>
										</div>
										<div class="panel-body text-center">
											<p class="lead">
												<strong>FREE</strong>
												<p style="color:green">Premium <?php echo $info['domain']; ?> Room Membership</p>
											</p>
										</div>
										<ul class="list-group list-group-flush text-center">
											<li class="list-group-item"><i class="icon-ok text-danger"></i>Join <?php echo $info['domain']; ?> Forum Discussions </li>
											<li class="list-group-item"><i class="icon-ok text-danger"></i>Allows user to post ads on the right side bar</li>
											<li class="list-group-item"></i>Allows user to post to marketplace</li>
											<li class="list-group-item"></i>Allows user to download free items posted by other users</li>
											<li class="list-group-item"></i>Allows user to access and create private forums</li>
										</ul>
										<div class="panel-footer">
											<a class="btn btn-lg btn-block btn-success" href="/onboarding">
												START FREE TRIAL
											</a>
										</div>
									</div>
							  </div>
							</div>
						</div>
					</div>
				  </div>
				</div>
				<!-- end modal -->
			</div>
		</div>
	</div>
