<?php $page = ''; include('header.php');?>
<style>
.page-container {
	background: white;
	padding: 30px 20px 60px;
	margin-top: 50px;
	margin-bottom: 100px;
	border:1px solid #d6e9c6;
}
.page-container h3 {
	margin-top: 0px;
}
.pg-side {
	border-left:none;
}
.upbox {
	background: rgb(250, 250, 250) none repeat scroll 0% 0%;
padding: 10px 10px 0px 10px;
border: 1px solid rgb(222, 222, 222);
border-radius: 6px;
}
.custab .btn {    
    font-size: 12px;
    padding: 3px 6px;
}
.btn-default {
	border:1px solid #dedede !important;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-7 page-container text-center">
			<h2 class="text-center">Post Offer <? echo $info['domain']?></h3>
			<ul class="nav nav-pills nav-justified thumbnail">
				 <li class="active"><a href="#">
					  <h4 class="list-group-item-heading">Step 1</h4>
					  <p class="list-group-item-text">Create Offer</p>
				 </a></li>
				 <li><a href="#">
					  <h4 class="list-group-item-heading">Step 2</h4>
					  <p class="list-group-item-text">Publish Offer</p>
				 </a></li>
			</ul>
			<div id="step-1">
				<h3 class="text-left"><i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;Create</h3>
				<form role="form" class="text-left">
						<div class="form-group">
							<input type="text" class="form-control" id="title" name="title" placeholder="Title" required>
						</div>
					  <div class="form-group">
					  <textarea class="form-control" type="textarea" id="description" placeholder="Some descriptions" maxlength="140" rows="4"></textarea>      
					  </div>
						<div class="form-group upbox">
								<label class="control-label">Upload Files</label>
								<input id="input-1" type="file" class="file">
								<br>
								<div>
									<div class="progress">
									  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
										 100%
									  </div>							  
									</div>
								</div>
						</div>
						<div class="form-group">
							<select class="form-control">
								 <option>Select Topic/Category</option>
								 <option>...</option>
								 <option>...</option>
								 <option>...</option>
								 <option>...</option>
							</select>  
						</div>
						<div class="form-group">
							<h4>Payment Method</h4>
							<a href="" class="btn btn-default"><img src="https://www.paypalobjects.com/webstatic/i/logo/rebrand/ppcom.svg"></a>
						</div>
						<div class="clearfix"><hr></div>
				<button type="button" id="submit" name="submit" class="btn btn-warning pull-right">Save and Continue</button>
			  </form>
			</div>
			<div class="clearfix"></div>
			<div id="step-2">
				<h3 class="text-left"><i class="fa fa-check-square" aria-hidden="true"></i>&nbsp;Publish</h3>
				<div class="pub-box">
					<h4>Please Review Your Offer</h4>
					<div class="off-title">
						<h5 class="text-left">
						<b>Title:</b>&nbsp;Autoleader Headphones Vinyl Decal Sticker Skin for Apple MacBook Air/Pro Laptop 13" 15"(INTL)
						</h5>
					</div>
					<div class="off-description">
						<p class="text-left"><b>Description:</b>&nbsp;
						This decal is made from high quality vinyl to ensure a hard wearing and long lasting graphic for your MacBook.
						Maintains the sleek and contemporary design of your device, and add a touch of individuality and make your device unique.
						Making your ever more popular device stand out from the crowd.
						</p>
					</div>
					<div class="off-category text-left">
						<b>Category:</b>&nbsp;Technology
					</div>
					<br>
					<div class="off-files">
						<img src="http://srv-live-02.lazada.com.ph/p/autoleader-headphones-vinyl-decal-sticker-skin-for-apple-macbook-air-pro-laptop-13-15-intl-3024-5635624-a1551997eb295babd0f0de9545288754-product.jpg" class="img-responsive">						
					</div>
				</div>
				<div class="clearfix"><hr></div>
				<button type="button" id="submit" name="submit" class="btn btn-warning pull-left">Back</button>
				
				<button type="button" id="submit" name="submit" class="btn btn-warning pull-right">Publish</button>&nbsp;
				<button type="button" id="submit" name="submit" class="btn btn-default pull-right" style="margin-right: 5px;">Cancel</button>
				<div class="clearfix"><br></div>
				<div class="alert alert-success" role="alert">
					Well done! Your offer has been successfully published!
				</div>
			</div>
		</div>
		<div class="col-md-5 page-container pg-side">
			<h2 class="text-center">My Offers</h3>
			<table class="table table-striped custab">
				 <thead>
					  <tr>
							<th>ID</th>
							<th>Title</th>
							<th class="text-center">Action</th>
					  </tr>
				 </thead>
					<tr>
						 <td>1</td>
						 <td>Lorem ipsum dolor news ...</td>
						 <td class="text-center">
							 <a class='btn btn-info btn-xs' href="#"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
							 <a href="#" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#deleteAdd">
							 <span class="glyphicon glyphicon-remove"></span> Del
							 </a>
						 </td>
					</tr>
					<tr>
						 <td>1</td>
						 <td>Lorem ipsum dolor news ...</td>
						 <td class="text-center">
							 <a class='btn btn-info btn-xs' href="#"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
							 <a href="#" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#deleteAdd">
							 <span class="glyphicon glyphicon-remove"></span> Del
							 </a>
						 </td>
					</tr>
					<tr>
						 <td>1</td>
						 <td>Lorem ipsum dolor news ...</td>
						 <td class="text-center">
							 <a class='btn btn-info btn-xs' href="#"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
							 <a href="#" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#deleteAdd">
							 <span class="glyphicon glyphicon-remove"></span> Del
							 </a>
						 </td>
					</tr>
			</table>
			<!-- Modal -->
			<div class="modal fade" id="deleteAdd" tabindex="-1" role="dialog">
			  <div class="modal-dialog" role="document">
				 <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					  <h4 class="modal-title" id="myModalLabel"><i class="fa fa-trash-o" aria-hidden="true"></i></h4>
					</div>
					<div class="modal-body">
					  Are you sure you want to delete this ad?
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
					  <button type="button" class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;Delete</button>
					</div>
				 </div>
			  </div>
			</div>
			<!-- End Modal -->
		</div>
	</div>
</div>

<?php include('footer.php');?>
<!-- <script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
