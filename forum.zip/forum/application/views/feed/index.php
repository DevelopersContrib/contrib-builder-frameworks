<?php include(dirname(__FILE__).'/../header.php');?>
<?php include(dirname(__FILE__).'/../post-container.php');?>
<style>
body {
	background:#EFEFEF;
}
.comment-box-img {
	float: left;
	height: 33px;
	position: absolute;
	margin-top: 0px;
	left: 15px;
	z-index: 999;
}
.comment-section table tr {
	margin-bottom:20px;
}
.comment-section .btn {
	width:125px;
}
.comment-section .btn-group > .btn:last-child:not(:first-child), .btn-group > .dropdown-toggle:not(:first-child) {
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
}
.comment-section .btn-group > .btn:first-child:not(:last-child):not(.dropdown-toggle) {
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
}
</style>
<div class="container feed-container">
	<div class="row">
		<div class="col-md-8">
			<div class="feed-left">
				<!-- -->
				<div class="tabbable-panel">
					<div class="tabbable-line">
						<ul class="nav nav-tabs ">
							<li class="active">
								<a href="#tab_default_1" data-toggle="tab">
								Trending </a>
							</li>
							<li>
								<a href="#tab_default_2" data-toggle="tab">
								Most Recent </a>
							</li>
							<li>
								<a href="#tab_default_3" data-toggle="tab">
								Top Voted </a>
							</li>
						</ul>
						<br>
						<div class="tab-content">
							<div class="tab-pane active" id="tab_default_1">
							</div>
							<div class="tab-pane" id="tab_default_2">
							</div>
							<div class="tab-pane" id="tab_default_3">
							</div>
						</div>
					</div>
				</div>
			</div>				
			<div class="clearfix"></div>
		</div>
		<div class="col-md-4">
			<div class="feed-right">
				<?php //include 'sidebar.php';?>
				<?php include(dirname(__FILE__).'/../sidebar.php');?>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function loadTrending(page)
{
	jQuery('#tab_default_1').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/gettrending',
		data:{page:page,domain:jQuery('#domain').val()},
		error: function(){},
		success: function(response){
			jQuery('#tab_default_1').loading('stop');
			jQuery('#tab_default_1').html(response.data.html);
		}
	});
}

function loadRecent(page)
{
	jQuery('#tab_default_2').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/getrecent',
		data:{page:page,domain:jQuery('#domain').val()},
		error: function(){},
		success: function(response){
			jQuery('#tab_default_2').loading('stop');
			jQuery('#tab_default_2').html(response.data.html);
		}
	});
}

function loadTop(page)
{
	jQuery('#tab_default_3').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/gettop',
		data:{page:page,domain:jQuery('#domain').val()},
		error: function(){},
		success: function(response){
			jQuery('#tab_default_3').loading('stop');
			jQuery('#tab_default_3').html(response.data.html);
		}
	});
}

jQuery(document).ready(function(){
	loadTrending();
	loadRecent();
	loadTop();
	jQuery('.btn-toggle').click(function() {
		jQuery(this).find('.btn').toggleClass('active');  
		
		if (jQuery(this).find('.btn-primary').size()>0) {
			jQuery(this).find('.btn').toggleClass('btn-primary');
		}
		if (jQuery(this).find('.btn-danger').size()>0) {
			jQuery(this).find('.btn').toggleClass('btn-danger');
		}
		if (jQuery(this).find('.btn-success').size()>0) {
			jQuery(this).find('.btn').toggleClass('btn-success');
		}
		if (jQuery(this).find('.btn-info').size()>0) {
			jQuery(this).find('.btn').toggleClass('btn-info');
		}
		
		jQuery(this).find('.btn').toggleClass('btn-default');
	});
	
	
	
});
</script>
	
	<?php include(dirname(__FILE__).'/../footer.php');?>