<div class="bread_crumbs_container">
	<?php
	$a = '';
	foreach($bread_crumbs as $param){
		$link = '<a class="bread_crumbs" href="'.$param['link'].'">'.$param['title'].'</a>';
		$a .= empty($a) ? $link : ' / '.$link;
	}
	echo $a;
	?>
</div>