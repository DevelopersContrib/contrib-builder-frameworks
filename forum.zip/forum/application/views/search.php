<style>
.search-container .input-group-btn {
	display: inherit;
}
.search-container .input-group-btn .btn {
	border-top-right-radius: 0px;
	border-bottom-right-radius: 0px;
}
.search-container #btn-search .fa {
	font-size: 19px;
}
.search-container .form-control {
	border: 1px solid #fff;
	box-shadow:none;
}
</style>
<div class="search-container">
	<div class="input-group">
		<form id="form-search" method="post" action="/search">
		<input type="hidden" name="search_param" value="all" id="search_param">
		<input id="search" type="text" class="form-control" name="search" placeholder="Search topic..." style="height:40px;border-right: none;">
		 <!--<div class="input-group-btn search-panel">
			<button type="button" class="btn btn-default dropdown-toggle search-btn-right" data-toggle="dropdown">
				<span id="search_concept">Filter by</span> <span class="caret"></span>
			</button>
			<ul class="dropdown-menu" role="menu">
			  <li><a href="#contains">Posts</a></li>
			  <li><a href="#its_equal">Threads</a></li>
			</ul>
		</div>-->
		<span class="input-group-btn">
			<button id="btn-search" class="btn btn-default" type="button" style="height: 40px;border-left: none;"><i class="fa fa-search" aria-hidden="true"></i></button>
		</span>
		</form>
	</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){	
	jQuery('#search').keypress(function(e){
		var p = e.which;
		 if(p==13){
			jQuery('#btn-search').trigger('click');
		 }
	});	
	jQuery('#btn-search').click(function(){
		if(jQuery('#search').val()!=''){
			jQuery('#form-search').attr('action','/search/'+encodeURIComponent(jQuery('#search').val())).submit();
		}
	});
});
</script>