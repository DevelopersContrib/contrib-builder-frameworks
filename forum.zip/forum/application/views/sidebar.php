<style>
.luser {
	height:38px;
}
#members-list .list-group-item {
    display: inline-block;
}
#forum-sidebar .fs-container h3 {
    border-bottom: 3px solid #dedede;
    padding-bottom: 10px;
    margin-bottom: 10px;
	margin-top: 5px;
}
#forum-sidebar {
	margin-bottom:10px;
}
#sidebar-category li::before {
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: block;
    position: absolute;
    top: 50%;
    left: 0px;
    width: 5px;
    height: 5px;
    border: 1px solid #979797;
    border-radius: 50%;
    content: "";
}
#sidebar-category a {
	margin-left:13px;
}
.offer-box h4 {
	color:#666;
}
.post-box h4 {
	color:#666;
}
</style>
<?php if(isset($_SESSION['uid']) && $info['member_info']['account_type'] == 'free'){ ?>
<div id="forum-sidebar">
	<div class="fs-container">
		<h3>Get Premium</h3>
		<p>Brand Forum Membership! Get access to all our premium offers!</p>
		<a href="/premium" class="btn btn-warning btn-lg btn-block">Upgrade to Premium Account!</a>
	</div>
</div>
<?php } ?>
<div id="forum-sidebar">
	<div class="fs-container">
		<h3>Latest Members</h3>
		<ul class="list-group text-center" id="members-list">
		</ul>
	</div>
</div>
<div id="forum-sidebar">
	<div class="fs-container">
		<h3>My Offer</h3>
		<div class="offer-box">
			<h4 class="text-center" id="offer">
			
			</h4>
			<a href="" class="btn btn-danger btn-lg btn-block" style="display:none"><b>Create New Offer</b></a>
		</div>
	</div>
</div>
<div id="forum-sidebar">
	<div class="fs-container">
		<h3>Daily Deals</h3>
		<div class="post-box">
			<!--h4 class="text-center" id="ad">
			Post an ad today (160x600)
			</h4-->
			<div id="ad" style="padding: 10px 0;">
			
			</div>
			<a href="" class="btn btn-danger btn-lg btn-block" style="display:none"><b>Post Ad</b></a>
		</div>
	</div>
</div>
<div id="forum-sidebar">
	<div id="all-topics" class="fs-container">
		<h3>All Topics</h3>
		<ul id="sidebar-category" class="list-group">
			<?php foreach($info['forum_topics'] as $subcat):?>
				<li class="list-group-item">
					<a href="/<?php echo $subcat['slug'] ?>"><?php echo $subcat['topic_name'] ?></a>
				</li>
			<?php endforeach;?>
		</ul>
	</div>
</div>
<script>
	$(document).ready(function(){
		
		show();
		
		jQuery('#members-list').loading({
			stoppable: false,
			message: 'Loading...',
		});
		var ajax = jQuery.ajax({
			type: "POST",
			url: '<?=str_replace('http:','https:',$info['ajax'])?>/forum2/getlatestmembers',
			data:{
				domain:jQuery('#domain').val(),
			},
			error: function(){},
			success: function(response){
				jQuery('#members-list').loading('stop');
				jQuery('#members-list').html(response.data.html);
				jQuery('#members-list a').tooltip();
			}
		});	
	});
	
	function showOffers(offers){
		var index = 0;
		var offerdiv = $('#offer');			
		
		if(offers.length==1){
			offerdiv.html(offers[index]['offer']);
		} else {
			offerdiv.html(offers[index]['offer']);
			index++;
			var showItems = setInterval(function(){
				if(index<offers.length){
					offerdiv.html(offers[index]['offer']);
					index++;
				} else {
					index = 0;
				}
			},20000);
		}
	}
	
	function showAds(ads){
		var index = 0;
		var addiv = $('#ad');			
		
		if(ads.length==1){
			addiv.html(ads[index]['ads']);
		} else {
			addiv.html(ads[index]['ads']);
			index++;
			var showItems = setInterval(function(){	
				if(index<ads.length){					
					addiv.html(ads[index]['ads']);
					index++;
				} else {
					index = 0;
				}
			},20000);
		}
	}
	
	function show(){
		var offers = <?=$info['offers']?>;
		var ads = <?=$info['ads']?>;
		var offerdiv = $('#offer');
		var addiv = $('#ad');
		var indexOffers = 0;	
		var indexAds = 0;
		
		if(offers[0]!=null && ads[0]==null){
			addiv.parents('#forum-sidebar').hide();
			showOffers(offers);
		} else if(offers[0]==null && ads[0]!=null){
			offerdiv.parents('#forum-sidebar').hide();
			showAds(ads);
		} else if(offers[0]==null && ads[0]==null){
			offerdiv.parents('#forum-sidebar').hide();
			addiv.parents('#forum-sidebar').hide();
		} else if(offers[0]!=null && ads[0]!=null){
			if(offers.length==1 && ads.length==1){
				offerdiv.html(offers[indexOffers]['offer']);
				addiv.html(ads[indexAds]['ads']);
			} else if(offers.length>1 && ads.length==1){
				addiv.html(ads[indexAds]['ads']);
				showOffers(offers);
			} else if(offers.length==1 && ads.length>1){
				offerdiv.html(offers[indexAds]['offer']);
				showAds(ads);
			} else if(offers.length>1 && ads.length>1){
				offerdiv.html(offers[indexOffers]['offer']);
				addiv.html(ads[indexAds]['ads']);
				indexOffers++;
				indexAds++;
				var showItems = setInterval(function(){
					if(indexOffers<offers.length){
						offerdiv.html(offers[indexOffers]['offer']);
						indexOffers++;
						if(indexAds<ads.length){
							addiv.html(ads[indexAds]['ads']);
							indexAds++;
						} else {
							indexAds = 0;
						}
					} else {
						indexOffers = 0;
					}
				},20000);
			}
		}
	}
</script>