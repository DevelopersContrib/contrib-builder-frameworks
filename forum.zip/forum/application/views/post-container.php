<style>
.post-container .btn-lg {
    height: 50px;
}
.post-container .form-control {
	border: none;
}
</style>
<div id="post-container-bg">
	<div class="bg-overlay"></div>
	<div class="post-container container">
		<div class="row">
			
			<div id="custom-search-input" data-toggle="modal" data-target="<?=isset($_SESSION['uid'])?'#postTopic':'#logModal';?> ">
				<div class="input-group col-md-12">
					<input id="txtpost" type="text" class="form-control input-lg" placeholder="What do you want to discuss?" />
					<span class="input-group-btn">
						<button id="btntxtpost" class="btn btn-warning btn-lg" type="button">
							<b>Post Topic</b>
						</button>
					</span>
				</div>
			</div>
			<?php include('post_form.php');?>
		</div>
	</div>
</div>
<?php
if(!isset($_SESSION['uid'])){
?>
<script>
jQuery(document).ready(function(){
	jQuery('#txtpost, #btntxtpost').click(function(){
		window.location = '/account/login';
	});
});
</script>
<?php
}
?>