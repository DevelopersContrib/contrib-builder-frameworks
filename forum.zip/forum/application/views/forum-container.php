<style>
#forum-sidebar {
	margin-top: 0px;
}
.ad-container {
	margin-bottom:15px;
}
</style>
<div class="search-container container" style="display:none;">
	<div class="row">
		<form id="form-search" method="post" action="/search">
		<div class="col-md-8 col-md-offset-2 sc-border">
			<div class="input-group">               
				<input type="hidden" name="search_param" value="all" id="search_param">         
				<input id="search" type="text" class="form-control" name="search" placeholder="Search topic...">
				 <!--<div class="input-group-btn search-panel">
					<button type="button" class="btn btn-default dropdown-toggle search-btn-right" data-toggle="dropdown">
						<span id="search_concept">Filter by</span> <span class="caret"></span>
					</button>
					<ul class="dropdown-menu" role="menu">
					  <li><a href="#contains">Posts</a></li>
					  <li><a href="#its_equal">Threads</a></li>
					</ul>
				</div>-->
				<span class="input-group-btn">
					<button id="btn-search" class="btn btn-default" type="button">Search</button>
				</span>
			</div>
		</div>
		</form>
	</div>
</div>

<div class="ad-container container">
	<div class="row">
		<div class="col-md-12 text-center">
			<div class="for-ad-space">
				<?=base64_decode($info['additional_html']);?>
				
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-8">			
			<div id="topics" class="forum-container">
				
			</div>
		</div>
		<div class="col-md-4">
			<?php include('sidebar.php');?>
		</div>
	</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#topics').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=str_replace('http:','https:',$info['ajax'])?>/forum2/getdiscussions',
		data:{uid:encodeURIComponent('<?=$_SESSION['uid']?>'),domain:jQuery('#domain').val(),topic_id:'<?=$info['categoryid']?>'},
		error: function(){},
		success: function(response){
			jQuery('#topics').loading('stop');
			jQuery('#topics').html(response.data.html);
		}
	});
	jQuery('#search').keypress(function(e){
		var p = e.which;
		 if(p==13){
			jQuery('#btn-search').trigger('click');
		 }
	});
	
	jQuery('#btn-search').click(function(){
		if(jQuery('#search').val()!=''){
			jQuery('#form-search').attr('action','/search/'+encodeURIComponent(jQuery('#search').val())).submit();
		}
	});
});
</script>