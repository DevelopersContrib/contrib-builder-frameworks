<?php $page = ''; include('header.php');?>
<style>
.page-container {
	background: white;
	padding: 30px 20px 60px;
	margin-top: 50px;
	margin-bottom: 90px;
	box-shadow: 0 1px 1px rgba(0,0,0,.05);
}
.page-container h3 {
	margin-top: 0px;
}
.thanks {
	color:#49B824;
	margin-top: 10px;
}
hr {
    margin-top: 20px;
    margin-bottom: 30px;
    border: 0;
    border-top: 10px solid #eee;
}
.btn-proceed {
	padding: 6px 12px;
}
.list-group-item {
   font-size: 17px;
}

html.loading {
	background: #333 url('http://ammoseek.com/img/big_loading.gif') no-repeat 50% 50%;
	-webkit-transition: background-color 0;
	transition: background-color 0;
}
</style>
<div class="container" style="height:100%;">
	<div id="loader" class="text-center load-container" style="margin:auto; display:block; padding-top:300px;">
		<div class="load-spinner"></div>
		Processing...
	</div>
	<div class="row">
		<div class="col-md-6 col-md-offset-3 page-container text-center" id="transaction-success-msg-container" style="display: none;">
			<h2 class="text-center">Payment Confirmation <? echo $info['domain']?></h3>
			<hr>
			<img src="https://rdbuploads.s3.amazonaws.com/icons/icon-handshake.png" style="height:100px;">
			<h1 class="thanks">Thank you for upgrading <br>your Account.</h1>
			<h3>Now you can, </h3>
			<ul class="list-group list-group-flush text-center">
				<li class="list-group-item"><i class="icon-ok text-danger"></i>Join <?php echo $info['domain']; ?> Forum Discussions </li>
				<li class="list-group-item"><i class="icon-ok text-danger"></i>Post ads on the right side bar</li>
				<li class="list-group-item"></i>Post to marketplace</li>
				<li class="list-group-item"></i>Download free items posted by other users</li>
				<li class="list-group-item"></i>Access and create private forums</li>
			</ul>
			<a href="/" class="btn btn-warning btn-lg btn-block btn-proceed"><h4>Proceed To Forum</h4></a>
		</div>
		<div class="error-container col-md-6 col-md-offset-3 page-container text-center" id="transaction-error-msg-container" style="display: none;">
			<h2 class="text-center">Payment Confirmation <? echo $info['domain']?></h3>
			<hr>
			<img src="https://rdbuploads.s3.amazonaws.com/icons/status-warning-icon.png" style="height:250px;">
			<h3 id="transaction-error-msg">We were unable to process your request. <br>Please try again later.<h3><br>
			<a href="/" class="btn btn-warning btn-lg btn-block btn-proceed"><h4>Back To Forum</h4></a>
		</div>
	</div>
</div>
<?php include('footer.php');?>
<script>
	$(document).ready(function(){		
		var transactionStatus = '<?=$data['status']?>';
		
		if(transactionStatus == 'Completed'){
			saveTransactionDetails();
		} else {		
			showErrorMessage('<?=$data['error']?>');
		}	
	});
	
	function showErrorMessage(msg){
		$('#loader').css('display','none');
		$('#transaction-error-msg').html(msg);
		$('#transaction-error-msg-container').show();			
		$('#transaction-success-msg-container').hide();
	}
	
	function showSuccessMessage(){
		$('#loader').css('display','none');
		$('#transaction-error-msg-container').hide();
		$('#transaction-success-msg-container').show();
	}
	
	function saveTransactionDetails(){
		$.ajax({
			type: 'POST',
			url: '<?=$info['ajax']?>'+'/forum2/transaction',
			data: {
				uid: encodeURIComponent('<?=$_SESSION['uid']?>'),
				domain: '<?=$info['domain']?>',
				transaction_id: '<?=$data['transaction_id']?>',
				status: '<?=$data['status']?>',
				description: '<?=$data['description']?>',
				summary: '<?=$data['summary']?>'
			},
			success: function(response){
				var	msg = 'Sorry! We were unable to process your request. Please try again later!';
				var error = 0;
				if(response.success){
					if(response.data['status']){
						if(response.data['is_premium']){
							<?php
								if(isset($_SESSION['account_type'])){
									$_SESSION['account_type'] = 'premium';
								}
							?>
							showSuccessMessage();
						} else {
							error++;
						}
					} else {
						error++;
					}
				} else {
					error++;
				}
				
				if(error>0){
					showErrorMessage(msg);
				}
			}
		});
	}
	/*
	function upgradeToPremium(){
		$.ajax({			
			type: 'POST',
			url: '<?=$info['ajax']?>'+'/forum2/upgradetopremium',
			data: { uid: encodeURIComponent('<?=$_SESSION['uid']?>'),domain:'<?=$info['domain']?>' },
			success: function(response){
				console.log(response);
				if(response){
					console.log('Congratulations! We successully upgraded your account to premium!');					
				} else {
					console.log('Sorry! We were unable to process your request. Please try again later!');
				}
			}
		});
	}
	*/
</script>































