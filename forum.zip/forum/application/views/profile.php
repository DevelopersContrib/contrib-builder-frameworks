<?php $page = 'profile'; include('header.php');?>
<style>
.profile-container {
	margin-top:20px;
	margin-bottom:100px;
}
.profile-container .pc-right {
	background:#fff;
	padding:20px;
}
.profile-container .pc-left {
	background:#fff;
	padding:20px;
	min-height:500px;
}
.pc-right h3 {
	border-bottom:1px solid #eee;
}
.pc-right h3 b {
	margin-right:10px;
}
.profile-container .form-control {
	margin-bottom: 15px;
}
.profile-container .well {
    min-height: 20px;
    padding: 25px;
    margin-bottom: 20px;
    background-color: #fafafa;
    border: 1px solid #e3e3e3;
    border-radius: 0px;
    -webkit-box-shadow: none;
    box-shadow: none;
}
.profile-container .form-control {
    display: block;
    width: 100%;
    height: 50px;
    padding: 6px 12px;
    font-size: 20px;
	border-radius:2px;
}
.profile-container .nav-tabs li a h3 {
	margin:0px;
}

.profile-picture {
	height: 220px;
	margin: 0px auto;
}
</style>

<div class="container profile-container">
	<div class="row">
		<div id="alert-update-success" class="alert alert-success alert-message-container hide">

		</div>
		<div id="alert-update-fail" class="alert alert-danger alert-message-container hide">

		</div>
		<div class="col-md-12">
			<h2><i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;Update Profile</h2>
		</div>
		<div class="col-md-8 pc-left">
			<!-- -->
			<div class="well">
				<ul class="nav nav-tabs">
				  <li class="active"><a href="#home" data-toggle="tab"><h3>Profile</h3></a></li>
				  <li><a href="#profile" data-toggle="tab"><h3>Password</h3></a></li>
				</ul>
				<div id="myTabContent" class="tab-content">
				  <div class="tab-pane active in" id="home">
				  <br>
					<form id="tab">
						<label>Username</label>
						<input id="txt-update-username" type="text" value="<?php echo $member_info['username']; ?>" class="input-xlarge form-control profile-input">
						<div id="alert-update-username" class="alert alert-danger hide">

						</div>
						<!-- <label>First Name</label>
						<input type="text" value="Andre" class="input-xlarge form-control">
						<label>Last Name</label>
						<input type="text" value="Cipriano" class="input-xlarge form-control"> -->
						<label>Email</label>
						<input id="txt-update-email" type="text" value="<?php echo $member_info['email']; ?>" class="input-xlarge form-control profile-input">
						<div id="alert-update-email" class="alert alert-danger hide">

						</div>
						<label>Avatar</label><i>&nbsp;Paste image link here:</i>
						<input id="txt-update-avatar" type="text" value="<?php echo (!empty($member_info['avatar'])) ? $member_info['avatar']:''; ?>" class="input-xlarge form-control profile-input">
						<!-- <label>Address</label>
						<textarea value="Smith" rows="3" class="input-xlarge form-control">2817 S 49th Apt 314 San Jose, CA 95101
						</textarea> -->
						<div>
							<button id="btn-update" class="btn btn-primary" disabled>Update</button>
						</div>
					</form>
				  </div>
				  <div class="tab-pane fade" id="profile">
				  <br>
					<form id="tab2">
						<label>Current Password</label>
						<input id="txt-current-password" type="password" class="input-xlarge form-control password-input">
						<div id="alert-current-password" class="alert alert-danger hide">

						</div>
						<label>New Password</label>
						<input id="txt-new-password" type="password" class="input-xlarge form-control password-input">
						<div id="alert-new-password" class="alert alert-danger hide">

						</div>
						<input id="txt-username" type="hidden" class="input-xlarge form-control" value="<?php echo $_SESSION['user']; ?>">
					</form>
					<div>
						<button id="btn-change-pwd" class="btn btn-primary" disabled>Update</button>
					</div>
				  </div>
			  </div>
			  </div>
			<!-- -->
		</div>
		<div class="col-md-4 pc-right">
			<div class="avatar-container">
				<?php if(!empty($member_info['avatar'])): ?>
					<img class="profile-picture img-responsive" src="<?php echo $member_info['avatar']; ?>">
				<?php else: ?>
					<img class="profile-picture img-responsive" src="https://rdbuploads.s3.amazonaws.com/icons/dummy-avatar.png">
				<?php endif; ?>

				<!--<h3>Edit Avatar</h3>
				<input id="txt-update-avatar" type="text" value="<?php echo (!empty($member_info['avatar'])) ? $member_info['avatar']:''; ?>" class="input-xlarge form-control"> -->
				<!-- -->
				<!-- <form action="" method="post" enctype="multipart/form-data" id="js-upload-form">
					<div class="form-inline">
					  <div class="form-group">
						<input type="file" name="files[]" id="js-upload-files" multiple>
					  </div>
					  <button type="submit" class="btn btn-sm btn-primary" id="js-upload-submit">Upload Photo</button>
					</div>
				</form> -->
				<!-- <div class="progress">
					<div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
					  <span class="sr-only">60% Complete</span>
					</div>
				  </div> -->
				<hr>
				<!-- -->
			</div>
			<!-- <h3>Statistics</h3> -->
			<!-- <p><b>Join Date:</b> 20th June 2016</p> -->
			<!-- <p><b>Total Posts:</b> 10</p> -->
			<!-- <p><b>Post Per Day</b> 1</p>			 -->
			<!-- <p><b>Last Activity:</b> 27th June 2016 01:58 AM</p> -->
			<!-- <p><b>Join Date:</b> 20th June 2016</p> -->
			<!-- <p><b>Referrals:</b> 0</p> -->
		</div>
	</div>
</div>

<?php include('footer.php');?>
<!-- <script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
<script type="text/javascript">
	$('document').ready(function() {
		console.log('<?=$_SESSION['user']?>');
		$('.profile-input').on('change',function(){
			$('#btn-update').prop('disabled',false);
		});
		
		$('.password-input').on('change',function(){
			$('#btn-change-pwd').prop('disabled',false);
		});
		
		$('#btn-update').on('click', function(e) {
			var username = $('#txt-update-username').val();
			var email    = $('#txt-update-email').val();

			$('#alert-update-username').html('').addClass('hide');
			$('#alert-update-email').html('').addClass('hide');

			if(validateForm('update-profile')) {
				update();
			}

			e.preventDefault();
		});

		$('#btn-change-pwd').on('click', function(e) {
			var username = $('#txt-username').val();
			var password = $('#txt-current-password').val();
			var newPassword = $('#txt-new-password').val();

			$('#alert-current-password').html('').addClass('hide');
			$('#alert-new-password').html('').addClass('hide');

			if(validateForm('change-password')) {
				if(checkIfAccountExists(username, password)) {
					changePassword(newPassword);
				} else {
					$('#alert-current-password').html('The password you enter does not match your current password!').removeClass('hide');
				}
			}

			e.preventDefault();
		});
	});

	function checkIfEmailExists(email) {
	  var url = '<?=$info['ajax']?>/forum2/CheckIfEmailExists';
		var currentUserEmail = '<?=$_SESSION['email']?>';
	  
		if(currentUserEmail != email){
			var isExists = function() {
				var tmp = null;
				$.ajax({
					async  : false,
					type   : 'POST',
					url    : url,
					data   : { email: email, domain: '<?=$info['domain']?>' },
					success: function(res) {
						if(res.success) {
							tmp = res.data['isExists'];
						}
					}
				});
				return tmp;
			}();

			return isExists;
		}
	}

	function checkIfUsernameExists(username) {
	  var url = '<?=$info['ajax']?>/forum2/CheckIfUsernameExists';
		var currentUser = '<?=$_SESSION['user']?>';
		if(currentUser != username){
			var isExists = function() {
				var tmp = null;
				$.ajax({
					async  : false,
					type   : 'POST',
					url    : url,
					data   : { username: username, domain: '<?=$info['domain']?>' },
					success: function(res) {
						if(res.success) {
							tmp = res.data['isExists'];
						}
					}
				});
				return tmp;
			}();

			return isExists;
		}	  
	}

	function checkIfAccountExists(username, password) {
	  var url = '<?=$info['ajax']?>/forum2/CheckAccountExists';
	  var password = btoa(password);
	  var isExists = function() {
	    var tmp = null;
	    $.ajax({
	      async  : false,
	      type   : 'POST',
	      url    : url,
	      data   : { username: username, password: password, domain:'<?=$info['domain']?>'},
	      success: function(res) {
	        if(res.success) {
	          tmp = res.data['isExists'];
	        }
	      }
	    });
	    return tmp;
	  }();
	  return isExists;
	}

	function validateForm(form) {
		var alertUpdateUsername = $('#alert-update-username');
		var alertUpdateEmail = $('#alert-update-email');
		var alertPassword = $('#alert-current-password');
		var alertConfirmPassword = $('#alert-new-password');
		var error = 0;

		switch (form) {
			case 'change-password':
				var currentPassword = $('#txt-current-password').val();
				var newPassword = $('#txt-new-password').val();

				if(!currentPassword) {
					alertPassword.html('Please enter current old password.').removeClass('hide');
					error++;
				} else if(!newPassword) {
					alertConfirmPassword.html('Please enter your new password.').removeClass('hide');
					error++;
				}
			break;

			case 'update-profile':
				var username = $('#txt-update-username').val();
				var email    = $('#txt-update-email').val();

				if(!username) {
					alertUpdateUsername.html('Please enter your new username.').removeClass('hide');
					error++;
				} else if(checkIfUsernameExists(username)) {
					alertUpdateUsername.html('Username is already used by another user.').removeClass('hide');
					error++;
				}
				
				if(!email) {
					alertUpdateEmail.html('Please enter your new email address.').removeClass('hide');
					error++;
				} else if(!validateEmail(email)) {
					alertUpdateEmail.html('Please enter a valid email.').removeClass('hide');
					error++;
				} else if(checkIfEmailExists(email)){
					alertUpdateEmail.html('Email address is already used by another user.').removeClass('hide');
					error++;
				}
			break;
			default:

		}

		if(error > 0) {
			return false;
		} else {
			return true;
		}
	}

	function update() {
		var username = $('#txt-update-username').val();
		var email    = $('#txt-update-email').val();
		var avatar   = $('#txt-update-avatar').val();
		var image		 = $('.profile-picture');
		var url = '/profile/update';
		$.ajax({
			type: 'POST',
			url: url,
			data: { username: username, email: email, avatar: avatar },
			success: function(res) {
				var response = $.parseJSON(res);
				if(response.success) {
					$('#user').html(response.username+' &nbsp;<span class="caret"></span>');
					if(avatar) {
						image.attr('src', avatar);
					} else {
						image.attr('src', 'https://rdbuploads.s3.amazonaws.com/icons/dummy-avatar.png');
					}
					$('#alert-update-success').html(response.message).removeClass('hide');
					$('#txt-username').val(response.username);
				} else {
					$('#alert-update-fail').html(response.message).removeClass('hide');
				}

				setTimeout(function() {
					$('.alert-message-container').html('').addClass('hide');
					$('#btn-update').prop('disabled',true);
				}, 3000);
			}
		});		
	}

	function changePassword(newPassword) {
		var password = btoa(newPassword);
		var url = '/profile/changePassword';
		$.ajax({
			type: 'POST',
			url: url,
			data: { password: password },
			success: function(res) {
				var response = $.parseJSON(res);
				if(response.success) {
					$('#alert-update-success').html('You have successfully changed your password.').removeClass('hide');
				} else {
					$('#alert-update-fail').html('Sorry unable to update your profile. Please try again!').removeClass('hide');
				}
				
				setTimeout(function(){
					$('#alert-update-success').html('').addClass('hide');
					$('#btn-change-pwd').prop('disabled',true);
				},3000);
			}
		});
	}
	
	function validateEmail(email) {
		var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		return regex.test(email);
	}
</script>
