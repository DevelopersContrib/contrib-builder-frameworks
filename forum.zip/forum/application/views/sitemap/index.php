<?php include(dirname(__FILE__).'/../header.php');?>
<style>
.group-links{
	background-color: #fff;
    margin-bottom: 20px;
    padding: 15px;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="group-links">
				<h2>Main</h2>
				<ul class="markdown-toc" >
					<li>
						<a href="/" class="label label-info text-capitalize">Home</a>
					</li>
					<li>
						<a href="/" class="label label-info text-capitalize">Forum</a>
					</li>
					<li>
						<a href="/feed" class="label label-info text-capitalize">Feed</a>
					</li>
					<li>
						<a href="/account/login" class="label label-info text-capitalize">Login</a>
					</li>
					<li>
						<a href="/account/signup" class="label label-info text-capitalize">Signup</a>
					</li>
					<li>
						<a href="/partner" class="label label-info text-capitalize">Partner with us </a>
					</li>
					<li>
						<a href="/staffing" class="label label-info text-capitalize">Apply now</a>
					</li>
					<li>
						<a href="/referral" class="label label-info text-capitalize">Referral</a>
					</li>
					<li>
						<a href="/developers" class="label label-info text-capitalize">Developers </a>
					</li>
					<li>
						<a href="/about" class="label label-info text-capitalize">About us </a>
					</li>
					<li>
						<a href="/terms" class="label label-info text-capitalize">Terms </a>
					</li>
					<li>
						<a href="/privacy" class="label label-info text-capitalize">Privacy </a>
					</li>
					<li>
						<a href="/contact" class="label label-info text-capitalize">Contact us </a>
					</li>
					<li>
						<a href="/search" class="label label-info text-capitalize">Search </a>
					</li>
				</ul>
				
			</div>
			<?=$sitemap?>
		</div>		
	</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
	
});
</script>
<?php include(dirname(__FILE__).'/../footer.php');?>