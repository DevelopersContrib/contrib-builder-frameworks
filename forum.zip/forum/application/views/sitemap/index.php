<?php include(dirname(__FILE__).'/../header.php');?>
<style>
.group-links{
	background-color: #fff;
    margin-bottom: 20px;
    padding: 15px;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="group-links">
				<h2>Main</h2>
				<ul class="markdown-toc" >
					<li>
						<a href="/" class="label label-info text-capitalize">Home</a>
					</li>
					<li>
						<a href="/" class="label label-info text-capitalize">Forum</a>
					</li>
					<li>
						<a href="/feed" class="label label-info text-capitalize">Feed</a>
					</li>
					<li>
						<a href="/account/login" class="label label-info text-capitalize">Login</a>
					</li>
					<li>
						<a href="/account/signup" class="label label-info text-capitalize">Signup</a>
					</li>
					<li>
						<a href="/partner" class="label label-info text-capitalize">Partner with us </a>
					</li>
					<li>
						<a href="/staffing" class="label label-info text-capitalize">Apply now</a>
					</li>
					<li>
						<a href="/referral" class="label label-info text-capitalize">Referral</a>
					</li>
					<li>
						<a href="/developers" class="label label-info text-capitalize">Developers </a>
					</li>
					<li>
						<a href="/about" class="label label-info text-capitalize">About us </a>
					</li>
					<li>
						<a href="/terms" class="label label-info text-capitalize">Terms </a>
					</li>
					<li>
						<a href="/privacy" class="label label-info text-capitalize">Privacy </a>
					</li>
					<li>
						<a href="/contact" class="label label-info text-capitalize">Contact us </a>
					</li>
					<li>
						<a href="/search" class="label label-info text-capitalize">Search </a>
					</li>
				</ul>
				
			</div>
			<?//=$sitemap?>
			
			<div class="group-links">
			<h2>Topics</h2>
			<ul class="markdown-toc" >
			<?php
				foreach($topics as $topic){
			?>
				<li>
					<a href="/<?=$topic->slug?>" class="label label-info text-capitalize"><?=stripslashes($topic->topic_name)?></a>
				</li>
			<?php
				}
			?>
			</ul>
			</div>

			<div class="group-links">
			<h2>Threads</h2>
			<ul class="markdown-toc" >
			<?php
				foreach($posts as $post){
			?>
				<li>
					<a href="/<?=$post->topic->slug?>/<?=$post->post_id?>-<?=$post->slug?>" class="label label-info text-capitalize"><?=stripslashes($post->title)?></a>
				</li>
			<?php
				}
			?>
			</ul>
			</div>

			<div class="group-links">
			<h2>Members</h2>
			<ul class="markdown-toc" >
			<?php
				foreach($members as $member){
			?>
				<li>
					<a href="/members/<?=$member->username?>" class="label label-info text-capitalize"><?=$member->username?></a>
				</li>
			<?php
				}
			?>
			</ul>
			</div>

			<div class="group-links">
			<h2>Tags</h2>
			<ul class="markdown-toc" >
			<li>
					<a href="/tags" class="label label-info text-capitalize">Tag</a>
				</li>
			<?php
				foreach($tags as $tag){
			?>
				<li>
					<a href="/tag/<?=$tag->tag_name?>" class="label label-info text-capitalize"><?=$tag->tag_name?></a>
				</li>
			<?php
				}
			?>
			</ul>
			</div>
		</div>		
	</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
	
});
</script>
<?php include(dirname(__FILE__).'/../footer.php');?>