<?php $page = 'onboarding'; include('header.php');?>
<style>
.selected-container {
	margin-top:150px;
}
.selected-container .label {
    display: inline-block;
    padding: 10px;
    font-size: 100%;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: .25em;
    margin: 2px;
    margin-bottom: 5px;
}
.welcome-container {
	margin-top:30px;
}
.welcome-container hr {
	margin-top: 10px;
	margin-bottom: -10px;
	border: 0;
	border-top: 1px solid #bbb;
}
.welcome-note {
	margin-top:20px;
}
.panel-danger > .panel-heading {
    color: #fff;
    background-color: #CC0000;
    border-color: #CC0000;
}
.panel-heading {
    padding: 35px 15px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
}
.panel-heading h4 {
	font-size: 35px;
}
.button-checkbox .btn {
	text-align:right !important;
	padding: 5px 12px;
	border-radius: 0px;
	margin-bottom: 3px;
}
.button-checkbox .fa {
	font-size: 25px;
}
.btn.active {
    -webkit-box-shadow: inset 0 1px 3px rgba(0,0,0,.125);
    box-shadow: inset 0 1px 3px rgba(0,0,0,.125);
}
.btn-default.active {
    color: #333;
    background-color: #fafafa;
}
hr {
    margin-top: 10px;
    margin-bottom: 0px;
    border: 0;
    border-top: 1px solid #ccc;
}
.button-checkbox .chckbox-topic {
	color:#fff;
}
.glyphicon-check {
	color:#fff;
}
.add-ht h2, .add-ht h3 {
	display:none;
}
.adsbygoogle {
	position: absolute !important;
	margin-top: 20px;
}
.add-ht iframe {
	position: absolute;
left: 350px;
margin-top: 0px;
}
.for-container {
	background: #fff;
	padding: 10px 0px 25px;
}
</style>
<?php
$forum_domains = array(
		'drugforum.com',
		'TvForum.com',
		'vcforum.net',
		'studentforum.com',
		'CEOForum.com',
		'symphonyforum.com',
		'streamforums.com',
		'educationforum.com',
		'garageforum.com',
		'forumlink.com',
		'mitforum.com',
		'harleyforum.com',
		'exportforum.com',
		'chemicalforum.com',
		'collegeforum.com',
		'digitalforums.com',
		'gamingforum.com',
		'satelliteforum.com',
		'hacksforum.com',
		'telecomforum.com',
		'buddyforum.com',
		'smallbusinessforum.net',
		'talentforum.com',
		'discoveryforum.com',
		'sugarforum.com',
		'labforum.com',
		'guruforum.com',
		'ipforum.com',
		'dslforum.com',
		'codeforum.com'
	);

	$key = array_rand($forum_domains, 8);
?>
<div class="container">
		<div id="btn-check-container" style="display:">
			<div class="row">
				<div class="col-md-6 col-md-offset-3 text-center">
					<div class="welcome-container">
						<h3>Welcome <b style="color:green"><?php echo (isset($_SESSION['user'])) ? $_SESSION['user'] : 'Guest'; ?></b>!</h3>
						<hr>
						<h2>Follow more topics to get started</h2>
						<div id="error-message" class="alert alert-danger hide">

						</div>
						<p>Select your first topic </p>
					</div>
				</div>
			</div>
			<div class="row" id="btn-check">
				<ul class="list-unstyled">
					<?php if(!empty($topics)): ?>
						<?php foreach($topics as $topic): ?>
							<li class="col-md-3">
								<span class="button-checkbox">
									<button id="<?php echo 'btn_'.$topic['topic_id']; ?>" type="button" class="btn-topic btn btn-block" data-color="default" data-topic="<?php echo $topic['topic_name']; ?>" ><?php echo $topic['topic_name']; ?></button>
									<input id="<?php echo 'input_'.$topic['topic_id']; ?>" type="checkbox" value="<?php echo $topic['topic_id']; ?>" class="chckbox-topic hidden" name="topics[]" />
								</span>
							</li>
						<?php endforeach; ?>
					<?php endif; ?>
				</ul>
			</div>
			<div class="row">
				<div class="col-md-12 text-center">
				<br>
					<!-- <button id="btn-skip" class="btn btn-lg btn-default">Skip</button> -->
					<button id="btn-continue" class="btn btn-lg btn-primary">Continue</button>
				</div>
			</div>
			<hr>
			<div class="row">
				<?php if(isset($attr['additional_html'])): ?>
					<div class="col-md-offset-2 col-md-8 add-ht">
						<?php echo base64_decode($attr['additional_html']); ?>
					</div>
				<?php endif; ?>
			</div>
			<div style="clear:both;height:300px;"></div>
		</div>

		<div id="welcome-msg" class="hide">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="selected-container">

					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="welcome-note" id="welnote" style="display:;">
						<img src="https://cdn.vnoc.com/icons/Welcome-In-Green-Background.png" class="img-responsive" style="margin:0px auto; height:220px;">
						<h1>to <span style="color:green"><?php echo ucwords($info['domain']); ?></span> Forum!</h1>
						<div class="row">
							<div class="col-md-12 text-center for-container">
								<h3>Check Out Other Forum Sites</h3>
								<?php
									for($i = 0; $i < count($key); $i++) {
										echo '	<a href="https://www.'.$forum_domains[$key[$i]].'" class="btn btn-sm btn-info" target="_blank">'.$forum_domains[$key[$i]].'</a>';
									}
								?>

							</div>
						</div>
						<div class="row">
							<div class="col-md-12 text-center" style="margin-top: 10px;">
								<!-- <button id="btn-skip" class="btn btn-lg btn-default">Skip</button> -->
								<a href="/" class="btn btn-lg btn-primary">Continue</a>
							</div>
						</div>
						<!-- <p>Redirecting you to the forum</p> -->
						<!-- <div class="load-spinner"></div> -->
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- <script src="/static/js/onboarding.js" charset="utf-8"></script> -->
<script>
$(function () {
	$('.button-checkbox').each(function () {

		// Settings
		var $widget = $(this),
		$button = $widget.find('.btn-topic'),
		$checkbox = $widget.find('input:checkbox'),
		color = $button.data('color'),
		settings = {
			on: {
				icon: 'glyphicon glyphicon-check1'
			},
			off: {
				icon: 'glyphicon glyphicon-unchecked1'
			}
		};

		// Event Handlers
		$button.on('click', function () {
			$checkbox.prop('checked', !$checkbox.is(':checked'));
			$checkbox.triggerHandler('change');
			updateDisplay();
		});

		$checkbox.on('change', function () {
			updateDisplay();
		});

		// Actions
		function updateDisplay() {
			var isChecked = $checkbox.is(':checked');

			// Set the button's state
			$button.data('state', (isChecked) ? "on" : "off");

			// Set the button's icon
			$button.find('.state-icon')
			.removeClass()
			.addClass('state-icon ' + settings[$button.data('state')].icon);

			// Update the button's color
			if (isChecked) {
				$button
				.removeClass('btn-' + color + ' active')
				.addClass('btn-primary');
			} else {
				$button
				.removeClass('btn-primary')
				.addClass('btn-' + color + ' active');
			}
		}

		// Initialization
		function init() {
			updateDisplay();

			// Inject the icon if applicable
			if ($button.find('.state-icon').length == 0) {
				$button.prepend('<i class="state-icon ' + settings[$button.data('state')].icon + '"></i> ');
			}
		}

		init();
	});
});
</script>
<script>
	$(document).ready(function() {

		$('#btn-continue').on('click', function() {
			var topics = $("input[name='topics[]']:checked").map(function() {
				return this.value;
			}).get();

			if(topics.length > 5 || topics.length < 5) {
				$('#error-message').html('Please select a total of 5 topics!').removeClass('hide');
			} else {
				addTopics(topics);
			}
		});
	});

	function addTopics(value) {
		var topics = [];
		var url = "/onboarding/addTopics";

		$.each(value, function(i, l) {
			var inputId = '#input_' + l;
			var btnId = '#btn_' + l;
			var topic = $(inputId).prev(btnId).data('topic');
			topics[i] = l;
			$('.selected-container').append('<span class="label label-warning">'+ topic +'</span>');
		});

		$.ajax({
			type: 'POST',
			url: url,
			data: { topics: topics },
			success: function(res) {
				var response = $.parseJSON(res);
				if(response.status) {
					var redirect_url = "/";

					$('#btn-check-container').addClass('hide');
					$('#welcome-msg').removeClass('hide');

					// setTimeout(function() {
					// 	window.location.href = redirect_url;
					// }, 700);
				} else {
					var message = response.message;
					// var redirect_url = "https://beta.uboard.com/onboarding";
					$('#error-message').html(message).removeClass('hide');
				}


			}
		});
	}
</script>
