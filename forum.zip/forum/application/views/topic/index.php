<?php include(dirname(__FILE__).'/../header.php');?>
<?php include(dirname(__FILE__).'/../post-container.php');?>
<style>
#forum-sidebar {
	margin-top:0px;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<?php include(dirname(__FILE__).'/../bread_crumbs.php');?>
			
			<div class="fc-per-topic" style="margin-top:0px;">
				<h2><?=stripslashes($datatitle)?></h2>
				<p><?=stripslashes($datadesc)?></p>
			</div>
			<div class="for-ad-space">
				<?=base64_decode($info['additional_html']);?>
			</div>
			<div id="topic" class="main-topic-container forum-container thread-container ">

			</div>
		</div>
		<div class="col-md-4">
			<?php include(dirname(__FILE__).'/../sidebar.php');?>
		</div>
	</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#topic').loading({
		stoppable: false,
		message: 'Loading...',
	});
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/gettopics',
		data:{topic:'<?=$topic?>',post:'<?=$post?>',page:'<?=$page?>',uid:encodeURIComponent('<?=$_SESSION['uid']?>'), domain:jQuery('#domain').val()},
		error: function(){},
		success: function(response){
			jQuery('#topic').loading('stop');
			jQuery('#topic').html(response.data.html);
		}
	});
});
</script>

<?php include(dirname(__FILE__).'/../footer.php');?>
