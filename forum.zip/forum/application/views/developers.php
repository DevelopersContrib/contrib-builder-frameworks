<?php $page = 'developers'; include('header.php');?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<style>
.page-container {
	background: white;
	padding: 20px;
	margin-top: 100px;
	margin-bottom: 180px;
}
.page-container h3 {
	margin-top: 0px;
}
.page-container .blur-box {
	border-bottom: 1px solid #eee;
	padding: 10px 0px;
	margin-bottom: 15px;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 page-container">
			<h2 class="text-center">Developers <?php echo $info['domain']; ?></h3>
			<hr>
			<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Do you have code or an app that could run this brand? <?php echo $info['domain']; ?> is connected with Contrib. </h4>
			<p></p>
			<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?php echo $info['domain']; ?>? </h4>
			<p class="text-center">
			<br>
			<a href="/contact" class="btn btn-primary btn-lg">Inquire Here</a>
			</p>
		</div>
	</div>
</div>

<?php include('footer.php');?>
<!-- <script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
