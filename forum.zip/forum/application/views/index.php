<?php $page = 'index'; include('header.php'); ?>

	<?php include('post-container.php');?>

	<?php include('forum-container.php');?>

	<script src="/static/js/signup.js" charset="utf-8"></script>
	<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#txtpost').keypress(function(){
			return false;
		});
		jQuery(document).on('click', '.panel-heading span.clickable', function(e){
			var $this = jQuery(this);
			if(!$this.hasClass('panel-collapsed')) {
				$this.parents('.panel').find('.panel-body').slideUp();
				$this.addClass('panel-collapsed');
				$this.find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
			} else {
				$this.parents('.panel').find('.panel-body').slideDown();
				$this.removeClass('panel-collapsed');
				$this.find('i').removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up');
			}
		});
	});
	</script>

	<?php include('footer.php');?>
