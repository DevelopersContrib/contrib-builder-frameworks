<?php
if(isset($_SESSION['uid'])){
?>

<style type="text/css">
	
	#editor {
	max-height: 250px;
	height: 250px;
	background-color: white;
	border-collapse: separate; 
	border: 1px solid rgb(204, 204, 204); 
	padding: 10px; 
	box-sizing: content-box; 
	-webkit-box-shadow: rgba(0, 0, 0, 0.0745098) 0px 1px 1px 0px inset; 
	box-shadow: rgba(0, 0, 0, 0.0745098) 0px 1px 1px 0px inset;
	border-top-right-radius: 3px; border-bottom-right-radius: 3px;
	border-bottom-left-radius: 3px; border-top-left-radius: 3px;
	overflow: auto;
	outline: none;
 	 width: 547px;
}

div[data-role="editor-toolbar"] {
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.dropdown-menu a {
  cursor: pointer;
}

.btn-toolbar {
    font-size: 0;
    margin-bottom: 10px;
    margin-top: 10px;
}
.btn-toolbar .btn {
    border: 1px solid #31B0D5 !important;
	height: 30px;
	margin-bottom: 5px !important;
}
</style>
<!-- modal -->
<style>
#postTopic .btn-default {
    background-color: #fff;
    border-color: #ccc !important;
    color: #333;
}
</style>
<div class="modal fade" id="postTopic" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<img src="<?=!empty($_SESSION['avatar'])?$_SESSION['avatar']:'https://rdbuploads.s3.amazonaws.com/icons/forum-avatar.gif'?>" style="height:35px;">
	  </div>
	  <div class="modal-body">
		<div>
		<div class="msg msg-warning msg-danger-text" style="display:none;"> 
		<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span class="error-msg">Please input a topic here</span></div>
		<input id="title" name="title" type="text" class="form-control input-lg txt" placeholder="What do you want to discuss?" />
		</div>
		<br>
		<div>
		<div class="msg msg-warning msg-danger-text" style="display:none; margin-top: 100px;"> 
		<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span class="error-msg">Please enter your details</span></div>
		<!-- <textarea id="description" name="description" class="form-control txt" placeholder="Enter Details Here"></textarea>-->		
		<!-- start of the wysiwyg -->
        <div class="btn-toolbar" data-role="editor-toolbar" data-target="#editor">
          <div class="btn-group">
            <a class="btn btn-default dropdown-toggle" data-toggle="dropdown" title="Font"><i class="fa fa-font"></i><b class="caret"></b></a>
              <ul class="dropdown-menu">
              </ul>
          </div>
          <div class="btn-group">
            <a class="btn btn-default dropdown-toggle" data-toggle="dropdown" title="Font Size"><i class="fa fa-text-height"></i>&nbsp;<b class="caret"></b></a>
             <ul class="dropdown-menu">
              <li><a data-edit="fontSize 5"><font size="5">Huge</font></a></li>
              <li><a data-edit="fontSize 3"><font size="3">Normal</font></a></li>
              <li><a data-edit="fontSize 1"><font size="1">Small</font></a></li>
              </ul>
          </div>
          <div class="btn-group">
            <a class="btn btn-default" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="fa fa-bold"></i></a>
            <a class="btn btn-default" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="fa fa-italic"></i></a>
            <a class="btn btn-default" data-edit="strikethrough" title="Strikethrough"><i class="fa fa-strikethrough"></i></a>
            <a class="btn btn-default" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="fa fa-underline"></i></a>
          </div>
          <div class="btn-group">
            <a class="btn" data-edit="insertunorderedlist" title="Bullet list"><i class="fa fa-list-ul"></i></a>
            <a class="btn" data-edit="insertorderedlist" title="Number list"><i class="fa fa-list-ol"></i></a>
            <a class="btn" data-edit="outdent" title="Reduce indent (Shift+Tab)"><i class="fa fa-indent"></i></a>
            <a class="btn" data-edit="indent" title="Indent (Tab)"><i class="fa fa-indent"></i></a>
          </div>
           <div class="btn-group">
            <a class="btn" data-edit="undo" title="Undo (Ctrl/Cmd+Z)"><i class="fa fa-undo"></i></a>
            <a class="btn" data-edit="redo" title="Redo (Ctrl/Cmd+Y)"><i class="fa fa-repeat"></i></a>
          </div>
          <div class="btn-group">
            <a class="btn" data-edit="justifyleft" title="Align Left (Ctrl/Cmd+L)"><i class="fa fa-align-left"></i></a>
            <a class="btn" data-edit="justifycenter" title="Center (Ctrl/Cmd+E)"><i class="fa fa-align-center"></i></a>
            <a class="btn" data-edit="justifyright" title="Align Right (Ctrl/Cmd+R)"><i class="fa fa-align-right"></i></a>
            <a class="btn" data-edit="justifyfull" title="Justify (Ctrl/Cmd+J)"><i class="fa fa-align-justify"></i></a>
          </div>
        </div>
        <div id="editor"></div>
        <textarea rows="2" id="descriptions" name="desc" cols="20" style="display:none;"  placeholder="Enter Your Details Here" >  </textarea>
		<!-- end of the wysiwyg -->
		</div>

		<br>
		<div>
		<div class="msg msg-warning msg-danger-text" style="display:none;"> 
		<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span class="error-msg">Please choose a topic</span></div>
		<select id="topic_id" name="topic_id" class="form-control">
		  <option value="">-- Choose a topic --</option>
		</select>
		</div>
		<br>
		<div>
			<input name="tags" id="tags" value="" />
		</div>
		<?php
			if($_SESSION['account_type'] =='premium'){
		?>
		<div class="checkbox"> <label> <input id="is_private" type="checkbox"> Private </label> </div>
		<div id="links"></div>	
		<button style="margin-top:10px" class="btn btn-primary" type="button" id="add-links">Add Items</button>
		<?php
			}
		?>
	  </div>							
	  <div class="modal-footer">
		<button id="submit-topic" data-loading-text="Saving..." type="button" class="btn btn-primary">Submit Topic</button>
	  </div>
	</div>
  </div>
</div>
<!-- end modal -->
<script src="/static/js/bootstrap-wysiwyg.js"></script>
<script src="/static/js/jquery.hotkeys.js"></script>
<!-- script for wysiwug -->
<script>

  $(function(){
    function initToolbarBootstrapBindings() {
      var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier', 
            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
            'Times New Roman', 'Verdana'],
            fontTarget = $('[title=Font]').siblings('.dropdown-menu');

      $.each(fonts, function (idx, fontName) {
          fontTarget.append($('<li><a data-edit="fontName ' + fontName +'" style="font-family:\''+ fontName +'\'">'+fontName + '</a></li>'));
      });

      $('a[title]').tooltip({container:'body'});

    	$('.dropdown-menu input').click(function() {return false;})
		    .change(function () {$(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');})
        .keydown('esc', function () {this.value='';$(this).change();});

      $('[data-role=magic-overlay]').each(function () { 
        var overlay = $(this), target = $(overlay.data('target')); 
        overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
      });
  	};

  	function showErrorAlert (reason, detail) {

  		var msg='';
  		if (reason==='unsupported-file-type') { msg = "Unsupported format " +detail; }
  		else {
  			console.log("error uploading file", reason, detail);
  		}
  		$('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>'+ 
  		 '<strong>File upload error</strong> '+msg+' </div>').prependTo('#alerts');
  	};
    initToolbarBootstrapBindings();  

  	$('#editor').wysiwyg({ fileUploadError: showErrorAlert} );
      window.prettyPrint && prettyPrint();
    });

</script>
<!-- end of the wysiwug -->

<script type="text/javascript">
function addlinks()
{
	var link = '<div class="input-group link">'+
		'<div class="msg msg-warning msg-danger-text" style="display:none;">'+
		'<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span class="error-msg">Invalid url format</span></div>'+
		'<input type="text" class="form-control url" placeholder="http://site.com/">'+
		'<span class="input-group-btn">'+
			'<button class="btn btn-default remove-links" type="button">x</button>'+
		'</span>'+
	'</div>';
	
	jQuery('#links').append(link);
	
	jQuery('.remove-links').off('click').on('click',function(){
		jQuery(this).parents('.link').remove();
	});
}

jQuery(document).ready(function(){
	jQuery('#add-links').click(function(){
		addlinks();
	});
	
	jQuery('#tags').tagsInput();
	
	jQuery('#postTopic').on('show.bs.modal', function (e) {
		jQuery('#postTopic').find('.msg').hide();
		jQuery('.txt').val('');
		jQuery('.link').remove();
	});
	
	var ajax = jQuery.ajax({
		type: "POST",
		url: '<?=$info['ajax']?>/forum2/gettopics',
		data:{uid:encodeURIComponent('<?=$_SESSION['uid']?>'),req:'c',domain:jQuery('#domain').val()},
		error: function(){
		
		},
		success: function(response){
			var p = '';
			for(var x=0;x<response.data.length;x++){
				if(p!=response.data[x].parent_id){
					jQuery('#topic_id').append('<optgroup label="'+response.data[x].parent_name+'">');
				}
				p = response.data[x].parent_id;
				jQuery('#topic_id').append('<option value="'+response.data[x].topic_id+'">'+response.data[x].topic_name+'</option>');
			}
		}
	});
	
	jQuery('#postTopic .form-control').focus(function(){
		jQuery(this).parent().find('.msg').hide();
	});
	
	jQuery('#postTopic .form-control').click(function(){
		jQuery(this).parent().find('.msg').hide();
	});
	
	jQuery('#submit-topic').click(function(){
		jQuery('#postTopic').find('.msg').hide();
		var title = jQuery('#postTopic #title').val();

		var editor = jQuery('#postTopic #editor').html();
		var descriptions = jQuery('#postTopic #descriptions').val();
		descriptions = editor;

		var topic_id = jQuery('#postTopic #topic_id').val();
		var domain = jQuery('#domain').val();
		var tags = '';

		jQuery('#postTopic .tag span').each(function(){
			var t =jQuery(this).html().replace(/\s+/g, '');
			t = t.replace(/&nbsp;/g, '');
			tags += tags==''? t:","+t;
		});

		var formdata = {
			title:title,
			editor:editor,
			topic_id:topic_id,
			domain:domain,
			tags:tags
		}
		
		if(title==''){
			jQuery('#postTopic #title').parent().find('.msg').show();
			return false;
		}

		if(descriptions==''){
			jQuery('#postTopic #editor').parent().find('.msg').show();
			return false;
		}else if(descriptions=='<br>'){
			jQuery('#postTopic #editor').parent().find('.msg').show();
			return false;
		}

		if(topic_id==''){
			jQuery('#postTopic #topic_id').parent().find('.msg').show();
			return false;
		}
		
		var url = '';
		var error = false;
		jQuery('#postTopic .url').each(function(){
			if(!validateURL(jQuery(this).val())){
				jQuery(this).parent().find('.msg').show();
				error = true;
			}else{
				url += url==''?jQuery(this).val():'::'+jQuery(this).val();
			}
		});
		
		if(error) return false;
			
		var $btn = jQuery(this).button('loading');
		var ajax = jQuery.ajax({
			type: "POST",
			url: '<?=$info['ajax']?>/forum2/posttopic',
			data:{
				title:title,
				uid:encodeURIComponent('<?=$_SESSION['uid']?>'),
				description:editor,
				topic_id:topic_id,
				domain:domain,
				tags:tags,
				<?php
					if($_SESSION['account_type'] =='premium'){
				?>
				is_private:jQuery('#is_private').is(':checked')?1:0,
				url:url,
				<?php
					}
				?>
				req:'c',
			},
			error: function(){
				$btn.button('reset');
				jQuery('#postTopic').modal('hide');
			},
			success: function(response){
				$btn.button('reset');
				jQuery('.link').remove();
				jQuery('#postTopic').modal('hide');
				window.location = '/'+response.data.slug;
			}
		});
	});
});

function validateURL(textval) {
    var urlregex = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/;
    return urlregex.test(textval);
}
</script>




<?php
}else{
?>
<?php
}
?>
