<?php $page = 'contact'; include('header.php');?>
<style>
.page-container {
	background:white;
	padding:20px;
	margin-top:20px;
	margin-bottom:50px;
}
.page-container h3 {
	margin-top: 0px;
}
.page-container .blur-box {
	border-bottom: 1px solid #eee;
	padding: 10px 0px;
	margin-bottom: 15px;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 page-container">
			<h2 class="text-center">Contact <? echo $info['domain']?></h3>
			<hr>
			<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<? echo $info['domain']?>"></script>
		</div>
	</div>
</div>

<?php include('footer.php');?>
<!-- <script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
