<?php $page = 'premium'; include('header.php');?>
<style>
.premium-container {
	margin-top:30px;
	margin-bottom:100px;
}
.panel {
    margin-bottom: 0px;   
}
strong {
	font-size: 35px;
}
.premium-box {
	margin-top:50px;
}
.list-group-item {
    position: relative;
    display: block;
    padding: 15px 15px;
    margin-bottom: -1px;
    background-color: #fff;
    border: 1px solid #ddd;
    font-size: 17px;
}
.panel-body {
    padding: 15px;
    border-bottom: 10px solid #dedede;
}
.pm {
	color:green;
	text-transform:capitalize;
}
.lead {
    margin-bottom: 0px;   
    margin-top: 10px;
}
.icon-premium {
	position: absolute;
left: 10px;
margin-top: -21px;
}
.btn-success {   
    font-size: 19px !important;
    padding: 12px 12px !important;
}
</style>
<div class="premium-container container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3 text-center premium-box">
				<div class="panel panel-success">
					<div class="panel panel-danger">						
						<div class="panel-body text-center">
							<img src="https://cdn.vnoc.com/icons/premium-icon.png" class="icon-premium">
							<p class="lead">
								<strong>Premium Account</strong>
								<p class="pm"><?php echo $info['domain']; ?> Premium Membership</p>
							</p>
						</div>
						<ul class="list-group list-group-flush text-center">
							<li class="list-group-item"><i class="icon-ok text-danger"></i>Join <?php echo $info['domain']; ?> Forum Discussions </li>
							<li class="list-group-item"><i class="icon-ok text-danger"></i>Allows user to post ads on the right side bar</li>
							<li class="list-group-item"></i>Allows user to post to marketplace</li>
							<li class="list-group-item"></i>Allows user to download free items posted by other users</li>
							<li class="list-group-item"></i>Allows user to access and create private forums</li>
						</ul>
						<div class="panel-footer">
							<a class="btn btn-lg btn-block btn-success" href="/pay" id="btn-upgrade">
								UPGRADE TO PREMIUM ACCOUNT
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
</div>
<?php include('footer.php');?>