<html>
<head>
	<title><?php echo stripslashes($title)//$info['title']; ?></title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta id="meta-title" name="title" content="<?php echo stripslashes(strip_tags($title)) ?>" />
	<?php /*?><meta id="meta-desc" name="description" content="<?php echo $info['domain']; ?> <?php echo $info['description']; ?>" /><?php */?>
	<meta id="meta-desc" name="description" content="<?php echo substr(stripslashes(strip_tags($description)),0,155).'...'; ?>" />
	<meta name="keywords" content="<?php echo $info['keywords']; ?>" />
    <meta name="author" content="<?php echo $info['domain']; ?>"/>  
    
     <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet" />
	<link href="/static/css/forum.css" rel="stylesheet" />
	<link href="/static/css/jquery.loading.css" rel="stylesheet" />

	<script src="https://code.jquery.com/jquery-1.12.3.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<script src="/static/js/jquery.loading.min.js" charset="utf-8"></script>
	<script src="/static/js/signup.js" charset="utf-8"></script>
	<script src="/static/js/jquery.tagsinput.js"></script>
	<link href="/static/css/jquery.tagsinput.css" rel="stylesheet" />
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
		// ga('create', 'UA-83684919-1', 'auto');
		ga('create', '<?=$info['account_ga']?>', 'auto');
		ga('send', 'pageview');
	</script>
	<!-- Piwik -->
	<script type="text/javascript">
		var _paq = _paq || [];
		_paq.push(['trackPageView']);
		_paq.push(['enableLinkTracking']);
		(function() {
			var u="//www.stats.numberchallenge.com/";
			_paq.push(['setTrackerUrl', u+'piwik.php']);
			_paq.push(['setSiteId', <?=$info['piwik_id']; ?>]);
			var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
			g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
		})();
	</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
	<style>
	#tags_tagsinput{
		width: 100% !important;
		border-radius: 4px;
		box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
		color: #555;
		display: block;
		font-size: 14px;
		line-height: 1.42857;
		transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
	}
	.tagsinput{
		width: 100% !important;
		border-radius: 4px;
		box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
		color: #555;
		display: block;
		font-size: 14px;
		line-height: 1.42857;
		transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
	}
	</style>
	<style>
	.top-navigation .btn-reg:hover {
		background:#C9302C !important;
		color:#fff !important;
		border-bottom: none !important;
	}
	.top-navigation .navbar-nav > li > a {
		padding-top: 15px;
		padding-bottom: 10px !important;
	}
	body {
		background:#EFEFEF;
	}
	#post-container-bg {
		<?php if(isset($attr['background_image'])): ?>
		background: #333 url(<?php echo $attr['background_image']; ?>);
		background-size: cover;
		<?php else: ?>
		background: #333 !important;
		<?php endif; ?>
		padding:70px 0px;
		margin-bottom:20px;
		position: relative;
	}
	.post-container {
		background: rgba(97, 104, 98, 0.3);
		padding: 15px 30px;
		margin-top: 20px;
		margin-bottom: 20px;
		border-radius: 3px;
		position: relative;
	}
	.bg-overlay {
		background-color: rgba(19, 19, 21, 0.8);
		bottom: 0;
		left: 0;
		position: absolute;
		right: 0;
		top: 0;
	}
	.post-container .btn-lg {
		padding: 12px 16px;
	}
	.post-container .input-lg {
		height: 50px;
		font-size:23px;
	}
	#forum-sidebar {
		background:#fff;
		padding:10px 15px;
		margin-top: 50px;
		margin-bottom: 50px;
		padding-bottom:20px;
	}
	#forum-sidebar .fs-container h3 {
		border-bottom: 2px solid #dedede;
		padding-bottom: 10px;
		margin-bottom: 10px;
	}
	#forum-sidebar .list-group-item {
    padding: 3px 0px;
    margin-bottom: 0px;
    background-color: #fff;
    border: none;
	}
	.g-recaptcha {
		margin-left: 25px;
		margin-top: 10px;
		margin-bottom: 10px;
	}
	.search-container .input-group {
		width: 130%;
		margin-left: 30px;
	}
	.btn-out {
		border: medium none;
	background: transparent none repeat scroll 0% 0%;
	padding: 0px;
	}
	.txt-domain {
		font-size: 32px;
		display: inline-block;
		margin-top: 10px;
		color: rgb(255, 255, 255);
		text-transform: capitalize;
	}
	.txt-domain a {
		color:#fff;
		text-decoration:none;
	}
	.dropdown-menu .upa {		
		color:#EC971F;
	}
	</style>
</head>
	<body>
		<header class="top-navigation">
			<div class="container">
				<div class="row">
					<div class="tn-bar">
						<nav class="navbar navbar-default navbar-static-top">
						  <div class="container">
							<div class="navbar-header">
							  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							  </button>
							 <!-- <a class="navbar-brand" href="/"><img src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-174x35.png" class="f_logo"></a>
							  -->
							  <? if($info['logo']!=''){ ?>
								<a class="navbar-brand" href="http://<?=$info['domain']?>"><img class="img-domain f_logo" src="<?=$info['logo']?>" alt="<?=$info['title']?>" title="<?=$info['domain']?>"/></a>
								<? }else{ ?>
								<h1 class="txt-domain"><a href="http://<?=$info['domain']?>"><?=ucwords($info['domain'])?></a></h1>
								<? } ?>

							</div>
							<div id="navbar" class="navbar-collapse collapse">
							  <ul class="nav navbar-nav">
									<?php include('search.php');?>
							  </ul>

							  <ul class="nav navbar-nav navbar-right">
								<li>
									<a href="/" id="nav-forum" class="nav-menu">Forum</a>
								</li>
								<li>
									<a href="/feed" id="nav-feed" class="nav-menu">Feed</a>
								</li>
								<li>
									<a href="/marketplace" id="nav-marketplace" class="nav-menu">Marketplace</a>
								</li>
								<?php if(isset($_SESSION['user'])): ?>
									<li class="dropdown">
										<a href="#" id="user" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['user']; ?>&nbsp;<span class="caret"></span></a>
										<ul class="dropdown-menu">
										  <li class="hide"><a href="#"><i class="fa fa-gear" aria-hidden="true"></i>&nbsp;Settings</a></li>											
											<?php if($page != 'premium' && $info['member_info']['account_type'] == 'free'){ ?>
												<li><a href="/premium" class="upa"><i class="fa fa-arrow-circle-up" aria-hidden="true"></i>&nbsp;Upgrade to Premium Account</a></li>
											<?php }elseif($info['member_info']['account_type'] == 'premium'){ ?>
												<li><a href="/postads" class="upa"><i class="fa fa-clipboard" aria-hidden="true"></i>&nbsp;Post Ads</a></li>
												<li><a href="/postoffer" class="upa"><i class="fa fa-tags" aria-hidden="true"></i>&nbsp;Post Offer</a></li>
											<?php } ?>
										  <li><a href="/profile"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;Update Profile</a></li>
											<li><a href="/home/logout"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;Log Out</a></li>
										  <!-- <li class="btn-out-c">
													<form class="" action="" method="POST">
														<button type="submit" name="logout" class="btn-out">
															<i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;Log Out
														</button>
													</form>
											</li> -->
										</ul>
									</li>
								<?php else: ?>
									<li><a href="/account/login">Login</a></li>
									<li><a href="/account/signup" class="btn btn-danger btn-reg">Sign Up</a>
									</li>
								<?php endif; ?>
							  </ul>
							</div><!--/.nav-collapse -->
						  </div>
						</nav>
					</div>
				</div>
			</div>
		</header>
<script type="text/javascript">
$(document).ready(function() {
	var page = window.location.href;
	var index = '<?php echo $page; ?>';

	if(page.indexOf('feed') > -1) {
		$('#nav-feed').addClass('active');
		$('#nav-forum').removeClass('active');
	} else if(index == 'index') {
		$('#nav-forum').addClass('active');
		$('#nav-feed').removeClass('active');
	} else {
		$('#nav-forum').removeClass('active');
		$('#nav-feed').removeClass('active');
	}
});
</script>
