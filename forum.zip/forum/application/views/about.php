<?php $page = 'referral'; include('header.php');?>
<style>
.page-container {
	background: white;
	padding: 30px 20px 60px;
	margin-top: 50px;
	margin-bottom: 90px;
}
.page-container h3 {
	margin-top: 0px;
}
.page-container .blur-box {
	border-bottom: 1px solid #eee;
	padding: 10px 0px;
	margin-bottom: 15px;
}
/* about us */
.about-year { border: 2px solid #6d6d6d; display: inline-block; font-size: 17px; height: 120px; margin-bottom: 40px; padding: 0px; width: 120px; }
.about-year span { font-size: 50px; font-weight: 600; left: -4px; letter-spacing: -5px; position: relative; top: 13px; }
.timeline-number { font-family: "Oswald",sans-serif; font-size: 25px; padding: 15px; line-height:25px;}
.timeline-year {font-size: 20px; font-weight: 600; line-height:60px;}
.text-uppercase {
    text-transform: uppercase;
    font-size: 25px;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 page-container text-center">
			<h2 class="text-center">About <? echo $info['domain']?></h3>
			<hr><br>
			<div class="about-year text-uppercase white-text"><span class="clearfix">20</span> Years</div>
            <p class="title-small text-uppercase letter-spacing-1 white-text font-weight-100">We have been in the forefront of domain development and technologies since 1996</p>
		</div>
	</div>
</div>

<?php include('footer.php');?>
<!-- <script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
