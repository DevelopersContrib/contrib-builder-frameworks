<?php $page = 'onboarding'; include('header.php');?>
<style>
.welcome-container {
	margin-top:50px;
}
.welcome-note {
	margin-top:140px;
}
.panel-danger > .panel-heading {
    color: #fff;
    background-color: #CC0000;
    border-color: #CC0000;
}
.panel-heading {
    padding: 35px 15px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
}
.panel-heading h4 {
	font-size: 35px;
}
.button-checkbox .btn {
	text-align:left !important;
	padding: 8px 12px;
	border-radius: 0px;
}
.button-checkbox .fa {
	font-size: 25px;
}
</style>
<div class="container">
		<div id="btn-check-container" style="display:">
			<div class="row">
				<div class="col-md-6 col-md-offset-3 text-center">
					<div class="welcome-container">
						<h3>Welcome, <b style="color:green">andrecipriano</b></h3>
						<hr>
						<h2>Follow more topics to get started</h2>
						<p>Select your first topic </p>						
					</div>
					
				</div>			
			</div>
			<div class="row" id="btn-check">
				<div class="col-md-3">
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Internet Marketing<i class="fa fa-object-group pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Freemarket<i class="fa fa-shopping-bag pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">SEO<i class="fa fa-cog pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Ad Network<i class="fa fa-area-chart pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Mobile Marketing<i class="fa fa-mobile pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Copy Writing<i class="fa fa-keyboard-o pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
				</div>
				<div class="col-md-3">
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Growth Hacking<i class="fa fa-pagelines pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Social Network<i class="fa fa-users pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">CRO<i class="fa fa-circle-o-notch pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Offline Marketing<i class="fa fa-microphone pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Web Design<i class="fa fa-desktop pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Local Events<i class="fa fa-share-alt pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
				</div>
				<div class="col-md-3">
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">eCommerce<i class="fa fa-shopping-cart pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Personal Development<i class="fa fa-level-up pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Product Reviews<i class="fa fa-certificate pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Programming<i class="fa fa-code pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Email Marketing<i class="fa fa-envelope pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">PPC/SEM<i class="fa fa-bar-chart pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
				</div>
				<div class="col-md-3">
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">eCommerce<i class="fa fa-shopping-cart pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Personal Development<i class="fa fa-level-up pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Product Reviews<i class="fa fa-certificate pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Programming<i class="fa fa-code pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">Email Marketing<i class="fa fa-envelope pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
					<br>
					<span class="button-checkbox">
						<button type="button" class="btn btn-block" data-color="primary">PPC/SEM<i class="fa fa-bar-chart pull-right" aria-hidden="true"></i></button>
						<input type="checkbox" class="hidden" checked />
					</span>
				</div>				
			</div>
			<hr>
			<div class="row">
				<div class="col-md-12 text-right">
					<a href="index.php" class="btn btn-lg btn-default">Skip</a>
					<a href="index.php" class="btn btn-lg btn-primary">Continue</a>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12 text-center">				
				<div class="welcome-note" id="welnote" style="display:;">
					<img src="https://rdbuploads.s3.amazonaws.com/icons/Welcome-In-Green-Background.png" class="img-responsive" style="margin:0px auto; height:220px;">
					<h1>to <span style="color:green">brand.com</span> Forum!</h1>
					<p>Redirecting you to the forum ....</p>
				</div>
			</div>
		</div>
	</div>
	
	<script src="https://code.jquery.com/jquery-1.12.3.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<script>
	$(function () {
    $('.button-checkbox').each(function () {

        // Settings
        var $widget = $(this),
            $button = $widget.find('button'),
            $checkbox = $widget.find('input:checkbox'),
            color = $button.data('color'),
            settings = {
                on: {
                    icon: 'glyphicon glyphicon-check'
                },
                off: {
                    icon: 'glyphicon glyphicon-unchecked'
                }
            };

        // Event Handlers
        $button.on('click', function () {
            $checkbox.prop('checked', !$checkbox.is(':checked'));
            $checkbox.triggerHandler('change');
            updateDisplay();
        });
        $checkbox.on('change', function () {
            updateDisplay();
        });

        // Actions
        function updateDisplay() {
            var isChecked = $checkbox.is(':checked');

            // Set the button's state
            $button.data('state', (isChecked) ? "on" : "off");

            // Set the button's icon
            $button.find('.state-icon')
                .removeClass()
                .addClass('state-icon ' + settings[$button.data('state')].icon);

            // Update the button's color
            if (isChecked) {
                $button
                    .removeClass('btn-default')
                    .addClass('btn-' + color + ' active');
            }
            else {
                $button
                    .removeClass('btn-' + color + ' active')
                    .addClass('btn-default');
            }
        }

        // Initialization
        function init() {

            updateDisplay();

            // Inject the icon if applicable
            if ($button.find('.state-icon').length == 0) {
                $button.prepend('<i class="state-icon ' + settings[$button.data('state')].icon + '"></i> ');
            }
        }
        init();
    });
});
	</script>