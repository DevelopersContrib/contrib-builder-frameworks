<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Signup to <?php echo $info['domain']; ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet" />
<link href="/static/css/forum.css" rel="stylesheet" />
<!-- <script src='https://www.google.com/recaptcha/api.js'></script> -->
<style>
body {
	background:#000 url(https://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/dvsup.png);
	color:#fff;
}
.form-signup {
	width: 350px;
	margin: 0px auto 0px;
}
hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #333;
}
.signup-container {
	margin-top:100px;
}
.signup-container .fa-times-circle {
	color:#fff;
	font-size:35px;
	float:right;
}
.msg {
	background: rgb(250, 250, 250) none repeat scroll 0% 0%;
	color: rgb(51, 51, 51);
	padding: 3px 6px;
	position: absolute;
	border: 1px solid #F87217;
	right: 120px;
	margin-top: 30px;
}
.signup-container .wrapper p {
	font-size:12px;
	margin: 0 0 5px;
}
.form-control {
	border:none;
}
.input-lg {
    height: 50px;
    font-weight: bold;
}
</style>
</head>
<body>
	<div class="container signup-container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<a href="/" id=""><i class="fa fa-times-circle" aria-hidden="true"></i></a>
				<hr>
			</div>
			<div class="col-md-6 col-md-offset-3 text-center">
				<div class="form-signup">
					<h1>Sign Up To Forum</h1>
					<div id="signup-user-error-container" class="msg msg-warning msg-danger-text hide">
						<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span    id="signup-user-error" class="error-msg"></span>
					</div>
					<input type="text" id="txt-username" class="form-control input-lg" placeholder="username" value="<?php echo (isset($username)) ? $username : ''; ?>" />
					</br>
					<div id="signup-email-error-container" class="msg msg-warning msg-danger-text hide">
						<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span id="signup-email-error" class="error-msg"></span>
					</div>
					<input type="text" id="txt-email" class="form-control input-lg" placeholder="email" value="<?php echo (isset($email)) ? $email : ''; ?>" />
					</br>
					<div id="signup-pwd-error-container" class="msg msg-warning msg-danger-text hide">
						<span class="glyphicon glyphicon-exclamation-sign"></span>&nbsp;<span id="signup-pwd-error" class="error-msg"></span>
					</div>
					<input type="password" id="txt-password" class="form-control input-lg" placeholder="password" />
					<!-- <div class="g-recaptcha" data-sitekey="6LcItiMTAAAAAKMAk9K3A8NUW6WEFxnExBWRI8AO">

					</div>
					<div id="alert-captcha" class="alert alert-danger hide">

					</div> -->
					<input type="hidden" id="current-domain" value="<?php echo $info['domain']; ?>">
					<input type="hidden" id="ip-address" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
					<input type="hidden" id="avatar" value="<?php echo (isset($avatar)) ? $avatar : ''; ?>">
					<hr>
					<div class="wrapper">
						<span class="group-btn">
							<a href="" id="btn-signup" class="btn btn-danger btn-lg btn-block">Sign Up <i class="fa fa-sign-in" aria-hidden="true"></i></a>
						</span>
						<br>
						<p>Already have an account? <a href="/account/login"><i class="fa fa-key" aria-hidden="true"></i>&nbsp;Login Here</a></p>
						<div id="loader" class="text-center load-container">
							<div class="load-spinner"></div>
							Submitting your data
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="/static/js/signup.js" charset="utf-8"></script>
<script>
	$(document).ready(function() {
		var loader = $('#loader');
		loader.hide();

		$('#btn-signup').on('click', function(e) {
			loader.show();
			if(validateSignupForm()) {
				register();
			} else {
				loader.hide();
			}
	    e.preventDefault();
	  });

		$('.form-control').on('keyup', function(e) {
			var key = e.which || e.keyCode;
			if(key == '13' || key == 13) {
				$('#btn-signup').trigger('click');
			}
		});

	});
</script>
</body>
</html>
