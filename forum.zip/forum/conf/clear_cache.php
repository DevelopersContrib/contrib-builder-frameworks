<?php

$dir = PATH_ROOT.'/cache/';

$dirHandle = opendir($dir);

while ($file = readdir($dirHandle)) {
    if(!is_dir($file)) {
        unlink ("$dir"."$file"); // unlink() deletes the files
    }
}

closedir($dirHandle);
?>

