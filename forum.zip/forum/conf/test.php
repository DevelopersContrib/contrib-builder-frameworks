<?
if($domain_type=="subdomain")
	$db=$cpanel_username."_vanilla_".$subdomain; //SUBDOMAIN
else
	$db=$cpanel_username."_vanilla"; 	
system("mysql -u$cpanel_username -p$cpanel_password $db < vanilla.sql",$res);
 
?> 