<?php if (!defined('APPLICATION')) exit();
$api_url = "http://www.contrib.com/api/";
$monetize_url = "http://manage.vnoc.com/monetize/getcode";

require_once'curl_client.php';
$max_redirect = 3;  // Skipable: default => 3
$client = new Curl_Client(array(

	CURLOPT_FRESH_CONNECT => 1,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_USERAGENT => ''

), $max_redirect);


$sitename =  $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];

if(stristr($sitename, '~') ===FALSE) {
	$sitename = $_SERVER["HTTP_HOST"];								
	$sitename = str_replace("http://","",$sitename);
	$sitename = str_replace("www.","",$sitename);	
	$key = md5($sitename);
	$siteurl = "http://".$sitename;
}else {
   $key = md5('vnoc.com');
   $d = explode('~',$sitename);
   $user = str_replace('/','',$d[1]);
   $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
   $client->get($url);
   $result = $client->currentResponse('body');
   $data_domain = json_decode($result,true);
   $error = 0;
   $sitename =   $data_domain[0]['domain'];
   $siteurl = "http://".$_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];
}

$url = $api_url.'getdomaininfo?domain='.$sitename.'&key='.$key;
$client->get($url);
$result = $client->currentResponse('body');
$data_domain = json_decode($result,true);
$error = 0;
if (!$data_domain['error'])
       {
            $domainid = $data_domain[0]['DomainId'];
            $forum_logo = $data_domain[0]['Logo'];
            $forum_title = $data_domain[0]['Title'];
            $forum_tagline = $data_domain[0]['Tagline'];
            $forum_base_url = "http://$sitename";
            $domain_type = $data_domain[0]['DomainType'];
            $forum_ga = $data_domain[0]['AccountGA'];
      	}else {
      		$error++;
}
if ($forum_ga == ""){
	$forum_ga = "UA-00000000-0";
}

$url = $api_url.'getforuminfo?domain_id='.$domainid.'&key='.$key;
$client->get($url);
$result = $client->currentResponse('body');
$data_forum = json_decode($result,true);
$forum_style = $data_forum[0]['Style'];
$forum_email = $data_forum[0]['AdminEmail'];

$client->get($api_url.'getcpanelinfo?domain_id='.$domainid.'&key='.$key);
$result = $client->currentResponse('body');
$data_cpanel = json_decode($result,true);
if (!$data_cpanel['error'])
{
	$cpanel_username = $data_cpanel[0]['Username'];
	$cpanel_password = $data_cpanel[0]['Password'];
}

if ($domain_type=="subdomain"){
	$s = explode(".",$sitename);
	$subdomain = $s[0];
}


//Process Logo
if ($forum_logo){
$ch = curl_init();
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch,CURLOPT_URL,$forum_logo);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$result=curl_exec($ch);
curl_close($ch);
$image_name = "A54D43RS4SUI.png"; 
$savefile = fopen("./uploads/".$image_name, "w");
fwrite($savefile, $result);
fclose($savefile); 
}  

//get monetize ads from vnoc
$url = $monetize_url.'?d='.$sitename.'&p=fright';
$client->get($url);
$result = $client->currentResponse('body');
$data_ads = json_decode($result,true);
$footer_banner = html_entity_decode(base64_decode($data_ads[0]['code']));


if (file_exists(PATH_ROOT.'/conf/setup.php')){
	require_once(PATH_ROOT.'/conf/setup.php');
	unlink(PATH_ROOT.'/conf/setup.php'); //delete file
}


// Conversations
$Configuration['Conversations']['Version'] = '2.0.18.4';

// Database
if($domain_type=="subdomain")
	$db=$cpanel_username."_vanilla_".$subdomain; //SUBDOMAIN
else
	$db=$cpanel_username."_vanilla"; 			//DOMAIN

$Configuration['Database']['Name'] = $db;
$Configuration['Database']['Host'] = 'localhost';
$Configuration['Database']['User'] = $cpanel_username;
$Configuration['Database']['Password'] = $cpanel_password;

// EnabledApplications
$Configuration['EnabledApplications']['Conversations'] = 'conversations';
$Configuration['EnabledApplications']['Vanilla'] = 'vanilla';

// EnabledPlugins
$Configuration['EnabledPlugins']['GettingStarted'] = 'GettingStarted';
$Configuration['EnabledPlugins']['HtmLawed'] = 'HtmLawed';
$Configuration['EnabledPlugins']['embedvanilla'] = TRUE;
$Configuration['EnabledPlugins']['AutoBookmark'] = TRUE;
$Configuration['EnabledPlugins']['BotStop'] = TRUE;
$Configuration['EnabledPlugins']['Facebook'] = TRUE;
$Configuration['EnabledPlugins']['FacebookFriends'] = TRUE;
$Configuration['EnabledPlugins']['Flagging'] = TRUE;
$Configuration['EnabledPlugins']['LikeThis'] = TRUE;
$Configuration['EnabledPlugins']['Gravatar'] = TRUE;
$Configuration['EnabledPlugins']['PostApproval'] = TRUE;
$Configuration['EnabledPlugins']['VanillaStats'] = TRUE;
$Configuration['EnabledPlugins']['cleditor'] = TRUE;
$Configuration['EnabledPlugins']['MyProfile'] = TRUE;
$Configuration['EnabledPlugins']['Sitemaps'] = TRUE;
$Configuration['EnabledPlugins']['ProfileFeeds'] = TRUE;
$Configuration['EnabledPlugins']['SocialButtons'] = TRUE;
$Configuration['EnabledPlugins']['Analytics'] = TRUE;

// Garden
$Configuration['Garden']['Title'] = $forum_title;
$Configuration['Garden']['Cookie']['Salt'] = 'CGVVTSF3D5';
$Configuration['Garden']['Cookie']['Domain'] = '';
$Configuration['Garden']['Registration']['ConfirmEmail'] = '1';
$Configuration['Garden']['Registration']['Method'] = 'Connect';
$Configuration['Garden']['Registration']['ConfirmEmailRole'] = '3';
$Configuration['Garden']['Registration']['CaptchaPrivateKey'] = '';
$Configuration['Garden']['Registration']['CaptchaPublicKey'] = '';
$Configuration['Garden']['Registration']['InviteExpiration'] = '-1 week';
$Configuration['Garden']['Registration']['InviteRoles'] = 'a:5:{i:4;s:1:"0";i:8;s:1:"0";i:32;s:1:"0";i:16;s:1:"0";i:3;s:1:"0";}';
$Configuration['Garden']['Email']['SupportName'] = $forum_title;
$Configuration['Garden']['Version'] = '2.0.18.4';
$Configuration['Garden']['RewriteUrls'] = TRUE;
$Configuration['Garden']['CanProcessImages'] = TRUE;
$Configuration['Garden']['Installed'] = TRUE;
$Configuration['Garden']['InstallationID'] = 'D14D-5EE0291E-F37E8E21';
$Configuration['Garden']['InstallationSecret'] = '31161aab4a8ef06dc022401689820a072ac2ada2';
if ($forum_logo){
$Configuration['Garden']['Logo'] = 'A54D43RS4SUI.png';
}
$Configuration['Garden']['Errors']['MasterView'] = 'deverror.master.php';
$Configuration['Garden']['GA'] = $forum_ga;
$Configuration['Garden']['Banner'] = $footer_banner;
// Modules
$Configuration['Modules']['Vanilla']['Content'] = 'a:6:{i:0;s:13:"MessageModule";i:1;s:7:"Notices";i:2;s:21:"NewConversationModule";i:3;s:19:"NewDiscussionModule";i:4;s:7:"Content";i:5;s:3:"Ads";}';
$Configuration['Modules']['Conversations']['Content'] = 'a:6:{i:0;s:13:"MessageModule";i:1;s:7:"Notices";i:2;s:21:"NewConversationModule";i:3;s:19:"NewDiscussionModule";i:4;s:7:"Content";i:5;s:3:"Ads";}';

// Plugins
$Configuration['Plugins']['GettingStarted']['Dashboard'] = '1';
$Configuration['Plugins']['GettingStarted']['Registration'] = '1';
$Configuration['Plugins']['GettingStarted']['Plugins'] = '1';
$Configuration['Plugins']['GettingStarted']['Categories'] = '1';
$Configuration['Plugins']['GettingStarted']['Discussion'] = '1';
$Configuration['Plugins']['BotStop']['Question'] = 'What is three plus three?';
$Configuration['Plugins']['BotStop']['Answer1'] = '6';
$Configuration['Plugins']['BotStop']['Answer2'] = 'six';
$Configuration['Plugins']['Facebook']['ApplicationID'] = '116832031815925';
$Configuration['Plugins']['Facebook']['Secret'] = '7ebf15fa5ba6ba69c23870d513310bff';
$Configuration['Plugins']['MyProfile']['Version'] = '0.1.9b';
$Configuration['Plugins']['PremiumAccounts']['Version'] = '0.7.7b';
$Configuration['Plugins']['ProfileFeeds']['Version'] = '0.1.1b';

// Routes
$Configuration['Routes']['DefaultController'] = 'discussions';
$Configuration['Routes']['c2l0ZW1hcGluZGV4LnhtbA=='] = 'a:2:{i:0;s:25:"/utility/sitemapindex.xml";i:1;s:8:"Internal";}';
$Configuration['Routes']['c2l0ZW1hcC0oLisp'] = 'a:2:{i:0;s:19:"/utility/sitemap/$1";i:1;s:8:"Internal";}';
$Configuration['Routes']['cm9ib3RzLnR4dA=='] = 'a:2:{i:0;s:15:"/utility/robots";i:1;s:8:"Internal";}';

// Vanilla
$Configuration['Vanilla']['Version'] = '2.0.18.4';
$Configuration['Vanilla']['Categories']['MaxDisplayDepth'] = '4';
$Configuration['Vanilla']['Categories']['DoHeadings'] = FALSE;
$Configuration['Vanilla']['Categories']['HideModule'] = FALSE;



// Last edited by admin (202.137.120.23)2012-12-10 00:42:37