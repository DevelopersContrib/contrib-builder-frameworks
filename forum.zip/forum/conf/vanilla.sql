/*
SQLyog Trial v8.71 
MySQL - 5.0.96-community : Database - ceoforum_vanilla
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `GDN_Activity` */

CREATE TABLE IF NOT EXISTS `GDN_Activity` (
  `ActivityID` int(11) NOT NULL auto_increment,
  `CommentActivityID` int(11) default NULL,
  `ActivityTypeID` int(11) NOT NULL,
  `ActivityUserID` int(11) default NULL,
  `RegardingUserID` int(11) default NULL,
  `Story` text collate utf8_unicode_ci,
  `Route` varchar(255) collate utf8_unicode_ci default NULL,
  `CountComments` int(11) NOT NULL default '0',
  `InsertUserID` int(11) default NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `Emailed` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`ActivityID`),
  KEY `FK_Activity_CommentActivityID` (`CommentActivityID`),
  KEY `FK_Activity_ActivityUserID` (`ActivityUserID`),
  KEY `FK_Activity_RegardingUserID` (`RegardingUserID`),
  KEY `FK_Activity_InsertUserID` (`InsertUserID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Activity` */

insert  into `GDN_Activity`(`ActivityID`,`CommentActivityID`,`ActivityTypeID`,`ActivityUserID`,`RegardingUserID`,`Story`,`Route`,`CountComments`,`InsertUserID`,`DateInserted`,`InsertIPAddress`,`Emailed`) values (1,NULL,2,1,NULL,'Welcome to Vanilla!',NULL,0,NULL,'2012-12-09 21:45:02','202.137.120.23',0);

/*Table structure for table `GDN_ActivityType` */

CREATE TABLE IF NOT EXISTS `GDN_ActivityType` (
  `ActivityTypeID` int(11) NOT NULL auto_increment,
  `Name` varchar(20) collate utf8_unicode_ci NOT NULL,
  `AllowComments` tinyint(4) NOT NULL default '0',
  `ShowIcon` tinyint(4) NOT NULL default '0',
  `ProfileHeadline` varchar(255) collate utf8_unicode_ci NOT NULL,
  `FullHeadline` varchar(255) collate utf8_unicode_ci NOT NULL,
  `RouteCode` varchar(255) collate utf8_unicode_ci default NULL,
  `Notify` tinyint(4) NOT NULL default '0',
  `Public` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`ActivityTypeID`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_ActivityType` */

insert  into `GDN_ActivityType`(`ActivityTypeID`,`Name`,`AllowComments`,`ShowIcon`,`ProfileHeadline`,`FullHeadline`,`RouteCode`,`Notify`,`Public`) values (1,'SignIn',0,0,'%1$s signed in.','%1$s signed in.',NULL,0,1),(2,'Join',1,0,'%1$s joined.','%1$s joined.',NULL,0,1),(3,'JoinInvite',1,0,'%1$s accepted %4$s invitation for membership.','%1$s accepted %4$s invitation for membership.',NULL,0,1),(4,'JoinApproved',1,0,'%1$s approved %4$s membership application.','%1$s approved %4$s membership application.',NULL,0,1),(5,'JoinCreated',1,0,'%1$s created an account for %3$s.','%1$s created an account for %3$s.',NULL,0,1),(6,'AboutUpdate',1,0,'%1$s updated %6$s profile.','%1$s updated %6$s profile.',NULL,0,1),(7,'WallComment',1,1,'%1$s wrote:','%1$s wrote on %4$s %5$s.',NULL,0,1),(8,'PictureChange',1,0,'%1$s changed %6$s profile picture.','%1$s changed %6$s profile picture.',NULL,0,1),(9,'RoleChange',1,0,'%1$s changed %4$s permissions.','%1$s changed %4$s permissions.',NULL,1,1),(10,'ActivityComment',0,1,'%1$s','%1$s commented on %4$s %8$s.','activity',1,1),(11,'Import',0,0,'%1$s imported data.','%1$s imported data.',NULL,1,0),(12,'Banned',0,0,'%1$s banned %3$s.','%1$s banned %3$s.',NULL,0,1),(13,'Unbanned',0,0,'%1$s un-banned %3$s.','%1$s un-banned %3$s.',NULL,0,1),(14,'WallPost',1,1,'%3$s wrote:','%3$s wrote on %2$s %5$s.',NULL,0,1),(15,'ConversationMessage',0,0,'%1$s sent you a %8$s.','%1$s sent you a %8$s.','message',1,0),(16,'AddedToConversation',0,0,'%1$s added %3$s to a %8$s.','%1$s added %3$s to a %8$s.','conversation',1,0),(17,'NewDiscussion',0,0,'%1$s started a %8$s.','%1$s started a %8$s.','discussion',0,0),(18,'NewComment',0,0,'%1$s commented on a discussion.','%1$s commented on a discussion.','discussion',0,0),(19,'DiscussionComment',0,0,'%1$s commented on %4$s %8$s.','%1$s commented on %4$s %8$s.','discussion',1,0),(20,'DiscussionMention',0,0,'%1$s mentioned %3$s in a %8$s.','%1$s mentioned %3$s in a %8$s.','discussion',1,0),(21,'CommentMention',0,0,'%1$s mentioned %3$s in a %8$s.','%1$s mentioned %3$s in a %8$s.','comment',1,0),(22,'BookmarkComment',0,0,'%1$s commented on your %8$s.','%1$s commented on your %8$s.','bookmarked discussion',1,0);

/*Table structure for table `GDN_AllLikes` */

CREATE TABLE IF NOT EXISTS `GDN_AllLikes` (
  `ID` int(11) NOT NULL auto_increment,
  `CommentID` int(11) default NULL,
  `DiscussionID` int(11) default NULL,
  `UserID` int(11) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_AllLikes` */

/*Table structure for table `GDN_AnalyticsLocal` */

CREATE TABLE IF NOT EXISTS `GDN_AnalyticsLocal` (
  `TimeSlot` varchar(8) collate utf8_unicode_ci NOT NULL,
  `Views` int(11) default NULL,
  UNIQUE KEY `UX_AnalyticsLocal` (`TimeSlot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_AnalyticsLocal` */

insert  into `GDN_AnalyticsLocal`(`TimeSlot`,`Views`) values ('20121209',51),('20121210',88);

/*Table structure for table `GDN_Ban` */

CREATE TABLE IF NOT EXISTS `GDN_Ban` (
  `BanID` int(11) NOT NULL auto_increment,
  `BanType` enum('IPAddress','Name','Email') collate utf8_unicode_ci NOT NULL,
  `BanValue` varchar(50) collate utf8_unicode_ci NOT NULL,
  `Notes` varchar(255) collate utf8_unicode_ci default NULL,
  `CountUsers` int(10) unsigned NOT NULL default '0',
  `CountBlockedRegistrations` int(10) unsigned NOT NULL default '0',
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  PRIMARY KEY  (`BanID`),
  UNIQUE KEY `UX_Ban` (`BanType`,`BanValue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Ban` */

/*Table structure for table `GDN_Category` */

CREATE TABLE IF NOT EXISTS `GDN_Category` (
  `CategoryID` int(11) NOT NULL auto_increment,
  `ParentCategoryID` int(11) default NULL,
  `TreeLeft` int(11) default NULL,
  `TreeRight` int(11) default NULL,
  `Depth` int(11) default NULL,
  `CountDiscussions` int(11) NOT NULL default '0',
  `CountComments` int(11) NOT NULL default '0',
  `DateMarkedRead` datetime default NULL,
  `AllowDiscussions` tinyint(4) NOT NULL default '1',
  `Archived` tinyint(4) NOT NULL default '0',
  `Name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `UrlCode` varchar(255) collate utf8_unicode_ci default NULL,
  `Description` varchar(500) collate utf8_unicode_ci default NULL,
  `Sort` int(11) default NULL,
  `PermissionCategoryID` int(11) NOT NULL default '-1',
  `InsertUserID` int(11) NOT NULL,
  `UpdateUserID` int(11) default NULL,
  `DateInserted` datetime NOT NULL,
  `DateUpdated` datetime NOT NULL,
  `LastCommentID` int(11) default NULL,
  `LastDiscussionID` int(11) default NULL,
  PRIMARY KEY  (`CategoryID`),
  KEY `FK_Category_InsertUserID` (`InsertUserID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Category` */

insert  into `GDN_Category`(`CategoryID`,`ParentCategoryID`,`TreeLeft`,`TreeRight`,`Depth`,`CountDiscussions`,`CountComments`,`DateMarkedRead`,`AllowDiscussions`,`Archived`,`Name`,`UrlCode`,`Description`,`Sort`,`PermissionCategoryID`,`InsertUserID`,`UpdateUserID`,`DateInserted`,`DateUpdated`,`LastCommentID`,`LastDiscussionID`) values (-1,NULL,1,12,0,0,0,NULL,1,0,'Root','root','Root of category tree. Users should never see this.',1,-1,1,1,'2012-12-09 21:45:02','2012-12-09 21:45:02',NULL,NULL),(2,-1,10,11,1,0,0,NULL,1,0,'Leadership','leadership','',10,-1,1,1,'2012-12-09 22:14:50','2012-12-09 22:14:50',NULL,NULL),(3,-1,8,9,1,0,0,NULL,1,0,'Renewal and Change','renewal-and-change','',8,-1,1,1,'2012-12-09 22:15:08','2012-12-09 22:15:08',NULL,NULL),(5,-1,6,7,1,0,0,NULL,1,0,'People and Performance','people-and-performance','',6,-1,1,1,'2012-12-09 22:15:40','2012-12-09 22:15:40',NULL,NULL),(6,-1,4,5,1,0,0,NULL,1,0,'Innovation','innovation','',4,-1,1,1,'2012-12-09 22:15:58','2012-12-09 22:15:58',NULL,NULL),(7,-1,2,3,1,0,0,NULL,1,0,'Programs','programs','',2,-1,1,1,'2012-12-09 22:16:06','2012-12-09 22:16:06',NULL,NULL);

/*Table structure for table `GDN_Comment` */

CREATE TABLE IF NOT EXISTS `GDN_Comment` (
  `CommentID` int(11) NOT NULL auto_increment,
  `DiscussionID` int(11) NOT NULL,
  `InsertUserID` int(11) default NULL,
  `UpdateUserID` int(11) default NULL,
  `DeleteUserID` int(11) default NULL,
  `Body` text collate utf8_unicode_ci NOT NULL,
  `Format` varchar(20) collate utf8_unicode_ci default NULL,
  `DateInserted` datetime default NULL,
  `DateDeleted` datetime default NULL,
  `DateUpdated` datetime default NULL,
  `InsertIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `UpdateIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `Flag` tinyint(4) NOT NULL default '0',
  `Score` float default NULL,
  `Attributes` text collate utf8_unicode_ci,
  `Hidden` enum('Yes','No') collate utf8_unicode_ci NOT NULL default 'Yes',
  PRIMARY KEY  (`CommentID`),
  KEY `FK_Comment_DiscussionID` (`DiscussionID`),
  KEY `FK_Comment_InsertUserID` (`InsertUserID`),
  KEY `FK_Comment_DateInserted` (`DateInserted`),
  FULLTEXT KEY `TX_Comment` (`Body`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Comment` */

/*Table structure for table `GDN_Conversation` */

CREATE TABLE IF NOT EXISTS `GDN_Conversation` (
  `ConversationID` int(11) NOT NULL auto_increment,
  `Subject` varchar(100) collate utf8_unicode_ci default NULL,
  `Contributors` varchar(255) collate utf8_unicode_ci NOT NULL,
  `FirstMessageID` int(11) default NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime default NULL,
  `InsertIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `UpdateUserID` int(11) NOT NULL,
  `DateUpdated` datetime NOT NULL,
  `UpdateIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `CountMessages` int(11) NOT NULL default '0',
  `LastMessageID` int(11) default NULL,
  `RegardingID` int(11) default NULL,
  PRIMARY KEY  (`ConversationID`),
  KEY `FK_Conversation_FirstMessageID` (`FirstMessageID`),
  KEY `FK_Conversation_InsertUserID` (`InsertUserID`),
  KEY `FK_Conversation_DateInserted` (`DateInserted`),
  KEY `FK_Conversation_UpdateUserID` (`UpdateUserID`),
  KEY `IX_Conversation_RegardingID` (`RegardingID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Conversation` */

/*Table structure for table `GDN_ConversationMessage` */

CREATE TABLE IF NOT EXISTS `GDN_ConversationMessage` (
  `MessageID` int(11) NOT NULL auto_increment,
  `ConversationID` int(11) NOT NULL,
  `Body` text collate utf8_unicode_ci NOT NULL,
  `Format` varchar(20) collate utf8_unicode_ci default NULL,
  `InsertUserID` int(11) default NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`MessageID`),
  KEY `FK_ConversationMessage_ConversationID` (`ConversationID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_ConversationMessage` */

/*Table structure for table `GDN_Discussion` */

CREATE TABLE IF NOT EXISTS `GDN_Discussion` (
  `DiscussionID` int(11) NOT NULL auto_increment,
  `Type` varchar(10) collate utf8_unicode_ci default NULL,
  `ForeignID` varchar(30) collate utf8_unicode_ci default NULL,
  `CategoryID` int(11) NOT NULL,
  `InsertUserID` int(11) NOT NULL,
  `UpdateUserID` int(11) NOT NULL,
  `LastCommentID` int(11) default NULL,
  `Name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `Body` text collate utf8_unicode_ci NOT NULL,
  `Format` varchar(20) collate utf8_unicode_ci default NULL,
  `Tags` varchar(255) collate utf8_unicode_ci default NULL,
  `CountComments` int(11) NOT NULL default '1',
  `CountBookmarks` int(11) default NULL,
  `CountViews` int(11) NOT NULL default '1',
  `Closed` tinyint(4) NOT NULL default '0',
  `Announce` tinyint(4) NOT NULL default '0',
  `Sink` tinyint(4) NOT NULL default '0',
  `DateInserted` datetime default NULL,
  `DateUpdated` datetime NOT NULL,
  `InsertIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `UpdateIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `DateLastComment` datetime default NULL,
  `LastCommentUserID` int(11) default NULL,
  `Score` float default NULL,
  `Attributes` text collate utf8_unicode_ci,
  `RegardingID` int(11) default NULL,
  `Hidden` enum('Yes','No') collate utf8_unicode_ci NOT NULL default 'Yes',
  `CountPendingComments` int(11) default NULL,
  PRIMARY KEY  (`DiscussionID`),
  KEY `IX_Discussion_Type` (`Type`),
  KEY `IX_Discussion_ForeignID` (`ForeignID`),
  KEY `FK_Discussion_CategoryID` (`CategoryID`),
  KEY `FK_Discussion_InsertUserID` (`InsertUserID`),
  KEY `IX_Discussion_DateLastComment` (`DateLastComment`),
  KEY `IX_Discussion_RegardingID` (`RegardingID`),
  FULLTEXT KEY `TX_Discussion` (`Name`,`Body`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


/*Table structure for table `GDN_Draft` */

CREATE TABLE IF NOT EXISTS `GDN_Draft` (
  `DraftID` int(11) NOT NULL auto_increment,
  `DiscussionID` int(11) default NULL,
  `CategoryID` int(11) default NULL,
  `InsertUserID` int(11) NOT NULL,
  `UpdateUserID` int(11) NOT NULL,
  `Name` varchar(100) collate utf8_unicode_ci default NULL,
  `Tags` varchar(255) collate utf8_unicode_ci default NULL,
  `Closed` tinyint(4) NOT NULL default '0',
  `Announce` tinyint(4) NOT NULL default '0',
  `Sink` tinyint(4) NOT NULL default '0',
  `Body` text collate utf8_unicode_ci NOT NULL,
  `Format` varchar(20) collate utf8_unicode_ci default NULL,
  `DateInserted` datetime NOT NULL,
  `DateUpdated` datetime default NULL,
  PRIMARY KEY  (`DraftID`),
  KEY `FK_Draft_DiscussionID` (`DiscussionID`),
  KEY `FK_Draft_CategoryID` (`CategoryID`),
  KEY `FK_Draft_InsertUserID` (`InsertUserID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Draft` */

/*Table structure for table `GDN_Flag` */

CREATE TABLE IF NOT EXISTS `GDN_Flag` (
  `DiscussionID` int(11) default NULL,
  `InsertUserID` int(11) NOT NULL,
  `InsertName` varchar(64) collate utf8_unicode_ci NOT NULL,
  `AuthorID` int(11) NOT NULL,
  `AuthorName` varchar(64) collate utf8_unicode_ci NOT NULL,
  `ForeignURL` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ForeignID` int(11) NOT NULL,
  `ForeignType` varchar(32) collate utf8_unicode_ci NOT NULL,
  `Comment` text collate utf8_unicode_ci NOT NULL,
  `DateInserted` datetime NOT NULL,
  KEY `FK_Flag_InsertUserID` (`InsertUserID`),
  KEY `FK_Flag_ForeignURL` (`ForeignURL`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Flag` */

/*Table structure for table `GDN_Invitation` */

CREATE TABLE IF NOT EXISTS `GDN_Invitation` (
  `InvitationID` int(11) NOT NULL auto_increment,
  `Email` varchar(200) collate utf8_unicode_ci NOT NULL,
  `Code` varchar(50) collate utf8_unicode_ci NOT NULL,
  `InsertUserID` int(11) default NULL,
  `DateInserted` datetime NOT NULL,
  `AcceptedUserID` int(11) default NULL,
  PRIMARY KEY  (`InvitationID`),
  KEY `FK_Invitation_InsertUserID` (`InsertUserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Invitation` */

/*Table structure for table `GDN_Log` */

CREATE TABLE IF NOT EXISTS `GDN_Log` (
  `LogID` int(11) NOT NULL auto_increment,
  `Operation` enum('Delete','Edit','Spam','Moderate','Error') collate utf8_unicode_ci NOT NULL,
  `RecordType` enum('Discussion','Comment','User','Registration','Activity') collate utf8_unicode_ci NOT NULL,
  `RecordID` int(11) default NULL,
  `RecordUserID` int(11) default NULL,
  `RecordDate` datetime NOT NULL,
  `RecordIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `OtherUserIDs` varchar(255) collate utf8_unicode_ci default NULL,
  `DateUpdated` datetime default NULL,
  `ParentRecordID` int(11) default NULL,
  `Data` text collate utf8_unicode_ci,
  `CountGroup` int(11) default NULL,
  PRIMARY KEY  (`LogID`),
  KEY `IX_Log_RecordType` (`RecordType`),
  KEY `IX_Log_RecordID` (`RecordID`),
  KEY `IX_Log_RecordIPAddress` (`RecordIPAddress`),
  KEY `IX_Log_ParentRecordID` (`ParentRecordID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Log` */

/*Table structure for table `GDN_Message` */

CREATE TABLE IF NOT EXISTS `GDN_Message` (
  `MessageID` int(11) NOT NULL auto_increment,
  `Content` text collate utf8_unicode_ci NOT NULL,
  `Format` varchar(20) collate utf8_unicode_ci default NULL,
  `AllowDismiss` tinyint(4) NOT NULL default '1',
  `Enabled` tinyint(4) NOT NULL default '1',
  `Application` varchar(255) collate utf8_unicode_ci default NULL,
  `Controller` varchar(255) collate utf8_unicode_ci default NULL,
  `Method` varchar(255) collate utf8_unicode_ci default NULL,
  `AssetTarget` varchar(20) collate utf8_unicode_ci default NULL,
  `CssClass` varchar(20) collate utf8_unicode_ci default NULL,
  `Sort` int(11) default NULL,
  PRIMARY KEY  (`MessageID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Message` */

/*Table structure for table `GDN_Permission` */

CREATE TABLE IF NOT EXISTS `GDN_Permission` (
  `PermissionID` int(11) NOT NULL auto_increment,
  `RoleID` int(11) NOT NULL default '0',
  `JunctionTable` varchar(100) collate utf8_unicode_ci default NULL,
  `JunctionColumn` varchar(100) collate utf8_unicode_ci default NULL,
  `JunctionID` int(11) default NULL,
  `Garden.Email.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Settings.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Settings.View` tinyint(4) NOT NULL default '0',
  `Garden.Routes.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Messages.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Applications.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Plugins.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Themes.Manage` tinyint(4) NOT NULL default '0',
  `Garden.SignIn.Allow` tinyint(4) NOT NULL default '0',
  `Garden.Registration.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Applicants.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Roles.Manage` tinyint(4) NOT NULL default '0',
  `Garden.Users.Add` tinyint(4) NOT NULL default '0',
  `Garden.Users.Edit` tinyint(4) NOT NULL default '0',
  `Garden.Users.Delete` tinyint(4) NOT NULL default '0',
  `Garden.Users.Approve` tinyint(4) NOT NULL default '0',
  `Garden.Activity.Delete` tinyint(4) NOT NULL default '0',
  `Garden.Activity.View` tinyint(4) NOT NULL default '0',
  `Garden.Profiles.View` tinyint(4) NOT NULL default '0',
  `Garden.Profiles.Edit` tinyint(4) NOT NULL default '0',
  `Garden.Moderation.Manage` tinyint(4) NOT NULL default '0',
  `Garden.AdvancedNotifications.Allow` tinyint(4) NOT NULL default '0',
  `Conversations.Moderation.Manage` tinyint(4) NOT NULL default '0',
  `Vanilla.Settings.Manage` tinyint(4) NOT NULL default '0',
  `Vanilla.Categories.Manage` tinyint(4) NOT NULL default '0',
  `Vanilla.Spam.Manage` tinyint(4) NOT NULL default '0',
  `Vanilla.Discussions.View` tinyint(4) NOT NULL default '0',
  `Vanilla.Discussions.Add` tinyint(4) NOT NULL default '0',
  `Vanilla.Discussions.Edit` tinyint(4) NOT NULL default '0',
  `Vanilla.Discussions.Announce` tinyint(4) NOT NULL default '0',
  `Vanilla.Discussions.Sink` tinyint(4) NOT NULL default '0',
  `Vanilla.Discussions.Close` tinyint(4) NOT NULL default '0',
  `Vanilla.Discussions.Delete` tinyint(4) NOT NULL default '0',
  `Vanilla.Comments.Add` tinyint(4) NOT NULL default '0',
  `Vanilla.Comments.Edit` tinyint(4) NOT NULL default '0',
  `Vanilla.Comments.Delete` tinyint(4) NOT NULL default '0',
  `Plugins.Flagging.Notify` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`PermissionID`),
  KEY `FK_Permission_RoleID` (`RoleID`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Permission` */

insert  into `GDN_Permission`(`PermissionID`,`RoleID`,`JunctionTable`,`JunctionColumn`,`JunctionID`,`Garden.Email.Manage`,`Garden.Settings.Manage`,`Garden.Settings.View`,`Garden.Routes.Manage`,`Garden.Messages.Manage`,`Garden.Applications.Manage`,`Garden.Plugins.Manage`,`Garden.Themes.Manage`,`Garden.SignIn.Allow`,`Garden.Registration.Manage`,`Garden.Applicants.Manage`,`Garden.Roles.Manage`,`Garden.Users.Add`,`Garden.Users.Edit`,`Garden.Users.Delete`,`Garden.Users.Approve`,`Garden.Activity.Delete`,`Garden.Activity.View`,`Garden.Profiles.View`,`Garden.Profiles.Edit`,`Garden.Moderation.Manage`,`Garden.AdvancedNotifications.Allow`,`Conversations.Moderation.Manage`,`Vanilla.Settings.Manage`,`Vanilla.Categories.Manage`,`Vanilla.Spam.Manage`,`Vanilla.Discussions.View`,`Vanilla.Discussions.Add`,`Vanilla.Discussions.Edit`,`Vanilla.Discussions.Announce`,`Vanilla.Discussions.Sink`,`Vanilla.Discussions.Close`,`Vanilla.Discussions.Delete`,`Vanilla.Comments.Add`,`Vanilla.Comments.Edit`,`Vanilla.Comments.Delete`,`Plugins.Flagging.Notify`) values (1,0,NULL,NULL,NULL,2,2,2,2,2,2,2,2,3,2,2,2,2,2,2,2,2,3,3,3,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,2),(2,2,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(3,3,NULL,NULL,NULL,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(4,4,NULL,NULL,NULL,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(5,8,NULL,NULL,NULL,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0),(6,32,NULL,NULL,NULL,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0),(7,16,NULL,NULL,NULL,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0),(8,0,'Category','PermissionCategoryID',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,2,2,2,2,2,3,2,2,0),(9,2,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(10,3,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(11,4,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(12,8,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0),(13,32,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0),(14,16,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0);

/*Table structure for table `GDN_Photo` */

CREATE TABLE IF NOT EXISTS `GDN_Photo` (
  `PhotoID` int(11) NOT NULL auto_increment,
  `Name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `InsertUserID` int(11) default NULL,
  `DateInserted` datetime NOT NULL,
  PRIMARY KEY  (`PhotoID`),
  KEY `FK_Photo_InsertUserID` (`InsertUserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Photo` */

/*Table structure for table `GDN_PremiumLog` */

CREATE TABLE IF NOT EXISTS `GDN_PremiumLog` (
  `UserID` int(11) NOT NULL,
  `TransactionID` char(19) collate utf8_unicode_ci NOT NULL,
  `Status` varchar(100) collate utf8_unicode_ci NOT NULL,
  `Inform` int(11) NOT NULL default '0',
  `Date` datetime NOT NULL,
  `Log` mediumtext collate utf8_unicode_ci NOT NULL,
  UNIQUE KEY `UX_PremiumLog` (`Date`),
  KEY `FK_PremiumLog_UserID` (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_PremiumLog` */

/*Table structure for table `GDN_Regarding` */

CREATE TABLE IF NOT EXISTS `GDN_Regarding` (
  `RegardingID` int(11) NOT NULL auto_increment,
  `Type` varchar(255) collate utf8_unicode_ci NOT NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  `ForeignType` varchar(32) collate utf8_unicode_ci NOT NULL,
  `ForeignID` int(11) NOT NULL,
  `OriginalContent` text collate utf8_unicode_ci,
  `ParentType` varchar(32) collate utf8_unicode_ci default NULL,
  `ParentID` int(11) default NULL,
  `ForeignURL` varchar(255) collate utf8_unicode_ci default NULL,
  `Comment` text collate utf8_unicode_ci NOT NULL,
  `Reports` int(11) default NULL,
  PRIMARY KEY  (`RegardingID`),
  KEY `FK_Regarding_Type` (`Type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Regarding` */

/*Table structure for table `GDN_Role` */

CREATE TABLE IF NOT EXISTS `GDN_Role` (
  `RoleID` int(11) NOT NULL auto_increment,
  `Name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `Description` varchar(500) collate utf8_unicode_ci default NULL,
  `Sort` int(11) default NULL,
  `Deletable` tinyint(4) NOT NULL default '1',
  `CanSession` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`RoleID`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Role` */

insert  into `GDN_Role`(`RoleID`,`Name`,`Description`,`Sort`,`Deletable`,`CanSession`) values (2,'Guest','Guests can only view content. Anyone browsing the site who is not signed in is considered to be a \"Guest\".',2,0,0),(4,'Applicant','Users who have applied for membership, but have not yet been accepted. They have the same permissions as guests.',3,0,1),(8,'Member','Members can participate in discussions.',4,1,1),(32,'Moderator','Moderators have permission to edit most content.',5,1,1),(16,'Administrator','Administrators have permission to do anything.',6,1,1),(3,'Confirm Email','Users must confirm their emails before becoming full members. They get assigned to this role.',7,1,1);

/*Table structure for table `GDN_Session` */

CREATE TABLE IF NOT EXISTS `GDN_Session` (
  `SessionID` char(32) collate utf8_unicode_ci NOT NULL,
  `UserID` int(11) NOT NULL default '0',
  `DateInserted` datetime NOT NULL,
  `DateUpdated` datetime NOT NULL,
  `TransientKey` varchar(12) collate utf8_unicode_ci NOT NULL,
  `Attributes` text collate utf8_unicode_ci,
  PRIMARY KEY  (`SessionID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Session` */

/*Table structure for table `GDN_Spammer` */

CREATE TABLE IF NOT EXISTS `GDN_Spammer` (
  `UserID` int(11) NOT NULL,
  `CountSpam` smallint(5) unsigned NOT NULL default '0',
  `CountDeletedSpam` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Spammer` */

/*Table structure for table `GDN_Tag` */

CREATE TABLE IF NOT EXISTS `GDN_Tag` (
  `TagID` int(11) NOT NULL auto_increment,
  `Name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `Type` varchar(10) collate utf8_unicode_ci default NULL,
  `InsertUserID` int(11) default NULL,
  `DateInserted` datetime NOT NULL,
  `CountDiscussions` int(11) NOT NULL default '0',
  PRIMARY KEY  (`TagID`),
  UNIQUE KEY `UX_Tag` (`Name`),
  KEY `IX_Tag_Type` (`Type`),
  KEY `FK_Tag_InsertUserID` (`InsertUserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_Tag` */

/*Table structure for table `GDN_TagDiscussion` */

CREATE TABLE IF NOT EXISTS `GDN_TagDiscussion` (
  `TagID` int(11) NOT NULL,
  `DiscussionID` int(11) NOT NULL,
  PRIMARY KEY  (`TagID`,`DiscussionID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_TagDiscussion` */

/*Table structure for table `GDN_User` */

CREATE TABLE IF NOT EXISTS `GDN_User` (
  `UserID` int(11) NOT NULL auto_increment,
  `Name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `Password` varbinary(100) NOT NULL,
  `HashMethod` varchar(10) collate utf8_unicode_ci default NULL,
  `Photo` varchar(255) collate utf8_unicode_ci default NULL,
  `About` text collate utf8_unicode_ci,
  `Email` varchar(200) collate utf8_unicode_ci NOT NULL,
  `ShowEmail` tinyint(4) NOT NULL default '0',
  `Gender` enum('m','f') collate utf8_unicode_ci NOT NULL default 'm',
  `CountVisits` int(11) NOT NULL default '0',
  `CountInvitations` int(11) NOT NULL default '0',
  `CountNotifications` int(11) default NULL,
  `InviteUserID` int(11) default NULL,
  `DiscoveryText` text collate utf8_unicode_ci,
  `Preferences` text collate utf8_unicode_ci,
  `Permissions` text collate utf8_unicode_ci,
  `Attributes` text collate utf8_unicode_ci,
  `DateSetInvitations` datetime default NULL,
  `DateOfBirth` datetime default NULL,
  `DateFirstVisit` datetime default NULL,
  `DateLastActive` datetime default NULL,
  `LastIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `DateUpdated` datetime default NULL,
  `UpdateIPAddress` varchar(15) collate utf8_unicode_ci default NULL,
  `HourOffset` int(11) NOT NULL default '0',
  `Score` float default NULL,
  `Admin` tinyint(4) NOT NULL default '0',
  `Banned` tinyint(4) NOT NULL default '0',
  `Deleted` tinyint(4) NOT NULL default '0',
  `CountUnreadConversations` int(11) default NULL,
  `CountDiscussions` int(11) default NULL,
  `CountUnreadDiscussions` int(11) default NULL,
  `CountComments` int(11) default NULL,
  `CountDrafts` int(11) default NULL,
  `CountBookmarks` int(11) default NULL,
  `Liked` int(11) NOT NULL default '0',
  `DisLiked` int(11) NOT NULL default '0',
  `ILiked` int(11) NOT NULL default '0',
  `PremiumExpire` datetime default NULL,
  `PremiumRole` int(11) NOT NULL default '0',
  PRIMARY KEY  (`UserID`),
  KEY `FK_User_Name` (`Name`),
  KEY `IX_User_Email` (`Email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_User` */

insert  into `GDN_User`(`UserID`,`Name`,`Password`,`HashMethod`,`Photo`,`About`,`Email`,`ShowEmail`,`Gender`,`CountVisits`,`CountInvitations`,`CountNotifications`,`InviteUserID`,`DiscoveryText`,`Preferences`,`Permissions`,`Attributes`,`DateSetInvitations`,`DateOfBirth`,`DateFirstVisit`,`DateLastActive`,`LastIPAddress`,`DateInserted`,`InsertIPAddress`,`DateUpdated`,`UpdateIPAddress`,`HourOffset`,`Score`,`Admin`,`Banned`,`Deleted`,`CountUnreadConversations`,`CountDiscussions`,`CountUnreadDiscussions`,`CountComments`,`CountDrafts`,`CountBookmarks`,`Liked`,`DisLiked`,`ILiked`,`PremiumExpire`,`PremiumRole`) values (1,'admin','$P$Bgwn2e/9cocxDygYgP6DxDE.ZktOBl1','Vanilla',NULL,NULL,'mychannelcom30@gmail.com',0,'m',2,0,0,NULL,NULL,'a:2:{s:16:\"PreviewThemeName\";s:0:\"\";s:18:\"PreviewThemeFolder\";s:0:\"\";}','','a:1:{s:12:\"TransientKey\";s:12:\"M66X0IQ0ARJH\";}',NULL,'1975-09-16 00:00:00','2012-12-09 21:45:02','2012-12-10 19:32:51','222.127.248.236','2012-12-09 21:45:02',NULL,'2012-12-10 19:28:03','202.137.120.23',-13,NULL,1,0,0,NULL,0,NULL,0,0,NULL,0,0,0,NULL,0);

/*Table structure for table `GDN_UserAuthentication` */

CREATE TABLE IF NOT EXISTS `GDN_UserAuthentication` (
  `ForeignUserKey` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ProviderKey` varchar(64) collate utf8_unicode_ci NOT NULL,
  `UserID` int(11) NOT NULL,
  PRIMARY KEY  (`ForeignUserKey`,`ProviderKey`),
  KEY `FK_UserAuthentication_UserID` (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserAuthentication` */

/*Table structure for table `GDN_UserAuthenticationNonce` */

CREATE TABLE IF NOT EXISTS `GDN_UserAuthenticationNonce` (
  `Nonce` varchar(200) collate utf8_unicode_ci NOT NULL,
  `Token` varchar(128) collate utf8_unicode_ci NOT NULL,
  `Timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`Nonce`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserAuthenticationNonce` */

/*Table structure for table `GDN_UserAuthenticationProvider` */

CREATE TABLE IF NOT EXISTS `GDN_UserAuthenticationProvider` (
  `AuthenticationKey` varchar(64) collate utf8_unicode_ci NOT NULL,
  `AuthenticationSchemeAlias` varchar(32) collate utf8_unicode_ci NOT NULL,
  `Name` varchar(50) collate utf8_unicode_ci default NULL,
  `URL` varchar(255) collate utf8_unicode_ci default NULL,
  `AssociationSecret` text collate utf8_unicode_ci NOT NULL,
  `AssociationHashMethod` varchar(20) collate utf8_unicode_ci NOT NULL,
  `AuthenticateUrl` varchar(255) collate utf8_unicode_ci default NULL,
  `RegisterUrl` varchar(255) collate utf8_unicode_ci default NULL,
  `SignInUrl` varchar(255) collate utf8_unicode_ci default NULL,
  `SignOutUrl` varchar(255) collate utf8_unicode_ci default NULL,
  `PasswordUrl` varchar(255) collate utf8_unicode_ci default NULL,
  `ProfileUrl` varchar(255) collate utf8_unicode_ci default NULL,
  `Attributes` text collate utf8_unicode_ci,
  PRIMARY KEY  (`AuthenticationKey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserAuthenticationProvider` */

insert  into `GDN_UserAuthenticationProvider`(`AuthenticationKey`,`AuthenticationSchemeAlias`,`Name`,`URL`,`AssociationSecret`,`AssociationHashMethod`,`AuthenticateUrl`,`RegisterUrl`,`SignInUrl`,`SignOutUrl`,`PasswordUrl`,`ProfileUrl`,`Attributes`) values ('Facebook','facebook',NULL,'...','...','...',NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `GDN_UserAuthenticationToken` */

CREATE TABLE IF NOT EXISTS `GDN_UserAuthenticationToken` (
  `Token` varchar(128) collate utf8_unicode_ci NOT NULL,
  `ProviderKey` varchar(64) collate utf8_unicode_ci NOT NULL,
  `ForeignUserKey` varchar(255) collate utf8_unicode_ci default NULL,
  `TokenSecret` varchar(64) collate utf8_unicode_ci NOT NULL,
  `TokenType` enum('request','access') collate utf8_unicode_ci NOT NULL,
  `Authorized` tinyint(4) NOT NULL,
  `Timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Lifetime` int(11) NOT NULL,
  PRIMARY KEY  (`Token`,`ProviderKey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserAuthenticationToken` */

/*Table structure for table `GDN_UserCategory` */

CREATE TABLE IF NOT EXISTS `GDN_UserCategory` (
  `UserID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `DateMarkedRead` datetime default NULL,
  `Unfollow` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`UserID`,`CategoryID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserCategory` */

/*Table structure for table `GDN_UserComment` */

CREATE TABLE IF NOT EXISTS `GDN_UserComment` (
  `UserID` int(11) NOT NULL,
  `CommentID` int(11) NOT NULL,
  `Score` float default NULL,
  `DateLastViewed` datetime default NULL,
  PRIMARY KEY  (`UserID`,`CommentID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserComment` */

/*Table structure for table `GDN_UserConversation` */

CREATE TABLE IF NOT EXISTS `GDN_UserConversation` (
  `UserID` int(11) NOT NULL,
  `ConversationID` int(11) NOT NULL,
  `CountReadMessages` int(11) NOT NULL default '0',
  `LastMessageID` int(11) default NULL,
  `DateLastViewed` datetime default NULL,
  `DateCleared` datetime default NULL,
  `Bookmarked` tinyint(4) NOT NULL default '0',
  `Deleted` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`UserID`,`ConversationID`),
  KEY `FK_UserConversation_LastMessageID` (`LastMessageID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserConversation` */

/*Table structure for table `GDN_UserDiscussion` */

CREATE TABLE IF NOT EXISTS `GDN_UserDiscussion` (
  `UserID` int(11) NOT NULL,
  `DiscussionID` int(11) NOT NULL,
  `Score` float default NULL,
  `CountComments` int(11) NOT NULL default '0',
  `DateLastViewed` datetime default NULL,
  `Dismissed` tinyint(4) NOT NULL default '0',
  `Bookmarked` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`UserID`,`DiscussionID`),
  KEY `FK_UserDiscussion_DiscussionID` (`DiscussionID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserDiscussion` */

insert  into `GDN_UserDiscussion`(`UserID`,`DiscussionID`,`Score`,`CountComments`,`DateLastViewed`,`Dismissed`,`Bookmarked`) values (1,1,NULL,1,'2012-12-10 00:37:24',0,0),(1,2,NULL,1,'2012-12-10 01:25:51',0,0),(1,3,NULL,1,'2012-12-10 01:21:18',0,0),(1,4,NULL,1,'2012-12-10 01:23:02',0,0),(1,5,NULL,1,'2012-12-10 01:25:43',0,0);

/*Table structure for table `GDN_UserMeta` */

CREATE TABLE IF NOT EXISTS `GDN_UserMeta` (
  `UserID` int(11) NOT NULL,
  `Name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `Value` text collate utf8_unicode_ci,
  PRIMARY KEY  (`UserID`,`Name`),
  KEY `IX_UserMeta_Name` (`Name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserMeta` */

insert  into `GDN_UserMeta`(`UserID`,`Name`,`Value`) values (0,'Garden.Analytics.LastSentDate','20121209');

/*Table structure for table `GDN_UserRole` */

CREATE TABLE IF NOT EXISTS `GDN_UserRole` (
  `UserID` int(11) NOT NULL,
  `RoleID` int(11) NOT NULL,
  PRIMARY KEY  (`UserID`,`RoleID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `GDN_UserRole` */

insert  into `GDN_UserRole`(`UserID`,`RoleID`) values (0,2),(1,16);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
