// function recaptcha() {
//   var isNotSpam = function() {
//     var captcha = grecaptcha.getResponse();
//     var tmp = null;
//
//     $.ajax({
//       async: false,
//       type : 'POST',
//       url  : '/home/recaptcha',
//       data : {
//         response: captcha,
//       },
//       success: function(res) {
//         var response = $.parseJSON(res);
//         tmp = response.success;
//       }
//     });
//     return tmp;
//   }();
//   return isNotSpam;
// }

function validateSignupForm() {
  var username      = $('#txt-username').val();
  var email         = $('#txt-email').val();
  var password      = $('#txt-password').val();
  var alertUsername = $('#signup-user-error');
  var alertEmail    = $('#signup-email-error');
  var alertPassword = $('#signup-pwd-error');
  // var alertCaptcha  = $('#alert-captcha');
  // var captcha       = grecaptcha.getResponse();
  var alertUsernameContainer = $('#signup-user-error-container');
  var alertEmailContainer    = $('#signup-email-error-container');
  var alertPasswordContainer = $('#signup-pwd-error-container');
  var counter  = 0;

  if(!username) {
    alertUsername.html('Please provide a username.').removeClass('hide');
    alertUsernameContainer.removeClass('hide');
    counter++;
  } else {
    if(username.length < 4) {
        alertUsername.html('Username must be alteast 4 characters long.').removeClass('hide');
        alertUsernameContainer.removeClass('hide');
      counter++;
    } else if(username.length > 13) {
      alertUsername.html('Username must not exceed 13 characters long.').removeClass('hide');
      alertUsernameContainer.removeClass('hide');
      counter++;
    } else if(checkIfUsernameExists(username)) {
      alertUsername.html('Username already exists.').removeClass('hide');
      alertUsernameContainer.removeClass('hide');
      counter++;
    } else {
      alertUsername.html('');
      alertUsernameContainer.addClass('hide')
    }
  }

  if(!email) {
    alertEmail.html('Please provide an email address.').removeClass('hide');
    alertEmailContainer.removeClass('hide')
    counter++;
  } else {
    if(!validateEmail(email)) {
      alertEmail.html('Please provide a valid email address.').removeClass('hide');
      alertEmailContainer.removeClass('hide')
      counter++;
    } else if(checkIfEmailExists(email)) {
      alertEmail.html('Email already exists.').removeClass('hide');
      alertEmailContainer.removeClass('hide')
      counter++;
    } else {
      alertEmail.html('');
      alertEmailContainer.addClass('hide')
    }
  }

  if(!password) {
    alertPassword.html('Please provide an account password.').removeClass('hide');
    alertPasswordContainer.removeClass('hide');
    counter++;
  } else if(password) {
    if(password.length < 4) {
      alertPassword.html('Password must be alteast 4 characters long.').removeClass('hide');
      alertPasswordContainer.removeClass('hide');
      counter++;
    } else if(password.length > 13) {
      alertPassword.html('Password must not exceed 13 characters long.').removeClass('hide');
      alertPasswordContainer.removeClass('hide');
      counter++;
    } else {
      alertPassword.html('');
      alertPasswordContainer.addClass('hide');
    }
  }

  // if(captcha.length < 1) {
  //   alertCaptcha.html('<small>Please check the checbox.</small>').removeClass('hide');
  //   counter++;
  // } else {
  //   var isNotSpam = recaptcha();
  //   if(isNotSpam) {
  //     alertCaptcha.html('').addClass('hide');
  //   } else {
  //     alertCaptcha.html('<small>Spam alert.</small>').removeClass('hide');
  //     counter++;
  //   }
  //   // alertCaptcha.html('').addClass('hide');
  // }

  if(counter > 0) {
    return false;
  } else {
    return true;
  }
}

function validateEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}

function checkIfEmailExists(email) {
  var url = 'http://api2.contrib.co/forum2/CheckIfEmailExists';
  var domain = $('#current-domain').val();
  // var url = 'http://184.107.160.133/forum/CheckIfEmailExists';

  var isExists = function() {
    var tmp = null;
    $.ajax({
      async  : false,
      type   : 'POST',
      url    : url,
      data   : { email: email, domain: domain },
      success: function(res) {
        if(res.success) {
          if(res.data['isExists'] && !res.data['domain_exists']) {
            tmp = res.data['domain_exists'];
          } else {
            tmp = res.data['isExists'];
          }
        }
      }
    });
    return tmp;
  }();

  return isExists;
}

function checkIfUsernameExists(username) {
  var domain = $('#current-domain').val();
  var url = 'http://api2.contrib.co/forum2/CheckIfUsernameExists';
  // var url = 'http://184.107.160.133/forum/CheckIfUsernameExists';
  var isExists = function() {
    var tmp = null;
    $.ajax({
      async  : false,
      type   : 'POST',
      url    : url,
      data   : { username: username, domain: domain },
      success: function(res) {
        if(res.success) {
          tmp = res.data['isExists'];
        }
      }
    });
    return tmp;
  }();

  return isExists;
}

function checkIfAccountExists(username, password) {
  var domain = $('#current-domain').val();
  var url = 'http://api2.contrib.co/forum2/CheckAccountExists';
  // var url = 'http://184.107.160.133/forum/CheckAccountExists';
  var password = btoa(password);
  var isExists = function() {
    var tmp = null;
    $.ajax({
      async  : false,
      type   : 'POST',
      url    : url,
      data   : { username: username, password: password, domain: domain },
      success: function(res) {
        if(res.success) {
          tmp = res.data['isExists'];
        }
      }
    });
    return tmp;
  }();
  return isExists;
}

function register() {
  var username = $('#txt-username').val();
  var email    = $('#txt-email').val();
  var password = $('#txt-password').val();
  var domain   = $('#current-domain').val();
  var avatar   = $('#avatar').val();
  var url = '/home/signup';

  password = btoa(password);

  $.ajax({
    type: 'POST',
    url: url,
    data: {
      username: username,
      email   : email,
      password: password,
      domain  : domain,
      avatar  : avatar
    },
    success: function(res) {
      if(res) {
        saveToVnocLeads();
      }
    }
  });
}

function saveToVnocLeads() {
  var email   = $('#txt-email').val();
  var domain  = $('#domain').val();
  var user_ip = $('#ip-address').val();
  var url = "http://www.contrib.com/forms/saveleads";

  $.ajax({
    type     : 'POST',
    url      : url,
    data     : {
      email  : email,
      domain : domain,
      user_ip: user_ip
    },
    success  : function(res) {
      saveSalesForceLead();
    }
  });
}

function saveSalesForceLead() {
  var email   = $('#txt-email').val();
  var domain  = $('#domain').val();
  var url = "http://www.manage.vnoc.com/salesforce/addlead";
  $.ajax({

    type: 'POST',
    url   : url,
    data  : {
      'firstName': name,
      'lastName' : name,
      'title'    : '',
      'email'    : email,
      'phone'    : '',
      'street'   : '',
      'city'     : '',
      'country'  : '',
      'state'    : '',
      'zip'      : '',
      'domain'   : domain,
      'form_type': 'Contrib Forum Framework'
    },
    success: function(res) {
      console.log(res);
      saveUserToContrib();
    }
  });
}

function saveUserToContrib() {
  var username = $('#txt-username').val();
  var email    = $('#txt-email').val();
  var password = $('#txt-password').val();
  var url = "http://api2.contrib.co/forum2/SaveUserToContrib";
  // var url = "http://184.107.160.133/forum/SaveUserToContrib";

  password = btoa(password);

  $.ajax({
    type: 'POST',
    url   : url,
    data  : {
      username: username,
      email   : email,
      password: password
    },
    success: function(res) {
      if(res.success) {
        $('#regModal').modal('hide');
        $('.modal-backdrop').remove();
        window.location.href = "/welcome";
      }
    },
    error: function() {
      $('#regModal').modal('hide');
      $('.modal-backdrop').remove();
      window.location.href = "/welcome";
    }
  });
}

function validateLoginForm() {
  var username = $('#txt-username').val();
  var password = $('#txt-password').val();
  var alertLoginUsername = $('#login-username-error');
  var alertLoginPassword = $('#login-pwd-error');
  var alertLoginUsernameContainer = $('#login-user-error-container');
  var alertLoginPwdContainer = $('#login-pwd-error-container');
  var counter = 0;
  alertLoginUsernameContainer.addClass('hide');
  alertLoginPwdContainer.addClass('hide');
  if(username && password) {

    if(!checkIfUsernameExists(username)) {
      alertLoginUsername.html("The username you’ve entered doesn’t match any account.").removeClass('hide');
      alertLoginUsernameContainer.removeClass('hide');
      counter++;
    } else {
      alertLoginUsername.html('').addClass('hide');
      if(!checkIfAccountExists(username, password)) {
        alertLoginPassword.html("The password you've entered is incorrect.").removeClass('hide');
        alertLoginPwdContainer.removeClass('hide');
        counter++;
      } else {
        alertLoginPassword.html('');
        alertLoginPwdContainer.addClass('hide')
      }
    }
  } else if(!username || !password) {
    if(!username) {
      alertLoginUsername.html('Please enter a username.').removeClass('hide');
      alertLoginUsernameContainer.removeClass('hide');
      counter++;
    } else {
      alertLoginUsername.html('');
      alertLoginUsernameContainer.addClass('hide')
    }

    if(!password) {
      alertLoginPassword.html('Please enter a password.').removeClass('hide');
      alertLoginPwdContainer.removeClass('hide')
      counter++;
    } else {
      alertLoginPassword.html('');
      alertLoginPwdContainer.addClass('hide')
    }
  }

  if(counter > 0) {
    return false;
  } else {
    return true;
  }
}
