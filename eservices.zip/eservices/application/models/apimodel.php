<?php
include("php_fast_cache.php");

class ApiModel extends Model {
	
	private $api_url = "http://api2.contrib.co/request/";
	private $api_handyman = "http://handyman.com/api/";
	private $api_urlco = "http://api1.contrib.co/request/";
	private $api_content_url = "http://api3.contrib.co/announcement/";
	private $headers = array('Accept: application/json');
	
 function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null){
	if(($method == 'PUT') || ($method=='DELETE')){
			$headers[] = 'X-HTTP-Method-Override: '.$method;
	}

	$handle = curl_init();
	curl_setopt($handle, CURLOPT_URL, $url);
	// curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
	if($user){
	 curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
	} 

	switch($method){
		case 'GET':
				break;
		case 'POST':
				curl_setopt($handle, CURLOPT_POST, true);
				curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
				break;
		case 'PUT':
				curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
				curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
				break;
		case 'DELETE':
				curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
				break;
	}
	
	$response = curl_exec($handle);
	return $response;
}
	
	function getdomain(){
	
		$domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
			/*$domain = $_SERVER["HTTP_HOST"];
			$domain = str_replace("http://","",$domain);
			$domain = str_replace("www.","",$domain);*/
		
		if(stristr($domain, '~') ===FALSE) {
			$domain = $_SERVER["HTTP_HOST"];
			$domain = str_replace("http://","",$domain);
			$domain = str_replace("www.","",$domain);
			$key = md5($domain);
		} else {
			$key = md5('vnoc.com');
			$d = explode('~',$domain);
			$user = str_replace('/','',$d[1]);
			$host = $_SERVER["HTTP_HOST"];
			$host = str_replace("http://","",$host);
			$host = str_replace("www.","",$host);
			$url = $this->api_url.'getdomainbyusername?username='.$user.'&key='.$key.'&host='.$host;
			$result =  $this->createApiCall($url, 'GET', $headers, array());
			$data_domain = json_decode($result,true);
			$error = 0;
			$domain =   $data_domain['data']['domain'];			
		}	
			return $domain;
	}

	function getkey(){
		return md5($this->getdomain());
	}
	
	function getdomaininfo(){		
    global $domainid;
    global $domain;
    global $memberid;
	  global $title;
	  global $logo ;
	  global $description;
	  // global $account_ga;
	  global $piwik_id;
		global $social_fb;
    global $social_gplus;
    global $social_twitter;
    global $social_linkedin;
    global $social_gtube;
    global $keywords;

		$info['keywords'] = $keywords;    
		$info['domainid'] = $domainid;
		$info['domain'] = $domain;
		$info['memberid'] = $memberid;
		$info['title'] = $title;
		$info['logo'] = $logo;
		$info['description'] = $description;
		$info['account_ga'] = $this->getGoogleAnalytics($domain);
		$info['piwik_id'] = $piwik_id;    	
		$info['attr'] = $this->getdomainattributes();
		$info['socials'] = array('fb'=>$social_fb,'gplus'=>$social_gplus,'twitter'=>$social_twitter);
		return $info;
	}
   
	function getdomainattributes(){
		global  $background_image;
		global  $header_text;

		$info_attributes['background_image_url'] = $background_image;
		$info_attributes['header_text'] = $header_text;

		return $info_attributes;   
	}
   
	function getprojecttypes(){
		global $projecttypes ;
		return $projecttypes;
	}
   
	function getstates(){
		global $states ;
		return $states;
	}
   
	function getcatnamebyslug($slug){
		global $projecttypes ;
		$name = "";
		foreach ($projecttypes as $key=>$val){
			if($val['slug']==$slug){
				$name = $val['name'];
				return $name;
			}
			if(count($val['children'])>0){
				foreach ($val['children'] as $ckey=>$cval){
					if($cval['slug'] == $slug){
						$name = $cval['name'];
						return $name;
					}
				}
			}	
		}
		return $name;
	}
   
	function getstateid($slug){
		global $states ;
		$state_id = "";
		foreach ($states as $key=>$val){
			if($val['slug']==$slug){
				$state_id = $val['id'];
				return $state_id;
			}
		}
		return $state_id;
	}
   
	function saveproject($data){
		$response = $this->createApiCall('http://handyman.com/api/saveproject', 'POST', $this->headers,$data);
		$response = json_decode($response, true);

		return $response;
	}
   
  function checkexist($field,$value){   
		$response = $this->createApiCall('http://handyman.com/api/checkexists?field='.$field.'&value='.$value.'', 'GET', $this->headers);
		$response = json_decode($response, true);
		
		return $response;
  }
   
  function getpiwikid(){
		$url3 = $this->api_urlco.'GetPiwikId?domain='.$this->getdomain().'&key='.$this->getkey();
		$result3 = $this->createApiCall($url3, 'GET', $this->headers, array());
    $data_domain3 = json_decode($result3,true);
		$piwik_id = $data_domain3['data']['idsite'];
		
		return $piwik_id;
  }
   
  function getfooterbanner(){
		//get monetize ads from vnoc
		$url = $this->api_urlco.'getbannercode?d='.$this->getdomain().'&p=footer';
		$result = $this->createApiCall($url, 'GET', $this->headers, array());
		$data_ads = json_decode($result,true);
		$footer_banner = html_entity_decode(base64_decode($data_ads['data']['content']));
		
		return $footer_banner;
  }
   
  function getfund(){
   
		$url = $this->api_url.'getfundcampaigns';
		$result = $this->createApiCall($url, 'GET', $this->headers, array()); 
		$items = json_decode($result,true);
		
		if($items['success']){
			$campaigns = $items['data'];
		}
   
		return $campaigns;
  }
   
  function relatedsitesnologo(){   
		global $related_nologo;
		return $related_nologo;   
  }
   
  function relatedsiteswithlogo(){   
		global $related_domains;
		return $related_domains;
  }

  function getaffiliateid(){
	  $url = $this->api_url.'getdomainaffiliateid?domain='.$this->getdomain().'&key='.$this->getkey();
		$result = $this->createApiCall($url, 'GET', $this->headers, array());
		$data_domain_affiliate = json_decode($result,true);
		
		if($data_domain_affiliate['success']){
			$domain_affiliate_id = $data_domain_affiliate['data']['affiliate_id'];
		}else{
			$domain_affiliate_id = '391'; //contrib.com affiliate id
		}
		// $domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$this->getdomain();
		return $domain_affiliate_id;
  }
  
	function getprograms(){
		$url = $this->api_url.'getReferralBanners?domain='.$this->getdomain().'&key='.$this->getkey().'&affiliate_id='.$this->getaffiliateid();
		$result = $this->createApiCall($url, 'GET', $this->headers, array());
		$program_result = json_decode($result,true);
		$programs = array();  
		if($program_result['success']){
			$programs = $program_result['data'];
		}else{
			$programs = array();
		}
		return $programs;
	} 
	
  function getquestions(){
		$url = $this->api_handyman.'Getquestions';
		$result = $this->createApiCall($url, 'GET', $this->headers, array()); 
		$items = json_decode($result,true);
		
		if($items['success']){
			$questions = $items['data'];
		}
    	return $questions;
  }
   
  function getsearches($member_id){
		$searches = array();
		$response = $this->createApiCall('http://api1.contrib.co/search/Getsearches?member_id='.$member_id, 'GET', $this->headers);
		$response = json_decode($response, true);
		
		if(isset($response['data'])){
			$searches = $response['data'];
		}
		return $searches;
  }
  
  function getleadscount($member_id,$keyword='',$status_id=''){
		$total = 0;
		$response = $this->createApiCall('http://api1.contrib.co/search/Getleadscount?member_id='.$member_id.'&keyword='.$keyword.'&status='.$status_id, 'GET', $this->headers);
		$response = json_decode($response, true);
		if(isset($response['data'])){
			$total = intval($response['data']['total']);
		}
		return $total;
  }
  
	function getleads($member_id,$keyword,$start=0,$limit=12,$status_id=''){
		$searches = array();
		$response = $this->createApiCall('http://api1.contrib.co/search/Getleads?member_id='.$member_id.'&keyword='.$keyword.'&start='.$start.'&limit='.$limit.'&status='.$status_id, 'GET', $this->headers);
		$response = json_decode($response, true);
		
		if(isset($response['data'])){
			$searches = $response['data'];
		}
		return $searches;
  }
	
	function geteservicespackages(){
		$packages = array();
		$response = $this->createApiCall('http://contrib.applications.com/eservicesapi/geteservicespackages', 'GET', $this->headers);
		$response = json_decode($response, true);
		
		if(isset($response['data'])){
			$packages = $response['data'];
		}
		return $packages;
	}
	
	function getservicescat(){
		//global $services_category;
		//return $services_category;

		$services_category = array();
		$response = $this->createApiCall('http://contrib.us/eservicesapi/getcategories', 'GET', $this->headers);
		$response = json_decode($response, true);
		
		if(isset($response['data'])){
			$services_category = $response['data'];
		}
		return $services_category;
	}
	
	function getGoogleAnalytics($domain){
		$response = $this->createApiCall('http://api2.contrib.co/request/getdomaininfo?domain='.$domain.'&key='.md5($domain), 'GET', $this->headers);
		$response = json_decode($response, true);
		
		if(isset($response['data'])){
			$account_ga = $response['data']['AccountGA'];
		}
		return $account_ga;
	}

	function getprogramsanim(){
		global $programs;
		return $programs;
	}

	//get contents
	function getcontent($domain,$page){
		$key = '5c1bde69a9e783c7edc2e603d8b25023';
		$url = $this->api_content_url.'GetFooterContents?domain='.$domain.'&key='.$key.'&page='.$page;
		$result =  createApiCall($url, 'GET', $headers, array());
		$data_domain = json_decode($result,true);
		$page = "";

		if (isset($data_domain['data']['content'])){
			$page = $data_domain['data']['content'];
		}

		return $page;
	}
}
?>