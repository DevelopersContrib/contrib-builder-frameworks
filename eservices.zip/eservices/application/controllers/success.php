<?php

class Success extends Controller {
	
  function index(){				
		if(isset($_POST['eservice'])){
			$session = $this->loadHelper('Session_helper');
			$api = $this->loadModel('ApiModel');
			$helper = $this->loadHelper('Url_helper');
			$info = $api->getdomaininfo();
			
			$title = 'Registration complete';
			$eservice = json_decode($_POST['eservice'],TRUE);
			
			$template = $this->loadView('success');
			$template->set('info', $info);
			$template->set('title', $title);
			$template->set('eservice', $eservice);
			$template->render();
		} else {
			header('Location: /');
		}
	}
}

?>