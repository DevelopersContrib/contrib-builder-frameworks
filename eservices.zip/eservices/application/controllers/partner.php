<?php

class Partner extends Controller {
	
  function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		
		$title = 'Partner :: '.ucwords($info['domain']);
		
		$template = $this->loadView('partner');
		$template->set('info', $info);
		$template->set('title', $title);
		$template->render();
	}
}

?>