<?php

class Cart extends Controller {
	
  function index(){
		$session = $this->loadHelper('Session_helper');
		
		if (isset($_SESSION['logged_in'])){
			header('Location: '.BASE_URL.'dashboard');
			exit;
		}else {
			$api = $this->loadModel('ApiModel');
			$helper = $this->loadHelper('Url_helper');
			$info = $api->getdomaininfo();
			$template = $this->loadView('cart');
			$template->set('info', $info);
			$template->render();
		}
	}
}

?>