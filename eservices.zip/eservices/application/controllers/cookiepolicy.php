<?php

class CookiePolicy extends Controller {
	
  function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		
		$title = 'Cookie Policy :: '.ucwords($info['domain']);
		
		$template = $this->loadView('cookiepolicy');
		$template->set('info', $info);
		$template->set('title', $title);
		$template->set('content', $api->getcontent($info['domain'],'cookie'));
		$template->render();
	}
}

?>