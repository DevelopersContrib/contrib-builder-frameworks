<?php

class Home extends Controller {
	
	function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$packages = $api->geteservicespackages();		
		$programs = $api->getprogramsanim();
		
		$title = 'Home :: '.ucwords($info['domain']);
		$page = 'index';		
		
		$template = $this->loadView('index');
		$template->set('programs', $programs);
		$template->set('info', $info);
		$template->set('title', $title);
		$template->set('page', $page);
		$template->set('eservices_packages',$packages);
		$template->render();
	}
}

?>