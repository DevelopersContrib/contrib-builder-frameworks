<?php

class Developers extends Controller {
	
  function index(){
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		
		$title = 'Developers :: '.ucwords($info['domain']);
		
		$template = $this->loadView('developers');
		$template->set('info', $info);
		$template->set('title', $title);
		$template->render();
	}
}

?>