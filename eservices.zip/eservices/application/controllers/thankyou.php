<?php

class Thankyou extends Controller {
	
  function index(){				
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		
		$eservices_url = $_POST['eservices_url'];
		
		$template = $this->loadView('thankyou');
		$template->set('info', $info);
		$template->set('eservices_url', $eservices_url);
		$template->render();
	}
}

?>