<?php

class Signup extends Controller {
	
  function index(){
	
		if(isset($_POST['order'])){

			$session = $this->loadHelper('Session_helper');
			$api = $this->loadModel('ApiModel');
			$helper = $this->loadHelper('Url_helper');
			$info = $api->getdomaininfo();
			$category = $api->getservicescat();
			$getdomainattributes = $api->getdomainattributes();
			$order = json_decode($_POST['order'],TRUE);
			$domain_name = $order['domain'];
			$package = $order['package']['packageId'];
			$items =  $order['items'];
			$title = 'Signup :: '.ucwords($info['domain']);
			$object = (object) $items;
			$template = $this->loadView('signup');
			$template->set('domain', $domain_name);
			$template->set('package', $package);
			$template->set('item_array', $items);
			$template->set('items', $object);
			$template->set('getdomainattributes', $getdomainattributes);
			$template->set('category', $category);
			$template->set('info', $info);
			$template->set('title', $title);
			$template->render();

		}else{
			header('Location: /');
		}
		
		
	}

	 function order()
	{
			$api = $this->loadModel('ApiModel');
			$helper = $this->loadHelper('Url_helper');
			$info = $api->getdomaininfo();
			$category = $api->getservicescat();
			$getdomainattributes = $api->getdomainattributes();
			$template = $this->loadView('order_list');
			$template->render();
	}
	 function cart()
	{
			$api = $this->loadModel('ApiModel');
			$helper = $this->loadHelper('Url_helper');
			$info = $api->getdomaininfo();
			$category = $api->getservicescat();
			$getdomainattributes = $api->getdomainattributes();
			$template = $this->loadView('cart_list');
			$template->render();
	}

  function ActionGetDesc(){

		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
  		$url = $_POST['domain'];
  		$exist = false;
  		$description = "";
		$tagsi = get_meta_tags($url);

		if ($this->is_url_exist($url)){
				$exist = true;
				$tags = get_meta_tags($url);
				if (isset($tags['description'])){
					$description = $tags['description'];  // a php manual
				}
			}
			
		if ($description == ""){
				$url = str_replace('http://','https://',$url);
				if ($this->is_url_exist($url)){
					$exist = true;
					$tags = get_meta_tags($url);
					if (isset($tags['description'])){
						$description = $tags['description'];  // a php manual
					}
				}
			}

		$result = array('exist'=>$exist,'description'=>$description,'domain'=>$url); 
	    echo json_encode($result);  
  }

  private function is_url_exist($url){
		    $ch = curl_init($url);    
		    curl_setopt($ch, CURLOPT_NOBODY, true);
		    curl_exec($ch);
		    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		
		    if($code == 200){
		       $status = true;
		    }else{
		      $status = false;
		    }
		    curl_close($ch);
		    return $status;
  }

}

?>