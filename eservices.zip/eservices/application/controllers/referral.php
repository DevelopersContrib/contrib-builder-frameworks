<?php

class Referral extends Controller {
	
  function index(){
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		
		$title = 'Referral :: '.ucwords($info['domain']);
		
		$programs = $api->getprograms();
		
		$template = $this->loadView('referral');
		$template->set('info', $info);
		$template->set('title', $title);
		$template->set('programs', $api->getprograms());
		$template->render();
	}
}

?>