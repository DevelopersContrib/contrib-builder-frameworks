<?php include('header.php'); ?>

<style>
.page-container {
	background:#fafafa;
	border: 1px solid rgb(222, 222, 222);
	margin-top: 120px;
	margin-bottom: 100px;
	padding: 80px 50px;
}
</style> 

<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 page-container">
			<h2 class="text-center">Developers <?=ucwords($info['domain'])?></h3>
			<hr>
			<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Do you have code or an app that could run this brand? <?=$info['domain']?> is connected with Contrib. </h4>
			<p></p>
			<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?php echo $info['domain']; ?>? </h4>
			<p class="text-center">
			<br>
			<a href="/contact" class="btn btn-primary btn-lg">Inquire Here</a>
			</p>
		</div>
	</div>
</div>


<?php include('footer.php'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>
