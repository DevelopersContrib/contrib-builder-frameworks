<div class="featured-partners">
	<div class="container">
		<h2 class="text-center">Featured Partners</h2>
		<div class="row">			
			<div class="panel3">
				<a href="http://eservices.com/"><img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-eservices-1-1.png" alt="eservices.com" title="eservices.com" style="padding: 16px;"></a>
			</div>
			<div class="panel3">
				<a href="http://applications.com/"><img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Applications-7.png" alt="applications.com" title="applications.com" style="padding: 28px 15px;"></a>
			</div>
			<div class="panel3">
				<a href="http://contrib.com/"><img class="img-responsive" src="https://www.contrib.com/images/assets/logo-contrib.png" alt="contrib.com" title="contrib.com" style="padding: 31px 24px;"></a>
			</div>
			<div class="panel3">
				<a href="http://vnoc.com/"><img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-vnoc4.png" alt="vnoc.com" title="vnoc.com" style="padding: 18px 15px;"></a>
			</div>
			<div class="panel3">
				<a href="http://referrals.com/"><img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta9-small.png" alt="referrals.com" title="referrals.com" style="padding: 35px 12px;"></a>
			</div>
		</div>
	</div>
</div>

<div class="featured-program">
	<div class="container">		
		<div class="row">
			<div class="col-md-6 col-md-offset-3 text-center">
					<h2 class="text-center">Featured Referral Program</h2>
			      <div class="row">
						<div class="col-md-12">
							<ul class="list-inline text-center fadeDivUl">
								<?php if (count($programs)>0):?>
							        <?php foreach ($programs as $key=>$val):?>
										<li>
											<div class="wrap-rp-bx-container">
												<?php echo $val['code']?>
											</div>
										</li>
									<?php endforeach;?>
								<?php endif?>	
							</ul>
						</div>
					</div>
			</div>					
		</div>
	</div>
</div>

<script>
	jQuery(document).ready(function(){
		$ds = jQuery('ul.fadeDivUl li');
		$ds.hide().eq(0).show();
		setInterval(function(){
			$ds.filter(':visible').fadeOut(function(){
				var $div = jQuery(this).next('li');
				if ( $div.length == 0 ) {
					$ds.eq(0).fadeIn();
				} else {
					$div.fadeIn();
				}
			});
		}, 10000);
    });
</script>