<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?=!empty($info['description']) ? $info['description']:'Eservices contrib.com'?>">
<meta name="author" content="<?php echo $info['domain']; ?>">
<meta name="keywords" content="<?php echo $info['keywords']; ?>" />
<title><?=$title?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="static/css/style.css">
<!-- piwik/ga -->
<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	// ga('create', 'UA-83684919-1', 'auto');
	ga('create', '<?=$info['account_ga']?>', 'auto');
	ga('send', 'pageview');
</script>
<!-- Piwik -->
<script type="text/javascript">
	var _paq = _paq || [];
	_paq.push(['trackPageView']);
	_paq.push(['enableLinkTracking']);
	(function() {
		var u="//www.stats.numberchallenge.com/";
		_paq.push(['setTrackerUrl', u+'piwik.php']);
		_paq.push(['setSiteId', <?=$info['piwik_id']; ?>]);
		var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
		g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
	})();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
</head>
<body>
<div class="fbg-container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
	  <div class="container">
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
			<span class="sr-only">Toggle navigation</td>
			<span class="icon-bar"></td>
			<span class="icon-bar"></td>
			<span class="icon-bar"></td>
		  </button>
		  <a class="navbar-brand e-logo" href="/"><?=ucwords($info['domain'])?></a>
		</div>
		<ul class="nav navbar-nav navbar-right nbr hide">
			<li><a href="#"><i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Sign In</a></li>		
			<li class="dropdown">
			  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Welcome,&nbsp;Andre 
				<span class="caret"></span>
			  </a>
			  <ul class="dropdown-menu">
				<li><a href="#">Settings</a></li>
				<li><a href="#">Log Out</a></li>
			  </ul>
			</li>
		</ul>
		<?php if($page == 'index'){ ?>
			<a href="" class="item-count-box"><h2 class="item-count pull-right">0</h2></a>
		<?php } else { ?>
			<ul class="nav navbar-nav navbar-right nbr">
				<li><a href="/">Back to Home</a></li>        
			</ul>	
		<?php } ?>
	  </div>  
	</nav>
	<?php if($page == 'index'){?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script>
		$(function(){
			$('.item-count-box').on('click',function(e){
				$('#btn-signup').trigger('click');
				e.preventDefault();
			});
		});
	</script>
	<?php } ?>
	