<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Eservices.com</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="static/css/style.css">
<style>
body {
	background:#fff;
}
</style>
</head>

<body>

<?php include('page-navigation.php'); ?>

<div class="table-container">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2><i class="fa fa-cart-plus" aria-hidden="true"></i>&nbsp;eServices Add Cart </h2>
				<hr>
				<table class="table table-striped custab table-bordered">
				<thead>
				<a href="#" class="btn btn-danger pull-right" style="margin-bottom: 10px;">
					<i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;Remove Selected
				</a>
					<tr>
						<th><input type="checkbox"></th>
						<th>eServices Item</th>
						<th>Price</th>
						<th>Fee</th>
						<th>Sub Total</th>
						<th>Instructions</th>
					</tr>
				</thead>
						<tr>
							<td><input type="checkbox"></td>
							<td>Create Logo</td>
							<td>$&nbsp;1</td>
							<td>$&nbsp;5</td>
							<td>$&nbsp;6</td>							
							<td class="text-center">
								<textarea class="form-control" rows="1"></textarea>
							</td>
						</tr>
						<tr>
							<td><input type="checkbox"></td>
							<td>Create Logo</td>
							<td>$&nbsp;1</td>
							<td>$&nbsp;5</td>
							<td>$&nbsp;6</td>							
							<td class="text-center">
								<textarea class="form-control" rows="1"></textarea>
							</td>
						</tr>
						<tr>
							<td><b>1 Domain</b></td>
							<td style="border-right: 1px solid transparent;"></td>
							<td style="border-right: 1px solid transparent;"></td>
							<td></td>
							<td><b>$&nbsp;12</b></td>
							<td><b>Total:&nbsp;$&nbsp;12</b></td>
						</tr>
				</table>
				<table>					
					<a href="#" class="btn btn-primary pull-right" style="margin-bottom: 10px;">
					<i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;Proceed To Order
					</a>
					<a href="#" class="btn btn-default pull-right" style="margin-bottom: 10px;margin-right: 5px;">
					<i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp;Back
					</a>
				</table>
			</div>
		</div>
	</div>
</div>


<?php include('footer.php'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>
