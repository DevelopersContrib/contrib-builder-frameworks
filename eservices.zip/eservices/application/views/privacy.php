<?php include('header.php'); ?>

<style>
.page-container {
	background:#fff;
	border: 1px solid rgb(222, 222, 222);
	margin-top: 10px;
	margin-bottom: 100px;
	padding: 50px 50px;
}
.mrgtop {
	margin-top: 70px;
}
</style>

<div class="container mrgtop">
<div class="row header-search">
  <h2 class="text-center">Privacy</h2>
  <div class="col-md-8 col-md-offset-2 page-container">
		<?php echo $content; ?>
</div>
</div>
</div>


<?php include('footer.php'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>
