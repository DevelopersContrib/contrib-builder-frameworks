<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
	<div class="navbar-header">
	  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
		<span class="sr-only">Toggle navigation</td>
		<span class="icon-bar"></td>
		<span class="icon-bar"></td>
		<span class="icon-bar"></td>
	  </button>
	  <a class="navbar-brand e-logo" href="/">Eservices.com</a>
	</div>
	<ul class="nav navbar-nav navbar-right nbr">
		<li><a href="/">Back to Home</a></li>        
    </ul>	
  </div>  
</nav>