<?php include('header.php'); ?>

<style>
.flow-container {
	margin-top:120px;
}
.success-container {
	margin-top:0px;
	margin-bottom:200px;
}
</style> 
<div class="flow-container">
	<div class="container text-center">
		<div class="row">				
			<div class="col-md-3">
				<a href="javascript:void(0)"><img class="active img-responsive" src="/img/plus.png" alt="Email" title="Email" id="flow1"></a>
			</div>
			<div class="col-md-3">
				<a href="javascript:void(0)"><img class="active img-responsive" src="/img/edit.png" alt="Package" title="Package" id="flow2"></a>
			</div>
			<div class="col-md-3">
				<a href="javascript:void(0)"><img class="active img-responsive" src="/img/cart.png" alt="Cart" title="Cart" id="flow3"></a>
			</div>
			<div class="col-md-3">
				<a href="javascript:void(0)"><img class="active img-responsive" src="/img/check.png" alt="Complete" title="Complete" id="flow4"></a>
			</div>
			<div class="col-md-12">
				<div class="flow-line"></div>
			</div>
		</div>
	</div>
</div>
<div class="container">
	<?php if(!empty($eservice)){ ?>
	<div class="row">
		<div class="col-md-6 col-md-offset-3 success-container text-center">
			<img src="/img/thankyou.png" alt="Thank you!" title="Thank you!" style="height:250px;">
			<h3 class="ty-purchase">For yor purchase.<br>We appreciate your business. </h3>
			<hr>
			<h4 class="ty-proceed">Proceed to contrib.applications.com where you can manage and edit your services and orders.</h4>
			<div class="panel panel-default">
			  <div class="panel-heading"><b>Transaction Details</b></div>
			  <div class="panel-body">
				<section><b>Domain:</b>&nbsp;<?=ucwords($eservice['domain']);?></section>
				<section><b>Add-on/s Microtask:&nbsp;</b><?=($eservice['item_count'] > 1) ? $eservice['item_count'].' items':$eservice['item_count'].' item'?></section>
				<section><b>Total:</b>&nbsp;$<?=$eservice['total_price']?></section>
				<h3><a href="<?=$eservice['url']?>" class="btn btn-warning btn-lg">Proceed</a></h3>
			  </div>
			</div>			
		</div>
	</div>
	<?php }?>	
</div>


<?php include('footer.php'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>
