<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Eservices.com</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="css/custom.css">
<style>
.success-container {
	margin-top:150px;
	margin-bottom:150px;
}
.panel {
	padding-bottom: 30px;
}
</style>  
</head>

<body>

<?php include('page-navigation.php'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3 success-container text-center">
			<div class="panel panel-default">
				<img src="/img/thankyou.png" style="height:250px;">
				<h3 style="margin-top:-30px;">For signing up to our eServices.</h3>
				<hr>
				<h4>You will now be redirected to contrib.applications.com where you can manage and edit your services and orders.</h4>			
				<h3><a href="" class="btn btn-warning btn-lg">Proceed</a></h3>
			</div>
		</div>
	</div>
</div>


<?php include('footer.php'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>
