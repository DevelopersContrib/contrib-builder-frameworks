<?php include('header.php'); ?>

<style>
.page-container {
	background:#fafafa;
	border: 1px solid rgb(222, 222, 222);
	margin-top: 100px;
	margin-bottom: 100px;
	padding: 50px 50px;
}
</style> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 page-container">
			<h2 class="text-center">Contact <?=ucwords($info['domain'])?></h3>
			<hr>
			<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?=$info['domain']?>"></script>
		</div>
	</div>
</div>


<?php include('footer.php'); ?>
</body>
</html>
