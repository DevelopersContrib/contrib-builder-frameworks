<?php include 'header.php'; ?>
	<div class="signup-head-container">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<h1 class="g-signup">
						<?=$info['attr']['header_text']?> <input type="text" class="form-control" placeholder="example.com" id="domain"> <div class="d-alert hide">Please provide your domain, before signing up!</div><a href="" class="btn btn-warning" id="btn-signup" >Sign Up</a>&nbsp;is free.
					</h1>
				</div>
				<form action="/signup" method="POST" id="order" style="display:none;">
					<input type="hidden" id="ecart" name="order" value="" />
				</form>
			</div>
		</div>
	</div>
	<div class="nft">
		<div class="container">
			<div class="row">
				<section>
				<div class="wizard">
					<div class="wizard-inner">
						<div class="connecting-line"></div>
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation" class="flow disabled">
								<a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Add Domain">
									<span class="round-tab">
										<i class="fa fa-plus-square" aria-hidden="true"></i>
									</span>
								</a>
							</li>
							<li role="presentation" class="flow disabled">
								<a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Select Package">
									<span class="round-tab">
										<i class="glyphicon glyphicon-pencil"></i>
									</span>
								</a>
							</li>
							<li role="presentation" class="flow disabled">
								<a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Confirm">
									<span class="round-tab">
										<i class="glyphicon glyphicon-shopping-cart"></i>
									</span>
								</a>
							</li>
							<li role="presentation" class="flow disabled">
								<a href="#complete" data-toggle="tab" aria-controls="complete" role="tab" title="Complete">
									<span class="round-tab">
										<i class="glyphicon glyphicon-ok"></i>
									</span>
								</a>
							</li>
						</ul>
					</div>
				</div>				
			</section>
		   </div>
		</div>
	</div>
	<div class="flow-container">
		<div class="container text-center">
			<div class="row">				
				<div class="col-md-3">
					<a href="javascript:void(0)"><img class="img-responsive" src="/img/plus.png" alt="Email" title="Email" id="flow1"></a>
				</div>
				<div class="col-md-3">
					<a href="javascript:void(0)"><img class="img-responsive" src="/img/edit.png" alt="Package" title="Package" id="flow2"></a>
				</div>
				<div class="col-md-3">
					<a href="javascript:void(0)"><img class="img-responsive" src="/img/cart.png" alt="Cart" title="Cart" id="flow3"></a>
				</div>
				<div class="col-md-3">
					<a href="javascript:void(0)"><img class="img-responsive" src="/img/check.png" alt="Complete" title="Complete" id="flow4"></a>
				</div>
				<div class="col-md-12">
					<div class="flow-line"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container pt-container">
    <div class="row">
			<div class="col-xs-12">
				<h2 class="text-center">E-Services Package Select</h2>		
			</div>			
			<!-- eservices packages --->		
			<?php foreach($eservices_packages as $package): ?>
			<div class="col-xs-12 col-md-4">
				<div class="panel panel-success s-a-links" id="boxpt_<?=$package['package_id']?>">
					<input class="packagebox" id="box-pt_<?=$package['package_id']?>" name="package[]" type="checkbox" />
					<label for="" class="offer-box package-to-order" id="package<?=$package['package_id']?>" data-package-id="<?=$package['package_id']?>">
						<div class="panel-body">						
							<table class="table">  
								<tr>
								<td class="text-center label-info">
									<h3><?=$package['package_name']?></h3>
									<strong><span>$</span> <?=$package['price']?></strong>
								</td></tr>
								<?php foreach($package['items'] as $item): ?>
									<tr><td data-id="<?=$item['item_id']?>" class="p-items"><i class="fa fa-check"></i><?=$item['item_title']?></td></tr>
								<?php endforeach; ?>
							</table>
						</div>
					</label>
				</div>
			</div> 
			<?php endforeach; ?>			
			<!-- end eservices packages --->		
    </div>
</div>

<div class="container">
	<div class="row">
		<div class="col-xs-12"><h2 class="text-center">E-Services Order Cart</h2></div>
	</div>
</div>
<div class="container se-container">
	<div class="row">
		<div class="col-md-12 text-center">
			<div class="form-inline">
			  <div class="form-group">
				<input type="text" class="form-control" id="inpt-search" placeholder="Search for eServices">
			  </div>
			  <button type="submit" class="btn btn-default" id="btn-search">Search</button>
			</div>
		</div>
	</div>
</div>
<div class="container eservices-container">
	<div class="row">
		<!-- item list -->
		<div id="eservices-item-container">
			
		</div>
		<!-- end item list -->	
	</div>
	<!-- pagination -->
	<div class="col-md-12 text-center">
		<div id="pagination">
			
		</div>
	</div>
	<!-- end pagination -->
</div>

<!-- featured sites -->
<?php include('featured.php'); ?>
<!-- /featured sites-->

<?php include('footer.php'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>	
	$(document).ready(function(){
		loadItems(1,'','asc');
		ecart = {};
		ecart.package = {};
		ecart.package['packageId'] = 0;
		ecart.package['items'] = [];
		ecart.items = [];
		// packageItemsList = []; 
		itemcount = 0;
		ispackageselected = false;
		
		$('#domain').on('focusout',function(){
			var flow = $('#flow1');

			if(!checkDomain($(this).val())){
				flow.removeClass('active');
			} else {
				flow.addClass('active');
			}
		});		
		
		$('#btn-signup').on('click',function(e){
			var url = '/signup';
			var domain = $('#domain').val();
			var error = 0;
			var flow = $('#flow1');
			
			if(!checkDomain(domain)){
				flow.removeClass('active');
				error++;
			} else {
				flow.addClass('active');
				
				if(ecart.package.packageId == 0 && (ecart.items.length == 'undefined' || ecart.items.length == 0)){
					showErrorMessage('Please select a package or eServices item/s.');
					error++;
				}	
			}
			
			// if(!domain){
				// showErrorMessage('Please provide a domain name.');
				// error++;
			// } else if(domain){
				// if(!isValidDomain(domain)){
					// showErrorMessage('Please provide a valid domain name.');
					// error++;
				// } else {
					// $('#flow1').addClass('active');
				// }
			// }
			
			// if(ecart.package.packageId == 0 && (ecart.items.length == 'undefined' || ecart.items.length == 0)){
				// showErrorMessage('Please select a package or eServices item/s.');
				// error++;
			// }		
			
			if(error < 1){
				ecart.domain = domain;
				$('#ecart').val(JSON.stringify(ecart));
				$('#order').submit();				
			}

			e.preventDefault();
		});
		
		$('#domain').on('keyup',function(e){
			key = e.keyCode || e.which;
			
			if(key == 13 || key == '13'){
				$('#btn-signup').trigger('click');
			}
		});
		
		$('.package-to-order').on('click',function(){
			var dis = $(this);
			var packageId = dis.data('package-id');
			var packagebox = dis.siblings('.packagebox');

			packagebox.prop('checked',!packagebox.prop('checked'));

			if(ecart.package.packageId == 'undefined' || ecart.package.packageId == 0){
				savePackage(packageId,dis.attr('id'));
				itemcount++;
			} else if(ecart.package.packageId != 0){
				if(ecart.package.packageId == packageId){
					clearPackage();
					itemcount--;
				} else {
					$('.itembox').prop('checked',false);
					savePackage(packageId,dis.attr('id'));
				}
			}
			
			if(ecart.package.items.length > 0 && ecart.items.length > 0){
				console.log('im in');
				for(item in ecart.package.items){
					if(ecart.items.indexOf(ecart.package.items[item]) > -1){
						index = ecart.items.indexOf(ecart.package.items[item]);
						ecart.items.splice(index, 1);
					}
				}
				itemcount = ecart.items.length + 1;
			}
			
			$('.item-count').html(itemcount);
			
			if(ecart.package.items.length > 0 || ecart.items.length > 0){
				$('#flow2').addClass('active');
			} else {
				$('#flow2').removeClass('active');
			}
			
		});
		
		$('#btn-search').on('click',function(e){
			var searchkey = $('#inpt-search').val();
			
			loadItems(1,searchkey,'asc');
			e.preventDefault();
		});
		
		$('#inpt-search').on('keyup',function(e){
			var key = e.which || e.keyCode;
			if(key == 13){
				$('#btn-search').trigger('click');
			}
			e.preventDefault();
		});
	});
	
	function checkDomain(domain){			
		if(!domain){
			showErrorMessage('Please provide a domain name.');
			return false;
		} else if(domain){
			if(!isValidDomain(domain)){
				showErrorMessage('Please provide a valid domain name.');
				return false;
			} else {
				var tmp = null;
				$.ajax({
					async: false,
					url: 'http://contrib.applications.com/eservicesapi/checkdomain',
					type: 'POST',
					data: { domain_name: domain },
					success: function(response){
						if(response.success){
							if(response.data.exists){
								showErrorMessage('Domain already exists.');
								tmp = false;
							} else {
								tmp = true;
							}
						}
					}
				});
				return tmp;
			}
		}
	}
	
	function isValidDomain(domain){
		var regex = new RegExp(/^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,6})$/); 
    return domain.match(regex);
	}
	
	function showErrorMessage(msg){
		$('.d-alert').removeClass('hide');
		$('.d-alert').html(msg);
		setTimeout(function(){
			 $('.d-alert').addClass('hide');
		 }, 3000);
	}
	
	function loadItems(page,searchkey,sortby){
		var itemcontainer = $('#eservices-item-container');
		var html = '';
		
		itemcontainer.html('<div class="text-center img-loader"><img src="/img/loading-2.gif" alt="Loading . . ." title="Loading . . ." /></div>');
		
		$.ajax(
		{
			url: "http://contrib.applications.com/eservicesapi/loadItems?page="+page+"&search_key="+searchkey+"&sortby="+sortby,
			type: 'POST',	
			success: function(response){
				if(response.success){
					var image = '';
					var data = [];
					var eservices_items = response.data['data']['items'];
					data['search_key'] = searchkey;
					data['sortby'] = sortby;
					data['adjacents'] = response.data['data']['adjacents'];
					data['cnt'] = response.data['data']['cnt'];
					data['end'] = response.data['data']['end'];
					data['lastpage'] = response.data['data']['lastpage'];
					data['limit'] = response.data['data']['limit'];
					data['lpm1'] = response.data['data']['lpm1'];
					data['next'] = response.data['data']['next'];
					data['page'] = response.data['data']['page'];
					data['prev'] = response.data['data']['prev'];
					data['start'] = response.data['data']['start'];
					data['total_count'] = response.data['data']['total_count'];									
					
					for(var item in eservices_items){
						// var getitemdetails = "getitemdetails('#box-ec"+eservices_items[item].item_id+"');";
						var getItemId = "getItemId("+eservices_items[item].item_id+");";
						
						if(eservices_items[item].image){
							image = eservices_items[item].image;
						} else {
							image = 'http://beta.eservices.com/img/camera.png';
						}
						
						html += '<div class="panel panel-default s-a-links">';
						html += '<input class="itembox" id="box-ec'+eservices_items[item].item_id+'" data-id="'+eservices_items[item].item_id+'" data-author="'+eservices_items[item].firstname+' '+eservices_items[item].lastname+'" type="checkbox" title="Save" name="items[]"/>';						
						html += '<label for="" class="offer-box item-to-order" onclick="javascript:'+getItemId+'">';
						html += '<div class="panel-body">';
						html += '<h5 class="oc-credit pull-left">By: <b>'+eservices_items[item].firstname+' '+eservices_items[item].lastname+'</b></h5>';
						html += '<h5 class="oc-credit pull-right"><span class="label label-warning">Add To Cart</h5>';
						html += '<img class="img-responsive" src="'+image+'" alt="'+eservices_items[item].title+'" title="'+eservices_items[item].title+'">';
						html += '<h3 class="oc-title">'+eservices_items[item].title+'</h3>';
						html += '<h5 class="oc-desc">'+eservices_items[item].description+'</h5>';
						html += '<div class="clearfix"></div>';
						html += '<h5 class="oc-credit pull-left"><b>Publish to: '+eservices_items[item].publish+'</b></h5>';
						html += '<h5 class="oc-credit pull-right"><b class="c-price">$'+eservices_items[item].price+'</b></h5>';
						html += '<div class="clearfix"></div>';
						html += '<h5 class="label label-primary"><b>'+eservices_items[item].category_name+'</b></h5>';
						html += '</div>';
						html += '</label>';
						html += '</div>';						
					}
					itemcontainer.html(html);
					ecart.package.items.forEach(selectItems);
					ecart.items.forEach(selectItems);
					loadpagination(data);
				}
			}
		});
	}
	
	function savePackage(packageId,dis){
		var dis = $('#'+dis);
		ecart.package = {};
		ecart.package['items'] = [];		
		
		ecart.package['packageId'] = packageId;
	
		dis.find('.p-items').each(function(){
			ecart.package.items.push($(this).data('id'));
		});
		
		$('.packagebox').prop('checked',false);
		dis.siblings('.packagebox').prop('checked',true);	
		
		ecart.package.items.forEach(selectItems);
	}
	
	function clearPackage(){
		ecart.package.items.forEach(deselectItems);
		
		ecart.package = {};
		ecart.package['packageId'] = 0;
		ecart.package['items'] = [];
		
		$('.packagebox').prop('checked',false);			
	}
	
	function getItemId(itemid){
		var itembox = '#box-ec'+itemid;	

		if(ecart.package.items.length == 'undefined' || ecart.package.items.length == 0){
			saveItemId(itembox,itemid);
		} else {
			if(ecart.package.items.indexOf(itemid) < 0){
				saveItemId(itembox,itemid);			
			}
		}
		
		if(ecart.package.items.length > 0 || ecart.items.length > 0){
			$('#flow2').addClass('active');
		} else {
			$('#flow2').removeClass('active');
		}
	}
	
	function saveItemId(itembox, itemid){
		$(itembox).prop('checked',!$(itembox).prop('checked'));
		
		var itemSelected = $(itembox).prop('checked');
		
		if(itemSelected){
			ecart.items.push(itemid);
			itemcount++;
		} else {
			index = ecart.items.indexOf(itemid);
			ecart.items.splice(index, 1);
			itemcount--;
		}
		
		$('.item-count').html(itemcount);
	}
	
	function loadpagination(data){	
		var pagination = '<ul class="pagination">';		
		var floadItems = '';		
		
		if(data.lastpage > 1){
			//previous button
			if(data.page > 1){
				floadItems = "loadItems("+data.prev+",'"+data.search_key+"','"+data.sortby+"');";
				pagination += '<li><a href="javascript:'+floadItems+'" aria-label="Previous"><span aria-hidden="true">«</span></a></li>';
			} else {
				pagination += '<li class="disabled"><a href="javascript:void(0);" aria-label="Previous"><span aria-hidden="true">«</span></a></li>';
			}
			
			//pages
			if(data.lastpage < 7 + (data.adjacents * 2)){
				for(var counter=1;counter<=data.lastpage;counter++){
					if(counter == data.page){
						pagination += '<li class="active"><a href="javascript:void(0);">'+counter+' <span class="sr-only">(current)</span></a></li>';
					} else {
						floadItems = "loadItems("+counter+",'"+data.search_key+"','"+data.sortby+"');";
						pagination += '<li><a href="javascript:'+floadItems+'" class="btn-pagination">'+counter+'</a></li>';
					}
				}
			} else if(data.lastpage > 5 + (data.adjacents * 2)){
				if(data.page < 1 ($adjacents * 2)){
					for(var counter=1;counter<4 + (data.adjacents * 2); counter++){
						if(counter == data.page){
							pagination += '<li class="active"><a href=\javascript:void(0);">'+counter+' <span class="sr-only">(current)</span></a></li>';
						} else {
							floadItems = "loadItems("+counter+",'"+data.search_key+"','"+data.sortby+"');";
							pagination += '<li><a href="javascript:'+floadItems+'">'+counter+'</a></li>';
						}
						pagination += '<li><a href="javascript:void(0);">...</a></li>';
						floadItems = "loadItems("+data.lpm1+",'"+data.search_key+"','"+data.sortby+"');";
						pagination += '<li><a href="javascript:'+floadItems+'">'+data.lpm1+'</a></li>';
						floadItems = "loadItems("+data.lastpage+",'"+data.search_key+"','"+data.sortby+"');";
						pagination += '<li><a href="javascript:'+floadItems+'">'+data.lastpage+'</a></li>';
					}
				} else if(data.lastpage - (data.adjacents * 2) > data.page && data.page > (data.adjacents * 2)){
					floadItems = "loadItems(1,'"+data.search_key+"','"+data.sortby+"');";
					pagination += '<li><a href="javascript:'+floadItems+'">1</a></li>';
					floadItems = "loadItems(2,'"+data.search_key+"','"+data.sortby+"');";
					pagination += '<li><a href="javascript:'+floadItems+'">2</a></li>';
					pagination += '<li><a href="javascript:void(0)\">...</a></li>';
					
					for(var counter=data.page - data.adjacents; counter <= data.page + data.adjacents; counter++){
						if(counter == data.page){
							pagination += '<li class="active"><a href="javascript:void(0);">'+counter+' <span class="sr-only">(current)</span></a></li>';
						} else {
							floadItems = "loadItems("+counter+",'"+data.search_key+"','"+data.sortby+"');";
							pagination += '<li><a href="javascript:'+floadItems+'">'+counter+'</a></li>';
						}
					}
					
					pagination += '<li><a href="javascript:void(0);">...</a></li>';
					floadItems = "loadItems("+data.lpm1+",'"+data.search_key+"','"+data.sortby+"');";
					pagination += '<li><a href="javascript:'+floadItems+'">'+data.lpm1+'</a></li>';
					floadItems = "loadItems("+data.lastpage+",'"+data.search_key+"','"+data.sortby+"');";
					pagination += '<li><a href="javascript:'+floadItems+'">'+data.lastpage+'</a></li>';
				} else {
					floadItems = "loadItems(1,'"+data.search_key+"','"+data.sortby+"');";
					pagination += '<li><a href="javascript:'+floadItems+'">1</a></li>';
					floadItems = "loadItems(2,'"+data.search_key+"','"+data.sortby+"');";
					pagination += '<li><a href="javascript:'+floadItems+'">2</a></li>';
					pagination += '<li><a href="javascript:void(0);">...</a></li>';
					
					for(var counter=data.lastpage - (2 + (data.adjacents * 2)); counter <= data.lastpage; counter++){
						if(counter == data.page){
							pagination += '<li class="active"><a href="javascript:void(0);">'+counter+' <span class="sr-only">(current)</span></a></li>';
						} else {
							floadItems = "loadItems("+counter+",'"+data.search_key+"','"+data.sortby+"');";
							pagination += '<li><a href="javascript:'+floadItems+'">'+counter+'</a></li>';
						}
					}
				}
			}
			
			//next button
			if(data.page < counter - 1){
				floadItems = "loadItems("+data.next+",'"+data.search_key+"','"+data.sortby+"');";
				pagination += '<li><a href="javascript:'+floadItems+'">»</a></li>';
			} else {
				pagination += '<li><a aria-label="Next" href="javascript:void(0);"><span aria-hidden="true">»</span></a></li>';
			}
			
		} //end if
		
		pagination += '</ul>';
		
		$('#pagination').html(pagination);
	}
	
	function selectItems(itemid){
		var itembox = '#box-ec'+itemid;
		$(itembox).prop('checked',true);
	}
	
	function deselectItems(itemid){
		var itembox = '#box-ec'+itemid;
		$(itembox).prop('checked',false);
	}
</script>
</body>
</html>