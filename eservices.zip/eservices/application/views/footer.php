<?php global $footer_html?>
<style>
.fnt-bold {
	color:#fff !important;
}
.footer-dark-1 {
    color: #fff;
    padding: 20px 0 15px;
    background-color: #333;
}
.footer-dark-1 h3 {
	font-size:19px;
}
.footer-dark-1 a {
	color:#ccc;
}
.footer-dark-2 {
    color: #fff;
    padding: 15px 0 10px;
    background-color: #222;
	font-size:12px;
}
.footer-dark-2 a {
	color:#ccc;
	font-size:12px;
}
.socials-ul .fa {
	font-size:35px;
}
.animated {
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
}
@-webkit-keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}

@keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        -ms-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        -ms-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}
.rotateIn {
    -webkit-animation-name: rotateIn;
    animation-name: rotateIn;
}
.r-d{
    -webkit-animation-delay: 2.5s;
    -moz-animation-delay: 2.5s;
    -ms-animation-delay: 2.5s;
    -o-animation-delay: 2.5s;
    animation-delay: 2.5s;
}
.r-d.rotateIn{
    position: absolute; 
    z-index: 10; 
    top: -20px; 
    left: 190px;
}
.arrw-rela {
    position: relative;
}
.socials-ul img {
	height: 40px;
}
.socials-ul img:hover {
	opacity:.8;
}
.socials-ul > li {
    padding-right: 2px;
    padding-left: 2px;
}
</style>
<div class="footer-dark-1">
	<div style="position:relative;">
			<div class="animated rotateIn r-d">
				<a target="_blank" href="http://referrals.contrib.com/idevaffiliate.php?id=71952&url=http://www.contrib.com/signup/firststep?domain=veteransrehab.com">
					<img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-8.png" alt="Contrib" title="Contrib">
				</a>
			</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							<?php echo $info['domain']; ?>
						</h3>
						<p>
							<?=$info['description']?>
						</p>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							get started
						</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a href="/partner" class="text-capitalize">
									Partner with us
								</a>
							</li>
							<li>
								<a href="/staffing" class="text-capitalize">
									Apply now
								</a>
							</li>
							<li>
								<a href="/referral" class="text-capitalize">
									referral
								</a>
							</li>							
							<li>
								<a href="/developers" class="text-capitalize">
									developers
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							company
						</h3>
						<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
							<li>
								<a href="/about" class="text-capitalize">
									About us
								</a>
							</li>
							<li>
								<a href="/terms" class="text-capitalize">
									Terms
								</a>
							</li>
							<li>
								<a href="/privacy" class="text-capitalize">
									Privacy
								</a>
							</li>
							<li>
								<a href="/cookiepolicy" class="text-capitalize">
									Cookie Policy
								</a>
							</li>
							<li>
								<a href="/contact" class="text-capitalize">
									Contact us
								</a>
							</li>
							<li>
								<a href="http://www.domaindirectory.com/policypage/unsubscribe?domain=<?=$info['domain']?>" class="text-capitalize" target="_blank">
									Unsubscribe
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							partners
						</h3>
						<p>
							 <?if($footer_html != ""):?>
					<?echo base64_decode($footer_html)?>
					<?php else:?>
					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
				<?endif;?>							
						</p>
						<h3 class="fnt-bold text-uppercase">
							Socials
						</h3>
						<ul class="list-inline socials-ul">							
							<li>
								<a title="facebook" class="icon-button facebook" href="<?=$info['socials']['fb']?>" target="_blank">
									<i class="fa fa-facebook-square"></i>
								</a>
							</li>
							<li>
								<a title="google-plus" class="icon-button google-plus" href="<?=$info['socials']['gplus']?>" target="_blank">
									<i class="fa fa-google-plus-square"></i>
								</a>

							</li>
							<li>
								<a title="twitter" class="icon-button twitter" href="<?=$info['socials']['twitter']?>" target="_blank">
									<i class="fa fa-twitter-square"></i>
								</a>
							</li>
						</ul>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer-dark-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6 f-a-links">
						© <?=date("Y")?> <a href="/" class="text-capitalize "><?php echo $info['domain']; ?></a>. All Rights Reserved. 
					</div>
					<div class="col-md-6">
						<ul class="list-inline text-right f-a-links">
							<li>
								<a href="/about" class="text-capitalize">
									<i class="fa fa-bookmark-o"></i>
									About us
								</a>
							</li>
							<li>
								<a href="/terms" class="text-capitalize">
									<i class="fa fa-book"></i>
									Terms
								</a>
							</li>
							<li>
								<a href="/privacy" class="text-capitalize">
									<i class="fa fa-cube"></i>
									privacy
								</a>
							</li>
							<li>
								<a href="/contact" class="text-capitalize">
									<i class="fa fa-phone-square"></i>
									contact us
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>