<?php include 'header.php'; ?>
<style type="text/css">
.loader:before,
.loader:after,
.loader {
  border-radius: 50%;
  width: 2.5em;
  height: 2.5em;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
  -webkit-animation: load7 1.8s infinite ease-in-out;
  animation: load7 1.8s infinite ease-in-out;
}
.loader {
  color: #286090;
  font-size: 6px;
  margin: 43px auto ;
  position: relative;
  text-indent: -9999em;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
  -webkit-animation-delay: -0.16s;
  animation-delay: -0.16s;
}
.loader:before {
  left: -3.5em;
  -webkit-animation-delay: -0.32s;
  animation-delay: -0.32s;
}
.loader:after {
  left: 3.5em;
}
.loader:before,
.loader:after {
  content: '';
  position: absolute;
  top: 0;
}
@-webkit-keyframes load7 {
  0%,
  80%,
  100% {
    box-shadow: 0 2.5em 0 -1.3em;
  }
  40% {
    box-shadow: 0 2.5em 0 0;
  }
}
@keyframes load7 {
  0%,
  80%,
  100% {
    box-shadow: 0 2.5em 0 -1.3em;
  }
  40% {
    box-shadow: 0 2.5em 0 0;
  }
}
.flow-container {
	margin-top:120px;
}
.signup-container {
	margin-top:80px;
}
.cart-header {
	color:#fff;
}
.signup-cart {
	margin-top: -120px;
}
</style>
<div class="flow-container">
		<div class="container text-center">
			<div class="row">				
				<div class="col-md-3">
					<a href="/"><img class="active img-responsive" src="/img/plus.png" alt="Email" title="Email" id="flow1"></a>
				</div>
				<div class="col-md-3">
					<a href="/"><img class="active img-responsive" src="/img/edit.png" alt="Package" title="Package" id="flow2"></a>
				</div>
				<div class="col-md-3">
					<a href="javascript:void(0)"><img class="img-responsive" src="/img/cart.png" alt="Cart" title="Cart" id="flow3"></a>
				</div>
				<div class="col-md-3">
					<a href="javascript:void(0)"><img class="img-responsive" src="/img/check.png" alt="Complete" title="Complete" id="flow4"></a>
				</div>
				<div class="col-md-12">
					<div class="flow-line"></div>
				</div>
			</div>
		</div>
	</div>
<div class="signup-container">
	<div class="container">
		<div class="row centered-form">
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
						<div class="panel-heading">
							<h2 class="panel-title text-center"><i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Please sign up for eServices</h2>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="form-group">
										<input type="text" value="" name="domain" id="domain" class="form-control" placeholder="Domain" disabled="">
									</div>
								</div>
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="form-group">
										<input type="text" name="email" id="email" class="form-control" placeholder="Email">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="form-group">
										<input type="password" name="password" id="password" class="form-control" placeholder="Password">
									</div>
								</div>
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="form-group">
										<select name="category" class="form-control form-control">
										  <?php if (!empty($category)): ?>
										  		<?php foreach ($category as $category): ?>
										  			  <option id="category" value="<?php echo $category['category_id']; ?>" ><?php echo $category['category_name']; ?></option>
										  		<?php endforeach ?>
										  <?php endif ?>
										</select>
									</div>
								</div>
							</div>			
							<input type="hidden" id="user_ip" value="<?php $ip = $_SERVER['REMOTE_ADDR']; echo $ip; ?>">
							<input type="hidden" id="domain_name1" value="<?php echo $info['domain']; ?>">
							<?php if (!empty($item_array)): ?>
									<?php foreach ($item_array as $item_array): ?>
										<input type="hidden" name="item[]" value="<?php echo $item_array?>">
									<?php endforeach ?>
							<?php else: ?>
									<?php $item_array = 0;  ?>
							<?php endif ?>
							<!-- for packages -->
							<?php if (!empty($package)): ?>
									<?php $packages = $package; ?>
							<?php else: ?>
									<?php $packages = '0'; ?>
							<?php endif ?>

							<input type="hidden" id="items" value="<?php echo $object ?>">
							<input type="hidden" id="packages" value="<?php echo $package;  ?>">
							<input type="hidden" id="domain_name" value="<?php echo $domain ?>">
							<div class="form-group">
								<textarea class="form-control" rows="4" id="description" placeholder="Description" style="height: 100px;"></textarea>
							</div>
							<div class="form-group">
								<div class="loader hide">Loading...</div>
							</div>
							<div class="alert alert-success hide" role="alert">
							 	 <a href="#" class="alert-link">Hello from the other side</a>
							</div>
							<div class="alert alert-danger hide" role="alert">
								  <a href="#" class="alert-link">Hello from the other side</a>
							</div>
							<input type="submit" id="submit_form" value="Sign Up" class="btn btn-primary btn-block">
							<input type="hidden" value="" id="response_domain" name="response_domain">
							<input type="hidden" value="" id="response_email" name="response_email">

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="signup-cart hide">
	<div class="cart_list" id="cart_list">
		<div class="table-container">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2 class="cart-header"><i class="fa fa-cart-plus" aria-hidden="true"></i>&nbsp;eServices Add Cart </h2>
						<form id="form-items" method="POST" action="">
							<table class="table table-striped custab table-bordered cart-table">
								<thead>
								<a href="#" id="removeselected" class="btn btn-danger pull-right" style="margin-bottom: 10px;">
									<i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;Remove Selected
								</a>
									<tr>
										<th class="chkall"><input class="hide" type="checkbox"></th>
										<th>eServices Item</th>
										<th>Price</th>
										<th>Fee</th>
										<th>Sub Total</th>
										<th>Instructions</th>
									</tr>
								</thead>
										<tfoot>
											<th class="total-domains" colspan="4">1 Domain</th>
											<th data-total="" class="total">$54.00</th>
											<th class="totals" data-total="">Total:$512.00</th>
										</tfoot>
							</table>
						</form>
							<table>					
								<a href="#" id="order" class="btn btn-primary pull-right" style="margin-bottom: 10px;">
								<i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;Proceed To Order
								</a>
								<a id="back" href="#" class="btn btn-default pull-right" style="margin-bottom: 10px;margin-right: 5px;">
								<i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp;Back
								</a>
						 </table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<form action="/success" method="POST" id="order-summary">
	<input type="hidden" name="eservice" value=""/>
</form>

<?php include('footer.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/js/jquery.session.js"></script>
<script type="text/javascript" src="/static/js/loadingoverlay.js"></script>

<script type="text/javascript">

jQuery(document).ready(function(){
		var final_domain = 'http://www.<?php echo $domain; ?>/';
		var domain = '<?php echo ucfirst($domain); ?>';
		jQuery('#domain').val(domain);	
		GetDesc(final_domain);
		getpackagesdetails();
		getitemsdetails();
	});

	jQuery('#submit_form').click(function(){
			Validate();
	});

	jQuery('#back').click(function(){
		$('.signup-cart').addClass('hide');
		$('.signup-container').removeClass('hide');
	});

	jQuery('#order').click(function(){						
		ActionSave();
	});

	jQuery('#removeselected').off('click').on('click',function(){
		var checked = jQuery('.chk:checked');
		if(checked.length==0) return false;

		if(checked.length>0){
			if(confirm('Continue removing the item'+(checked.length>1?'s?':'?'))){
				checked.parents('tr').remove();
				jQuery('.chkall').prop('checked',false);
			}
		}
		ComputeTotal();
		if(jQuery('.cart-table tbody tr').length==0){
			window.location.href = '/';
		}
	});

	function Validate(){	

		var counter = 1;
		var domain = $('#domain').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var description = $('#description').val();
	    var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	    var category_id =  $('#category').val();
	    var category_name = $('#category option:selected').text();

		if (domain == '') {
			ErrorMessage('Please fill the domain.');
			return false;
		}else if(!IsValidDomain(domain)){
			ErrorMessage('Please provide a valid domain.');
			return false;
		}else if(email == ''){
			ErrorMessage('Please fill the email address.');
			return false;
		}else if(password == ''){
			ErrorMessage('Please fill the password.');
			return false;
		}else if(password.length < 6){
			ErrorMessage('Please provide a password atleast 6.');
			return false;
		}else if(description ==''){
			ErrorMessage('Please fill a description.');
			return false;
		}else if(!emailfilter.test(email)){
			ErrorMessage('Please fill a valid email address.');
			return false;
		}else{
			$.ajax({
				url: 'http://contrib.us/eservicesapi/checkemail',
				type: 'POST',
				data: { email:email },
				success: function(response){
					if(response.success){
						if(!response.data.exists){
							ComputeTotal();
							$('.loader').removeClass('hide');
							setTimeout(function(){
										$('.loader').addClass('hide');
										$('.signup-cart').removeClass('hide');
										$('.signup-container').addClass('hide');
										$('#flow3').addClass('active');
							 }, 2000);							
							return true;
						} else {
							ErrorMessage('Email address already exists.');
							return false;
						}
					} 
				}
			});
			
		}
	}

	function validateURL(url){
			return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
	}

	function IsValidDomain(domain) { 
   		 var re = new RegExp(/^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,6})$/); 
   		 return domain.match(re);
	}

	function ErrorMessage(param){
		jQuery('.alert-danger').removeClass('hide');
		jQuery('.alert-danger').html(param);
		setTimeout(function(){
				 $('.alert-danger').addClass('hide');
		 }, 4000);
	}

	function GetDesc(domain){
		jQuery.post('http://contrib.us/eservicesapi/getcontent',
		{
			url:domain
		},
		function(data){
			if (data.success) {
				jQuery('#description').val(data.data.description);
			};
		})
	}

	function ActionSave(){

		$.LoadingOverlay("show");
		var domain = jQuery('#domain').val();
		var url = 'http://www.'+domain+' ';
		var email = jQuery('#email').val();
		var password = jQuery('#password').val();
		var description = jQuery('#description').val();
		var category = jQuery('select[name=category]').val();
		var domain_name = jQuery('#domain_name1').val();
		var user_ip = jQuery('#user_ip').val();
		
		var formdata = {
			domain:domain,
			email:email,
			password:password,
			description:description,
			category:category
		}

		$.post('http://contrib.us/eservicesapi/register',{

				url:url,
				description:description,
				email:email,
				password:password,	
				category_id:category,
				domain_name:domain_name,
				user_ip:user_ip

			},function(data){

				if(data.success){	
					var u = btoa(data.data.email);
					console.log(data);
					jQuery.post('http://contrib.us/eservice/order/processorder',jQuery('#form-items').serialize()+'&domain_ids='+data.data.domain.domain_id+'&u='+u,
						function(response){
							$.LoadingOverlay("hide");
							var data = {};
									data.domain = $('#domain').val();
									data.item_count = $('.cart-table').find('tbody tr').length;
									data.total_price = $('.total').data('total');
									data.url = 'http://contrib.us/eservice/update/'+response.order_id+'/?u='+encodeURIComponent(u);
							var successform = $('#order-summary');
							
							successform.find('input').val(JSON.stringify(data));
							successform.submit();
						});
				} else {
					$('.loader').addClass('hide');
					ErrorMessage(data.data.error_message);
				}	
		});	

	}	

	function reduce(item_array){
		return item_array.reduce();
	}
	// if there is items
	function getpackagesdetails(){

		var item = '<?php echo $item_array ?>';
		
		if (item == '0') {
			console.log('do nothing');
		}else{
			var tr = '';
			var itms_id ;
			itms_id = $("input[name='item[]']").map(function(){
			return this.value;
			}).get();
			console.log(itms_id);
			var chooose_items = itms_id.toString();

			jQuery.post('http://contrib.us/eservicesapi/loaditems',
			{
				
				item_ids:chooose_items

			},function(response){
				var response_item = response.data['data'];
				console.log(response_item)
				var count = 0;

				for (var i in response_item) {
							var price = parseFloat(Math.round(response_item[i].price * 100) / 100).toFixed(2);
							var fee = parseFloat(Math.round(response_item[i].service_fee * 100) / 100).toFixed(2);
							var subtotal = parseFloat(price) + parseFloat(fee);
							var id = response_item[i].item_id;
							var ins = response_item[i].instruction;
							var desc = response_item[i].description;
							var fill = (ins == null || ins == '' ? fill = desc : fill = ins );
							tr += '<tr>';
							tr += '<td><input class="chk" type="checkbox" id="check_'+response_item[i].item_id+'"><input name="itemid[]" type="hidden" value="'+id+'"></td>';		
							tr += '<td>'+response_item[i].title+'</td>';		
							tr += '<td>$'+price+'</td>';		
							tr += '<td>$'+fee+'</td>';		
							tr += '<td data-subtotal="'+subtotal+'" class="sub_total">$'+subtotal+'</td>';									
							tr += '<td class="text-center" id="'+response_item[i].item_id+'"><textarea name="instruction[]" class="form-control" rows="5">'+fill+'</textarea></td>';	
							tr += '</tr>';	
				};
				jQuery('.cart-table').append(tr);
			});
		}
	}
	//if there is packageid
	function getitemsdetails(){

		var package_idsi = <?php echo $packages; ?>	
		if (package_idsi == '0') {
			console.log('do nothing with');
		}else{
	
			jQuery.post('http://contrib.us/eservicesapi/loadpackages',
			{
				package_ids:package_idsi

			},function(response){
				var response_package = response.data['data'];
				var tr = '';
				for (var i in response_package) {
							var price = parseFloat(Math.round(response_package[i].price * 100) / 100).toFixed(2);
							var fee = parseFloat(Math.round(response_package[i].service_fee * 100) / 100).toFixed(2);
							var subtotal = parseFloat(price) + parseFloat(fee);
							var id = response_package[i].package_id;
							tr += '<tr>';
							tr += '<td><input data-package-id='+id+' class="chk" type="checkbox" id="check_'+response_package[i].package_id+'"><input name="packageid" type="hidden" value="'+id+'"></td>';		
							tr += '<td>'+response_package[i].package_name+'</td>';		
							tr += '<td class="center">$'+price+'</td>';		
							tr += '<td class="center">$'+fee+'</td>';		
							tr += '<td data-subtotal="'+subtotal+'" class="sub_total">$'+subtotal+'</td>';									
							tr += '<td class="text-center" id="'+response_package[i].package_id+'"><textarea name="package_instruction" class="form-control" rows="5"></textarea></td>';	
							tr += '</tr>';			
				};
				jQuery('.cart-table').append(tr);
			});
		}

	}

	function ComputeTotal(){

			var total = 0;
			var domain = '<?php echo ucfirst($domain); ?>';
			jQuery('.sub_total').each(function(){
				total = total+parseFloat(jQuery(this).attr('data-subtotal'));
			});
			total = parseFloat(Math.round(total * 100) / 100).toFixed(2);
			jQuery('.total').html('$'+total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
			jQuery('.total').attr('data-total',total);
			jQuery('.cc-number').html(jQuery('.cart-table tbody tr').length);
			jQuery('.custom-btn-red').html(jQuery('.cart-table tbody tr').length+' <i class="fa fa-cart-arrow-down"></i>');
			
			if(jQuery('.cart-table tbody tr').length<1){
				console.log('hello wala sulod');		
			}else{
				console.log('hello naa sya');
			}
			
			var countdomains = 1;
			var totals = total * countdomains;
			totals = parseFloat(Math.round(totals * 100) / 100).toFixed(2);
			
			jQuery('.total-domains').html(domain);
			jQuery('.totals').html('Total : $'+totals.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
			jQuery('.totals').attr('data-total',totals);
	}

</script>
</body>
</html>
