<?php

    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
	$header_text = "{{HEADER_TEXT}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $affiliate_id = "{{AFF_ID}}";
    $piwik_id = '{{PIWIK_ID}}';
    $related_domains = {{RELATED_DOMAINS}};
    $related_nologo = {{RELATED_NOLOGO}};
    $partners = {{PARTNERS}};
    $social_fb = '{{SOCIAL_FB}}';
    $social_gplus = '{{SOCIAL_GPLUS}}';
    $social_twitter = '{{SOCIAL_TWITTER}}';
    $social_linkedin = '{{SOCIAL_LINKEDIN}}';
    $social_gtube = '{{SOCIAL_GTUBE}}';
    $projecttypes = {{PROJECT_TYPES}};
    $states = {{STATES}};
    $topsites = {{TOPSITES}};
    $services_category = {{SERVICES_CATEGORY}};
?>