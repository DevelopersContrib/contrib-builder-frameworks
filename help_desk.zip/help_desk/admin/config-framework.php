<?php 
$domain="tempshop.com"; 
$db="site294w_shop"; 
$sitename="tempshop.com"; 
$cpanel_username="site294wyqjgnd"; 
$cpanel_password="FdVk2az!QYvWgB3030"; 
$title="Tempshop.com"; 
$account_ga="UA-127636844-10"; 
$piwik_id="2874"; 
$desc="Join our exclusive community of like minded people on tempshop.com"; 
$logo=""; 
$keywords="temp, shop"; 
$keyword=""; 
$footer_html=""; 
$social_fb="https://www.facebook.com/Contrib.Official"; 
$social_gplus="https://plus.google.com/u/1/105733839510740941811/posts"; 
$social_twitter="https://twitter.com/contrib"; 
$social_gtube="https://www.youtube.com/user/contribcom1"; 
$social_linkedin="http://www.linkedin.com/company/contrib-com"; 
$memberid="38"; 
$domainname="tempshop.com"; 
$domainid="1680"; 
$domain_affiliate_link="http://referrals.contrib.com/idevaffiliate.php?id=3491&url=http://www.contrib.com/signup/firststep?domain=tempshop.com"; 
$footer_banner=""; 
$related_domains=array (
  0 => 
  array (
    'domain_name' => 'capitalinvestments.com',
    'domain_id' => '2193',
    'logo' => 'https://cdn.vnoc.com/logos/logo-capitalinvestments.png',
    'title' => 'Welcome to capitalinvestments.com',
    'slug' => 'finance-commerce',
  ),
  1 => 
  array (
    'domain_name' => 'e-rates.com',
    'domain_id' => '3901',
    'logo' => 'https://cdn.vnoc.com/logos/logo-e-rates1.png',
    'title' => 'E-rates.com',
    'slug' => 'finance-commerce',
  ),
  2 => 
  array (
    'domain_name' => 'annuityresource.com',
    'domain_id' => '24530',
    'logo' => 'https://cdn.vnoc.com/logos/logo-AnnuityResource1.png',
    'title' => '',
    'slug' => 'finance-commerce',
  ),
  3 => 
  array (
    'domain_name' => 'restmanager.com',
    'domain_id' => '29087',
    'logo' => 'https://cdn.vnoc.com/logos/logo-RestManager-1.png',
    'title' => 'Restmanager.com',
    'slug' => 'finance-commerce',
  ),
  4 => 
  array (
    'domain_name' => 'mortgagechain.com',
    'domain_id' => '6496',
    'logo' => 'https://cdn.vnoc.com/logos/logo-MortgageChain-1.png',
    'title' => 'Welcome to mortgagechain.com',
    'slug' => 'finance-commerce',
  ),
  5 => 
  array (
    'domain_name' => 'energyinvestments.com',
    'domain_id' => '10940',
    'logo' => 'https://cdn.vnoc.com/logos/logo-EnergyInvestments1.png',
    'title' => 'Energyinvestments.com',
    'slug' => 'finance-commerce',
  ),
  6 => 
  array (
    'domain_name' => 'powercheckup.com',
    'domain_id' => '25654',
    'logo' => 'https://cdn.vnoc.com/logos/logo-PowerCheckUP1.png',
    'title' => 'Welcome to powercheckup.com',
    'slug' => 'finance-commerce',
  ),
  7 => 
  array (
    'domain_name' => 'mobileinvestments.com',
    'domain_id' => '4527',
    'logo' => 'https://cdn.vnoc.com/logos/logo-mobileinvestments1.png',
    'title' => 'Welcome to mobileinvestments.com',
    'slug' => 'finance-commerce',
  ),
  8 => 
  array (
    'domain_name' => 'reportmanager.com',
    'domain_id' => '29257',
    'logo' => 'https://cdn.vnoc.com/logos/logo-ReportManager-1.png',
    'title' => 'Reportmanager.com',
    'slug' => 'finance-commerce',
  ),
  9 => 
  array (
    'domain_name' => 'shoptangerine.com',
    'domain_id' => '16548',
    'logo' => 'https://cdn.vnoc.com/logos/logo-shoptangerine1.png',
    'title' => 'Welcome to shoptangerine.com',
    'slug' => 'finance-commerce',
  ),
);
define('DOMAIN_ID',1680);
define('LOGO','');
define('TITLE','Tempshop.com');
define('DOMAIN','tempshop.com');
?>