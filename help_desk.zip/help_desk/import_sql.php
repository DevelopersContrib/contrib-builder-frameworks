<?php 


function slugstring($string){
    $result = strtolower($string);
    $result = preg_replace("/[^A-Za-z0-9\s-._\/]/", "", $result);
    $result = trim(preg_replace("/[\s-]+/", " ", $result));
    $result = trim(substr($result, 0, 50));
    $result = preg_replace("/\s/", "-", $result);    
    return $result;
}

$bg_images = array(
	'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-shop-first.jpeg',
	'https://rdbuploads.s3.amazonaws.com/backgrounds/pexels-photo-291762.jpeg',
	'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-phones.jpeg',
	'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-starwars.jpeg',
	'https://rdbuploads.s3.amazonaws.com/backgrounds/still-life-teddy-white-read.jpg'
); 

$rand_keys = array_rand($bg_images, 3);

$conn = new PDO("mysql:host=".HOST.";dbname=".DB, DB_USERNAME, DB_PASSWORD);

$sql = "Delete from users where domain_id = '".DOMAIN_ID."'";
$q = $conn->prepare($sql);
$q->execute();

$sql = "insert into `users` (`user`, `pass`, `isadmin`, `name`, `email`, `signature`, `language`, `categories`, `afterreply`, 
	`autostart`, `autoreload`, `notify_customer_new`, `notify_customer_reply`, `show_suggested`, `notify_new_unassigned`, `notify_new_my`, 
	`notify_reply_unassigned`, `notify_reply_my`, `notify_assigned`, `notify_pm`, `notify_note`, `default_list`, `autoassign`, `heskprivileges`, 
	`ratingneg`, `ratingpos`, `rating`, `replies`, `domain_id`) values('admin@".$domain."','6154a5f6c35d49e36acc9978b39d73b890bbed30','1',
	'Admin','admin@".$domain."','',NULL,'','0','1','0','1','1','1','1','1','1','1','1','1','1','','1','','1','1','3','2','".DOMAIN_ID."');";
$q = $conn->prepare($sql);
$q->execute();

$url = "https://e7lq80c199.execute-api.us-west-2.amazonaws.com/api1?request=getTeamPerDomainId&key=".md5($domain)."&domain_id=".DOMAIN_ID."&domain=$domain&pass=1";
$headers = array('Accept: application/json');

$result = createApiCall($url, 'GET', $headers, array());
$results = json_decode($result,true);
if ($results['success']){
	function hesk_Pass2Hash1($plaintext) {
		$majorsalt  = '';
		$len = strlen($plaintext);
		for ($i=0;$i<$len;$i++)
		{
			$majorsalt .= sha1(substr($plaintext,$i,1));
		}
		$corehash = sha1($majorsalt);
		return $corehash;
	}
	
	foreach($results['data'] as $team){
		
		$firstname = $team['firstname'];
		$lastname = $team['lastname'];
		$email = $team['email'];
		$role_name = $team['role_name'];
		$password = $team['password'];
		$role_id = $team['role_id'];
		$sql = "insert into `users` (`user`, `pass`, `isadmin`, `name`, `email`, `signature`, `language`, 
			`categories`, `afterreply`, `autostart`, 
			`autoreload`, `notify_customer_new`, `notify_customer_reply`, `show_suggested`, `notify_new_unassigned`, 
			`notify_new_my`, `notify_reply_unassigned`, `notify_reply_my`, `notify_assigned`, `notify_pm`, 
			`notify_note`, `default_list`, `autoassign`, `heskprivileges`, `ratingneg`, `ratingpos`, `rating`, 
			`replies`, `domain_id`) values('".$email."','".hesk_Pass2Hash1($password)."','$role_id','$firstname $lastname','".$email."',
			'',NULL,'1','0','1','0','1','1','1','1','1','1','1','1','1','1','','1','can_submit_any_cat,can_view_tickets','1','1','3','2','".DOMAIN_ID."');";
		$q = $conn->prepare($sql);
		$q->execute();
	}
}

$bg_images = array(
    'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-shop-first.jpeg',
    'https://rdbuploads.s3.amazonaws.com/backgrounds/pexels-photo-291762.jpeg',
    'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-phones.jpeg',
    'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-starwars.jpeg',
    'https://rdbuploads.s3.amazonaws.com/backgrounds/still-life-teddy-white-read.jpg'
); 

// $rand_keys = array_rand($bg_images, 3);
// $sql = "Update modules set image_url=? where id=?";
// $q = $conn->prepare($sql);
// $q->execute(array($bg_images[$rand_keys[0]],$img_id1));

$conn = null;
?>