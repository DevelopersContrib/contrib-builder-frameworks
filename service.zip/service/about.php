<?php
include 'includes/config.php';
include 'header.php';
?>

  
	<div class="content"><!-- content -->
		<input type="hidden" name="domain_name" id="domain_name" value="<?php echo $domain ?>"/>
		<div class="contentWrapper"><h2>Building Great Assets since 1996</h2></div>		
		<div class="container"> 	  
		  <div class="row">
		  <div class="tape"></div>
			<div class="content-wrapper">
				<div class="col-7 col-sm-7 col-lg-7">					
					<div class="introduction">
					   
						<h2>About <?php echo $domain?></h2>
						
						    <?php if ($about !=""):?>
						
						    <p> <?php echo stripcslashes($about)?></p>
						    
						    <?php else:?>
						    <p><?=$title?> is a venture of eCorp.com Inc.</p>
						
						    <p><?=$description?></p>

                           <p>Ecorp is the worlds largest virtual domain development incubator on the planet.  Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms. We build and manage world class web-based, domain centric operating businesses for clients and internal ventures.  </p> 
						    
						<?php endif?>
						
					</div>
				</div>
				<div class="col-5 col-sm-5 col-lg-5">					
					<div class="form-con">
						<div class="form-box" style="width:100%;"> 
								<div id="form_option">
									<h1>Contact Us Today!</h2>
									<div class="form-content" style="width:83%;background: #F0F0F0;">
												<h3>I&#39;m interested in : </h3>
												<div style="font-size: 16px;line-height: 35px;min-height:190px">
													<table>
														<tr>
															<td width="30px"><input type="radio" name="service" value="partner"></td>
															<td>Partner / Develop with <?php echo $domain?></td>
														</tr>
														
														<tr>
															<td><input type="radio" name="service" value="staffing"></td>
															<td>Staffing Opportunities with <?php echo $domain?></td>
														</tr>
														
														<tr>
															<td><input type="radio" name="service" value="offer"></td>
															<td>Submitting an Offer for <?php echo $domain?></td>
														</tr>
														<tr>
															<td><input type="radio" name="service" value="inquire"></td>
															<td>Inquire / Sponsor with <?php echo $domain?></td>
														</tr>
													</table>
												</div>
											</div><!--form-content-->
										</div>	
											<div id="form_partner" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/signup/partnership/<?php echo $domain?>" scrolling="no" frameborder="0" style="width: 355px;height: 460px;"></iframe>
											</div>
											<div id="form_advertise" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												form_advertise
											</div>
											<div id="form_staffing" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/signup/staffing/<?php echo $domain?>" scrolling="no" frameborder="0" style="width: 355px;height: 460px;"></iframe>
											</div>
											<div id="form_develop" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/signup/staffing/<?php echo $domain?>" scrolling="no" frameborder="0" style="width: 355px;height: 460px;"></iframe>
											</div>
											<div id="form_offer" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://domaindirectory.com/servicepage/offer_form_content.php?domain=<?php echo $domain?>" scrolling="no" frameborder="0" style="width:350px;height:500px;"></iframe>
											</div>
											<div id="form_inquire" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://domaindirectory.com/servicepage/inquiry_form.php?domain=<?php echo $domain?>" scrolling="no" frameborder="0" style="width:350px;height:460px;"></iframe>
											</div>
											
										
									</div><!--form-box -->
	</div><!-- form-con-->
				</div>
					<div style="clear:both"></div>
			</div>
		  </div>
		</div> 
	</div><!-- end content -->
	
	<?php include 'footer.php';?>