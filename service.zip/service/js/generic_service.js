$(function(){
	var domain_name = $('#domain_name').val();
	
	$('._options').hide();

	$('input[name=service]:radio').change(function(){
		var option = $(this).val();		
		$('#form_option').hide();
		$('#form_'+option).show();		
	});

	$('._back').click(function(){
		$('#form_option').show();
		$('._options').hide();
		
	});
	
	getRandomDomains();
	getsocial(domain_name,'fb');
	getsocial(domain_name,'twitter');
	getsocial(domain_name,'linkedin');
	getsocial(domain_name,'gplus');
	getsocial(domain_name,'gtube');
	getsocial(domain_name,'pinterest');
	getsocial(domain_name,'aboutme');
	getsocial(domain_name,'angellist');
	getsocial(domain_name,'crunchbase');
	getsocial(domain_name,'foursquare');
	getsocial(domain_name,'fs6');
	getsocial(domain_name,'livestream');
	getsocial(domain_name,'meetup');
	getsocial(domain_name,'metacafe');
	getsocial(domain_name,'outlook');
	getsocial(domain_name,'tumblr');
	getsocial(domain_name,'vimeo');	
});

function getRandomDomains(){
		var count = 3;
		$.getJSON('http://manage.vnoc.com/company/getRandomDomain/'+count,function(data){
				for(var i = 0; i< count; i++){
					var rand_domain_data = data[i];
					var random_domain_name = capitalise(rand_domain_data.value);
					$('#randomdomain_'+(i+1)).html('<a href="http://'+rand_domain_data.value+'" class="d_title"><b>></b>'+random_domain_name+'</a>');
				}
		});
	}
	
function getsocial(domain_name,social){
	
	$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
					var socialdata = data[0];
					if(socialdata.error == true){
						//do nothing
					}else if(socialdata.profile_url == ""){
						//do nothing
					}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
						//do nothing
					}else{
						$('#socials_container').append('<a href="'+socialdata.profile_url+'"><img src="images/'+social+'.png" height="40px"></a>');
					}		
	});
}

function capitalise(string) {
        string = string.toLowerCase();
        return string.charAt(0).toUpperCase() + string.slice(1);
}