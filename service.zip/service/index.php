<?php
include 'includes/config.php';
include 'header.php';
?>

  
	<div class="content"><!-- content -->
		<input type="hidden" name="domain_name" id="domain_name" value="<?php echo $domain ?>"/>
		<div class="contentWrapper"><h2>Building Great Assets since 1996</h2></div>		
		<div class="container"> 	  
		  <div class="row">
		  <div class="tape"></div>
			<div class="content-wrapper">
				<div class="col-7 col-sm-7 col-lg-7">					
					<div class="introduction">
					   <?php if ($introduction !=""):?>
					      <?php echo stripcslashes($introduction)?>      
					   <?php else:?>
					    <!-- p><a href="http://<?=ucwords($domain)?>" title="<?php echo $title?>" alt="<?php echo $title?>"><?php echo ucwords($domain)?></a> platform is part of the <a href="http://www.globalventures.com" alt="Global Ventures" title="Global Ventures">Global Ventures Network</a>.  Founded in 1996, Global Ventures is the worlds largest virtual Domain Development Incubator on the planet.</p>  
							<p>We <a href="http://www.contrib.com">create and match great domain platforms </a> with talented people, applications and resources to build successful, value driven, web-based businesses.</p>    
							<p>Our network synergy created by the platform of over 1,000,000 unique monthly visitors,  20,000 owner operated domain assets and leveraging its <a href="http://www.ecorp.com">patented eCorp Business Model</a>.</p> 
							<p><a href="http://www.globalventures.com" alt="great domain platforms" title="Global Ventures">Global Ventures </a> is rapidly expanding globally and always seeks out great, quality, driven people to join the fastest growing Virtual Business Network.</p -->  
					   
					   <p><a href="http://www.globalventures.com" alt="Global Ventures" title="Global Ventures">Global Ventures</a> and
					   its patent pending <a href="http://www.ecorp.com">eCorp</a> model is the worlds largest virtual domain development incubator on the planet.
					   Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms.<br /><br />
					   We strive for world class service while expanding our positioning as being experts in web-based,
					   domain centric operating businesses for clients and internal
					   ventures such as <a href="http://<?=ucwords($domain)?>" title="<?php echo $title?>" alt="<?php echo $title?>"><?php echo ucwords($domain)?></a>.</p>

					   
					   <?php endif;?>
						
					</div>
				</div>
				<div class="col-5 col-sm-5 col-lg-5">					
					<div class="form-con">
						<div class="form-box" style="width:100%;"> 
								<div id="form_option">
									<h1>Contact Us Right Now</h2>
									<div class="form-content" style="width:83%;background: #F0F0F0;">
												<h3>I&#39;m interested in : </h3>
												<div style="font-size: 16px;line-height: 35px;min-height:190px">
													<table>
														<tr>
															<td style="width:30px;height: 35px;"><input type="radio" name="service" value="partner"></td>
															<td>Partner / Develop with <?php echo ucfirst($domain)?></td>
														</tr>
														
														<tr>
															<td style="width:30px;height: 35px;"><input type="radio" name="service" value="staffing"></td>
															<td>Staffing Opportunities with <?php echo ucfirst($domain)?></td>
														</tr>
														
														<tr>
															<td style="width:30px;height: 35px;"><input type="radio" name="service" value="offer"></td>
															<td>Submit an Offer for <?php echo ucfirst($domain)?></td>
														</tr>
														<tr>
															<td style="width:30px;height: 35px;"><input type="radio" name="service" value="inquire"></td>
															<td>Inquire / Sponsor with <?php echo ucfirst($domain)?></td>
														</tr>
													</table>
												</div>
											</div><!--form-content-->
										</div>	
											<div id="form_partner" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/forms/partner/<?php echo $domain?>" scrolling="no" frameborder="0" style="width: 355px;height: 460px;"></iframe>
											</div>
											<div id="form_advertise" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												form_advertise
											</div>
											<div id="form_staffing" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/forms/staffing/<?php echo $domain?>" scrolling="no" frameborder="0" style="width: 355px;height: 460px;"></iframe>
											</div>
											<div id="form_develop" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/forms/staffing/<?php echo $domain?>" scrolling="no" frameborder="0" style="width: 355px;height: 460px;"></iframe>
											</div>
											<div id="form_offer" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/forms/offer/<?php echo $domain?>" scrolling="no" frameborder="0" style="width:350px;height:500px;"></iframe>
											</div>
											<div id="form_inquire" class="_options">
												<a href="javascript:;" class="_back">Back</a>
												<iframe src="http://www.contrib.com/forms/inquiry/<?php echo $domain?>" scrolling="no" frameborder="0" style="width:350px;height:460px;"></iframe>
											</div>
											
										
									</div><!--form-box -->
	</div><!-- form-con-->
				</div>
					<div style="clear:both"></div>
			</div>
		  </div>
		</div> 
	</div><!-- end content -->
	
	<?php include 'footer.php';?>