<style>
.content { background:url(<?php echo $background_image?>) no-repeat top center; border-bottom:1px solid #eee; padding-top:20px; }
</style>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" 
      type="image/icon"
      href="/images/favicon.ico">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="canonical" href="http://<?=$domain?>/<?=str_replace('.php','',basename($_SERVER['PHP_SELF']))?>/" />
	<meta name="robots" content="index, follow" />
	<title><?php echo $title?></title>
    <meta name="title" content="<?php echo $domain?> " />
    <meta name="description" content="<?php echo $domain?> <?php echo $description?>" />
   <link href="http://fonts.googleapis.com/css?family=Reenie+Beanie" rel="stylesheet" type="text/css">
	<link href="http://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet" type="text/css">
    <link href="css/inquiry/style.css" rel="stylesheet">    
    <link href="css/inquiry/grid.css" rel="stylesheet">
	<link href="css/inquiry/custom.css" rel="stylesheet">
	<script type="text/javascript" src="js/clear_textbox.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript" src="js/generic_service.js"></script>
	
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?php echo $account_ga?>']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>
 
<body>
  
 <div class="head"><!-- head --> 
		<div class="container">			
		  <div class="row">
			<h1 class="head-tit"><a href="http://<?=ucwords($domain)?>" title="<?php echo $title?>" alt="<?php echo $title?>"><?php echo ucwords($domain)?></a></h1>	
		  </div>
		</div>
	</div><!-- end head -->