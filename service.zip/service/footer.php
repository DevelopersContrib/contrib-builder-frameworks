<div class="footer">
<!-- footer -->
		<div class="container"> 
			<div class="row">
				<div class="box bdrt col-6 col-sm-4 col-lg-4">
					<h3><a href="http://www.contrib.com/brand/details/<?php echo $domain?>">About <?php echo ucwords($domain)?></a></h3>
					Know more indepth stats for <?php echo ucwords($domain)?>. <a href="http://www.contrib.com/brand/details/<?php echo strtolower($domain)?>">Visit</a> our Assets and People Marketplace today. 
				</div>
				<div class="box bdrt col-6 col-sm-4 col-lg-4">
					<h3>Other Assets</h3>
					<ul class="doms">
						<li id="randomdomain_1"><a href="#"><b>></b>Challenge.com</a></li>
						<li id="randomdomain_2"><a href="#"><b>></b>HowToSellDomains.com</a></li>
						<li id="randomdomain_3"><a href="#"><b>></b>MyOtherCoolDomain.com</a></li>
					</ul>
				</div>
				<div class="box col-6 col-sm-4 col-lg-4">
					<h3>Stay Connected</h3>
					<div id="socials_container">
						
					</div>
				</div>
			</div>		   
		</div> 
	</div><!-- end footer -->
	
	<div class="sub-footer">
		<div class="container">
			<div class="row">
			<div class="col-lg-12">
				<div class="foot-credit">
				<a href="http://<?php echo $domain?>/about">About Us</a>&nbsp; 
				<a href="http://<?php echo $domain?>/terms">Terms</a>&nbsp; 
				<a href="http://<?php echo $domain?>/privacy">Privacy Policy</a>&nbsp;  
				<p>&copy; Copyright <?php echo date('Y')?> <?php echo ucwords($domain)?>. All Rights Reserved.</p>
				</div>
			</div>
		   </div>
		</div>
	</div>
  </body>
</html>
