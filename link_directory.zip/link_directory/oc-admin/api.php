<?php
$return = array();

switch( Params::getParam('action') )
{
	case('getcategory'):
		foreach(Category::newInstance()->listAll() as $category){
			$return[] = array(
				"id"=>$category['pk_i_id'],
				"parent_id"=>$category['fk_i_parent_id'],
				"name"=>$category['s_name'],
				"description"=>$category['s_description'],
				"slug"=>$category['s_slug'],
				"items"=>$category['i_num_items'],
				);
		}
		
	break;
	case('addlisting'):
		//http://links.handyman.com/oc-admin/index.php?page=api&action=addlisting&title=Title%20in%20USmana1&content=Lor4em%20ipsum&category=Technology&contactemail=email@yahoo.com&contactname=Mr.%20False%20Name1&city_area=07841454774&city=Arizona&region=Arizona&countryId=US&country=United%20States&datetime=2013-03-08%2012:34:56&url=http://www.yahoo1.com&images=http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png
		$mItems = new ItemActions(true);
		
		$errormsg = '';
		list($success, $cat_info, $meta_info) = addlisting_ex();
		
		if($success<2) { //2 is the success code for active ads & 1 for inactive
			$errormsg .= sprintf(__("%s (Item %d)", "add"), $success, $klisting)."<br/>";
			$return = array('status'=>0,'msg'=>$errormsg);
		}else{
			$return = array('status'=>2,'msg'=>$errormsg,'id'=>$success);
		}
	break;
	case('editlisting'):
		//http://links.handyman.com/oc-admin/index.php?page=api&action=editlisting&id=28&title=Title%20in%20USmana1&content=Lor4em%20ipsum&category=Technology&contactemail=email@yahoo.com&contactname=Mr.%20False%20Name1&city_area=07841454774&city=Arizona&region=Arizona&countryId=US&country=United%20States&datetime=2013-03-08%2012:34:56&url=http://www.yahoo1.com&images=http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png

		$mItems = new ItemActions(true);
		
		$errormsg = '';
		list($success, $cat_info, $meta_info) = editlisting_ex();
		
		if($success!=1) { //2 is the success code for active ads & 1 for inactive
			$errormsg .= sprintf(__("%s (Item %d)", "adimporter"), $success, $klisting)."<br/>";
			$return = array('status'=>0,'msg'=>$errormsg);
		}else{
			$return = array('status'=>$success,'msg'=>$errormsg);
		}
	break;
	case('delete'):
		$id      = Params::getParam('id');
		if(empty($id)){
			$return = array('status'=>0,'msg'=>"The listing couldn't be deleted");
		}else{
			$success = false;
			
			foreach( $id as $i ) {
				if ( $i ) {
					$itemManager = Item::newInstance();
					$aItem   = $itemManager->findByPrimaryKey( $i );
					$mItems  = new ItemActions( true );
					$success = $mItems->delete( $aItem['s_secret'], $aItem['pk_i_id'] );
				}
			}

			if( $success ) {
				$return = array('status'=>1,'msg'=>'The listing has been deleted');
			}else{
				$return = array('status'=>0,'msg'=>"The listing couldn't be deleted");
			}
		}
	break;
	default:
	break;
}

function editlisting_ex() {
	$cat_info = array();
	$meta_info = array();
	
	$listing = array();
		
    $mItems = new ItemActions(true);

	$catId = $_REQUEST['categoryid'];

	Params::setParam("country", $_REQUEST['country']);
    Params::setParam("countryId", $_REQUEST['countryId']);
    Params::setParam("region", $_REQUEST['region']);
    Params::setParam("city", $_REQUEST['city']);
    Params::setParam("cityArea", $_REQUEST['city_area']);
    Params::setParam("address", $_REQUEST['address']);
    Params::setParam("price", $_REQUEST['price']);
    Params::setParam("currency", $_REQUEST['currency']);
    Params::setParam("contactName", $_REQUEST['contactname']);
    Params::setParam("contactEmail", $_REQUEST['contactemail']);
	
    if($catId==null) {
		$cats = $_REQUEST['category'];
		
        $cat_insert = true;
        $catId = 0;
        if(!empty($cats)) {
			$cat = $cats;
			$lang = osc_language();                
			$categoryDescription[$lang] = array('s_name' => $cat);
			if($catId==0) {
				if(isset($cat_info[$lang]) && isset($meta_info[$lang][$cat])) {
					$catId = $cat_info[$lang][$cat];
				} else {
					$exists = Category::newInstance()->listWhere("b.fk_c_locale_code = '".$lang."' AND b.s_name = '".$cat."'");
					if(isset($exists[0]) && isset($exists[0]['pk_i_id'])) {
						$cat_info[$lang][$cat] = $exists[0]['pk_i_id'];
						$cat_insert = false;
						$catId = $exists[0]['pk_i_id'];
					}
				}
			}
               
            $category = array();
            $category['fk_i_parent_id'] = NULL;
            $category['i_expiration_days'] = 0;
            $category['i_position'] = 0;
            $category['b_enabled'] = 1;
            if($cat_insert) {
                $catId = Category::newInstance()->insert($category, $categoryDescription);
            }

        }
    }
	
    Params::setParam("catId", $catId);
	
	$title_list = $_REQUEST['title'];
    $content_list = $_REQUEST['content'];
	$image_list = $_REQUEST['images'];
    $custom_list = $_REQUEST['custom'];
	

    $title = array();
    $content = array();
    $photos = '';
	$lang = osc_language();
    
	$title[$lang] = $title_list;
	
    
	$content[$lang] = $content_list;
	
    $meta_array = array();
    	
	$cfield = Field::newInstance()->findBySlug('url');
	if(!empty($cfield)){
		$meta_array[$cfield['pk_i_id']] = $_REQUEST['url'];
	}
    if(!empty($meta_array)){
        Params::setParam("meta", $meta_array);
    }
	
	if(!empty($image_list)){
		$image_list = explode('::',$image_list);
		
		foreach($image_list as $image) {
			$tmp_name = "adimporterimage_".$k.'_'.microtime();
			$image_ok = osc_downloadFile($image, $tmp_name);
			if($image_ok) {
				$photos['error'][] = 0;
				$photos['size'][] = 100;
				$photos['type'][] = 'image/jpeg';
				$photos['tmp_name'][] = osc_content_path()."downloads/".$tmp_name;
			}
		}
		$_FILES['photos'] = $photos;
	}
    

	Params::setParam("title", $title);
    Params::setParam("description", $content);
	// echo "<pre>";
	// Params::_view();
	// echo "</pre>";
	// die();
    $mItems->prepareData(false);
    $success = $mItems->edit();
    return array($success, $cat_info, $meta_info);
}

function addlisting_ex() {
	$cat_info = array();
	$meta_info = array();
	
	$listing = array();
		
    $mItems = new ItemActions(true);

	$catId = $_REQUEST['categoryid'];

	Params::setParam("country", $_REQUEST['country']);
    Params::setParam("countryId", $_REQUEST['countryId']);
    Params::setParam("region", $_REQUEST['region']);
    Params::setParam("city", $_REQUEST['city']);
    Params::setParam("cityArea", $_REQUEST['city_area']);
    Params::setParam("address", $_REQUEST['address']);
    Params::setParam("price", $_REQUEST['price']);
    Params::setParam("currency", $_REQUEST['currency']);
    Params::setParam("contactName", $_REQUEST['contactname']);
    Params::setParam("contactEmail", $_REQUEST['contactemail']);
	
    if($catId==null) {
		$cats = $_REQUEST['category'];
		
        $cat_insert = true;
        $catId = 0;
        if(!empty($cats)) {
			$cat = $cats;
			$lang = osc_language();                
			$categoryDescription[$lang] = array('s_name' => $cat);
			if($catId==0) {
				if(isset($cat_info[$lang]) && isset($meta_info[$lang][$cat])) {
					$catId = $cat_info[$lang][$cat];
				} else {
					$exists = Category::newInstance()->listWhere("b.fk_c_locale_code = '".$lang."' AND b.s_name = '".$cat."'");
					if(isset($exists[0]) && isset($exists[0]['pk_i_id'])) {
						$cat_info[$lang][$cat] = $exists[0]['pk_i_id'];
						$cat_insert = false;
						$catId = $exists[0]['pk_i_id'];
					}
				}
			}
               
            $category = array();
            $category['fk_i_parent_id'] = NULL;
            $category['i_expiration_days'] = 0;
            $category['i_position'] = 0;
            $category['b_enabled'] = 1;
            if($cat_insert) {
                $catId = Category::newInstance()->insert($category, $categoryDescription);
            }

        }
    }
	
    Params::setParam("catId", $catId);
	
	$title_list = $_REQUEST['title'];
    $content_list = $_REQUEST['content'];
	$image_list = $_REQUEST['images'];
    $custom_list = $_REQUEST['custom'];
	

    $title = array();
    $content = array();
    $photos = '';
	$lang = osc_language();
    
	$title[$lang] = $title_list;
	
    
	$content[$lang] = $content_list;
	
    $meta_array = array();
    	
	$cfield = Field::newInstance()->findBySlug('url');
	if(!empty($cfield)){
		$meta_array[$cfield['pk_i_id']] = $_REQUEST['url'];
	}
    if(!empty($meta_array)){
        Params::setParam("meta", $meta_array);
    }
	
	if(!empty($image_list)){
		$image_list = explode('::',$image_list);
		
		foreach($image_list as $image) {
			$tmp_name = "adimporterimage_".$k.'_'.microtime();
			$image_ok = osc_downloadFile($image, $tmp_name);
			if($image_ok) {
				$photos['error'][] = 0;
				$photos['size'][] = 100;
				$photos['type'][] = 'image/jpeg';
				$photos['tmp_name'][] = osc_content_path()."downloads/".$tmp_name;
			}
		}
		$_FILES['photos'] = $photos;
	}
    

	Params::setParam("title", $title);
    Params::setParam("description", $content);
	// echo "<pre>";
	// Params::_view();
	// echo "</pre>";
	// die();
    $mItems->prepareData(true);
    $success = $mItems->add(true);
    return array($success, $cat_info, $meta_info);
}

header('Content-Type: application/json');
echo  json_encode($return);
?>