<?php $domain="1800startups.com"; 

$db="site42o3_links"; 

$sitename="1800startups.com"; 

$cpanel_username="site42o3"; 

$cpanel_password="qOr5Pv@fT6W"; 

$title="1800startups.com"; 

$account_ga=""; 

$desc="Join our exclusive community of like minded people on 1800startups.com"; 

$logo=""; 

$memberid="38"; 

$domainname="1800startups.com"; 

$domainid="13295"; 

$domain_affiliate_link="http://referrals.contrib.com/idevaffiliate.php?id=17018&url=http://www.contrib.com/signup/firststep?domain=1800startups.com"; 

$footer_banner=""; ?>