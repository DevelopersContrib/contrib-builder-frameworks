<?php
$host="localhost"; 
$root=$cpanel_username; 
$root_password=$cpanel_password; 

$user=$cpanel_username."_maida";
$pass='bing2k';

if($flag_sub==1)
		$db=$cpanel_username."_links_".$subname; //SUBDOMAIN
else

$db=$cpanel_username."_links";  			//DOMAIN

$curl = "https://$cpanel_username:$cpanel_password@localhost:2083/frontend/x3/sql/addb.html?db=$db";
@file_get_contents($curl);


try {
	$dbh = new PDO("mysql:host=$host", $cpanel_username, $cpanel_password);
	$dbh->exec("CREATE DATABASE IF NOT EXISTS `$db`;
			CREATE USER '$user'@'localhost' IDENTIFIED BY '$pass';
			GRANT ALL ON `$db`.* TO '$user'@'localhost';
			FLUSH PRIVILEGES;
		 "); 
	 
	//or die(print_r($dbh->errorInfo(), true));
	$output = shell_exec("mysql -u$cpanel_username -p$cpanel_password $db < links.sql");
	
} catch (PDOException $e) {
	die("DB ERROR: ". $e->getMessage());
}


$conn = new PDO("mysql:host=$host;dbname=$db", $cpanel_username, $cpanel_password);
 
$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
$q = $conn->prepare($sql);
$q->execute(array($domain,'subdomain_host')); 

$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
$q = $conn->prepare($sql);
$q->execute(array($title,'pageTitle')); 

$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
$q = $conn->prepare($sql);
$q->execute(array($desc,'pageDesc')); 

$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
$q = $conn->prepare($sql);
$q->execute(array($account_ga,'google_analytics_id')); 

		
?>