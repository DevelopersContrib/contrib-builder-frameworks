<?php
 global $title, $logo, $desc, $bg_type, $bg_color, $bg_image, 
	$image_style, $about_desc, $domain,$domain_affiliate_link, $partners,$cpanel_username,$cpanel_password;

$headers = array('Accept: application/json');
function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null){
	if (($method == 'PUT') || ($method=='DELETE')){
		$headers[] = 'X-HTTP-Method-Override: '.$method;
	}

	$handle = curl_init();
	curl_setopt($handle, CURLOPT_URL, $url);
	curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
	if ($user){
		curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
	} 

	switch($method){
		case 'GET':
		break;
		case 'POST':
		curl_setopt($handle, CURLOPT_POST, true);
		curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
		break;
		case 'PUT':
		curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
		curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
		break;
		case 'DELETE':
		curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
		break;
	}
	$response = curl_exec($handle);
	return $response;
}

$filename = 'import_sql.php';
if (file_exists($filename) && file_exists('config-framework.php')) { //for rebuild
	unlink('config-framework.php');
	if(file_exists('oc-admin/config-framework.php'))
		unlink('oc-admin/config-framework.php');
}

$flag_sub = 0;
$subname = '';
if ($_SERVER["HTTP_HOST"]!='contrib.com' && !file_exists('config-framework.php')) {
	$api_url = "http://api1.contrib.co/request/";
	$domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www

	$key = md5('vnoc.com');

    $api_url = "http://api1.contrib.co/request/";
    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $error = 0;
    $error_msg = '';
    if(stristr($domain,'~') ===FALSE) {
    	$domain = $_SERVER["HTTP_HOST"];
		$domain = str_replace("http://","",$domain);
    	$domain = str_replace("www.","",$domain);
		
		$keydomain = $domain;
    	$key = md5($keydomain);
    }else {
       $key = md5('vnoc.com');
       $d = explode('~',$domain);
       $user = str_replace('/','',$d[1]);
       
	   $host = $_SERVER["HTTP_HOST"];
		$host = str_replace("http://","",$host);
		$host = str_replace("www.","",$host);
	   $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key.'&host='.$host;

       $result =  createApiCall($url, 'GET', $headers, array());
       $data_domain = json_decode($result,true);
       $domain =   $data_domain['data']['domain'];
    }

	$parsed = parse_url('http://'.$domain);
	$exploded = explode('.', $parsed["host"]);
	$flag_sub = (count($exploded) > 2)? 1 : 0;
	if(!empty($flag_sub)){
		$subname = $exploded[0];
	}
	
    $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
	
    $result = createApiCall($url, 'GET', $headers, array());
    $data_domain = json_decode($result,true);
    
    if ($data_domain['success']){
    	$domainid = $data_domain['data']['DomainId'];
    	$domainname = $data_domain['data']['DomainName'];
    	$memberid = $data_domain['data']['MemberId'];
    	$title = $data_domain['data']['Title'];
		if(empty($title)) $title = ucwords($domainname);
    	$logo = $data_domain['data']['Logo'];
    	$desc = $data_domain['data']['Description'];
    	$account_ga = $data_domain['data']['AccountGA'];
    	$desc = stripslashes(str_replace('\n','<br>',$desc));
	}else{
		$error_msg .= $data['data']['error_message'];
		$error++;
	}

	$url = $api_url.'getcpanelinfo?domain_id='.$domainid.'&key='.$key;
	$result =  createApiCall($url, 'GET', $headers, array());
	$data_cpanel = json_decode($result,true);
	
	if($data_cpanel['success']){
		$DomainId = $data_cpanel['data']['DomainId'];
		$cpanel_username = $data_cpanel['data']['Username'];
		$cpanel_password = $data_cpanel['data']['Password'];
		$ServerId = $data_cpanel['data']['ServerId'];
	}else {
    	$error++;
    }
	
	$sitename =  $domain;
	//get monetize ads from vnoc
    $url = $api_url.'getbannercode?d='.$domain.'&p=footer';
    $result = createApiCall($url, 'GET', $headers, array());
    $data_ads = json_decode($result,true);
    $footer_banner = html_entity_decode(base64_decode($data_ads['data']['content']));
    
    //get domain affiliate id
    $url = $api_url.'getdomainaffiliateid?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $data_domain_affiliate = json_decode($result,true);
    if ($data_domain_affiliate['success']){
    	$domain_affiliate_id = $data_domain_affiliate['data']['affiliate_id'];
    }else {
    	$domain_affiliate_id = '391'; //contrib.com affiliate id
    }
    $domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$domain;

	if ($error > 0){
		if(!file_exists($filename)){
			echo "<center><h3>Please wait while page is loading...</h3>
				<br><small>Server Time:".date('m/d/Y h:i:s a', time())."</small>
			</center>";
			$page = $_SERVER['PHP_SELF'];
			$sec = "5";
			header("Refresh: $sec; url=$page");
		}
		exit;
	}
	if($flag_sub)
		$db=$cpanel_username."_links_".$subname; //SUBDOMAIN
	else
		$db=$cpanel_username."_links";  			//DOMAIN
		
	$file='<?php '.
		'$domain="'.$domain.'"; '."\n\n".
		'$db="'.$db.'"; '."\n\n".
		'$sitename="'.$sitename.'"; '."\n\n".
		'$cpanel_username="'.$cpanel_username.'"; '."\n\n".
		'$cpanel_password="'.$cpanel_password.'"; '."\n\n".
		'$title="'.$title.'"; '."\n\n".
		'$account_ga="'.$account_ga.'"; '."\n\n".
		'$desc="'.$desc.'"; '."\n\n".
		'$logo="'.$logo.'"; '."\n\n".
		'$memberid="'.$memberid.'"; '."\n\n".
		'$domainname="'.$domainname.'"; '."\n\n".
		'$domainid="'.$domainid.'"; '."\n\n".
		'$domain_affiliate_link="'.$domain_affiliate_link.'"; '."\n\n".
		'$footer_banner="'.$footer_banner.'"; '.
		'?>';
	file_put_contents('config-framework.php', $file);

	if(!file_exists($filename)){//update only
		$host="localhost"; 
		$conn = new PDO("mysql:host=$host;dbname=$db", $cpanel_username, $cpanel_password);
		
		$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
		$q = $conn->prepare($sql);
		$q->execute(array($domain,'subdomain_host')); 

		$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
		$q = $conn->prepare($sql);
		$q->execute(array($title,'pageTitle')); 

		$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
		$q = $conn->prepare($sql);
		$q->execute(array($desc,'pageDesc')); 

		$sql = " Update `oc_t_preference` set `s_value`=? where `s_name`=?";
		$q = $conn->prepare($sql);
		$q->execute(array($account_ga,'google_analytics_id')); 
	
	}
} 

include 'config-framework.php';


if ($sitename!='contrib.com' && file_exists($filename)) {
    include('import_sql.php'); //creates DB
	unlink($filename); //deletes file
}


?>
<?php

/**
 * The base MySQL settings of Osclass
 */
define('MULTISITE', 0);

/** MySQL database name for Osclass */
define('DB_NAME', $db);

/** MySQL database username */
define('DB_USER', $cpanel_username);

/** MySQL database password */
define('DB_PASSWORD', $cpanel_password);

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Table prefix */
define('DB_TABLE_PREFIX', 'oc_');

define('REL_WEB_URL', '/');

define('WEB_PATH', 'http://'.$domain.'/');

?>