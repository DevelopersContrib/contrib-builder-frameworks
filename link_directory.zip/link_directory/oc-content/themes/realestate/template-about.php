<?php
    /*
     *      OSCLass � software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2010 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()); ?>">
    <head>
        <?php osc_current_web_theme_path('head.php') ; ?>
        <meta name="robots" content="noindex, nofollow" />
        <meta name="googlebot" content="noindex, nofollow" />
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
        <style type="text/css">
            .brdr{
                border: 1px solid;
            }

            .inline{
                padding:0;
            }
            .inline > li{
                display: inline-block;
                list-style: none outside none;
                padding-left: 15px;
                padding-right: 15px;
            }
            .inline li a{
                color: #fff;
            }

            .ul-under-plan li{
                box-shadow: 0 0 2px #000;
                padding-top: 5px;
                padding-bottom: 5px;
                margin-bottom: 10px;
                margin-right: 5px;
            }

            /* hr Lines  style*/
            hr.lineLines:after{
                content: "\f039";
                background: none repeat scroll 0 0 rgb(255, 255, 255);
                color: rgb(238, 238, 238);
                display: inline-block;
                font-size: 1em;
                padding: 0 0.25em;
                position: relative;
                top: -0.5em;
                width: 33px;
                font-family: FontAwesome;
                font-style: normal;
                font-weight: normal;
                line-height: 1;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }
            hr.lineLines {
                text-align: center;
                margin: 1.5em 0;
                padding: 0;
                height: 0;
                -moz-box-sizing: content-box;
                box-sizing: content-box;
                border: 0;
                border-top: 1px solid #eee;
            }
            .sec-cont-h1{
                color: #333;
                font-size: 36px;
            }
        </style>
    </head>
    <body>
        <?php osc_current_web_theme_path('header.php') ; ?>
        <!-- <div class="" style="float:left; width: 550px;">
            <h1><?php echo osc_static_page_title() ; ?></h1>
            <div><?php echo osc_static_page_text() ; ?></div>
        </div> -->
        <div class="section-pages">
            <div class="section-container-ttle">
                <h1 class="sec-cont-h1">About us</h1>
            </div>
        </div>
        <div class="wrap-content-sections">
            <div class="content-pages">
                <p>
                    <b><?php echo ucfirst(meta_domain())?></b>, a division eCorp, has been providing home owners, contractors and service providers with quality matching services and helpful resources since 1998. We ourselves are homeowners, contractors and users of <?php echo ucfirst(meta_domain())?> to fill our own need to find quality contractors to do property management and home improvement with our commercial and residential real-estate holdings. We know how frustrating it can be in finding quality and respectable handyman contractors and will continue to bring new products and services to our site to make your experience an enjoyable one.
                </p>
                <br>
                <p>
                    Have you heard of myspace or facebook? Well forget social networking, we are focused on you, the consumer. RealtyProfile is a construction related consumer networking applications build specifically for the homeowner/contractor/realtor market. We are becoming the industry standard "consumer networking" portal. We have recently introduced our customized web page offering, free for a limited time, to home owners, realtors and contractors. RealtyProfile is becoming a catalyst product for our customers to help streamline communications, rate/review service providers, update and track work progress and much more. Handyman and RealtyProfile are your home improvement and property management best friend if you want to save time, frustration and get the job done. We have many exciting future developments planned. Below you can see we have a large online virtual real estate portfolio to work with. We are here to serve you and strive to bring products and service to market that make your life easier when trying to improve or maintain your most important asset, your property. Contact us webmaster at handyman dot com anytime with your comments or questions and please check back often and visit our award winning RealtyForum.
                </p>
                <br>
                <p>
                    Respectfully,
                </p>
                <br>
                <p>
                    <?php echo ucfirst(meta_domain())?>
                </p>
                <br>
                <p>
                    Other developments planned.
                </p>
                <br>
                <ul class="inline ul-under-plan">
                    <li>
                        PropertyManagement.com
                    </li>
                    <li>
                        HomeManagement.com
                    </li>
                    <li>
                        HomeChannel.com
                    </li>
                    <li>
                        Renovated.com
                    </li>
                    <li>
                        HomeTech.net
                    </li>
                    <li>
                        LocalReferrals.com
                    </li>
                    <li>
                        SmartHouse.com
                    </li>
                    <li>
                        ServiceProviders.com
                    </li>
                    <li>
                        ServiceDirectory.com
                    </li>
                    <li>
                        RealtyLink.com
                    </li>
                    <li>
                        LoanCenter.com
                    </li>
                    <li>
                        ConstructionShop.com
                    </li>
                    <li>
                        SubContracting.com
                    </li>
                    <li>
                        Lawn-Care.com
                    </li>
                    <li>
                        PaintingServices.com
                    </li>
                    <li>
                        LocalNetwork.com
                    </li>
                    <li>
                        LocalProviders.com
                    </li>
                    <li>
                        HomePainters.com
                    </li>
                </ul>
                <p>
                    Over 500 more construction, home improvement, renovations, service related projects.
                </p>
                <br>
            </div>
        </div>
        <?php osc_current_web_theme_path('footer.php') ; ?>
    </body>
</html>