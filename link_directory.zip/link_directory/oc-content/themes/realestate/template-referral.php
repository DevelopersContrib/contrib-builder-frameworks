<?php
    /*
     *      OSCLass � software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2010 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()); ?>">
    <head>
        <?php osc_current_web_theme_path('head.php') ; ?>
        <meta name="robots" content="noindex, nofollow" />
        <meta name="googlebot" content="noindex, nofollow" />
    </head>
    <body>
        <?php osc_current_web_theme_path('header.php') ; ?>
        <div class="" style="float:left; width: 550px;">
            <h1><?php echo osc_static_page_title() ; ?></h1>
            <div><?php echo osc_static_page_text() ; ?></div>
        </div>
		
		
		<style>
    .input-block-level {
        display: block;
        width: 100%;
        min-height: 30px;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
   
    .banner-main dl {
        margin-bottom: 20px;
    }
    
    .banner-main dt,
    .banner-main dd {
        line-height: 20px;
    }
    
    .banner-main dt {
        font-weight: bold;
    }
    
    .banner-info dd {
        margin-left: 10px !important;
margin-bottom: 0px !important; 
    }
    
    .banner-main  .dl-horizontal {
        *zoom: 1;
    }
    
    .banner-main  .dl-horizontal:before,
    .banner-main  .dl-horizontal:after {
        display: table;
        line-height: 0;
        content: "";
    }
    
    .dl-horizontal:after {
        clear: both;
    }
    
    .dl-horizontal dt {
        float: left;
        width: 160px;
        overflow: hidden;
        clear: left;
        text-align: right;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .dl-horizontal dd {
        margin-left: 180px;
    }
    .padd-banner{
        padding: 10px 20px;
    }
    .banner-main{
        margin-bottom: 30px;
        padding-bottom:10px;
        border-bottom: 1px solid #fff;
    }
    .banner-main textarea{
        resize:none;
        border-radius: 4px;
        border: 1px solid #000000;
    }
    .banner-main:last-child{
        border-bottom: none;
    }
    .banner-header{
        font-weight: 300;
        color: #fff;
        border-bottom: 1px solid #fff;
        line-height: 65px;
        margin:0 0 30px;
    }
    .banner-img-cont{
        margin-bottom: 25px;
    }
    .banner-source{
        color: #fff !important;
        font-size:18px;
    }
    .banner-info{
        color: #fff !important;
    }
    /*
    ==============================================
    tossing
    ==============================================
    */
    
    .tossing{
        animation-name: tossing;
        -webkit-animation-name: tossing;	
        
        animation-duration: 2.5s;	
        -webkit-animation-duration: 2.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes tossing {
        0% {
            transform: rotate(-4deg);	
        }
        50% {
            transform: rotate(4deg);
        }
        100% {
            transform: rotate(-4deg);	
        }						
    }
    
    @-webkit-keyframes tossing {
        0% {
            -webkit-transform: rotate(-4deg);	
        }
        50% {
            -webkit-transform: rotate(4deg);
        }
        100% {
            -webkit-transform: rotate(-4deg);	
        }				
    }
    /*
    ==============================================
    floating
    ==============================================
    */
    
    .floating{
        animation-name: floating;
        -webkit-animation-name: floating;
        
        animation-duration: 1.5s;	
        -webkit-animation-duration: 1.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes floating {
        0% {
            transform: translateY(0%);	
        }
        50% {
            transform: translateY(8%);	
        }	
        100% {
            transform: translateY(0%);
        }			
    }
    
    @-webkit-keyframes floating {
        0% {
            -webkit-transform: translateY(0%);	
        }
        50% {
            -webkit-transform: translateY(8%);	
        }	
        100% {
            -webkit-transform: translateY(0%);
        }			
    }
    .text-center{
        text-align:center;
    }
    #container2 p{
        text-align: center !important;
    }
	
	/* Add New 2 banner */
    .wrap-allbanner{
        background: url(http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-728x90-1.png)no-repeat scroll;
        height: 90px;
        width: 728px;
        position: relative;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    .bannerType1{
        text-decoration: none;
    }
    .bannerType1, .bannerType1:focus,.bannerType1:hover{
        outline: none;
    }
    .wrap-bannerLeft, .wrap-bannerRight{
        display: inline-block;
        float: left;
    }
    /* Left COntainer */
    .wrap-bannerLeft{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        height: 90px;
        vertical-align: top;
        padding: 15px 5px 20px 10px;
        width: 245px;
        overflow: hidden;
		
    }
    /*Link Domain*/
    .ellipsis {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .aBnnrP{
        display: block;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        font-weight: bold;
        font-size: 22px;
        line-height: normal;
        margin: 0;
        color: #0088CC;
        text-align: center;
        text-transform: capitalize;
        text-decoration: none;
    }

    /* Right Container */
    .wrap-bannerRight{
        color: #FFFFFF;
        height: 90px;
        margin-left: 84px;
        width: 397px;
    }
    .content-rightText{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 350px;
        padding-top: 16px;
        margin: auto;
    }
    .content-rightText span{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
    }
    .content-rightText span, .content-rightText p{
        font-size: 25px;
        text-align: center;
        text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
    }
    .content-rightText p{
        padding: 12px 0 8px;
        margin: 0;
    }
    /*Image*/
    .logo-banners1{
        max-width: 100%;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
		max-height: 58px;
    }

    /*Second Bannder*/
    .wrapBanner-2{
        background: url(http://d2qcctj8epnr7y.cloudfront.net/images/jayson/180x150-1.png) no-repeat scroll;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        margin: auto;
        position: relative;
        height: 150px;
        width: 180px;
        overflow: hidden;
    }
    .bannerType2{
        color: #fff;
        text-decoration: none;
    }
    .bannerType2,.bannerType2:hover,.bannerType2:focus{
        outline: none;
    }

    /*Top banner*/
    .wrap-topBanner{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        position: relative;
        display: block;
        width: 118px;
        margin: 37px auto 0;
    }
    .wrap-contentTop{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        font-size: 20px;
        letter-spacing: 0.01em;
        line-height: 1.1em;
        text-align: center;
        text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
        text-align: center;
    }
    .wrap-contentTop p{
        margin: 0;
    }
    .wrap-contentTop span{
        display: block;
    }

    /*Down banner*/
    .wrap-downBanner{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
        height: 37px;
        margin: 5px 0 0;
        overflow: hidden;
    }
    .wrap-contentDown{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 125px;
        height: 35px;
        margin: auto;
		padding: 1px 0;
    }
    .wrap-contentDown img{
        max-width: 100%;
		max-height: 32px;
		text-align:center;
    }
    .wrap-contentDown p{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
        margin: 0;
        color: #0088CC;}
	
       dd{ margin: 0 0 0px !important;}
</style>
		
		<div class="padd-banner" style="border-radius: 10px;background:rgba(0,0,0,0.8);">
			<div class="banner-main">
				<?php
					$domain = $_SERVER['HTTP_HOST'];
					if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
						$domain = $regs['domain'];
					}
					
					$iframe = '<iframe src="http://referrals.contrib.com/aff_index.php?affiliate='.$domain.'" width="100%" height="760px" scrolling="auto" frameborder="0" seamless=""></iframe>';
				?>
				<?php if( osc_is_web_user_logged_in() ) { ?>
				<?php
						$url = "http://www.api.contrib.com/forms/addaffiliate";
						$param = array(
							'domain'=>$domain,
							'email'=>osc_logged_user_email(),
							'username'=>osc_logged_user_name(),
							'password'=>'123456789',
							//'firstname'=>$sc_first_name,
							//'lastname'=>$sc_last_name
						);
						
						$curl = curl_init();
						curl_setopt ($curl, CURLOPT_URL, $url);
						curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($curl, CURLOPT_POST, true);
						curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($param));
						$result = curl_exec ($curl);
						curl_close ($curl);
												
						if(!empty($result)){						
							$user_login_idev = $result;						
							$url = "http://api2.contrib.com/request/getaffiliateloginurl?affiliate_id=$user_login_idev";
							
							$curl = curl_init(); 
							curl_setopt ($curl, CURLOPT_URL, $url); 
							curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
							$result = curl_exec ($curl); 
							curl_close ($curl);  
							$d = json_decode($result);
					
							$iframe = '<iframe src="'.$d->data->url.'" width="100%" height="760px" scrolling="auto" frameborder="0" seamless=""></iframe>';
						}
					}
					echo $iframe;
				?>
				
			</div>
				<?php
					$url = "http://api2.contrib.com/request/getdomainaffiliateid?domain=$domain&key=".md5($domain);
					
					$curl = curl_init();
					curl_setopt ($curl, CURLOPT_URL, $url);
					curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
					$result = curl_exec ($curl);
					curl_close ($curl);

					$result = json_decode($result);
					$affiliate_id = $result->data->affiliate_id;

				?>
				
				<div class="banner-main">
				<dl class="dl-horizontal banner-info">
					<dt>Marketing Group</dt><dd>Handyman.com</dd>
					<dt>Banner Size</dt><dd>300x300</dd>
					<dt>Banner Description</dt><dd>Handyman Search by Zip Widget</dd>
					<dt>Target URL</dt><dd>http://handyman.com</dd>
				</dl>

				<div class="floating text-center banner-img-cont">
						<script type="text/javascript" src="http://handyman.com/widgets/searchbyzip?aff_id=http://referrals.contrib.com/idevaffiliate.php?id=<?php echo $affiliate_id?>"></script>

					</div>

				<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
				<textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" 
				readonly="readonly"><script type="text/javascript" 
				src="http://handyman.com/widgets/searchbyzip?aff_id=http://referrals.contrib.com/idevaffiliate.php?id=<?php echo $affiliate_id?>"></script>
				</textarea>
								</div>
				
								<div class="banner-main">
									<dl class="dl-horizontal banner-info">
										<dt>Marketing Group</dt><dd>Contrib</dd>
										<dt>Banner Size</dt><dd>728 x 90</dd>
										<dt>Banner Description</dt><dd><?=$domain?> Banner</dd>
										<dt>Target URL</dt><dd>http://<?=$domain?></dd>
									</dl>

									<div class="floating text-center banner-img-cont">
									<script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?=$domain?>/11555"></script>
                                
									</div>

									<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
									<textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
									    <script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?=$domain?>/11555"></script>
                                </textarea>
								</div>
								<div class="banner-main">
									<dl class="dl-horizontal banner-info">
										<dt>Marketing Group</dt><dd><?=$domain?></dd>
										<dt>Banner Size</dt><dd>180 x 150</dd>
										<dt>Banner Description</dt><dd><?=$domain?> Banner</dd>
										<dt>Target URL</dt><dd>http://<?=$domain?></dd>
									</dl>

									<div class="floating text-center banner-img-cont">
										                                    <script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?=$domain?>/11555"></script>
                                
									</div>

									<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
									<textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
									                                    <script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?=$domain?>/11555"></script>
                                </textarea>
								</div>
								<div class="banner-main">
				<dl class="dl-horizontal banner-info">
					<dt>Marketing Group</dt><dd>Contrib</dd>
					<dt>Banner Size</dt><dd>150 x 150</dd>
					<dt>Banner Description</dt><dd>Contrib Sticker 1</dd>
					<dt>Target URL</dt><dd>http://www.contrib.com</dd>
				</dl>
				
				<div class="tossing text-center banner-img-cont">
					<img src="http://referrals.contrib.com/banners/badge-contrib-3.png" />
				</div>
				
				<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
				<textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly"><a href="http://referrals.contrib.com/idevaffiliate.php?id=<?php echo $affiliate_id?>" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-3.png" width="150" height="150" alt="Contrib"></a></textarea>
			</div>
			<!-- dynamic -->
			
		</div>

		
		
		
        <?php osc_current_web_theme_path('footer.php') ; ?>
    </body>
</html>