<?php
/*
Plugin Name: Osclass upgrade fix
Plugin URI: http://www.osclass.org/
Description: This plugin prepare your installationn to be upgrade. This plugin is required for all versions older than 3.3.X
Version: 1.0.0
Author: Osclass
Author URI: http://www.osclass.org/
Plugin update URI: upgrade-fix
*/

function upgrade_fix_call_after_install()
{
    if(osc_version() < 340) {
        $message = "";
        $error = 0;
        $sql_error_msg = "";
        $rm_errors = 0;
        $perms = osc_save_permissions();
        osc_change_permissions();

        $maintenance_file = ABS_PATH . '.maintenance';
        $fileHandler = @fopen($maintenance_file, 'w');
        fclose($fileHandler);

        /***********************
         **** DOWNLOAD FILE ****
         ***********************/
        $data = osc_file_get_contents("http://osclass.org/latest_version_v1.php");
        $data = json_decode(substr($data, 1, strlen($data) - 3), true);
        $source_file = $data['url'];
        if ($source_file != '') {

            $tmp = explode("/", $source_file);
            $filename = end($tmp);
            $result = osc_downloadFile($source_file, $filename);

            if ($result) { // Everything is OK, continue
                /**********************
                 ***** UNZIP FILE *****
                 **********************/
                $tmp_path = osc_content_path() . 'downloads/oc-temp/core-' . $data['version'] . '/';
                @mkdir(osc_content_path() . 'downloads/oc-temp/', 0777);
                @mkdir($tmp_path, 0777);
                $res = osc_unzip_file(osc_content_path() . 'downloads/' . $filename, $tmp_path);
                if ($res == 1) { // Everything is OK, continue
                    /**********************
                     ***** COPY FILES *****
                     **********************/
                    $fail = -1;
                    if ($handle = opendir($tmp_path)) {
                        $fail = 0;
                        while (false !== ($_file = readdir($handle))) {
                            if ($_file != '.' && $_file != '..' && $_file != 'oc-content') {
                                $data = osc_copy($tmp_path . $_file, ABS_PATH . $_file);
                                if ($data == false) {
                                    $fail = 1;
                                };
                            }
                        }
                        closedir($handle);
                        //TRY TO REMOVE THE ZIP PACKAGE
                        @unlink(osc_content_path() . 'downloads/' . $filename);

                        if ($fail == 0) { // Everything is OK, continue
                            /************************
                             *** UPGRADE DATABASE ***
                             ************************/
                            $error_queries = array();
                            if (file_exists(osc_lib_path() . 'osclass/installer/struct.sql')) {
                                $sql = file_get_contents(osc_lib_path() . 'osclass/installer/struct.sql');

                                $conn = DBConnectionClass::newInstance();
                                $c_db = $conn->getOsclassDb();
                                $comm = new DBCommandClass($c_db);
                                $error_queries = $comm->updateDB(str_replace('/*TABLE_PREFIX*/', DB_TABLE_PREFIX, $sql));

                            }
                            if ($error_queries[0]) { // Everything is OK, continue
                                /**********************************
                                 ** EXECUTING ADDITIONAL ACTIONS **
                                 **********************************/
                                if (file_exists(osc_lib_path() . 'osclass/upgrade-funcs.php')) {
                                    // There should be no errors here
                                    define('AUTO_UPGRADE', true);
                                    require_once osc_lib_path() . 'osclass/upgrade-funcs.php';
                                }
                                // Additional actions is not important for the rest of the proccess
                                // We will inform the user of the problems but the upgrade could continue
                                /****************************
                                 ** REMOVE TEMPORARY FILES **
                                 ****************************/
                                $rm_errors = 0;
                                $dir = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp_path), RecursiveIteratorIterator::CHILD_FIRST);
                                for ($dir->rewind(); $dir->valid(); $dir->next()) {
                                    if ($dir->isDir()) {
                                        if ($dir->getFilename() != '.' && $dir->getFilename() != '..') {
                                            if (!rmdir($dir->getPathname())) {
                                                $rm_errors++;
                                            }
                                        }
                                    } else {
                                        if (!unlink($dir->getPathname())) {
                                            $rm_errors++;
                                        }
                                    }
                                }
                                if (!rmdir($tmp_path)) {
                                    $rm_errors++;
                                }
                                $deleted = @unlink(ABS_PATH . '.maintenance');
                                if ($rm_errors == 0) {
                                    $message = __('Everything looks good! Your Osclass installation is up-to-date');
                                    osc_add_flash_ok_message($message, 'admin');
                                } else {
                                    $message = __('Nearly everything looks good! Your Osclass installation is up-to-date, but there were some errors removing temporary files. Please manually remove the "oc-content/downloads/oc-temp" folder');
                                    osc_add_flash_warning_message($message, 'admin');
                                    $error = 6; // Some errors removing files
                                }
                            } else {
                                $sql_error_msg = $error_queries[2];
                                $message = __('Problems when upgrading the database');
                                $error = 5; // Problems upgrading the database
                            }
                        } else {
                            $message = __('Problems when copying files. Please check your permissions. ');
                            $error = 4; // Problems copying files. Maybe permissions are not correct
                        }
                    } else {
                        $message = __('Nothing to copy');
                        $error = 99; // Nothing to copy. THIS SHOULD NEVER HAPPEN, means we don't update any file!
                        $deleted = @unlink(ABS_PATH . '.maintenance');
                    }
                } else {
                    $message = __('Unzip failed');
                    $error = 3; // Unzip failed
                    $deleted = @unlink(ABS_PATH . '.maintenance');
                }
            } else {
                $message = __('Download failed');
                $error = 2; // Download failed
                $deleted = @unlink(ABS_PATH . '.maintenance');
            }
        } else {
            $message = __('Missing download URL');
            $error = 1; // Missing download URL
            $deleted = @unlink(ABS_PATH . '.maintenance');
        }

        if ($error == 5) {
            $message .= "<br /><br />" . __('We had some errors upgrading your database. The follwing queries failed:') . implode("<br />", $sql_error_msg);
        }

        foreach ($perms as $k => $v) {
            @chmod($k, $v);
        }
    } else {
        $error = 0;
        $message = __('Everything looks good! Your Osclass installation is up-to-date');
    }
    echo '==='.$error.'=='.$message.'===';
}


function upgrade_fix_call_after_uninstall() {
    osc_deleteDir(dirname(__FILE__));
}

// This is needed in order to be able to activate the plugin
osc_register_plugin(osc_plugin_path(__FILE__), 'upgrade_fix_call_after_install');
osc_add_hook(__FILE__ . "_uninstall", 'upgrade_fix_call_after_uninstall');
?>
