<?php
/*
Plugin Name: Links Importer
Plugin URI: http://www.contrib.com/
Description: This plugin import links from csv file
Author: Contrib Development Team
Author URI: http://www.contrib.com/
Plugin update URI: http://contrib.com
*/

   function links_importer_menu() {
        osc_admin_menu_plugins('Links Importer', osc_admin_render_plugin_url('links_importer/admin.php'), 'links_importer_submenu');
    }
    
   function links_importer_actions() {
        $dao_preference = new Preference();
        $option         = Params::getParam('option');

        if( Params::getParam('file') != 'links_importer/admin.php' ) {
            return '';
        }

        if( $option == 'upload' ) {
        	
        	if (is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
	        
	        
	        $handle = fopen($_FILES['csv_file']['tmp_name'], "r");
	        $i=0;
	        $count = 0;
	        
	        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
	        	$mItems = new ItemActions(true);
	        	
	        	$array = array('email'=>'partner@contrib.com','catId'=>$data[2],'title'=>array('en_US'=>$data[0]),'description'=>array('en_US'=>$data[3]),'link'=>$data[1],'logo'=>$data[4]);
                $mItems->generateData( $array );
                $success = $mItems->addcustom();

                    if($success!=1 && $success!=2) {
                        osc_add_flash_error_message( $success);
                    }else {
                    	$i++;
                    }     
                    
                  $count++;  
	        }
	 
	        fclose($handle);
	        osc_add_flash_ok_message(__('Uploaded '.$i.' out of '.$count.' links', 'links_importer'), 'admin');
            osc_redirect_to(osc_admin_render_plugin_url('links_importer/admin.php'));
        	
        	}else {
        		osc_add_flash_error_message(__('No file uploaded'), 'admin');
        	}
        }
    }
    
    osc_add_hook('init_admin', 'links_importer_actions');

    function links_importer_admin() {
        osc_admin_render_plugin('links_importer/admin.php');
    }
    
    osc_add_hook(osc_plugin_path(__FILE__)."_configure", 'links_importer_admin');
    osc_add_hook('admin_menu_init', 'links_importer_menu');
?>