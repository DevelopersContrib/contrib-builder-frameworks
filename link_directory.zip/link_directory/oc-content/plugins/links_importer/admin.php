<h2 class="render-title">Import Links From CSV</h2>
<small><b>Format:</b>Title, Link, Category Id, Description, Logo url</small>
<form action="<?php echo osc_admin_render_plugin_url('links_importer/admin.php'); ?>" method="post" enctype="multipart/form-data">
    <input type="hidden" name="option" value="upload" />
    <fieldset>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label">CSV File</div>
                <div class="form-controls"><input name="csv_file" id="csv_file" type="file"  /></div>
            </div>
            <div class="form-row">
                <div class="form-label">Sample Csv Download</div>
                <div class="form-controls"><a href="/oc-content/uploads/sample_csv.csv">download</a></div>
            </div>
            <div class="form-actions">
                <input type="submit" value="Upload" class="btn btn-submit">
            </div>
        </div>
    </fieldset>
</form>