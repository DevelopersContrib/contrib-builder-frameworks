<?php defined("APP") or die() ?>
<section>
  <div class="calltoaction">
    <div class="container">
      <span><?php echo e("Home") ?> / <?php echo $page->title ?></span>
    </div>
  </div>
  <div class="container">
    <div class="row page">
      <div class="col-md-8">
        <div class="post">
          <h3><?php echo $page->title ?></h3>
          <article>
            <?php 
				$c = preg_replace("/Domain.com/",ucwords($_SERVER['HTTP_HOST']),$page->content);
				$c = preg_replace("/Msurvey.com/",ucwords($_SERVER['HTTP_HOST']),$c);
				
				
				$c = str_replace('\r\n','', $c);
				
				echo $c;
			?>
          </article>
        </div>
      </div>
      <div class="col-md-4 side">
        <?php $this->ads(300) ?>
      </div>
    </div>    
  </div>
</section>