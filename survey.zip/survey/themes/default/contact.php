<?php defined("APP") or die() ?>
<?php global $domain;?>
<section>
	<div class="container">    
		<div class="centered form">
      
     
		<iframe src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?php echo $domain?>" frameborder="0" style="height:500px;width:100%;">
<p><a href="<?php echo $domain ?>"> Contact Us Today
</a></p>
</iframe>
   
		</div>
	</div>
</section>