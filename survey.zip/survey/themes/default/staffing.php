<?php defined("APP") or die() ?>
<?php global $domain;?>
<section>
	<div class="container">    
		<div class="centered form">
      
     
		<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?=$domain?>&f=staffing"></script>
   
		</div>
	</div>
</section>