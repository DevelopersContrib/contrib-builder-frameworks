<?php
echo '<h1>im testpage</h1>';
?>