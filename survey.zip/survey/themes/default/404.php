<?php defined("APP") or die() ?>
<section>
  <div class="container">
  	<div class="centered is404">
			<h1>404</h1>
			<h2>Not Found.</h2>
  	</div>
  </div>
</section>