<?php 
$host="localhost"; 
$root=$cpanel_username; 
$root_password=$cpanel_password; 

$user=$cpanel_username."_dev";
$pass='School3030';


$db=$cpanel_username."_surveys";  			//DOMAIN

if(strlen($cpanel_username)>8){
	$db = substr($cpanel_username, 0, 8)."_surveys";
}



include "xml/cpaneluapi.class.php"; //include the class file
$uapi = new cpanelAPI($cpanel_username, $cpanel_password, $domain); //instantiate the object
$response = $uapi->uapi->Mysql->get_server_information();

$response = $uapi->create_database(['name' => 	$db ]);


// your cPanel username
$cpanel_user = $cpanel_username;

// your cPanel password
$cpanel_pass = $cpanel_password;

// your cPanel skin
$cpanel_skin = 'paper_lantern';

// your cPanel domain
$cpanel_host = 'localhost';

// database username
$db_user = $user;

// database password
$db_pass = $pass;

$site = "https://$cpanel_username:$cpanel_password@localhost:2083/execute/Mysql/";
$result = @file_get_contents("{$site}create_database?name=$db");
$result .= @file_get_contents("{$site}create_user?name={$db_user}&password={$db_pass}");
$result .= @file_get_contents("{$site}set_privileges_on_database?user={$db_user}&database={$db}&privileges=ALL");

// create the database (old method which is now deprecated)
$site = "https://$cpanel_user:$cpanel_pass@localhost:2083/frontend/$cpanel_skin/sql/";
$result = @file_get_contents("{$site}adddb.html?db=$db");
$result .= @file_get_contents("{$site}adduser.html?user={$db_user}&pass={$db_pass}");
$result .= @file_get_contents("{$site}addusertodb.html?user={$cpanel_username}&db={$db}&ALL=ALL");
    
    
$cpanel_skin = 'x3';

$site = "https://$cpanel_username:$cpanel_password@localhost:2083/execute/Mysql/";
$result = @file_get_contents("{$site}create_database?name=$db");
$result .= @file_get_contents("{$site}create_user?name={$db_user}&password={$db_pass}");
$result .= @file_get_contents("{$site}set_privileges_on_database?user={$db_user}&database={$db}&privileges=ALL");

// create the database (old method which is now deprecated)
$site = "https://$cpanel_user:$cpanel_pass@localhost:2083/frontend/$cpanel_skin/sql/";
$result = @file_get_contents("{$site}adddb.html?db=$db");
$result .= @file_get_contents("{$site}adduser.html?user={$db_user}&pass={$db_pass}");
$result .= @file_get_contents("{$site}addusertodb.html?user={$cpanel_username}&db={$db}&ALL=ALL");
try {
	$dbh = new PDO("mysql:host=$host", $cpanel_username, $cpanel_password);
	$dbh->exec("CREATE DATABASE IF NOT EXISTS `$db`;
			CREATE USER '$user'@'localhost' IDENTIFIED BY '$pass';
			GRANT ALL ON `$db`.* TO '$user'@'localhost';
			FLUSH PRIVILEGES;
		 "); 
	 
	//or die(print_r($dbh->errorInfo(), true));
	$output = shell_exec("mysql -u$cpanel_username -p$cpanel_password $db < msurvey.sql");
	//include "execute_sql_file.php"; //temp 
	
} catch (PDOException $e) {
	die("DB ERROR: ". $e->getMessage());
}

 //die();
$conn = new PDO("mysql:host=$host;dbname=$db", $cpanel_username, $cpanel_password);
 
$sql = " Update `setting` set `var`=? where `config`=?";
$q = $conn->prepare($sql);
$q->execute(array('https://'.$sitename,'url')); 

$sql = " Update `setting` set `var`=? where `config`=?";
$q = $conn->prepare($sql);
$q->execute(array($title,'title')); 

$sql = " Update `setting` set `var`=? where `config`=?";
$q = $conn->prepare($sql);
$q->execute(array('social@'.$domain,'email')); 

$sql = " Update `setting` set `var`=? where `config`=?";
$q = $conn->prepare($sql);
$q->execute(array($desc,'description')); 

$sql = " Update `setting` set `var`=? where `config`=?";
$q = $conn->prepare($sql);
$q->execute(array($logo,'logo')); 

$sql = " Update `page` set `content`=? where `id`=?";
$q = $conn->prepare($sql);
$q->execute(array('<p>'.ucwords($domain).' Survey Platform is part of the Global Ventures Network.</p><p>Founded in 1996, Global Ventures is the worlds largest virtual Domain Development Incubator on the planet.</p>\r\n\r\n<p>We create and match great domain platforms like the survey platform with talented people, applications and resources to build successful, value driven, web-based businesses quickly. Join the fastest growing Virtual Business Network and earn Equity and Cowork with other great people making a difference by joining us here at Msurvey.com.</p>',1)); 

/*if(!empty($account_ga)){
	$sql = " Update `setting` set `var`=? where `config`=?";
	$q = $conn->prepare($sql);			
	$q->execute(array($account_ga,'googleanalytics')); 
}*/
?>