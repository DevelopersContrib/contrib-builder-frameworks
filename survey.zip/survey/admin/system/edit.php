<?php if(!defined("APP")) die()?>
<div class="panel panel-default">
  <div class="panel-heading">
    <?php echo $header ?>
  </div>      
  <div class="panel-body">
  	<?php echo $content ?>
  </div>