<?php
 echo phpinfo();
?>