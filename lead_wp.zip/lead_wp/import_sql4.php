<?php

$host="localhost"; 
$root=$cpanel_username; 
$root_password=$cpanel_password; 
$user = substr($cpanel_username,0,8).'_dev';
$passw = 'School3030';
$db = substr($cpanel_username,0,8).'_wp4';
system("mysql -u$user -p$passw $db < wp4.sql"); 

$conn = new PDO("mysql:host=$host;dbname=$db", $user, $passw);

$sql = " UPDATE wp_options SET option_value= replace( option_value, 'https://javapoint.com', 'https://$sitename' ) ;";
$q = $conn->prepare($sql);
$q->execute();

$sql = " UPDATE wp_options SET option_value= replace( option_value, 'https://javapoint.com', 'http://$sitename' ) ;";
$q = $conn->prepare($sql);
$q->execute();

$sql = " UPDATE wp_options SET option_value= replace( option_value, 'Javapoint.com', '$sitename' ) ;";
$q = $conn->prepare($sql);
$q->execute();

$sql = " UPDATE wp_options SET option_value= replace( option_value, 'Javapoint.com', '$sitename' ) ;";
$q = $conn->prepare($sql);
$q->execute();

$sql = " Update `wp_options` set option_value=? where option_name=?";
$q = $conn->prepare($sql);
$q->execute(array($title,'blogname'));

// $sql = " Update `wp_options` set option_value=? where option_name=?";
// $q = $conn->prepare($sql);
// $q->execute(array('/home/'.$cpanel_username.'/public_html/wp-content/uploads/et_temp','et_images_temp_folder'));

// $sql = " Update `wp_options` set option_value=? where option_name=?";
// $q = $conn->prepare($sql);
// $q->execute(array('a:3:{s:5:"state";s:11:"maintenance";s:20:"logged_in_permission";b:1;s:11:"lib_options";a:6:{s:10:"page_title";s:0:"";s:7:"heading";s:'.strlen($sitename).':"'.$sitename.'";s:9:"time_text";s:'.strlen($desc).':"'.$desc.'";s:13:"body_bg_color";s:4:"#fff";s:4:"logo";N;s:7:"body_bg";N;}}','maintenance'));

$sql = " Update `wp_users` set user_login='$wp_uname' where ID='1'";
$q = $conn->prepare($sql);
$q->execute();
   
$sql = " Update `wp_users` set user_pass='$wp_pass' where ID='1'";
$q = $conn->prepare($sql);
$q->execute();


// if($mc_theme==''){
	// $mc_theme = 'TheCorporation2';
// }
// $sql = " Update `wp_options` set option_value=? where option_name=?";
// $q = $conn->prepare($sql);
// $q->execute(array($mc_theme,'template'));

// $sql = " Update `wp_options` set option_value=? where option_name=?";
// $q = $conn->prepare($sql);
// $q->execute(array($mc_theme,'stylesheet'));

// $sql = " Update `wp_options` set option_value=? where option_name=?";
// $q = $conn->prepare($sql);
// $q->execute(array($mc_theme,'current_theme')); 
		   
		  
	
      
	  
 
?>