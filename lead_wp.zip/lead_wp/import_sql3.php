<?php
$host="localhost"; 
$root=$cpanel_username; 
$root_password=$cpanel_password; 

$user=$cpanel_username."_maida";
$pass='bing2k';

if($flag_sub==1)
	$db=$cpanel_username."_wp3_".$subname; //SUBDOMAIN
else
	$db=$cpanel_username."_wp3"; 			//DOMAIN

$curl = "https://$cpanel_username:$cpanel_password@localhost:2083/frontend/x3/sql/addb.html?db=$db";
@file_get_contents($curl);


    try {
        $dbh = new PDO("mysql:host=$host", $cpanel_username, $cpanel_password);

        $dbh->exec("CREATE DATABASE IF NOT EXISTS `$db`;
                CREATE USER '$user'@'localhost' IDENTIFIED BY '$pass';
                GRANT ALL ON `$db`.* TO '$user'@'localhost';
                FLUSH PRIVILEGES;
             "); 
        
        //or die(print_r($dbh->errorInfo(), true));
        
       system("mysql -u$cpanel_username -p$cpanel_password $db < wp3.sql");     

    } catch (PDOException $e) {
        die("DB ERROR: ". $e->getMessage());
    }
    
    
       $conn = new PDO("mysql:host=$host;dbname=$db", $cpanel_username, $cpanel_password);

     /*  $sql = " Update `wp_options` set option_value=? where option_name=?";
	   $q = $conn->prepare($sql);
	   $q->execute(array('http://'.$sitename,'siteurl'));
 
	   $sql = " Update `wp_options` set option_value=? where option_name=?";
	   $q = $conn->prepare($sql);
	   $q->execute(array('http://'.$sitename,'home'));*/
	   
	   $sql = " UPDATE wp_options SET option_value= replace( option_value, 'Venturepoints.com', '$sitename' ) ;";
	   $q = $conn->prepare($sql);
	   $q->execute();
        
	   $sql = " UPDATE wp_options SET option_value= replace( option_value, 'venturepoints.com', '$sitename' ) ;";
	   $q = $conn->prepare($sql);
	   $q->execute();
	   
	   $sql = " Update `wp_options` set option_value=? where option_name=?";
	   $q = $conn->prepare($sql);
	   $q->execute(array($title,'blogname'));
	   
	   $sql = " Update `wp_options` set option_value=? where option_name=?";
	   $q = $conn->prepare($sql);
	   $q->execute(array('/home/'.$cpanel_username.'/public_html/wp-content/uploads/et_temp','et_images_temp_folder'));
	   
	   $sql = " Update `wp_options` set option_value=? where option_name=?";
	   $q = $conn->prepare($sql);
	   $q->execute(array('a:3:{s:5:"state";s:11:"maintenance";s:20:"logged_in_permission";b:1;s:11:"lib_options";a:6:{s:10:"page_title";s:0:"";s:7:"heading";s:'.strlen($sitename).':"'.$sitename.'";s:9:"time_text";s:'.strlen($desc).':"'.$desc.'";s:13:"body_bg_color";s:4:"#fff";s:4:"logo";N;s:7:"body_bg";N;}}','maintenance'));

		$sql = " Update `wp_users` set user_login='$wp_uname' where ID='1'";
		$q = $conn->prepare($sql);
		$q->execute();
		   
		$sql = " Update `wp_users` set user_pass='$wp_pass' where ID='1'";
		$q = $conn->prepare($sql);
		$q->execute();


	  if($mc_theme==''){
			$mc_theme = 'TheCorporation2';
	   }
		   $sql = " Update `wp_options` set option_value=? where option_name=?";
		   $q = $conn->prepare($sql);
		   $q->execute(array($mc_theme,'template'));
		   
		   $sql = " Update `wp_options` set option_value=? where option_name=?";
		   $q = $conn->prepare($sql);
		   $q->execute(array($mc_theme,'stylesheet'));
		   
		   $sql = " Update `wp_options` set option_value=? where option_name=?";
		   $q = $conn->prepare($sql);
		   $q->execute(array($mc_theme,'current_theme')); 
		   
		  
	
      
	  
 
?>