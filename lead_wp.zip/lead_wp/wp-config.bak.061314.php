<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */
global $title, $logo, $desc, $bg_type, $bg_color, $bg_image, $image_style, $about_desc;

 function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}

 
$headers = array('Accept: application/json');
$api_url = "http://www.contrib.com/api/";
$sitename =  $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];

if(stristr($sitename, '~') ===FALSE) {
	$sitename = $_SERVER["HTTP_HOST"];								
	$sitename = str_replace("http://","",$sitename);
	$sitename = str_replace("www.","",$sitename);	
}else {
   $key = md5('vnoc.com');
   $d = explode('~',$sitename);
   $user = str_replace('/','',$d[1]);
   $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
   $result =  createApiCall($url, 'GET', $headers, array());
   $data_domain = json_decode($result,true);
   $error = 0;
   $sitename =   $data_domain[0]['domain'];
}



//input sitename without www | http:
$string_tmp = explode(".",$sitename ); 					
$subname = $string_tmp[0];											//gets subdomain name
$subdomain = str_replace($subname.".","",$sitename);				
$domainTMP = substr($subdomain, 0, strpos($subdomain, "."));		//removing .com |.net |.org etc	
				 
if($domainTMP!=""){
	$flag_sub = 1;	//if SUBDOMAIN
	$site_host = $subdomain;
}else{
	$flag_sub = 0;	//if DOMAIN
	$site_host = $sitename;
}

$key = md5($site_host);



$url = $api_url.'getdomaininfo?domain='.$sitename.'&key='.$key; //gets domain|subdomain data
$result =  createApiCall($url, 'GET', $headers, array());
$data_domain = json_decode($result,true);
$error = 0;
if (!$data_domain['error'])
{
	$domainid = $data_domain[0]['DomainId'];
	$domainname = $data_domain[0]['DomainName'];
	$title = $data_domain[0]['Title'];
	$logo = $data_domain[0]['Logo'];
	$desc = $data_domain[0]['Description'];
	$account_ga = $data_domain[0]['AccountGA'];
	
}else {
	$error++;
}

$url = $api_url.'getcpanelinfo?domain_id='.$domainid.'&key='.$key;
$result =  createApiCall($url, 'GET', $headers, array());
$data_cpanel = json_decode($result,true);
if (!$data_cpanel['error'])
{
	$cpanel_username = $data_cpanel[0]['Username'];
	$cpanel_password = $data_cpanel[0]['Password'];
}else{
	$error++;
}

$url = $api_url.'getdomainattributes?domain='.$domainname.'&key='.$key; //gets domain|subdomain WP Lead background data
$result =  createApiCall($url, 'GET', $headers, array());
$data_wplead = json_decode($result,true);
 
if (!isset($data_wplead['error']))
{
	
	$bg_image = $data_wplead[0]['background_image_url'];				
    $wp_uname = $data_wplead[1]['wp_admin_username'];
	$wp_pass = md5($data_wplead[2]['wp_admin_password']);
	$forsale = $data_wplead[3]['show_for_sale_banner'];
	$forsaletext = $data_wplead[4]['for_sale_text'];
	
	if($forsaletext=='') $forsaletext = 'This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.';
	
	$bg_type = "image";
	$image_style = "no-repeat";					
}else {
	$error++;
}

if($wp_uname=='') $wp_uname = 'admin';
if($wp_pass=='' || str_replace(' ','',$wp_pass)=='') $wp_pass = 'school3030';

//get monetize ads from vnoc
$url = $api_url.'getbannercode?d='.$sitename.'&p=footer';
$result =  createApiCall($url, 'GET', $headers, array());
$data_ads = json_decode($result,true);
//$footer_banner = html_entity_decode(base64_decode($data_ads[0]['code']));
$footer_banner = "";


//get number of leads for counter
$url = $api_url.'getdomainleadscount?domain='.$sitename.'&key='.$key;
$result =  createApiCall($url, 'GET', $headers, array());
$data_follow_count = json_decode($result,true);
if (!$data_follow_count['error'])
       {
       	$follow_count = ($data_follow_count[0]['total'] + 1 ) * 25;
       }else {
       	$follow_count = 1 * 25;
       }

	   
//get domain affiliate id
$url = $api_url.'getdomainaffiliateid?domain='.$sitename.'&key='.$key;
$result =  createApiCall($url, 'GET', $headers, array());
$data_domain_affiliate = json_decode($result,true);
if (!$data_domain_affiliate['error']){
	$domain_affiliate_id = $data_domain_affiliate['affiliate_id'];
}else {
	$domain_affiliate_id = '391'; //contrib.com affiliate id
}
$domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$domain;
 	   
	   
	   

if ($error > 0){
	 echo "<center><h3>Problem with Api</h3></center>";
	 exit;
}



$filename = 'import_sql.php';

if ($site_host!='contrib.com' && file_exists($filename)) {

    include('import_sql.php'); //creates DB
	
	unlink($filename); //deletes file
}


// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
if($flag_sub==1)
	define('DB_NAME', $cpanel_username.'_wp_'.$subname);	//if SUBDOMAIN
else
	define('DB_NAME', $cpanel_username.'_wp');				//if DOMAIN
	

/** MySQL database username */
define('DB_USER', $cpanel_username);

/** MySQL database password */
define('DB_PASSWORD', $cpanel_password );

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'a}ot!nz|V;Q-zIU_|+|PnD7GD-*#%iBF0Tv8QbrIkn?_ f{*{U(|JS]?D-, +.AH');
define('SECURE_AUTH_KEY',  'gX$pgLp^a~_E)KPe67jHQC_~l&A+f@Gw(o|S(O/=5sP_3JxuCc^2|!VeE8u7jB)C');
define('LOGGED_IN_KEY',    'MIXvZ5_#E?J{!dy7HzpZ>UnE| xyxHh&Svy|MQc0Ecv[#zBbW!-cHw+H@p!IEyR-');
define('NONCE_KEY',        'k`ke jr+]>*Gw|E3o<,70{_fZeEy07w+`&0&GuM[dMI|_Po9]jYx5h{}bIezHD  ');
define('AUTH_SALT',        'PqjDd-L$~@u+(m?ikkTsBzUmzBN8Ttlw8aem3.O{Q(_Z~h$|@NnLg:g?ZT:.G?^E');
define('SECURE_AUTH_SALT', '<wFd^}._Bp)q]^9Of.>|lv7>lZ*N^V<q -#eN}4xWBWb s-Lx>:>)[=1O#Ac|%yt');
define('LOGGED_IN_SALT',   'P.&4[>jxIy/F9XA5@3hA3pe03k&m(Vq]y#&?WdzX[NQ4D~*tlEycxX&|+.~Sk|nf');
define('NONCE_SALT',       'TwZozr*kdm{s+:-ce)JNfH*gG}Ev#s1l2||u-j%OasE.W$|LaM4pi0gRIv+Q/>q3');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');