
<? include('header.php'); ?>

<style>
body {
	background: url('http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/lead_bg.jpg');
	background-size:cover;
	background-attachment:fixed;
}
.overflow-ad {
	background: none repeat scroll 0px 0px rgba(0, 0, 0, 0.7);
	margin-top:30px;
	margin-bottom:30px;
}
.devpage {
	margin-bottom:150px;
	margin-top:150px;
	background: none repeat scroll 0px 0px rgba(0, 0, 0, 0.7);
	color:#fff;
}
</style>

<div class="container devpage">
	<div class="row">
		<div class="col-md-12">
			<h2><i class="fa fa-code"></i>&nbsp;Are you a Developer?</h2>
			<div class="devbox">
				<p class="devdesc"><i class="fa fa-rocket"></i>&nbsp;Do you have code or an app that could run this brand? Interpricing.com is connected with Contrib. </p>
				<p class="devdesc"><i class="fa fa-rocket"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run Interpricing.com? </p>
				<p class="proceedto"><a href="/contact.html" class="btn btn-success">Inquire Here</a></p>
			</div>
		</div>
	</div>
</div>

<? include('footer.php'); ?>

<style>
.arrw-rela {
	display:none;
}
</style>