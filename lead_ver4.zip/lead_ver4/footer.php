			<div class="new-footer">
            <div class="container">
                <div class="pull-left">
                    <ul class="list-inline new-nav new-footer-nav">
                        <li>
                            <span class="domain-name-muted">CONTRIB &trade;</span>
                        </li>
                    </ul>
                </div>
                <div class="pull-right">
                    <ul class="list-inline new-nav new-footer-nav">
                        <li><a href="http://<?=$domain?>">Home</a></li>   
                        <li><a href="contact.html">Contact us</a></li>  
                        <li><a href="partner.html">Partner with us</a></li>
                        <li><a href="apply.html">Apply now </a></li>
                        <li><a href="terms.html">Terms </a></li>
                        <li><a href="inquire.html">Inquire</a></li>
                        <li><a href="referral.html">Referral</a></li>
                        <li><a href="fundpage.html">Fund</a></li>
                        <li><a href="developers.html">Developer</a></li>
						
                    </ul>
                </div>
            </div>
        </div>
        <div class="colophon text-center">
            &copy; <?=ucwords($domain)?> 2013 - 2016<br>
			<?=$footer_banner?>
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
            <script src="https://code.jquery.com/jquery.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
            <!--script src="js/bootstrap.min.js"></script-->
			<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
			<script src="js/lead.js" type="text/javascript"></script>
			<script src="js/jquery.counter.js" type="text/javascript"></script>
			<script type="text/javascript">
			  var _gaq = _gaq || [];
			  _gaq.push(['_setAccount', '<?=$account_ga?>']);
			  _gaq.push(['_trackPageview']);

			  (function() {
				var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
				ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			  })();
			</script>
			<script type="text/javascript">
				$(function(){
					var domain_name = $('#domain').val();
	
					getsocial(domain_name,'fb','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251686_facebook_circle_color.png');
					getsocial(domain_name,'twitter','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251704_twitter_circle_color.png');
				});
				
				function getsocial(domain_name,social,icon_src){
	
					$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
									var socialdata = data[0];
									if(socialdata.error == true){
										//do nothing
									}else if(socialdata.profile_url == ""){
										//do nothing
									}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
										//do nothing
									}else{
										$('#socials_container').append('&nbsp;<a href="'+socialdata.profile_url+'"><img src="'+icon_src+'" height="40px"></a>&nbsp;');
										$('span#follow_us').text("Follow us  ");
									}		
					});
				}
				
			</script>
    </body>
</html>
