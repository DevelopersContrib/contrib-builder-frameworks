<?php include('header.php'); ?>
<style>
body {
	background: url('http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/lead_bg.jpg');
	background-size:cover;
	background-attachment:fixed;
}
.overflow-ad {
	background: none repeat scroll 0px 0px rgba(0, 0, 0, 0.7);
	margin-top:30px;
	margin-bottom:30px;
}
</style>
<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap-responsive.css"/>

<div class="container-fluid lead-reset-padd" >
	<div class="row-fluid">
		<div class="wrap-ad" style="margin-bottom: 20px;">
			<div class="container overflow-ad">
				<div class="row-fluid">
					<div class="content-ad">
						<div style="margin-top: -40px;">
							<h4>Learn more about Joining our Partner Network</h4>
						</div>
						
						<div class="section-heading-ttle text-left">
							<h2 style="padding-left:0;"><span id="_title">TERMS OF USE</span></h2>							
						</div>
						
						<div class="row-fluid">
							<div class="span12">
								<div id="f_terms" style="text-align: left;">

									<?php 
									   $api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
									  $url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=terms';
									  $result =  createApiCall($url, 'GET', $headers, array());
									  $data_domain = json_decode($result,true);
									  if (isset($data_domain['data']['content'])){
									   $terms =   $data_domain['data']['content'];
									  }else {
									    $terms = "";
									  }

									  echo $terms;
									?>

								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--3rd section-->



<?php include('footer.php'); ?>