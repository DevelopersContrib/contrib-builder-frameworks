<?php

function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}

    $api_url = "http://api3.contrib.co/request/";
    $api_url1 = "http://api1.contrib.co/request/";
    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $key = md5('vnoc.com');
    $monetize_url = "http://manage.vnoc.com/monetize/getcode";
    $error = 0;


  
     if(stristr($domain, '~') ===FALSE) {
			$domain = $_SERVER["HTTP_HOST"];
		    $domain = str_replace("http://","",$domain);
			$domain = str_replace("www.","",$domain);
			$key = md5($domain);
		}else {
		    $key = md5('vnoc.com');
            $d = explode('~',$domain);
            $user = str_replace('/','',$d[1]);
            $host = $_SERVER["HTTP_HOST"];
		    $host = str_replace("http://","",$host);
		    $host = str_replace("www.","",$host);
		    $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key.'&host='.$host;
            $result =  createApiCall($url, 'GET', $headers, array());
            $data_domain = json_decode($result,true);
            $error = 0;
            $domain =   $data_domain['data']['domain'];
		}




        $data_domain = NULL;
        while ($data_domain == NULL){
           $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
           $result = createApiCall($url, 'GET', $headers, array());
           $data_domain = json_decode($result,true);
        }
        
        
    if ($data_domain['success']){
	$domainid = $data_domain['data']['DomainId'];
	$domainname = $data_domain['data']['DomainName'];
	$memberid = $data_domain['data']['MemberId'];
	$title = $data_domain['data']['Title'];
	$logo = $data_domain['data']['Logo'];
	$description = $data_domain['data']['Description'];
	$account_ga = $data_domain['data']['AccountGA'];
	
	$description = stripslashes(str_replace('\n','<br>',$description));
			

			
	$url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
    $result2 = createApiCall($url2, 'GET', $headers, array());
    $data_domain2 = json_decode($result2,true);
			
    if($data_domain2['success']){
		$background_image = $data_domain2['data']['background_image_url'];
		$top_description = $data_domain2['data']['top_description'];
		$bottom_text = $data_domain2['data']['bottom_text'];
		$background_type = '';
		$background_color = '';		
		$image_style = '';
		
		$top_description = stripslashes(str_replace('\n','<br>',$top_description));
		
		$forsale =$data_domain2['data']['show_for_sale_banner'];
		$forsaledefault =$data_domain2['data']['show_for_sale_banner_DefaultValue'];
		$forsaletext = $data_domain2['data']['for_sale_text'];
	
		if($forsaletext=='') $forsaletext = 'This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.';
	
		
	}else{
		$error++;
	}
			
}else {
	$error++;
}

/**
	get team members from vnoc
**/
/**
	identify if url is subdomain.
**/
$team_domain_name = $domain;
$domain_parts = explode('.',$domain);
	if(sizeof($domain_parts) == 3 ){
		$team_domain_name = $domain_parts[1].".".$domain_parts[2];
	}

	
$inProductionArray = array(
						array("domain"=>'referrals.com',"logo"=>'http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png',"thumb"=>'http://www.globalventures.com/wp-content/uploads/2012/05/2012-07-21_1006-228279_185x185.png',"desc"=>'<strong>Most effective Business Referral Program and Tools Available.</strong> <br>Find and share referrals locally.'),
						array("domain"=>'contrib.com',"logo"=>'http://assets.zipsite.net.s3.amazonaws.com/contrib/logo-contrib-tm-ver-4.png',"thumb"=>'http://www.globalventures.com/wp-content/uploads/2013/11/contrib-small.jpg',"desc"=>'<strong>What is Contrib? Launching a business in 8 weeks is now possible with the right mix of people, product, and premium domains.</strong> <br>Find your dream brand and build it with Contrib line of frameworks.'),
						array("domain"=>'photostream.com',"logo"=>'http://www.beta.photostream.com/img/logo-photostream.png',"thumb"=>'http://d2qcctj8epnr7y.cloudfront.net/sheina/drop-shad-photostream.png',"desc"=>'<strong>Join, Love and Share Photo Stream.</strong> <br>Create your own Stream with your friends, team or family. Make it private or public. Up to 250mb per stream for free and up to 2 streams per user.Your choice!')
					);	
shuffle($inProductionArray);	
	
$url3 = $api_url.'getTeamPerDomain?domain_name='.$inProductionArray[0]['domain'];
$result3 =  createApiCall($url3, 'GET', $headers, array());
$data_team = json_decode($result3,true);
$teams = array();

if($data_team['success']){
	$team_cnt = sizeof($data_team['data']);
	$data_team = $data_team['data'];
	for($_cnt=0;$_cnt<$team_cnt;$_cnt++){
		$teams[$_cnt]['firstname'] = $data_team[$_cnt]['firstname'];
		$teams[$_cnt]['lastname'] = $data_team[$_cnt]['lastname'];
		$teams[$_cnt]['picture'] = $data_team[$_cnt]['picture'];
		$teams[$_cnt]['teamid'] = $data_team[$_cnt]['teamid'];
		$teams[$_cnt]['role'] = $data_team[$_cnt]['teamid'];
	}
}else{
	$error++;
}


//get number of TEAM domain leads for counter
$urlTeam = $api_url.'getdomainleadscount?domain='.$inProductionArray[0]['domain'].'&key='.$key;
$resultTeam =  createApiCall($urlTeam, 'GET', $headers, array());
$team_follow_count = json_decode($resultTeam,true);
if ($team_follow_count['success'])
       {
       	$follow_count_team = ($team_follow_count['data']['leads'] + 1 ) * 25;
       }else {
       	$follow_count_team = 1 * 25;
       }





//get monetize ads from vnoc
$url = $api_url1.'getbannercode?d='.$domain.'&p=footer';
$result = createApiCall($url, 'GET', $headers, array());
$data_ads = json_decode($result,true);
//$footer_banner = html_entity_decode(base64_decode($data_ads['data']['content']));
$footer_banner = '<iframe id="a33aac4a" name="a33aac4a" src="http://ecorp.com/adserver/www/delivery/afr.php?zoneid=4&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;ct0=INSERT_ENCODED_CLICKURL_HERE" frameborder="0" scrolling="no" width="728" height="80">&lt;a href="http://ecorp.com/adserver/www/delivery/ck.php?n=a2e1eadf&amp;cb=INSERT_RANDOM_NUMBER_HERE" target="_blank"&gt;&lt;img src="http://ecorp.com/adserver/www/delivery/avw.php?zoneid=4&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a2e1eadf&amp;ct0=INSERT_ENCODED_CLICKURL_HERE" border="0" /&gt;&lt;/a&gt;</iframe>';

//get piwik id
$url3 = $api_url1.'GetPiwikId?domain='.$domain.'&key='.$key;
$result3 = createApiCall($url3, 'GET', $headers, array());
$data_domain3 = json_decode($result3,true);
$piwik_id = $data_domain3['data']['idsite'];


//get number of domain leads for counter
$url = $api_url.'getdomainleadscount?domain='.$domain.'&key='.$key;
$result =  createApiCall($url, 'GET', $headers, array());
$data_ads = json_decode($result,true);
$data_follow_count = json_decode($result,true);
if($data_follow_count['success']){
	$follow_count = ($data_follow_count['data']['leads'] + 1 ) * 25;
}else{
	$follow_count = 1 * 25;
}
	   

 //get domain affiliate id
$url = $api_url.'getdomainaffiliateid?domain='.$domain.'&key='.$key;
$result =  createApiCall($url, 'GET', $headers, array());
$data_ads = json_decode($result,true);
$data_domain_affiliate = json_decode($result,true);
if ($data_domain_affiliate['success']){
	$domain_affiliate_id = $data_domain_affiliate['data']['affiliate_id'];
}else {
	$domain_affiliate_id = '391'; //contrib.com affiliate id
}
$domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$domain;
 
//partners
	
	$url = $api_url.'getpartners?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $partners_result = json_decode($result,true);
    $approved_partner = "";
	
    if ($partners_result['success']){
		$approved_partner = $partners_result;
    }
	
	   //get related domains
		$url = $api_url.'getrelateddomains?domain='.$domain.'&limit=15';
		$result = createApiCall($url, 'GET', $headers, array());
		$data_domains = json_decode($result,true);
    	if ($data_domains['success']){
    		$related_domains = $data_domains['data'];
    	}
	 
      //get fund campaigns
		$url = $api_url.'getfundcampaigns';
		$result = createApiCall($url, 'GET', $headers, array()); 
		$items = json_decode($result,true);
		if ($items['success']){
    		$campaigns = $items['data'];
		}

/*constants
 to all lead templates
*/

/*
$host = "domaindirectory.com";
$user = "domaindi_maida";
$pwd = "bing2k";
$db = "domaindi_sites";

$link = mysql_connect($host, $user,$pwd);
if (!$link) {
   echo "Error establishing connection.";
}

	$db_selected = mysql_select_db($db, $link);
*/
	/**
		generate robots.txt if not exist
	**/
	$filename = '/robots.txt';
	//if(!(file_exists($filename))) {
		$my_file = 'robots.txt';
		$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
		$data = '---BEGIN ROBOTS.TXT ---
	User-Agent: *
	Disallow:

	Sitemap: http://'.$domain.'/sitemap.html
	--- END ROBOTS.TXT ----';
		fwrite($handle, $data);
	//}

?>