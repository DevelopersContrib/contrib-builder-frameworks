<? include('header.php'); ?>
<style>
.j-bck {
	background-size:cover;
	position: relative;
	padding: 100px 0px 70px;
}
.bg-overlay {
    background-color: rgba(19, 19, 21, 0.7);
    bottom: 0;
    left: 0;
    position: absolute;
    right: 0;
    top: 0;
}
.arrw-rela {
	position: relative;
}
.arrw-point-white {
	background: url("http://d2qcctj8epnr7y.cloudfront.net/contrib/arrow-1-medium.png") no-repeat scroll 0 0 rgba(0, 0, 0, 0);
	height: 92px;
	left: -126px;
	position: absolute;
	top: 10px;
	width: 100px;
}
</style>
<div class="jumbotron j-bck">
	<div class="bg-overlay"></div>
    <div class="container" style="position:relative;">
        
        <!-- CONTRIB BADGE -->				
        <div style="position:relative;">
            <div style="position: absolute; z-index: 10; top: -15px; left: -200px;" class="animated rotateIn r-d">
                <a href="<?=$domain_affiliate_link?>" target="_blank" alt="Contrib.com">
                    <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-3.png" alt="Contrib.com" title="Contrib.com">
                </a>
            </div>
        </div>
        <!-- END CONTRIB BADGE -->
        
        <div class="row">
			<div class="col-md-6">
				<div class="col-left">
					<h1>
						<? if($description!=''){
						echo stripslashes(str_replace('\n','<br>',$description));
						}else if(str_replace(' ','',$top_description)!=''){
							echo stripslashes(str_replace('\n','<br>',$top_description));
						}else{
							echo 'Learn more about Joining our Partner Network.';
						} ?>
					</h1>
					<div class="arrw-rela">
                        <div class="arrw-point-white">
                            
                        </div>
                    </div>
                    <form id="leadform" style="margin: 0;">
                        <div class="input-group wrap-email-input input-group-lg has-success">
                            <input type="text" class="form-control" id="email" placeholder="email@yahoo.com" />
                            <input type="text" class="form-control" id="secret" name="secret" value="" style="display:none;" />
                            <input type="hidden" id="refid" value="0">
                            <input type="hidden" id="domain" value="<?php echo $domain?>">
                            <input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
                            <span class="input-group-btn">
                                <button class="btn btn-success" id="submitLead" type="button" style="font-size: 15px;">Join Now!</button>
                            </span>									
                        </div><!-- /input-group -->
                    </form>
					<center style="margin: 15px 30px 20px 30px;">
                        <span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999999" data-stop="<?=$follow_count?>">
                            <span class="part part0">
                                <?
									$count = 7;
									$digits = strlen($follow_count);
									$splittedString = str_split($follow_count);
									for($i=$count; $i>0; $i--){
										if($i==$digits){
											for($j=0;$j<$digits;$j++){						
												echo '<span class="digit digit'.$splittedString[$j].'"></span>';
											}	
											break;					
										}else{
											echo '<span class="digit digit0"></span>';
										}
									}
                                ?>
                            </span>	
                        </span>
                    </center>
				</div>
				<table style="border:0px;width: 350px;margin: 0 auto;">
                        <tr>
                            <td valign='top' style='width:15%;'>
                                <script src="http://platform.linkedin.com/in.js" type="text/javascript"></script>
                                <script type="IN/Share" data-url="http://www.linked.com"></script>
                            </td>
                            <td valign='top' style='width:85%;'>
                                
                                <!-- AddThis Button BEGIN -->
                                <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
                                    <a class="addthis_button_preferred_1"></a>
                                    <a class="addthis_button_preferred_2"></a>
                                    <a class="addthis_button_preferred_3"></a>
                                    <a class="addthis_button_preferred_4"></a>
                                    <a class="addthis_button_compact"></a>
                                    <a class="addthis_counter addthis_bubble_style"></a>
                                </div>
                                <script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
                                <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>
                                <!-- AddThis Button END -->
                            </td>    
                        </tr>
                </table>					
					<div id="socials_container" style="text-align:center;margin-top:20px"><span id="follow_us"></span>&nbsp;</div>
			</div>
			<div class="col-md-6">
				<div class="col-right">
					<a href="javascript:;" class="pull-right i-t-img" style="height: 255px; margin: 25px 0 0 0;">
						<iframe width="420" height="250" src="//www.youtube.com/embed/vIFRu6BdChI" frameborder="0" allowfullscreen></iframe>
					</a>
				</div>
			</div>
            
        </div> 
        
        <div class="row">
            <div class="col-lg-12" id="leadcontent">
                
            </div>
        </div>
    </div>
</div>
<div class="sec">
    <div class="container">
        <div class="feature feature-left feature-treasure">
            <h3>Contribute</h3>
            <p>Contribute using your skills, services, apps and/or capital. Contribute to great apps powering some of the worlds best domains.</p>
        </div>
        <div class="feature feature-right feature-people">
            <h3>Create Value</h3>
            <p>Amazing things happen with the right people, technology, concept and resources. From equity ownership, great people creating synergy, or the 2% of shares going to charity, Contrib members focus on creating Value.</p>
        </div>
        <div class="feature feature-left feature-chair">
            <h3>Browse our Marketplace</h3>
            <p>Browse our assets marketplace, work with great people, share in the success.</p>
        </div>
    </div>
</div>
<div class="sec l-r-b l-n-h-p">
    <div class="text-center m-b">
        <h5 style="margin: 0 0 25px;">Get Involved with Brands that are in Production</h5>
        <h2><img src="<?=$inProductionArray[0]['logo']?>" alt="<?=ucwords($inProductionArray[0]['domain'])?>" title="<?=ucwords($inProductionArray[0]['domain'])?>" style="width: 400px;"></h2>
        <p><?=$inProductionArray[0]['desc']?></p>
        <p></p>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-lg-12">
                <div class="row">
                    
                    <? 
                                    $leftbox = '';
$rightbox = '';
for($i=0; $i<sizeof($teams); $i++){	
    if($i==6) break;
    
    if($teams[$i]['picture']=='') $teamPhoto = 'http://manage.vnoc.com/images/avatar2.png';
    else $teamPhoto = 'http://manage.vnoc.com/uploads/picture/'.$teams[$i]['picture'];
    
    $box = '
										<div class="user-m user-m-l">
                                            <div class="cntbtr cl text-right">
                                                <div class="avatar">
                                                    <img src="'.$teamPhoto.'" alt="'.ucwords($teams[$i]['firstname'].' '.$teams[$i]['lastname']).'" title="'.ucwords($teams[$i]['firstname'].' '.$teams[$i]['lastname']).'" style="height: 100%;" >
                                                </div>
                                                <div class="details">
                                                    <div class="username">'.ucwords($teams[$i]['firstname'].' '.$teams[$i]['lastname']).'</div>
                                                    <span class="stake">'.ucwords($teams[$i]['role']).'</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
									';
    
    if($i%2==0){
        $leftbox .= $box ;
    }else{
        $rightbox .= $box;
    }							
} 
                    ?>
                    
                    
                    <div class="sec psn-r n-p-clear spot-clear" style="padding-top: 30px;">
                        <div class="col-xs-4 col-sm-4 col-lg-4">
                            <div class="contributor-c-l">									
                                <?=$leftbox?>
                            </div><!-- Left Column -->
                        </div>
                        <div class="col-xs-4 col-sm-4 col-lg-4">
                            <div class="center-column" style="margin-left: 16px;">
                                <a href="http://<?=$inProductionArray[0]['domain']?>" target="_blank" class="idea-card card">
                                    <div class="hi glw g-d" style="padding: 5px;">
                                        <img src="<?=$inProductionArray[0]['thumb']?>" alt="<?=ucwords($inProductionArray[0]['domain'])?>" title="<?=ucwords($inProductionArray[0]['domain'])?>">
                                    </div>
                                    <div class="details">
                                        <div class="pitch" style="text-align:center"><?=ucwords($inProductionArray[0]['domain'])?><br>Team Members<br>and Followers</div>                                                
                                    </div>
                                    <center style="margin: 15px 30px 20px 30px;">
                                        <span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999999" data-stop="<?=$follow_count_team?>">
                                            <span class="part part0">
                                                <?
                        $count = 7;
$digits = strlen($follow_count_team);
$splittedString = str_split($follow_count_team);
for($i=$count; $i>0; $i--){
    if($i==$digits){
        for($j=0;$j<$digits;$j++){						
            echo '<span class="digit digit'.$splittedString[$j].'"></span>';
        }	
        break;					
    }else{
        echo '<span class="digit digit0"></span>';
    }
}
                                                ?>
                                            </span>	
                                        </span>
                                    </center>
                                </a>										
                            </div><!-- Left Column -->
                        </div>
                        <div class="col-xs-4 col-sm-4 col-lg-4">
                            <div class="contributor-c-r">
                                <? $rightbox = str_replace('user-m-l','user-m-r',$rightbox); ?>
                                <?=str_replace('cl text-right','cr text-left',$rightbox)?>
                            </div><!-- Right Column -->
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>
</div>
<div class="sec">
    <div class="container">
        <div class="sec-heading">
            <h1 class="ttle text-center">
                Upcoming Ideas
            </h1>
            <!--a href="#" class="btn  btn-gray pull-right">See all ideas</a-->
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-lg-12 thum-m-b">
                <div class="row">
                    
                    <?
                                                    $ideasArray = array
                                                    (
                                                    array("domain"=>"micromarkets.com","thumb"=>"http://www.globalventures.com/wp-content/uploads/2012/04/micromarkets-300x192.png","desc"=>"Choose your Micro Market, Create Micro Jobs  and Sell your products and Services - Micro markets is a Job Centre - Buy and Sell your products and services to your chosen local micro markets. Post a Job for your small services for free - Micro Markets"),
                                                    array("domain"=>"photostream.com","thumb"=>"http://d2qcctj8epnr7y.cloudfront.net/images/lucille/photostream2-300x192.png","desc"=>"Have a funny or unique Photo taken from your SmartPhone? Register Now for free to Win amazing Prizes in our 2013 PhotoChallenge, Sponsored by PhotoStream. Submit photos to win challenges today!"),
                                                    array("domain"=>"socialid.com","thumb"=>"http://d2qcctj8epnr7y.cloudfront.net/images/lucille/socialid-300x192.png","desc"=>"SocialID helps you get the social name for all major social networking websites."),
                                                    array("domain"=>"mergers.com","thumb"=>"http://www.globalventures.com/wp-content/uploads/2012/08/mergers-edited1.png","desc"=>"Launched in November 2012, Mergers.com is an online portal about the international Mergers & Acquisitions market. Stay updated about the latest transactions and check our monthly tips about how to get your Investment Banking career started; Mergers.com provide the most accurate informations on the latest deals."),
                                                    array("domain"=>"applications.net","thumb"=>"http://www.globalventures.com/wp-content/uploads/2012/08/applications-300x192.jpg","desc"=>"If you think you got the best website, or if you want to discuss problems and want to get the best out of a free developer community, then Applications.net is your key.")										   
                                                );

shuffle($ideasArray);
$ideacnt=0;							
foreach($ideasArray as $idea){
    $ideacnt++;
                    ?>
                    <div class="col-xs-4 col-sm-4 col-lg-4">
                        <a class="a-link" href="http://<?=$idea['domain']?>" target="_blank">
                            <div class="thumbnail">
                                <img src="<?=$idea['thumb']?>" alt="<?=ucwords($idea['domain'])?>" title="<?=ucwords($idea['domain'])?>"/>
                                <div class="caption">
                                    <h3><?=ucwords($idea['domain'])?></h3>
                                    <div style="text-align: justify;"><?=$idea['desc']?></div>
                                </div>
                            </div>
                        </a>
                    </div>
                    
                    <?
                        if($ideacnt==3) break;
}
                    ?>
                    
                </div>
            </div>
        </div>
        
        
    </div>
</div>
<div class="doodad"></div>
<div class="sec">
    <div class="container">
        <div class="feature feature-right feature-ideas">
            <h3>Have an idea for <?=ucwords($domain)?>?</h3>
            <p>Submit your idea today and if it is built and worthy, a founder's seat is ready for you to claim.</p>
            <p><a href="http://www.contrib.com/brand/details/<?=$domain?>" class="btn btn-gray" target="_blank">Submit your own idea</a></p>
        </div>
    </div>
</div>

<!-- verticals -->
<?php if (count($related_domains)>0):?>
<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
<div class="verb">
	<div class="container">
		<div class="row">
		  <div class="col-md-12">
			<h2><i class="fa fa-globe"></i>&nbsp; Other Brands On <?php echo $vertical?> Vertical</h2>
				<div class="vertical-list">
				  <ul class="list-unstyled">
				  <?php foreach ($related_domains as $key=>$val):?>
					<li class="col-md-4 odd"><a href="http://<?php echo $val['domain_name']?>"><i class="fa fa-arrow-right"></i>&nbsp;<?php echo ucfirst($val['domain_name'])?></a></li>
				 <?php endforeach;?>	
				  </ul>
				  <div class="clearfix"></div>
				</div>
				<div class="col-md-12" style="text-align:center;"><a href="http://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" target="_blank" class="btn btn-success">View More</a></div>
		  </div>
		</div>
	</div>
</div>
<?php endif;?>

<? include('footer.php'); ?>
