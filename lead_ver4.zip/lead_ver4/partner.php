<? include('header.php'); ?>
	<?	
											$partners_list = array();
											if(!$approved_partner == ""):
												$partners_list = $approved_partner['data'];
											endif;
										?>
<style>
body {
	background: url('http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/lead_bg.jpg');
	background-size:cover;
	background-attachment:fixed;
}
.overflow-ad {
	background: none repeat scroll 0px 0px rgba(0, 0, 0, 0.7);
	margin-top:30px;
	margin-bottom:30px;
}
</style>
<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap-responsive.css"/>

<div class="container-fluid lead-reset-padd" >
	<div class="row-fluid">
		<div class="wrap-ad" style="margin-bottom: 20px;">
			<div class="container overflow-ad">
				<div class="row-fluid">
					<div class="content-ad">
						<div style="margin: -40px 0 30px 0;">
							<h4>Learn more about Joining our Partner Network</h4>
						</div>
						
						<div class="section-heading-ttle text-left">
							<h2 style="padding-left:0;"><span id="_title">PARTNER WITH <?=ucwords($domain)?></h2>							
						</div>
						
						<div class="row-fluid">
							<div class="span12">
								
									<div class="span4">
										<iframe id="l_partner" src="http://www.contrib.com/forms/partner/<?=$domain?>" frameborder="0" scrolling="no" style="width:335px;height:470px;border: none;background: whitesmoke;border-radius: 5px;margin-top: 30px;"></iframe>
									</div>
									<div class="span7">
										<div class="row-fluid">
											<div id="r_about">
												<p class="p-desc stripe-text right text-left">
													<span class="p-intro"><?=ucwords($domain)?></span>
													is a venture of eCorp.com Inc.
													<br>
													<br>
													<?=$description?> 
													<br>
													<br>
													<span class="p-intro">eCorp</span> is the worlds largest virtual domain development incubator on the planet. Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms. We build and manage world class web-based, domain centric operating businesses for clients and internal ventures. Learn more about our ventures, staffing opportunites and partnership models.
												</p>
												<br />
												<p class="p-desc stripe-text left text-left">
													<a href="http://globalventures.com" target="_blank" class="btn btn-primary btn-large">
														Learn about this site
													</a>
												</p>
											</div>
										</div><!-- row-fluid -->
										<div class="row-fluid">
												<!-- static partners -->
											<div class="row-fluid blckBckgrnd">
												<div class="span4">
													<a href="http://globalventures.com">
														<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png" alt="GlobalVentures.com" title="GlobalVentures.com" />
													</a>
												</div><!-- span4 -->
												<div class="span8">
													<h3><a href="http://globalventures.com">GlobalVentures.com</a></h3>
													<p>
														Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly.
														Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.
													</p>
													<p>
														With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.
													</p>
												</div><!-- span8 -->
											</div>

											<div class="row-fluid blckBckgrnd">
												<div class="span4">
													<a href="http://ifund.com">
														<img class="img-responsive" src="http://www.contrib.com/uploads/logo/ifund.png" alt="iFund.com" title="iFund.com" />
													</a>
												</div><!-- span4 -->
												<div class="span8">
													<h3><a href="http://ifund.com">iFund.com</a></h3>
													<p>
														iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
														advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
														investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
														iFund receives no compensation in connection with the purchase or sale of securities.
													</p>
												</div><!-- span8 -->
											</div>

											<div class="row-fluid blckBckgrnd">
												<div class="span4">
													<a href="http://ichallenge.com">
														<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png" alt="iChallenge.com" title="iChallenge.com" />
													</a>
												</div><!-- span4 -->
												<div class="span8">
													<h3><a href="http://ichallenge.com">iChallenge.com</a></h3>
													<p>
														The best internet challenges. Solve and win online prizes.
													</p>
												</div><!-- span8 -->
											</div>
											
										<div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://socialid.com">
                                                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-socialid1.png" alt="SocialId.com" title="SocialId.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://socialid.com">SocialId.com</a></h3>
                                            <p>
                                                SocialId helps you get the social name for all major social networking websites.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                      <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://virtualinterns.com">
                                                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png" alt="Virtualinterns.com" title="Virtualinterns.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://socialid.com">Virtualinterns.com</a></h3>
                                            <p>
                                               Join our exclusive community of like minded people on virtualinterns.com
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://referrals.com">
                                                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png" alt="Referrals.com" title="Referrals.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://referrals.com">Referrals.com</a></h3>
                                            <p>
                                               Most effective Business Referral Program and Tools Available. Find and share referrals locally.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>

                                     <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://bidtellect.com">
                                                <img class="img-responsive" src="https://d1p6j71028fbjm.cloudfront.net/logos/Bidtellect_logoH.png" alt="bidtellect.com" title="bidtellect.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://bidtellect.com">Bidtellect.com</a></h3>
                                            <p>
                                              The First Open, Multi-format, Multi-device Native Exchange Connecting Advertisers and Publishers to Deliver Native Advertising at Scale.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                    <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://consultants.com">
                                                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png" alt="consultants.com" title="consultants.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://consultants.com">Consultants.com</a></h3>
                                            <p>
                                              Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
                                    
                                      <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://domainholdings.com">
                                                <img class="img-responsive" src="https://www.domainholdings.com/wp-content/uploads/dh-logo-medium-31.png" alt="domainholdings.com" title="domainholdings.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://domainholdings.com">Domainholdings.com</a></h3>
                                            <p>
                                              Domain Holdings is an award winning domain brokerage company specializing in premium domain sales and stealth brand acquisitions.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>

                                      <div class="row-fluid blckBckgrnd">
                                        <div class="span4">
                                            <a href="http://handyman.com">
                                                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png" alt="handyman.com" title="handyman.com" />
                                            </a>
                                        </div><!-- span4 -->
                                        <div class="span8">
                                            <h3><a href="http://handyman.com">Handyman.com</a></h3>
                                            <p>
                                              Handyman.com is the best place to find a professional contractor.
                                            </p>
                                        </div><!-- span8 -->
                                    </div>
												<!-- static partners -->
												
											<!-- start dynmic partners -->


											<?foreach($partners_list AS $partner_detail):?>
												<div class="row-fluid blckBckgrnd">
													<div class="span4">
														<a href="<?echo $partner_detail['url'];?>">
															<img class="img-responsive" src="<?echo $partner_detail['image'];?>" alt="<?echo $partner_detail['company_name'];?>" title="<?echo $partner_detail['company_name'];?>">
														</a>
													</div><!-- span4 -->
													<div class="span8">
														<h3><a href="<?echo $partner_detail['url'];?>"><?echo $partner_detail['company_name'];?></a></h3>
														<p><?echo $partner_detail['summary'];?></p>
														<p><?echo $partner_detail['description'];?></p>
													</div><!-- span8 -->
												</div>
											<?endforeach;?>
											<!-- dynamic partners -->
										</div>
									</div><!-- span7 -->
									
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--3rd section-->
<style type="text/css">
	.blckBckgrnd{
		background: rgba(0,0,0,1);
		padding: 20px 15px;
		margin-bottom: 10px;
		box-shadow: 0 0 3px rgba(255, 255, 255, 0.4)
	}
	.span8 p{text-align: justify;}
</style>
<? include('footer.php'); ?>