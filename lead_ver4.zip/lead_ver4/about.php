<?php include('header.php'); ?>
<style>
body {
	background: url('http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/lead_bg.jpg');
	background-size:cover;
	background-attachment:fixed;
}
.overflow-ad {
	background: none repeat scroll 0px 0px rgba(0, 0, 0, 0.7);
	margin-top:30px;
	margin-bottom:30px;
	padding: 0px 50px;
	margin-top: 75px;
	margin-bottom: 75px;
	width: 760px !important;
}
.content-ad h4 {
	font-size: 25px;
	margin-bottom: 20px;
}
</style>
<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap-responsive.css"/>

<div class="container-fluid lead-reset-padd" >
	<div class="row-fluid">
		<div class="wrap-ad" style="margin-bottom: 20px;">
			<div class="container overflow-ad">
				<div class="row-fluid">
					<div class="content-ad">
						<div style="margin-top: -40px;">
							<h4>About <?php echo ucfirst($domain)?></h4>
						</div>
						
						
						<div class="row-fluid">
							<div class="span12">
								<div id="f_terms" style="text-align: left;">

									<p><?php echo ucfirst($domain)?> is a proud venture of Global Ventures, LLC.</p>
			                        <p>Global Ventures, LLC, established in 1996, invests in young innovators, entrepreneurs and professionals with a desire to solving big problems and help world. We combine our resources with a series of intense challenges, real-world skills development, amazing and flexible opportunities and a shared ownership and experience with the most talented young founders and professionals around the world.</p>
			                        <p>Join our network of performance based companies using <?php echo $domain?></p>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--3rd section-->



<?php include('footer.php'); ?>