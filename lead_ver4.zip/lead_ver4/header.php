<? include 'includes/config.php';?>
<? include 'includes/metatitle.php';?>
<!DOCTYPE html>
<html>
    <head>
		<title><?=$meta?></title>
		<link rel="icon" type="image/icon" href="favicon.ico">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta charset="utf-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />		
		<meta name="robots" content="index, follow" />		
		<meta name="title" content="<?=$meta?> " />
		<meta name="description" content="<?=ucwords($domain)?> - <?=$meta_desc?>" />
		<meta name="keyword" content="<?=$keywords?>" />
        <!-- Bootstrap -->
        <!--link href="css/bootstrap.css" rel="stylesheet"-->
		<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
        <link href="css/custom.css" rel="stylesheet">
		<link href="css/verticals.css" rel="stylesheet">
        <link href="js/jquery.counter-analog.css" media="screen" rel="stylesheet" type="text/css" />
		<link href="js/jquery.counter-analog2.css" media="screen" rel="stylesheet" type="text/css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
		<![endif]-->
		
		<style>        
		<? if($background_image != ""){ ?>
			.j-bck{ background: url(<?=$background_image?>);color: #A0A0A0; }
		<? }else{ ?>
			.j-bck{ background: url('http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/lead_bg.jpg') no-repeat; }
		<? } ?>
		.logo-text{
			font-size: 30px;
			font-weight: 600;
			color: #000000;
			margin: 0;
			text-align: center;
			font-family: "Helvetica Neue", Helvetica, sans-serif;
		}
		.media-body, .media-left, .media-right {
			display: table-cell;
			vertical-align: top;
		}
		.media-left, .media > .pull-left {
			padding-right: 10px;
		}
		.media-right, .media > .pull-right {
			padding-left: 10px;
		}
		.contrib-task-container .media-heading {
			margin: 10px;
		}
		.contrib-task-container .media-right .btn-danger {
			margin-top: 5px;
		}
		</style>
		
        <!-- Piwik -->
		<script type="text/javascript">
		  var _paq = _paq || [];
		  _paq.push(['trackPageView']);
		  _paq.push(['enableLinkTracking']);
		  (function() {
			var u="//www.stats.numberchallenge.com/";
			_paq.push(['setTrackerUrl', u+'piwik.php']);
			_paq.push(['setSiteId', <?=$piwik_id?>]);
			var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
			g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
		  })();
		</script>
		<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=1" style="border:0;" alt="" /></p></noscript>
		<!-- End Piwik Code -->
    </head>
    <body>
		<? if($forsale=='1' || $forsaledefault =='1'){ ?>
		<div style="padding:10px 0 10px 0; margin:0; color: #fff; background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
            <?=$forsaletext?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$domain?>" target="_blank" style="color:blue;">Inquire now</a>.
        </div>
		<? } ?>
		
        <nav class="navbar navbar-default nav-back" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#tggle">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand nav-res-st" href="http://<?=$domain?>">                   
					<? if($logo!=''){ ?>
						<img class="logo-dom" src="<?=$logo?>" alt="<?=$title?>" title="<?=$domain?>" />			
                    <? }else{ ?>
						<h1 class="logo-text"><?=ucwords($domain)?></h1>
                    <? } ?>
                </a>
            </div>
            <div class="collapse navbar-collapse" id="tggle">
                
                <ul class="nav navbar-nav navbar-right nn-a">
                    <li><a class="btn btn-green" href="http://www.contrib.com/signup/firststep?domain=<?=$domain?>"  target="_blank">Join the Community</a></li>
                    <li><a class="btn btn-gray" href="http://www.contrib.com/home/signin" target="_blank">Sign In</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>


	
		
		