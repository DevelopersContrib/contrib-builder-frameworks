<?php  
    include('header.php');
?>
	<body>
		<style>
			.contMatched {
				background: rgb(102, 6, 7) none repeat scroll 0 0;
				border-radius: 10px;
				color: #fff;
				min-height: 90px;
				padding: 10px;
				text-align: center;
				text-shadow: 0 0 2px #5c5959;
				margin-bottom: 25px;
			}
			.wrap-form-container-dir {
				background-color: #e9e9e9;
				border-radius: 4px;
				margin-bottom: 15px;
				padding: 15px 15px 0;
				position: relative;
			}

			.wrap-form-container-dir.wrap-form-container-dir-solo{
				padding: 30px 10px 21px;
			}
			.meta-orSpan {
				background-color: rgb(102, 6, 7);
				border-radius: 50%;
				box-shadow: 0 0 0 5px #f9f9f9;
				color: #fff;
				font-size: 17px;
				font-weight: 700;
				height: 45px;
				line-height: 43px;
				position: absolute;
				right: -38px;
				text-shadow: none;
				top: 34px;
				width: 45px;
				z-index: 1;
			}
			.findJobInner1 {
				background-color: #f7f7f7;
				border-bottom: 5px solid rgb(237, 236, 236);
				margin: 10px 0 15px;
				padding: 10px 15px 15px;
			}
			.relative {
				position: relative;
			}
			.separatorCircle {
				border-bottom: 7px solid #4779ba;
				bottom: -6px;
				left: 38.5%;
				position: absolute;
				width: 23%;
			}
			.findJobInner1 h4 {
				margin-top: 5px;
			}
			.save-check-box{
			}
			.findJobInner1.select-checkbox{
				border: medium none transparent;
				margin: 0;
				padding: 5px 15px;
			}
			.success-social {
				margin-top: 20px;
				border: 1px solid #ccc;
				padding: 10px 20px 30px 20px;
				border-radius: 6px;
				box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.075);
			}

			.success-social .fa {
				font-size: 50px;
				color: #d43f3a;
			}
			.qna-side .qna-side-title {
				clear: both;
				font-size: 16px;
				font-weight: bold;
			}
			.qna-side .list-group-item .glyphicon {
				color: #777;
			}
			.col-lg-9, .col-lg-6{
				margin-bottom:10px;
			}
			
		</style>
		<?php include('navigation.php');?>
		<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/form-wizard.css">
		<script src="<?php echo BASE_URL; ?>js/jquery.maskedinput.js" type="text/javascript"></script>
		<div class="pages-container">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h1>Post a Project</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="page-content p-c-2">
			<div class="container">
			<div id="errors2"></div>
				<div class="row">
					<div class="col-lg-8">
						<div class="container">
							<div class="row">
								<div class="col-lg-8">
									<div class="wrap-wizardForm-handyman">
										<div class="form-wizard">
								<div class="form-body">
									<h1 class="text-center ttle-frm-wiz"> Post a Project and Get <b>Results</b> <i>Immediately </i></h1>
							
									<div class="tab-content">
										<div id="tab1" class="tab-pane active">
											<div class="wrap-wizardForm-project">
												<div class="row">
													<div class="col-lg-12">
														<div class="form-horizontal">
															<hr/>
															<div class="row">
																<label for="business_name" class="control-label col-lg-3 fnt-nrml">
																	Project Type <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<select name="projecttype" id="projecttype" class="form-control req">
																		<option value="">Select Project Type</option>
																		<?php
																				foreach($projecttypes  as $key=>$info2)
																				{
																					if($projecttype_id == $info2['ProjectTypeId']){
																							$sel = "selected";
																						}else {
																							$sel = "";
																						}
																					  echo '<option value="'.$info2['ProjectTypeId'].'" '.$sel.'>'.$info2['Name'].'</option>';
																					
																				}
										                              	?>
																	</select>
																	<span class="postProjErr projecttype_message text-red"></span>
																</div>
																<label for="" class="control-label col-lg-3 fnt-nrml">
																	Ideal Start Date <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<select name="projectstart" id="projectstart" class="form-control req">
																		<option>Select</option>
																		<option value="Now">Now</option>
																		<option value="1-Week">1-Week</option>
																		<option value="2-Weeks">2-Weeks</option>
																		<option value="3-Weeks">3-Weeks</option>
																		<option value="1-2 Months">1-2 Months</option>
																		<option value="3-6 Months">3-6 Months</option>
																	</select>
																	<span class="postProjErr projectstart_message text-red"></span>
																</div>
																<label for="" class="control-label col-lg-3 fnt-nrml">
																	Project Status <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<select name="projectstatus" id="projectstatus" class="form-control req">
																		<option></option>
																		<option value="Ready to Hire">Ready to Hire</option>
																		<option value="Planning and Budgeting">Planning and Budgeting</option>
																	</select>
																	<span class="postProjErr projectstatus_message text-red"></span>
																</div>
																<label for="business_name" class="control-label col-lg-3 fnt-nrml">
																	Project Description <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<textarea name="projectdesc" id="projectdesc" rows="1" class="form-control req"></textarea>
																	<span class="postProjErr projectdesc_message text-red"></span>
																</div>
															
																<div class="col-md-12">
																	<div class="row">
																		<label for="" class="control-label col-lg-3 fnt-nrml" style="font-size:13px;">
																			Phone Number (10 digit number with area code) <span class="text-red pd-left">*</span>
																		</label>
																		<div class="col-lg-9">
																			<input type="text" class="form-control req" id="homeown_phone" name="homeown_phone">
																			<div id="errmsg2"></div>
																			<span class="postProjErr homeown_phone text-red"></span>
																		</div>
																	</div>
																</div>
															
																<label for="" class="control-label col-lg-3 fnt-nrml">
																	City <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<input type="text" type="text" value="<?php echo $city?>" id="city" name="city" class="form-control req"> 
																	<span class="postProjErr city text-red"></span>
																</div>

																<label for="" class="control-label col-lg-3 fnt-nrml">
																	Address <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<textarea name="projectaddress" id="projectaddress" rows="1" class="form-control req"></textarea>
																	<span class="postProjErr projectaddress text-red"></span>
																</div>
																<label for="" class="control-label col-lg-3 fnt-nrml">
																	State <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<select name="projectstate" id="projectstate" class="form-control input-lg req">
																					<option>Please select</option>
																					<option name="Alabama" value="2" <?php if ($state == 2) echo "selected"?>>Alabama</option>
																					<option name="Alaska" value="1" <?php if ($state == 1) echo "selected"?>>Alaska</option>
																					<option name="Arizinto states" value="4" <?php if ($state == 4) echo "selected"?>>Arizona states</option>
																					<option name="Arkansas" value="3" <?php if ($state == 3) echo "selected"?>>Arkansas</option>
																					<option name="California" value="5" <?php if ($state == 5) echo "selected"?>>California</option>
																					<option name="Connecticut" value="7" <?php if ($state == 7) echo "selected"?>>Connecticut</option>
																					<option name="Delaware" value="9" <?php if ($state == 9) echo "selected"?>>Delaware</option>
																					<option name="Florida" value="10" <?php if ($state == 10) echo "selected"?>>Florida</option>
																					<option name="Georgia" value="11" <?php if ($state == 11) echo "selected"?>>Georgia</option>
																					<option name="Hawaii" value="12" <?php if ($state == 12) echo "selected"?>>Hawaii</option>
																					<option name="Idaho" value="14" <?php if ($state == 14) echo "selected"?>>Idaho</option>
																					<option name="Indiana" value="52" <?php if ($state == 52) echo "selected"?>>Indiana</option>
																					<option name="Idiana States" value="16">Indiana States</option>
																					<option name="Kansas" value="17" <?php if ($state == 17) echo "selected"?>>Kansas</option>
																					<option name="Kentucky" value="18" <?php if ($state == 18) echo "selected"?>>Kentucky</option>
																					<option name="Louisiana" value="19" <?php if ($state == 19) echo "selected"?>>Louisiana</option>
																					<option name="Maine" value="22" <?php if ($state == 22) echo "selected"?>>Maine</option>
																					<option name="Maryland" value="21" <?php if ($state == 21) echo "selected"?>>Maryland</option>
																					<option name="Massachusetts" value="20" <?php if ($state == 20) echo "selected"?>>Massachusetts</option>
																					<option name="Michigan" value="23" <?php if ($state == 23) echo "selected"?>>Michigan</option>
																					<option name="Minnesota states" value="24" <?php if ($state == 24) echo "selected"?>>Minnesota states</option>
																					<option name="Minnesota" value="53" <?php if ($state == 53) echo "selected"?>>Minnesota</option>
																					<option name="Mississippi" value="26" <?php if ($state == 26) echo "selected"?>>Mississippi</option>
																					<option name="Missouri" value="25" <?php if ($state == 25) echo "selected"?>>Missouri</option>
																					<option name="Nevada states" value="30" <?php if ($state == 30) echo "selected"?>>Nevada states</option>
																					<option name="Nevada" value="34" <?php if ($state == 34) echo "selected"?>>Nevada</option>
																					<option name="New Hampshire" value="31" <?php if ($state == 31) echo "selected"?>>New Hampshire</option>
																					<option name="New Jersey" value="32" <?php if ($state == 32) echo "selected"?>>New Jersey</option>
																					<option name="New Mexico" value="33" <?php if ($state == 33) echo "selected"?>>New Mexico</option>
																					<option name="New York" value="35" <?php if ($state == 35) echo "selected"?>>New York</option>
																					<option name="North Carolina" value="28" <?php if ($state == 28) echo "selected"?>>North Carolina</option>
																					<option name="Ohio" value="36" <?php if ($state == 36) echo "selected"?>>Ohio</option>
																					<option name="Oklahoma states" value="37" <?php if ($state == 37) echo "selected"?>>Oklahoma states</option>
																					<option name="Pennsylvania" value="39" <?php if ($state == 39) echo "selected"?>>Pennsylvania</option>
																					<option name="South Carolina states" value="41" <?php if ($state == 41) echo "selected"?>>South  Carolina states</option>
																					<option name="South Dakota states" value="42" <?php if ($state == 42) echo "selected"?>>South Dakota states</option>
																					<option name="Tennessee" value="43" <?php if ($state == 43) echo "selected"?>>Tennessee</option>
																					<option name="Texas" value="44" <?php if ($state == 44) echo "selected"?>>Texas</option>
																					<option name="Utah" value="45" <?php if ($state == 45) echo "selected"?>>Utah</option>
																					<option name="Virginia" value="46" <?php if ($state == 46) echo "selected"?>>Virginia</option>
																					<option name="Washingto" value="48" <?php if ($state == 48) echo "selected"?>>Washington</option>
																					<option name="West Virginia" value="50" <?php if ($state == 50) echo "selected"?>>West Virginia</option>
																					<option name="Wiscinto statesi" value="49" <?php if ($state == 49) echo "selected"?>>Wisconsin states</option>
																					<option name="Wyoming" value="51" <?php if ($state == 51) echo "selected"?>>Wyoming</option>
																				</select>
																	
																	<span class="postProjErr projectstate text-red"></span>
																</div>
																<label for="" class="control-label col-lg-3 fnt-nrml">
																	Zipcode <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<?php if($zip != '0'):?>
																		<input type="text" value="<?echo $zip?>" id="zip_code" name="zip_code" class="form-control req">
																			
																	<?php else: ?>
																	
																		<input type="text" value="" id="zip_code" name="zip_code" class="form-control req">
																	<?php endif;?>
																	<div id="errmsg"></div>
																	<span class="postProjErr zip_code text-red"></span>
																</div>
																
															
															</div>
															
															<div class="row form-group">
																<label for="" class="control-label col-lg-3 fnt-nrml">
																	Do You Own the Property <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-9">
																	<label class="radio-inline">
																	<input type="radio" id="projectown" value="1" name="won_pro"/> No
																	</label>
																	<label class="radio-inline">
																		<input type="radio" id="projectown" value="0" name="won_pro" checked/> Yes
																	</label>
																	<span class="help-block hide"> Provide your project type </span>
																</div>
															</div>
														
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 form-actions wizardFrom">
													<div class="row">
														<div class="col-lg-offset-4 col-lg-8" style="text-align:right !important;">
														
															<a class="btn btn-primary btn-lg" href="javascript:;" id="continuetoprojectinof">
																Continue to Get Free Estimates
																<i class="fa fa-chevron-right"></i>
															</a>
														
															
															
														</div>
													</div>
												</div>
											</div>
										</div>
										<div id="tab3" class="tab-pane">
											<div class="wrap-wizardForm-project">
												<div class="row">
													<div class="col-lg-12">
													
													<!--  register  -->
												<div id="content-register">
													<h3 class="fnt-nrml">
														<span class="">User Information </span>
													</h3>
													<div id="errors3"></div>
													<div class="form-horizontal">
														<div class="formRgstr">
															
															
															<div class="form-group">
                             
                              <label for="" class="control-label col-lg-4 fnt-nrml">
																	First Name <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-6">
																	<input type="text" class="form-control req" id="homeown_fname" name="homeown_fname"> 
																	<span class="postProjErr homeown_fname text-red"></span>
																</div>
																<label for="" class="control-label col-lg-4 fnt-nrml">
																	Last Name <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-6">
																	<input type="text" class="form-control req" id="homeown_lname" name="homeown_lname"> 
																	<span class="postProjErr homeown_lname text-red"></span>
																</div>
                                
																<label for="" class="control-label col-lg-4 fnt-nrml">
																	Public Username <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-6">
																	<input type="text" id="howeown_pname" name="howeown_pname" class="form-control req"> 
																	<span class="postProjErr howeown_pname text-red"></span>
																</div>
                                
															</div>
															<div class="form-group">
																<label for="" class="control-label col-lg-4 fnt-nrml">
																	Email <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-6">
																	<input type="text" class="form-control req" id="homeown_email" name="homeown_email"> 
																	<span class="postProjErr homeown_email text-red"></span>
																</div>
															</div>
															<div class="form-group">
																<div class="col-lg-6 col-xs-offset-4">
																	<label class="checkbox-inline">
																		<input type="checkbox" id="termscon" name="termscon"> I Accept And Agree To The <a href="/home/terms" target ="_blank">Terms & Condition.</a>
																	</label>
																</div>
															</div>
														</div>
													</div>
												</div>
												
												</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 form-actions wizardFrom">
													<div class="row">
														<div class="col-lg-offset-4 col-lg-8">
														
															<a href="javascript:;" class="btn btn-lg btn-default" id="backtoprojectinfo">
																<i class="fa fa-chevron-left"></i> 
																Back
															</a>
															<a class="btn btn-success btn-lg" href="javascript:;" id="continuetosuccess">
																Get Free Estimates 
																<i class="fa fa-chevron-right"></i>
															</a>
															
														</div>
													</div>
												</div>
											</div>
										</div>
										<div id="tab4" class="tab-pane">
											<div class="col-lg-8 col-lg-offset-2">
												<h1 class="text-success text-center">
													Thank You for Signing-up!
												</h1>
												<p class="text-center">Please wait while we prepare an instant contractor match. Check your email to view your password.</p>
												<br>
											</div>
											<div class="row">
												<div class="col-lg-12 form-actions wizardFrom">
													<div class="row">
														<div class="col-lg-offset-4 col-lg-8">
															
															<a href="javascript:;" class="btn btn-success" id="successid" style="display:none;">
																Submit 
																<i class="fa fa-check"></i>
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
									
									</div>
									<!-- <div class="row">
										<div class="col-lg-12 form-actions wizardFrom">
											<div class="row">
												<div class="col-lg-offset-4 col-lg-8">
													<a href="javascript:;" class="btn btn-default " style="display:none;">
														<i class="fa fa-chevron-left"></i> 
														Back
													</a>
													<a class="btn btn-primary" href="javascript:;" style="display:none;">
														Continue 
														<i class="fa fa-chevron-right"></i>
													</a>
													<a href="javascript:;" class="btn btn-success" style="">
														Submit 
														<i class="fa fa-check"></i>
													</a>
												</div>
											</div>
										</div>
									</div> -->
								</div>
							</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="alert alert-info">
							<strong>Dear Clients,</strong> <br>
							<p>
								First you will need to fill out this form, describing what needs to be done. Once your Project is approved and posted on the site, relevant Business people will be alerted. You'll receive email alerts when your Project starts getting interest and you'll then compare Contractor by reviewing profiles, work history, qualifications and customer reviews.
							</p>
						</div>
						<div class="success-social">
						   <?php global $social_fb ,$social_twitter,$social_linkedin,$social_gtube, $social_gplus ;?>
							<h3>Handyman social links for instant liking</h3>
							<a href="<?php echo $social_fb ?>"><i class="fa fa-facebook-square"></i></a>
							<a href="<?php echo $social_twitter?>"><i class="fa fa-twitter-square"></i></a>
							<a href="<?php echo $social_gplus?>"><i class="fa fa-google-plus-square"></i></a>
							<a href="<?php echo $social_gtube?>"><i class="fa fa-youtube-square"></i></a>
						</div>
						<div style="clear:both"><br></div>
						<div class="panel panel-default">
						    <div class="panel-heading">
						        <h4>Recent questions and answers</h4>
						    </div>
						    <ul class="list-group qna-side">
						       <?php if (count($questions)>0):?>
						       <?php for ($i=0;$i<count($questions);$i++):?>
							        <li class="list-group-item">
							            <p class="qna-side-title">
							                <span class="glyphicon glyphicon glyphicon-question-sign"></span>
							                <a class="qna-side-ask" href="http://handyman.com/questions/details/id/<?php echo $questions[$i]['question_id']?>/n/<?php echo $questions[$i]['slug']?>" target="_blank"><?php echo stripcslashes($questions[$i]['title'])?></a>
							            </p>
							            <p class="qna-side-who"> posted <?php echo date("m/d/Y h:i a", strtotime($questions[$i]['date_posted']));?> in <a href="http://handyman.com/questions/category/cat/<?php echo $questions[$i]['type_id']?>/n/<?php echo $questions[$i]['type_slug']?>" target="_blank"><?php echo $questions[$i]['type_name']?></a> by
							                 <?php if ($questions[$i]['owner_user_type'] == 'homeowner'):?>
							                	<a href="http://handyman.com/homeowner/profile/user/<?php echo $questions[$i]['owner_username']?>" class="qa-user-link" target="_blank"><?php echo $questions[$i]['owner_name']?></a>
							                	<?php else:?>
							                	<a href="http://handyman.com//contractor/profile/user/<?php echo $questions[$i]['owner_username']?>" class="qa-user-link" target="_blank"><?php echo $questions[$i]['owner_name']?></a>
							                	
							                <?php endif;?>
							            </p>
							        </li>
						        <?php endfor;?>
						       <?php endif?> 
						        
						    </ul>
						</div>
					</div>
				</div>
			</div>
			<br>
			<br>
		</div>
		
<script src="<?php echo BASE_URL; ?>js/postproject4.js"></script>
<?php include ('footer.php')?>