<?php
    include('header.php');
?>
	<body>
		<?php include('navigation.php');?>
		


<?php include ('footer.php')?>
