<?php
    include('header.php');
?>
	<style type="text/css">
		.brdr{
			border:1px solid;
		}
		.section4{
			background-color: #fff;
			padding-top: 10px;
			padding-bottom: 10px;
			border-top: 1px solid #ddd;
			padding: 30px 0 50px;
		}
		.ul-rv img{
			max-height: 43px;
		}
		.ul-rv li{
			margin-bottom: 10px;
		}
		.rv-text-a{
			background: none repeat scroll 0 0 #f0f0f0;
			border: 1px solid #ddd;
			border-radius: 4px;
			font-size: 18px;
			padding: 10px 0;
		}
		.rv-text-a:before,.rv-text-a:after{
			display: table;
			content: "";
		}
		.rv-text-a:after{
			clear: both;
		}
		/* Added 8-15-16 */
		.section1{
			padding:180px 0;
		}
		.contMatched {
			background-color: rgba(0, 0, 0, 0.5);
			border-radius: 10px;
			color: #fff;
			margin-bottom: 25px;
			min-height: 90px;
			padding: 15px 5px 0;
			text-align: center;
			text-shadow: 0 0 2px #5c5959;
		}
		.wrap-form-container-dir {
			background-color: #e9e9e9;
			border-radius: 4px;
			margin-bottom: 15px;
			padding: 15px 15px 0;
			position: relative;
		}
		.wrap-form-container-dir.wrap-form-container-dir-solo{
			padding: 30px 10px 21px;
		}
		.meta-orSpan {
			background-color: rgb(102, 6, 7);
			border-radius: 50%;
			box-shadow: 0 0 0 5px #f9f9f9;
			color: #fff;
			font-size: 17px;
			font-weight: 700;
			height: 45px;
			line-height: 43px;
			position: absolute;
			right: -38px;
			text-shadow: none;
			top: 34px;
			width: 45px;
			z-index: 1;
		}
		.ttle-soleo{
			color: #ffffff;
			font-size: 60px;
			font-weight: bold;
			text-shadow: 0 0 5px #000000;
		}
	</style>
	<body>
		<?php include('navigation.php');?>
		<div class="section1"
			<?php if($info_attributes['background_image_url'] != ""):?>
			style="background:url('<?php echo $info_attributes['background_image_url']?>') no-repeat scroll center center / cover rgba(0, 0, 0, 0);"
			<?php endif; ?>>
			<div class="container text-center project hide">
				<div class="wrap-menu-content">
					<div id="estimate_display" class="row content-menu active">
						<div class="col-lg-6 col-lg-offset-3">
							<h1>
								Get an Estimate!
							</h1>
						</div>
						<div class="col-lg-8 col-lg-offset-2 form-project">
							<div class="row">
								<div class="col-lg-5">
									<div class="form-group">
										<select name="proj_types" id="proj_types" class="form-control input-lg">
											<option value="0">Project Type</option>
											<?php
												foreach($projecttypes as $array)
												{
													foreach($array as $key => $info2)
													{
													  echo '<option value="'.$info2['ProjectTypeId'].'" name='.$info2['Name'].'>'.$info2['Name'].'</option>';
													}
												}
											?>
										</select>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="form-group">
										<label for="zip" class="sr-only">ZIP</label>
										<input placeholder="ZIP" type="text" class="form-control input-lg" id="zipcodes2">
									</div>
								</div>
								<div class="col-lg-2">
									<div class="form-group">
										<a href="javascript:;" id="estiredirect" class="btn btn-primary btn-lg btn-block">Go!</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="expert_display" class="row content-menu" style="display:none;">
						<div class="col-lg-6 col-lg-offset-3">
							<h1>Ask an Expert</h1>
						</div>
						<div class="col-lg-6 col-lg-offset-3 form-project form-blue">
							<div class="row">
								<div class="col-lg-5">
									<div class="form-group">
										<select name="proj_cat" id="proj_cat" class="form-control input-lg">
											<option value="0">Category</option>
											<?php
												foreach($projecttypes as $array)
												{
													foreach($array as $key => $info2)
													{
													  echo '<option value="'.$info2['ProjectTypeId'].'">'.$info2['Name'].'</option>';
													}
												}
											?>
										</select>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="form-group">
										<label for="" class="sr-only">Ask</label>
										<input placeholder="Ask" type="text" class="form-control input-lg">
									</div>
								</div>
								<div class="col-lg-2">
									<div class="form-group">
										<a href="javascript:;" class="btn btn-danger btn-lg btn-block" id="askredirect">Go!</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row nav-menu">
					<div class="col-lg-6 col-lg-offset-3">
						<div class="row wrap-menu-nav">
							<div id="esticlass" class="col-lg-6 sub-menu active">
								<a href="javascript:;" id="estimate"><i class="fa fa-fax "></i> Get an Estimate</a>
							</div>
							<div id="askclass" class="col-lg-6 sub-menu">
								<a href="javascript:;" id="expert"><i class="fa fa-info-circle "></i> Ask an Expert</a>
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-lg-offset-2">
						<h1 class="text-center ttle-soleo">Looking for?</h1>
						<div class="contMatched clearfix " id="newform">
							<div class="col-md-4">
								<div class="wrap-form-container-dir wrap-form-container-dir-solo clearfix">
									<div class="form-group">
										<select class="form-control input-lg"  name="proj_cat" id="proj_cat" >
											<option value="0">Category</option>
											<?php
												foreach($projecttypes as $array)
												{
													foreach($array as $key => $info2)
													{
													  echo '<option value="'.$info2['ProjectTypeId'].'">'.$info2['Name'].'</option>';
													}
												}
											?>
										</select>
									</div>
									<span class="meta-orSpan visible-md visible-lg hidden-sm hidden-xs">
										<i class="fa fa-search"></i>
									</span>
								</div>
							</div>
							<div class="col-md-4">
								<div class="wrap-form-container-dir clearfix">
									<div class="form-group">
										<input type="text" placeholder="City" class="form-control ui-autocomplete-input" name="proj_city" id="proj_city" autocomplete="off">
									</div>
									<div class="form-group">
										<select class="form-control " id="proj_state" name="proj_state">
											<option>Please select</option>
											<option name="Alabama" value="2">Alabama</option>
											<option name="Alaska" value="1">Alaska</option>
											<option name="Arizinto states" value="4">Arizona states</option>
											<option name="Arkansas" value="3">Arkansas</option>
											<option name="California" value="5">California</option>
											<option name="Connecticut" value="7">Connecticut</option>
											<option name="Delaware" value="9">Delaware</option>
											<option name="Florida" value="10">Florida</option>
											<option name="Georgia" value="11">Georgia</option>
											<option name="Hawaii" value="12">Hawaii</option>
											<option name="Idaho" value="14">Idaho</option>
											<option name="Indiana" value="52">Indiana</option>
											<option name="Idiana States" value="16">Indiana States</option>
											<option name="Kansas" value="17">Kansas</option>
											<option name="Kentucky" value="18">Kentucky</option>
											<option name="Louisiana" value="19">Louisiana</option>
											<option name="Maine" value="22">Maine</option>
											<option name="Maryland" value="21">Maryland</option>
											<option name="Massachusetts" value="20">Massachusetts</option>
											<option name="Michigan" value="23">Michigan</option>
											<option name="Minnesota states" value="24">Minnesota states</option>
											<option name="Minnesota" value="53">Minnesota</option>
											<option name="Mississippi" value="26">Mississippi</option>
											<option name="Missouri" value="25">Missouri</option>
											<option name="Nevada states" value="30">Nevada states</option>
											<option name="Nevada" value="34">Nevada</option>
											<option name="New Hampshire" value="31">New Hampshire</option>
											<option name="New Jersey" value="32">New Jersey</option>
											<option name="New Mexico" value="33">New Mexico</option>
											<option name="New York" value="35">New York</option>
											<option name="North Carolina" value="28">North Carolina</option>
											<option name="Ohio" value="36">Ohio</option>
											<option name="Oklahoma states" value="37">Oklahoma states</option>
											<option name="Pennsylvania" value="39">Pennsylvania</option>
											<option name="South Carolina states" value="41">South  Carolina states</option>
											<option name="South Dakota states" value="42">South Dakota states</option>
											<option name="Tennessee" value="43">Tennessee</option>
											<option name="Texas" value="44">Texas</option>
											<option name="Utah" value="45">Utah</option>
											<option name="Virginia" value="46">Virginia</option>
											<option name="Washingto" value="48">Washington</option>
											<option name="West Virginia" value="50">West Virginia</option>
											<option name="Wiscinto statesi" value="49">Wisconsin states</option>
											<option name="Wyoming" value="51">Wyoming</option>
										</select>
									</div>
									<span class="meta-orSpan visible-md visible-lg hidden-sm hidden-xs">
										<i class="fa fa-map-marker"></i>
									</span>
								</div>
							</div>
							<div class="col-md-4">
								<div class="wrap-form-container-dir clearfix">
									<div class="form-group">
										<input type="text" placeholder="Zipcode" class="form-control" name="proj_zip" id="proj_zip">
									</div>
									<div class="form-group">
										<a class="btn btn-primary btn-block" data-loading-text="Searching..." href="javascript:submitsearch()" id="submit">Submit</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="section2">
			<div class="container">
				<div class="row">
				  	<div class="col-lg-12">
						<h1 class="ftre-style1-link">Acquired by Handyman.com</h1>
				    </div>
			  	</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<h1>Get Matched to a Screened Professional Handyman</h1>
						<p><?php echo ucfirst($info['domain'])?> helps you find an experienced, professional Handyman contractor in your local area, FREE, NO OBLIGATIONS. <?php echo ucfirst($info['domain'])?> is the industry leading portal for the home improvement, home repair and remodeling industry. Our free tools and services help both homeowners and contractors facilitate the process to accomplish your home repair and remodeling needs. Serving the Home and Contractor market. Why use our pros?</p>
						<p>For the commercial real estate market or projects over $5,000, <?php echo ucfirst($info['domain'])?> offers a free consultation service to analyze your needs and find suppliers, general contractors and local professional service providers. Are you lacking a professional website or want to communicate more efficiently with your customer or contractor? Get a Free Webpage and Free Consultation and manage it online. Need professional and experienced contractors, subcontractors or handymen due to an increase in your work load? You have come to the right place at <?php echo ucfirst($info['domain'])?>, your local referral and local handyman service provider.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="section3">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 f1">
						<a href="<?php echo BASE_URL; ?>postproject" class="feature-link text-center">
							post a project
							<span class="meta-desc">Home owner post your project free<i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f2">
						<a href="http://handyman.com/contractor/find" class="feature-link text-center">
							FIND CONTRACTOR
							<span class="meta-desc">Contractors in Your Area Now  <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f3">
						<a href="http://handyman.com/project/find" class="feature-link text-center">
							FIND PROJECT
							<span class="meta-desc">Get Contractor Projects  <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f4">
						<a href="http://handyman.com/home/how-it-works" class="feature-link text-center">
							HOW IT WORKS
							<span class="meta-desc">Free Match-up for your project!   <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="section4">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h1 class="ftre-style1-link">
							Other Brands on <?php echo ucfirst($info['domain'])?> Vertical
						</h1>
					</div>
					<div class="col-lg-6">
						<div class="row">
							<div class="col-lg-6">
								<ul class="list-inline ul-rv">
								<? $row_cnt = 0; ?>
								<? shuffle($relatedsiteswithlogo); ?>
								<? foreach($relatedsiteswithlogo as $row){ ?> 
									<li>
										<a href="http://<?=$row['domain_name']?>" target="_blank">
											<img class="img-responsive" src="<?=$row['logo']?>" alt="<?=$row['domain_name']?>">
										</a>
									</li>
									<? $row_cnt++; ?>
									<? if($row_cnt==6) break; ?>
									<? if($row_cnt%3==0){ ?>
								</ul>
							</div>
							<div class="col-lg-6">
								<ul class="list-inline ul-rv">
							<? }?> 
						<? } ?>
								</ul>
							</div>

						</div>
					</div>
					<div class="col-lg-6">
						<div class="row">
							<div class="rv-text-a">
								<div class="col-lg-6">
									<ul class="list-unstyled">
									<? $row_cnt1 = 0; ?>
									<? shuffle($relatedsitesnologo); ?>
									<? foreach($relatedsiteswithlogo as $row1){ ?> 
										<li>
											<i class="fa fa-star-o"></i>
											<a href="http://<?=$row1['domain_name']?>" target="_blank">
												<?=ucwords($row1['domain_name'])?>
											</a>
										</li>
									<? $row_cnt1++; ?>
									<? if($row_cnt1==12) break; ?>
									<? if($row_cnt1%6==0){ ?>
									</ul>
								</div>
								<div class="col-lg-6">
									<ul class="list-unstyled">
										
								<? } ?>
											<? } ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

<script src="<?php echo BASE_URL; ?>js/home.js"></script>
<?php include ('footer.php')?>
