<?php  
    include('header.php');
?>
	<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" />
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/fd.css">
	<body>
		<?php include('navigation.php');?>
		<div class="hf-wrap">
			<div class="hf-wrap-sub">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="text-center lead-ttle-top">
								<br><br>
								<h1 class="brdr-lead">
									Are you a Developer?
								</h1>
								<h3 class="fnt-300 fnt-lato" style="color:#fff;">
									Do you have code or an app that could run this brand? <?php echo ucfirst($info['domain'])?> is connected with Contrib.
								</h3>
								<h3 class="fnt-300 fnt-lato" style="color:#fff;">
									Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world’s best brands on them. Do you have an app, or code that could help run <?php echo ucfirst($info['domain'])?>?
								</h3>
								<br><br>
								<p>
									<a href="/contact" class="btn btn-primary btn-lg">Inquire here</a>
								</p>
								<br><br><br>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php include ('footer.php')?>