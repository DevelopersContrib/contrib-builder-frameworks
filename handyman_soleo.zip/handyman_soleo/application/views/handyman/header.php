<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $info['title']?></title>
		<meta charset="utf-8" />
		<meta name="description" content="<?php echo $info['description']?>" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="<?php echo $info['keywords']?>">
		<!-- Bootstrap -->
		
		
		
<?php if(preg_match('/(?i)msie [1-8]/',$_SERVER['HTTP_USER_AGENT'])) { ?>
     
		<link rel="stylesheet" href="<?php echo BASE_URL; ?>css/boostrap-3.3.1-css/bootstrap.min.css">
<? } else { ?>
	
		<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<?php } ?>
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/index.css">
		 <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/index.css" type="text/css" media="screen" />
		 <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/pages.css" type="text/css" media="screen" />
		 <input type="hidden" id="base_url" name="base_url" value="<?php echo BASE_URL; ?>">
		 <link rel="stylesheet" media="screen" type="text/css" href="<?php echo BASE_URL; ?>css/serviceforms/partner.css">
		 <link rel="stylesheet" media="screen" type="text/css" href="<?php echo BASE_URL; ?>css/serviceforms/staffing.css">
		 <link rel="stylesheet" media="screen" type="text/css" href="<?php echo BASE_URL; ?>css/serviceforms/offer.css">
		 <link rel="stylesheet" media="screen" type="text/css" href="<?php echo BASE_URL; ?>css/serviceforms/inquiry.css"> 
		 
		 <script>
			  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

			  ga('create', '<?php echo $info['account_ga']?>', '<?echo $info['domain']?>');
			  ga('send', 'pageview');
		</script>
		

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="https://code.jquery.com/jquery.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	
	
	
	<?php if(preg_match('/(?i)msie [1-8]/',$_SERVER['HTTP_USER_AGENT'])) { ?>
		 
			<script src="<?php echo BASE_URL; ?>js/boostrap-3.3.1-js/bootstrap.min.js"></script>

		<? } else { ?>
		
			<script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
	<?php } ?>
	
	<style type="text/css">
	</style> <!-- Do Not Include this -->
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	
	<!-- Piwik -->
	<script type="text/javascript">
	  var _paq = _paq || [];
	  _paq.push(['trackPageView']);
	  _paq.push(['enableLinkTracking']);
	  (function() {
		var u="//www.stats.numberchallenge.com/";
		_paq.push(['setTrackerUrl', u+'piwik.php']);
		_paq.push(['setSiteId', <?echo $info['piwik_id']?>]);
		var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
		g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
	  })();
	</script>
	<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=1" style="border:0;" alt="" /></p></noscript>
	<!-- End Piwik Code -->
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.1/themes/smoothness/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.11.1/jquery-ui.js"></script>
	
	</head>