<?php  
    include('header.php');
?>
	<body>
		<?php include('navigation.php');?>
		<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/form-wizard.css">
		<script src="<?php echo BASE_URL; ?>js/jquery.maskedinput.js" type="text/javascript"></script>
		<div class="pages-container">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h1>Post a Project</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="page-content p-c-2">
			<div class="container">
			<div id="errors2"></div>
				<div class="row">
					<div class="col-lg-8">
						<div class="container">
							<div class="row">
								<div class="col-lg-8">
									<div class="wrap-wizardForm-handyman">
										<div class="form-wizard">
								<div class="form-body">
									<h1 class="text-center ttle-frm-wiz"> Post a Project and Get <b>Results</b> <i>Immediately </i></h1>
							
									<div class="tab-content">
										<div id="tab1" class="tab-pane active">
											<div class="wrap-wizardForm-project">
												<div class="row">
													<div class="col-lg-12">
														<div class="form-horizontal">
															<hr/>
															<div class="row nopads">
															<label for="business_name" class="control-label col-lg-2 fnt-nrml">
																	Select Project Type <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<select name="projecttype" id="projecttype" class="form-control ">
																		<?php if($projecttype_id != '0'):?>
																		<?php 				
																			foreach($projecttypes as $array)
																			{
																				foreach($array as $key => $info)
																				{
																				if($projecttype_id == $info['ProjectTypeId']){
																				echo '<option value="'.$info['ProjectTypeId'].'" name='.$info['Name'].'>'.$info['Name'].'</option>';
																				}
																				}
																			}	
																		?>
																		
																		
																	<?php endif;?>
																	
																	
																	<option>Select Type</option>
																	<?php 				
																			foreach($projecttypes as $array)
																			{
																				foreach($array as $key => $info)
																				{
																				echo '<option value="'.$info['ProjectTypeId'].'" name='.$info['Name'].'>'.$info['Name'].'</option>';
																				}
																			}	
																		?>
																	</select>
																	<label class="postProjErr projecttype_message"></label>
																</div>
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	Zipcode <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<?php if($zip != '0'):?>
																		<input type="text" value="<?echo $zip?>" id="zip_code" name="zip_code" class="form-control">
																			
																	<?php else: ?>
																	
																		<input type="text" value="" id="zip_code" name="zip_code" class="form-control">
																	<?php endif;?>
																	<div id="errmsg"></div>
																	<label class="postProjErr zip_code"></label>
																</div>
															</div>
																										
															<div class="row nopads">
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	First Name <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<input type="text" class="form-control " id="homeown_fname" name="homeown_fname"> 
																	<label class="postProjErr homeown_fname"></label>
																</div>
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	Last Name <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<input type="text" class="form-control " id="homeown_lname" name="homeown_lname"> 
																	<label class="postProjErr homeown_lname"></label>
																</div>
														
															</div>
														
														
															<div class="row nopads">
															
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	Phone Number (10 digit number with area code) <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<input type="text" class="form-control " id="homeown_phone" name="homeown_phone">
																	<div id="errmsg2"></div>
																	<label class="postProjErr homeown_phone"></label>
																</div>
															
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	City <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<input type="text" type="text" value="" id="city" name="city" class="form-control "> 
																	<label class="postProjErr city"></label>
																</div>
															</div>
															<div class="row nopads">
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	Address <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<textarea name="projectaddress" id="projectaddress" rows="3" class="form-control "></textarea>
																	<label class="postProjErr projectaddress"></label>
																</div>
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	State <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<select name="projectstate" id="projectstate" class="form-control input-lg">
																					<option>Please select</option>
																					<option name="Alabama" value="2">Alabama</option>
																					<option name="Alaska" value="1">Alaska</option>
																					<option name="Arizinto states" value="4">Arizona states</option>
																					<option name="Arkansas" value="3">Arkansas</option>
																					<option name="California" value="5">California</option>
																					<option name="Connecticut" value="7">Connecticut</option>
																					<option name="Delaware" value="9">Delaware</option>
																					<option name="Florida" value="10">Florida</option>
																					<option name="Georgia" value="11">Georgia</option>
																					<option name="Hawaii" value="12">Hawaii</option>
																					<option name="Idaho" value="14">Idaho</option>
																					<option name="Indiana" value="52">Indiana</option>
																					<option name="Idiana States" value="16">Indiana States</option>
																					<option name="Kansas" value="17">Kansas</option>
																					<option name="Kentucky" value="18">Kentucky</option>
																					<option name="Louisiana" value="19">Louisiana</option>
																					<option name="Maine" value="22">Maine</option>
																					<option name="Maryland" value="21">Maryland</option>
																					<option name="Massachusetts" value="20">Massachusetts</option>
																					<option name="Michigan" value="23">Michigan</option>
																					<option name="Minnesota states" value="24">Minnesota states</option>
																					<option name="Minnesota" value="53">Minnesota</option>
																					<option name="Mississippi" value="26">Mississippi</option>
																					<option name="Missouri" value="25">Missouri</option>
																					<option name="Nevada states" value="30">Nevada states</option>
																					<option name="Nevada" value="34">Nevada</option>
																					<option name="New Hampshire" value="31">New Hampshire</option>
																					<option name="New Jersey" value="32">New Jersey</option>
																					<option name="New Mexico" value="33">New Mexico</option>
																					<option name="New York" value="35">New York</option>
																					<option name="North Carolina" value="28">North Carolina</option>
																					<option name="Ohio" value="36">Ohio</option>
																					<option name="Oklahoma states" value="37">Oklahoma states</option>
																					<option name="Pennsylvania" value="39">Pennsylvania</option>
																					<option name="South Carolina states" value="41">South  Carolina states</option>
																					<option name="South Dakota states" value="42">South Dakota states</option>
																					<option name="Tennessee" value="43">Tennessee</option>
																					<option name="Texas" value="44">Texas</option>
																					<option name="Utah" value="45">Utah</option>
																					<option name="Virginia" value="46">Virginia</option>
																					<option name="Washingto" value="48">Washington</option>
																					<option name="West Virginia" value="50">West Virginia</option>
																					<option name="Wiscinto statesi" value="49">Wisconsin states</option>
																					<option name="Wyoming" value="51">Wyoming</option>
																				</select>
																	
																	<label class="postProjErr projectstate"></label>
																</div>
																
															
															</div>
															
															<div class="row nopads">
															<label for="" class="control-label col-lg-2 fnt-nrml">
																	Ideal Start Date <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<select name="projectstart" id="projectstart" class="form-control ">
																		<option>Select</option>
																		<option value="Now">Now</option>
																		<option value="1-Week">1-Week</option>
																		<option value="2-Weeks">2-Weeks</option>
																		<option value="3-Weeks">3-Weeks</option>
																		<option value="1-2 Months">1-2 Months</option>
																		<option value="3-6 Months">3-6 Months</option>
																	</select>
																	<label class="postProjErr projectstart_message"></label>
																</div>
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	Project Status <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<select name="projectstatus" id="projectstatus" class="form-control ">
																		<option></option>
																		<option value="Ready to Hire">Ready to Hire</option>
																		<option value="Planning and Budgeting">Planning and Budgeting</option>
																	</select>
																	<label class="postProjErr projectstatus_message"></label>
																</div>
															</div>
														<div class="row nopads">
														<label for="" class="control-label col-lg-2 fnt-nrml">
																	Completion Time Frame <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<select name="projecttimeframe" id="projecttimeframe" class="form-control ">
																		<option>Select</option>
																		<option value="Timing is Flexible">Timing is Flexible</option>
																		<option value="Less than 2 months">Less than 2 months</option>
																		<option value="More than 2 months">More than 2 months</option>
																	</select>
																	<label class="postProjErr projecttimeframe_messafe"></label>
																</div>
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	Project Budget <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-4">
																	<select name="projectbudget" id="projectbudget" class="form-control ">
																		<option value="">Select</option>
																		<option value="up to $500">up to $500</option>
																		<option value="$500 to $1000">$500 to $1000</option>
																		<option value="$1000 to $2500">$1000 to $2500</option>
																		<option value="$2500 to $5000">$2500 to $5000</option>
																		<option value="$5000 to $10000">$5000 to $10000</option>
																		<option value="$10000 to $25000">$10000 to $25000</option>
																		<option value="$25000 to $50000">$25000 to $50000</option>
																		<option value="$50000 to $100000">$50000 to $100000</option>
																		<option value="$100000 to $200000">$100000 to $200000</option>
																		<option value="$200000 +">$200000 +</option>
																	</select>
																	<label class="postProjErr projectbudget"></label>
																</div>
														</div>
															
											<div class="form-group nopads">
																<label for="business_name" class="control-label col-lg-2 fnt-nrml">
																	Project Description <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-10">
																	<textarea name="projectdesc" id="projectdesc" rows="2" class="form-control "></textarea>
																	<label class="postProjErr projectdesc_message"></label>
																</div>
															</div>
															
															<div class="form-group nopads">
																<label for="" class="control-label col-lg-2 fnt-nrml">
																	Do You Own the Property <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-10">
																	<label class="radio-inline">
																	<input type="radio" id="projectown" value="1" name="won_pro"/> No
																	</label>
																	<label class="radio-inline">
																		<input type="radio" id="projectown" value="0" name="won_pro" checked/> Yes
																	</label>
																	<span class="help-block hide"> Provide your project type </span>
																</div>
															</div>
														
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 form-actions wizardFrom">
													<div class="row">
														<div class="col-lg-offset-4 col-lg-8" style="text-align:right !important;">
														
															<a class="btn btn-primary btn-lg" href="javascript:;" id="continuetoprojectinof">
																Continue to Get Free Estimates
																<i class="fa fa-chevron-right"></i>
															</a>
														
															
															
														</div>
													</div>
												</div>
											</div>
										</div>
										
										
										<div id="tab3" class="tab-pane">
											<div class="wrap-wizardForm-project">
												<div class="row">
													<div class="col-lg-12">
													
													<!--  register  -->
												<div id="content-register">
													<h3 class="fnt-nrml">
														<span class="">User Information </span>
													</h3>
													<div id="errors3"></div>
													<div class="form-horizontal">
														<div class="formRgstr">
															
															
															<div class="form-group">
																<label for="" class="control-label col-lg-4 fnt-nrml">
																	Public Username <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-6">
																	<input type="text" id="howeown_pname" name="howeown_pname" class="form-control "> 
																	<label class="postProjErr howeown_pname"></label>
																</div>
															</div>
															<div class="form-group">
																<label for="" class="control-label col-lg-4 fnt-nrml">
																	Email <span class="text-red pd-left">*</span>
																</label>
																<div class="col-lg-6">
																	<input type="text" class="form-control " id="homeown_email" name="homeown_email"> 
																	<label class="postProjErr homeown_email"></label>
																</div>
															</div>
															<div class="form-group">
																<div class="col-lg-6 col-xs-offset-4">
																	<label class="checkbox-inline">
																		<input type="checkbox" id="termscon" name="termscon"> I Accept And Agree To The <a href="/home/terms" target ="_blank">Terms & Condition.</a>
																	</label>
																</div>
															</div>
														</div>
													</div>
												</div>
												
												</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-12 form-actions wizardFrom">
													<div class="row">
														<div class="col-lg-offset-4 col-lg-8">
														
															<a href="javascript:;" class="btn btn-lg btn-default" id="backtoprojectinfo">
																<i class="fa fa-chevron-left"></i> 
																Back
															</a>
															<a class="btn btn-success btn-lg" href="javascript:;" id="continuetosuccess">
																Get Free Estimates 
																<i class="fa fa-chevron-right"></i>
															</a>
															
														</div>
													</div>
												</div>
											</div>
										</div>
										<div id="tab4" class="tab-pane">
											<div class="col-lg-8 col-lg-offset-2">
												<h1 class="text-success text-center">
													Thank You for Signing-up!
												</h1>
												<p class="text-center">Please wait while we prepare an instant contractor match. Check your email to view your password.</p>
												<br>
											</div>
											<div class="row">
												<div class="col-lg-12 form-actions wizardFrom">
													<div class="row">
														<div class="col-lg-offset-4 col-lg-8">
															
															<a href="javascript:;" class="btn btn-success" id="successid" style="display:none;">
																Submit 
																<i class="fa fa-check"></i>
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
									
									</div>
									<!-- <div class="row">
										<div class="col-lg-12 form-actions wizardFrom">
											<div class="row">
												<div class="col-lg-offset-4 col-lg-8">
													<a href="javascript:;" class="btn btn-default " style="display:none;">
														<i class="fa fa-chevron-left"></i> 
														Back
													</a>
													<a class="btn btn-primary" href="javascript:;" style="display:none;">
														Continue 
														<i class="fa fa-chevron-right"></i>
													</a>
													<a href="javascript:;" class="btn btn-success" style="">
														Submit 
														<i class="fa fa-check"></i>
													</a>
												</div>
											</div>
										</div>
									</div> -->
								</div>
							</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="alert alert-info">
							<strong>Dear Clients,</strong> <br>
							<p>
								First you will need to fill out this form, describing what needs to be done. Once your Project is approved and posted on the site, relevant Business people will be alerted. You'll receive email alerts when your Project starts getting interest and you'll then compare Contractor by reviewing profiles, work history, qualifications and customer reviews.
							</p>
						</div>
					</div>
				</div>
			</div>
			<br>
			<br>
		</div>
		
<script src="<?php echo BASE_URL; ?>js/postproject3.js"></script>
<?php include ('footer.php')?>