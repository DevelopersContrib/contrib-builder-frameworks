
<? include_once 'header.php'; ?>


<div id="container2">
<div id="middlebox">
<div id="content2">
<!--h2>Contact <?=$domain?></h2-->

	<iframe src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?=$domain?>" scrolling="no" frameborder="0" style="width: 350px;background: whitesmoke;height: 500px;padding: 15px 0 0 15px;border-radius: 5px;margin:40px"></iframe>


  

</div>
</div>
</div>


<? include_once 'footer.php';?>