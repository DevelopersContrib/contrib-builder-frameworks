
<!-- verticals-->
<?php if (count($related_domains)>0):?>
<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
<div class="verticals">
	<div class="container">
		<div class="row vermar">
				<div class="span12 text-center lead-ttle-top">
					<h4 class="brdr-lead">
						<i class="fa fa-globe"></i>
							Other Brands on <?php echo $vertical?> Vertical
					</h4>
				</div>				
				<div class="span12">
					<div class="row">
						<div class="span3"></div>
						<div class="span6">
							<div class="row">
								<div id="multiColumn">
									<ul>
										<?foreach($related_domains as $rel_domains):?>
											
											<li>
												<a href="http://<?php echo $rel_domains['domain_name']?>" class="verlinks" target="_blank">
													<div class="vernames">					
														<h3><i class="fa fa-arrow-right"></i>&nbsp;<?php echo ucwords($rel_domains['domain_name'])?></h3>
													</div>
												</a>
												
											</li>
										<? endforeach?>
									</ul>
								</div>								
							</div>
							<div class="row-fluid text-center">
								<div class="span12">
									<a target="_blank" class="vmore" href="http://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>"><i class="fa fa-search"></i>&nbsp;View More</a>
								</div>
							</div>
						</div>	
						<div class="span3"></div>
					</div>
				</div>
				
		</div>
	</div>
</div>
<?php endif;?>
<!-- -->

<div class="section-footer">
	<div class="container">
		<div id="partners">
			<p>
				<a href="/about">About</a><a href="/contact">Contact us</a><a href="/partners">Partner with us</a><a href="/staffing">Apply now</a>  
				<a href="/terms">Terms</a>
				<a href="/privacy">Privacy</a>
				<a href="/referral">Referral</a>
				<a href="/fund">Fund</a>
				<a href="/developers">Developers</a>
				<!--a href="/services">Services</a--><!--a href="http://www.applications.net">Developers Wanted</a-->
			</p>
		</div>
	</div>
	<div id="footer">
		<div>&copy; <?=$domain?> 2013-2016 </div>
		<?php echo $footer_banner?>
	</div>  
</div>
	
<!-- /container -->

 <input type="hidden" name="domain_name" id="domain_name" value = "<?echo $domain?>">
<!--/* OpenX Javascript Tag v2.8.7 */-->

<!-- div class="dev-wanted rotate">
<a href="http://www.contrib.com" target="_blank">Developers Wanted<i>!</a></i>
</div -->
<style>
.dev-wanted{position: fixed;background-color: rgb(251, 122, 58);border-color: rgb(251, 122, 58);top: 400px;left: 0;padding: 5px 15px;border-radius: 1px 1px 10px 10px;box-shadow: -1px 1px 1px rgb(158, 82, 0);}
.dev-wanted a{color: rgb(255, 255, 255);font-weight: bold;font-family: Arial, Helvetica, sans-serif;font-size: 14px;text-decoration: none;}
.dev-wanted:hover{background-color: rgb(233, 104, 40);border-color: rgb(197, 85, 29);}
.rotate {
-webkit-transform: rotate(270deg);-webkit-transform-origin: 0 0;
-moz-transform: rotate(270deg);-moz-transform-origin: 0 0 0;
-ms-transform: rotate(270deg);-ms-transform-origin: 0 0;
-o-transform: rotate(270deg);-o-transform-origin: 0 0;
}
</style>
<script src="js/jquery.counter.js" type="text/javascript"></script>
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script>


	
$(function() {
	//$('.counter').counter();
	
	var domain_name = $('#domain_name').val();
	
	getsocial(domain_name,'fb','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251686_facebook_circle_color.png');
	getsocial(domain_name,'twitter','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251704_twitter_circle_color.png');
	getsocial(domain_name,'gplus','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/gplus.png');
	
	
	
});

function getsocial(domain_name,social,icon_src){
	
	$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
					var socialdata = data[0];
					if(socialdata.error == true){
						//do nothing
					}else if(socialdata.profile_url == ""){
						//do nothing
					}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
						//do nothing
					}else{
						$('#socials_container').append('&nbsp;<a href="'+socialdata.profile_url+'"><img src="'+icon_src+'" height="40px"></a>&nbsp;');
					}		
	});
}

</script>


</body>
</html>