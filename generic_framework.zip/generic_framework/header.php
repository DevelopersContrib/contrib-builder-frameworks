<?php include('includes/config.php');?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="icon" type="image/icon" href="favicon.ico">
<script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
<link rel="canonical" href="http://<?=$domain?>" />
<meta name="robots" content="index, follow" />
<title><?=$title?></title>
<meta name="title" content="<?=$domain?> " />
<meta name="description" content="<?=$domain?> <?=$description?>" />
<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="js/jquery.counter-analog.css" media="screen" rel="stylesheet" type="text/css" />
<link href="js/jquery.counter-analog2.css" media="screen" rel="stylesheet" type="text/css" />
<![if IE]>
<link rel="stylesheet" type="text/css" href="css/style-ie.css" />
<![endif]>
<![if !IE]>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/verticals.css" />
<![endif]>
<style>
	<? if($background_image != ""){ ?>
	html {background: url(<?=$background_image?>) fixed;color: #A0A0A0;
	<? }else{ ?>
	html { background: url('http://rdbuploads.s3.amazonaws.com/backgrounds/Dollarphotoclub_54820605-me.jpg') no-repeat center center fixed; color: #A0A0A0;}
	<? } ?>
	
	.logotext{
		font-size: 50px;
		font-weight: bold;
		color: #fff;
		text-shadow: 0 1px 4px #000;
		margin-top: 50px;
		text-align: center;
		font-family: "Helvetica Neue", Helvetica, sans-serif;
	}

	
    .animated {
        -webkit-animation-duration: 1s;
        animation-duration: 1s;
        -webkit-animation-fill-mode: both;
        animation-fill-mode: both;
    }
    @-webkit-keyframes rotateIn {
        0% {
            -webkit-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(-200deg);
            transform: rotate(-200deg);
            opacity: 0;
        }
    
        100% {
            -webkit-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(0);
            transform: rotate(0);
            opacity: 1;
        }
    }
    
    @keyframes rotateIn {
        0% {
            -webkit-transform-origin: center center;
            -ms-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(-200deg);
            -ms-transform: rotate(-200deg);
            transform: rotate(-200deg);
            opacity: 0;
        }
    
        100% {
            -webkit-transform-origin: center center;
            -ms-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(0);
            -ms-transform: rotate(0);
            transform: rotate(0);
            opacity: 1;
        }
    }
    .rotateIn {
        -webkit-animation-name: rotateIn;
        animation-name: rotateIn;
    }
    .r-d{
        -webkit-animation-delay: 2.5s;
        -moz-animation-delay: 2.5s;
        -ms-animation-delay: 2.5s;
        -o-animation-delay: 2.5s;
        animation-delay: 2.5s;
    }
    .arrw-rela {
        position: relative;
    }
    .arrw-point-white {
        background: url("http://d2qcctj8epnr7y.cloudfront.net/contrib/arrow-1-medium.png") no-repeat scroll 0 0 rgba(0, 0, 0, 0);
        height: 92px;
        left: -89px;
        position: absolute;
        top: 85px;
        width: 100px;
    }
	
	#socials_container{text-align:center}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?=$account_ga?>']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$piwik_id?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->


<script type="text/javascript">
    $(document).ready(function(){
        $('.wrap-feature').css({'min-height': (($(window).height()))+'px'});
        $(window).resize(function(){
            $('.wrap-feature').css({'min-height': (($(window).height()))+'px'});
        });
    });
</script>
</head>
<body style="background-color: transparent !important;">

<? if($forsale=='1' || $forsaledefault=='1'){ ?>
	<div style="padding:10px 0 10px 0; margin:0; color: #fff; background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
		<?=$forsaletext?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$domain?>" target="_blank" style="color:blue;">Inquire now</a>.
	</div>
<? } ?>

<div style="position:relative;">
    <div style="position: absolute; z-index: 10; top: -20px; left: 190px;" class="animated rotateIn r-d">
       <a href="<?=$domain_affiliate_link;?>" target="_blank" alt="Contrib">
            <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-3.png">
        </a>
    </div>
</div>
<!-- script height -->



