<?php include_once 'header.php'; ?>



<div id="container2" style="width: 680px;">

<div id="middlebox">

<div id="content2">

<h2>Interested in Sponsoring, Partnering or Supporting  <?=$domain?>, Join Free today</h2>

<br />
<iframe src="http://domaindirectory.com/servicepage/partners_form.php?domain=<?=$domain?>" frameborder="0" scrolling="no" style="width:360px;height:435px;border: none;background: whitesmoke;border-radius: 5px;"></iframe>

<br class="clear" />    

<br class="clear" />    

<br class="clear" />    

<!-- div style="font-size:11px">

	<b><?=$domain?> </b>is considered a premium domain and at Domain Directory, 

	most of the domains are for development with in our Rapid Domain Builder platform. 

	Very few offers we receive on our domains are result in a transaction so please put your highest 

	and best offer forward to avoid wasting anytime. Good luck and wishing you a great 2011. 

</div -->

 

</div>

</div>

</div>



<? include_once 'footer.php';?>



<style>

.contact-hold{font-size:12px;color:white;font-weight: bold;}

#submit {height:40px !important;width:100px !important;float:right} 

.contact-hold input.c-in {

    background: none repeat scroll 0 0 #FFFFFF;

    border: 1px solid #BAC2C7;

    color: #000000;

    font-size: 12px;

    height: 26px;

    padding: 0 10px;

    width: 230px;

	-webkit-border-radius: 5px;

	-moz-border-radius: 5px;

	-o-border-radius: 5px;

	border-radius: 5px;

}

</style>