
<? include_once 'header.php'; ?>



<div id="container2">
<div id="middlebox">
<div id="content2">
<h2>Our Staffing Needs at <?=$domain?></h2>
<p>We are looking for the best of the best, Full-Time, Part-Time, Moonlighting, Contractual and Freelance.</p>

<p>We consult and manage over 100,000 domain name ventures  and are always seeking Strategic Partnerships, Applications, Domains, Engineers, Developers, Specialist and just cool smart people around the Globe.  Learn more about openings and opportunities with our partner companies and send us your resume or examples to accelerate the process.</p>
<p>Learn more about <a href="/contact.php">openings and opportunities</a> with our partner companies.</p>
<br />

<iframe src="http://www.contrib.com/forms/staffing/<?=$domain?>" scrolling="no" height="470px" width="350px" style="border:none;background: whitesmoke;border-radius: 5px;"></iframe>

</div>
</div>
</div>


<? include_once 'footer.php';?>