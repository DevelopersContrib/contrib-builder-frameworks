<?php
    $domain =   "digitelmedia.com";
    $domainid = "8882";
    $memberid = "38";
    $title = "Digitelmedia.com";
    $logo =  "";
    $description = "Join our exclusive community of like minded people on digitelmedia.com";
    $account_ga = "";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "";
    $fb_page =  "";
    $twitter = "";
    $bottom_text  = "";
    $forsale = "";
    $forsaledefault = "";
	$forsaletext = "This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.";
    $footer_banner = "";
    $domain_affiliate_link = "http://referrals.contrib.com/idevaffiliate.php?id=10854&url=http://www.contrib.com/signup/firststep?domain=digitelmedia.com";
    $additional_html = "";
	$about = "<p>Global Ventures, LLC, established in 1996, is a Real Estate and Technology company focused on building and leveraging electronic corporations (eCorp) within the Domain Name System.  Premium domains and companies such as Referrals.com,Staffing.com, Mergers.com, Domain Holdings, VentureCamp, Handyman.com, DSL.com and over 20,000 others are the core digital asset and building blocks of Global Ventures.</p> 							  <p>With over 1,000,000 targeted unique monthly visitors, Global Ventures utilizes both virtual and physical real estate with effective business models, streamlined policy and procedures with a balanced and optimal productivity and management platform for the global economy.</p> 							  <p>Learn more about joining our team, becoming an iPartner, or leveraging one of our premium domain assets or companies to help grow your business.</p>";
    $piwik_id = '14248';
	$partner_image = array (
  0 => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png',
  1 => 'http://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png',
  2 => 'http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png',
);
	$partner_domain = array (
  0 => 'contrib.com',
  1 => 'globalventures.com',
  2 => 'referrals.com',
);
	$partner_link = array (
  0 => 'http://contrib.com',
  1 => 'http://globalventures.com',
  2 => 'http://referrals.com',
);
	$partner_description = array (
  0 => 'Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today. ',
  1 => ' Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.  With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people. ',
  2 => 'Most effective Business Referral Program and Tools Available. Find and share referrals locally. ',
);
	$top_images = array (
  0 => '',
);
	$top_links = array (
  0 => '',
);
	$top_link_names = array (
  0 => '',
);
    $related_domains = array (
  0 => 
  array (
    'domain_name' => 'rapsurvey.com',
    'domain_id' => '24283',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-RapSurvey1.png',
    'title' => 'Rapsurvey.com',
    'slug' => 'business',
  ),
  1 => 
  array (
    'domain_name' => 'artschallenge.com',
    'domain_id' => '3427',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ArtsChallenge1.png',
    'title' => 'Artschallenge.com',
    'slug' => 'business',
  ),
  2 => 
  array (
    'domain_name' => 'gamegeeks.com',
    'domain_id' => '2925',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-GameGeeks1.png',
    'title' => 'Gamegeeks.com',
    'slug' => 'business',
  ),
  3 => 
  array (
    'domain_name' => 'stocktrivia.com',
    'domain_id' => '23575',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-StockTrivia1.png',
    'title' => 'Stocktrivia.com',
    'slug' => 'business',
  ),
  4 => 
  array (
    'domain_name' => 'workingdemos.com',
    'domain_id' => '23577',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-WorkingDemos1.png',
    'title' => 'Workingdemos.com',
    'slug' => 'business',
  ),
  5 => 
  array (
    'domain_name' => 'boardport.com',
    'domain_id' => '18054',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-BoardPort1.png',
    'title' => 'Boardport.com',
    'slug' => 'business',
  ),
  6 => 
  array (
    'domain_name' => 'ministryfund.com',
    'domain_id' => '21767',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-MinistryFund1.png',
    'title' => 'Ministryfund.com',
    'slug' => 'business',
  ),
  7 => 
  array (
    'domain_name' => 'amercard.com',
    'domain_id' => '27',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/AMerCard.com.png',
    'title' => 'Amercard.com',
    'slug' => 'business',
  ),
  8 => 
  array (
    'domain_name' => 'metamansion.com',
    'domain_id' => '23569',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-MetaMansion1.png',
    'title' => 'Metamansion.com',
    'slug' => 'business',
  ),
  9 => 
  array (
    'domain_name' => 'eventurelab.com',
    'domain_id' => '24460',
    'logo' => 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-EventureLab1.png',
    'title' => 'Eventurelab.com',
    'slug' => 'business',
  ),
);
    $fund_campaigns = array (
  0 => 
  array (
    'post_title' => 'Acting.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/acting-com/',
    'post_name' => 'acting-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/acting.com_.png',
    'post_content' => 'Acting.com allows actors and people in the entertainment industry to put up their profile to get casting audition jobs and opportunities. It also allows companies in the Production industry to...',
  ),
  1 => 
  array (
    'post_title' => 'CodeChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/codechallenge-com/',
    'post_name' => 'codechallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/codechallenge.png',
    'post_content' => '<h4>Join CodeChallenge.com</h4>
<h4><strong>Are you an entrepreneur or want to work for a great online business?</strong></h4>
*Select your niche.
*Get mentorship and access to premium online...',
  ),
  2 => 
  array (
    'post_title' => 'Cookboard.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Florida',
    'campaign_author' => 'Maai Florendo',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cookboard-com/',
    'post_name' => 'cookboard-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/11/logo-CookBoard-2.png',
    'post_content' => 'Your #1 Local Food Marketplace community! Join us as we launch it Dec 2014!

Where local chefs create cook boards for availability to the local foodie community\\n\\n

In depth...',
  ),
  3 => 
  array (
    'post_title' => 'CoWork.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cowork-com-virtual-opportunities-to-do-amazing-things/',
    'post_name' => 'cowork-com-virtual-opportunities-to-do-amazing-things',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/02/4743596194.jpg',
    'post_content' => '<a href="http://www.cowork.com">Cowork.com</a>

CoWork.com is an online venture creation network that works with other like minded professionals building awesome companies, projects and...',
  ),
  4 => 
  array (
    'post_title' => 'iChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/ichallenge-com/',
    'post_name' => 'ichallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/3616845592.jpg',
    'post_content' => 'Ichallenge.com is a gamification challenge framework that allows you to join a challenge or sponsor a challenge without monetary involvement.

&nbsp;',
  ),
  5 => 
  array (
    'post_title' => 'iContent.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/icontent-com/',
    'post_name' => 'icontent-com',
    'logo' => 'http://ifund.com/wp-content/uploads/2014/03/icontent-logo.png',
    'post_content' => '<p>iContent is a xml application that connects all your content into an integrated and intelligent system that learns and earns while you focus on creating amazing audio, visual and contextual...',
  ),
  6 => 
  array (
    'post_title' => 'Linked.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/linked-com/',
    'post_name' => 'linked-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/03/Linked_com-linked_com.png',
    'post_content' => 'Linking people, skills and opportunities to create the worlds largest crowd commerce business creation system. Be a part of Linked.com and get equity shares for your donations.

<img...',
  ),
  7 => 
  array (
    'post_title' => 'Micro Markets',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/micro-markets/',
    'post_name' => 'micro-markets',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/micromarkets1.png',
    'post_content' => '<a href="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets.png"><img alt="logo-micromarkets" src="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets-300x44.png"...',
  ),
  8 => 
  array (
    'post_title' => 'MusicChannel.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/musicchannel-com/',
    'post_name' => 'musicchannel-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/07/51661884511.jpg',
    'post_content' => 'MusicChannel is a weekly bounty competition that allows unsigned artists to publish their songs, make them viral and if they are selected will win weekly bounties!

We are looking for backers...',
  ),
  9 => 
  array (
    'post_title' => 'PhotoChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/photochallenge-com/',
    'post_name' => 'photochallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/photochallenge.png',
    'post_content' => '<h4>Join PhotoChallenge.com</h4>
<h4><strong>Are you an entrepreneur or want to work for a great online business?</strong></h4>
*Select your niche.
*Get mentorship and access to premium online...',
  ),
);
   
	
?>