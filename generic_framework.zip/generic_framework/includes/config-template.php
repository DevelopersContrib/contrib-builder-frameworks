<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
    $fb_page =  "{{FB_PAGE}}";
    $twitter = "{{TWITTER}}";
    $bottom_text  = "{{BOTTOM_TEXT}}";
    $forsale = "{{SHOW_FOR_SALE}}";
    $forsaledefault = "{{SHOW_FOR_SALE_DEFAULT}}";
	$forsaletext = "{{FOR_SALE_TEXT}}";
    $footer_banner = "{{FOOTER_BANNER}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $additional_html = "{{ADDITIONAL_HTML}}";
    $footer_html = "{{FOOTER_HTML}}";
	$about = "{{ABOUT}}";
    $piwik_id = '{{PIWIK_ID}}';
	$partner_image = {{PARTNER_IMAGE}};
	$partner_domain = {{PARTNER_DOMAIN}};
	$partner_link = {{PARTNER_DOMAIN_LINK}};
	$partner_description = {{PARTNER_DESCRIPTION}};
	$top_images = {{TOP_IMAGES}};
	$top_links = {{TOP_LINKS}};
	$top_link_names = {{TOP_LINK_NAMES}};
    $related_domains = {{RELATED_DOMAINS}};
    $fund_campaigns = {{FUND_CAMPAIGNS}};
    $approved_partner = {{PARTNERS}};
	
?>