
<? include_once 'header.php'; ?>

<div id="container2">

<div id="middlebox">

<div id="content2">

<h2>About <?=$domain?></h2>
<p><?=$title?> is a venture of of Global Ventures, LLC.</p>

<p><?=$description?></p>

<!--<p>Global Ventures, LLC, established in 1996, is a Real Estate and Technology company focused on building and leveraging electronic corporations (eCorp) within the Domain Name System.  Premium domains and companies such as Referrals.com,Staffing.com, Mergers.com, Domain Holdings, VentureCamp, Handyman.com, DSL.com and over 20,000 others are the core digital asset and building blocks of Global Ventures.</p>
							 
<p>With over 1,000,000 targeted unique monthly visitors, Global Ventures utilizes both virtual and physical real estate with effective business models, streamlined policy and procedures with a balanced and optimal productivity and management platform for the global economy.</p>
							 
<p>Learn more about joining our team, becoming an iPartner, or leveraging one of our premium domain assets or companies to help grow your business.</p>-->
	
	<?php echo $about?>
			




</div>

</div>

</div>





<? include_once 'footer.php';?>