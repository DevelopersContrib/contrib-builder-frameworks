NEWS FRAMEWORK Readme
by MB

Instructions
1. Fill db info in site_config.php for both RDB and writeable db for newsletter
2. Add the path for SEssion_tracking.php on site_config on line 34.
2. Fill db info on rss_config using RDB DB info for rss feeds.
3. Set /Cache/ directory permissions to 777
4. Thats it ! Load em up!




FEATURES VERSION 1.1
Main User Features :

   1. User can subscribe to latest news with our newsletter
   2. User can subscribe to Site�s Feed




Main Domain Owner Settings : Managesettings_news.php - RONAN

   1. SITE SETTINGS
         1. Be able to add/edit title
         2. Be able to add/edit tags
         3. Be able to add/edit tagline
         4. Be able to add/edit keywords - 1 major keyword
         5. Be able to add/edit footer copyright

   2. CONTENT MANAGEMENT
         1. Be able to post micro news- domain owner
         2. Be able to edit About
         3. Be able to edit Contact Us
         4. Be able to add/edit 4 Page Categories and Keywords that will serve as top most navigation
         5. Be able to add Digg feed
         6. Be able to add Twitter profile - twitter.com/maidabarrientos
         7. Be able to add Flickr  profile - flickr.com/maidabarrientos


   3. NEWSLETTER MANAGEMENT
         1. Be able to manage/add/edit newsletter subscriptions � leads
         2. Be able to export leads
   4. AD MANAGEMENT
         1. They can add their own ads for $1
         2. This is free if we have our own default ads running