<?
 //database for RDB
 $db_server = "localhost";
 $db_name = "contrib_page";
 $db_username = "contrib_maida";
 $db_userpassword = "bing2k";
 //DO NOT EDIT BELOW
 $dbhandle = mysql_connect($db_server, $db_username, $db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($db_name, $dbhandle) or die("Couldn't open
 database $db_name");

 $sitename = "contrib.com";//input sitename without www
// $sitename = "AnotherNews.com";//Domain url here
 $sitename = str_replace("http://","",$sitename);
 $sitename = str_replace("www.","",$sitename);

include('library/constants.php');// for news functions
require_once("simplepie/simplepie.inc");
require_once('library/news.php');
?>