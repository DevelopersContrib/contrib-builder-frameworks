<?php
/***************************************
SimplePie_Accelerator Demo
Author: Michael P. Shipley
Help: http://tech.groups.yahoo.com/group/simplepie-support/
Link: http://www.michaelpshipley.com
Requires: PHP5, SimplePie, PHP exec, wget, Linux based operating system
*****************************************/
require_once 'simplepie_accelerator.php';
require_once 'links.php'; // newline delimited strings

// if called by javascript xmlhttprequest, run demo then exit
if(isset($_POST['ajax']))
{
	run_benchmark($links);
	exit;
}

// html
header('Cache-Control: no-cache');
ini_set("zlib.output_compression", "0");
ob_implicit_flush();
ini_set("display_errors", "1");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>SimplePie_Accelerator Demo</title>
	<style type="text/css">
		#benchmark{margin:2em}
		#benchmark_result{margin-bottom:2em}
	</style>
</head>

<body>
<h1>SimplePie_Accelerator Demo</h1>
<h2>Instructions</h2>
<ol>
<li>Upload the <strong>simplepie_accelerator</strong> folder to your webserver.</li>
<li>Point your browser to <strong>simplepie_accelerator_demo.php</strong></li>
<li>Click [Run Demo]</li>
</ol>

<div id="benchmark">

<form action="simplepie_accelerator_demo.php" method="post" id="benchmarkform" onsubmit="return run_benchmark()">
	<input type="submit" value="Run Demo" name="submit">
</form>

<div id="benchmark_result">

<?php

if(isset($_POST['submit']))
{
	run_benchmark($links);
}


function run_benchmark($links)
{
	$urls = explode("\n",$links);

	echo '<h3>Testing '.count($urls).' feeds.</h3>';

	echo '<h3>Unaccelerated demo (1 feed at a time)</h3>';
	ob_flush();
	$maxProcesses = 1;
	$enableCache = 0; // turn cache off for demo
	$unacceleratedTime = process($urls,$maxProcesses,$enableCache);


	echo '<h3>Accelerated demo (5 feeds at a time)</h3>';
	ob_flush();
	$maxProcesses = 5;
	$enableCache = 0; // turn cache for demo
	$acceleratedTime = process($urls,$maxProcesses,$enableCache);
}



function process($urls,$maxProcesses,$enableCache)
{
	$begin = explode(' ', microtime());
	$begin = $begin[1] + $begin[0];
	$errors = array();
	$options = array(
		'urls'=>$urls,
		'maxProcesses'=>$maxProcesses,
		'timeout'=>5,
		'debug'=>1,
		'cacheDuration'=>0,
		'enableCache'=>$enableCache);
	$sa = new SimplePie_Accelerator($options);
	if($sa->fatal_error())
	{
		echo '<h3>'.$sa->fatal_error().'</h3>';
	}
	else
	{
		$errors = $sa->get_errors();
		$end = explode(' ', microtime());
		$elapsed = round($end[0] + $end[1] - $begin, 3);
		echo '<h3>Elapsed time: ' . $elapsed . '</h3>';
		echo '<h3>' . count($errors) . ' Errors</h3>';
		if(count($errors))
		{
			foreach($errors as $error)
			{
				echo $error['url'];
				echo '<br>';
				echo $error['errorMsg'];
				echo '<br>';
				echo '<br>';
			}
		}
		return $elapsed;
	}
}
?>
</div id="benchmark_result">
</div id="benchmark">
</body>
</html>
<script type="text/javascript" src="simplepie_accelerator_demo.js<?php echo '?'.time() ?>"></script>