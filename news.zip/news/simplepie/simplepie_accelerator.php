<?php
/**
 * SimplePie Accelerator
 *
 * Execute multiple SimplePie instances in parallel to update the SimplePie cache faster.
 *
 * Requires: PHP5, SimplePie, PHP exec, wget
 *
 * LICENSE: This source file is subject to the BSD license
 * that is available through the world-wide-web at the following URI:
 * http://www.opensource.org/licenses/bsd-license.php.
 *
 * @author     Michael P. Shipley <michaelpshipley@michaelpshipley.com>
 * @copyright  2008 Michael P. Shipley
 * @license    http://www.opensource.org/licenses/bsd-license.php BSD
 * @version    1.0
 * @link       http://www.michaelpshipley.com Michael Shipley
 * @link       http://tech.groups.yahoo.com/group/simplepie-support/ Support
 * @link       http://simplepie.org/ SimplePie
 * @todo       make it work with windows operating system
 */


/**
 * SimplePie_Accelerator
 *
 * A class that executes multiple SimplePie processes in parallel to update the SimplePie cache faster.
 *
 */
class SimplePie_Accelerator
{
	/**
	 * Holds all process information.
	 * @var array
	 * @access private
	 */
	private $processes = array();

	/**
	 * If there is a fatal error then this variable will hold the error message, otherwise it will be empty.
	 * @var string
	 * @access private
	 */
	private $fatalErrorMsg = '';

	/**
	 * Process errors are stored here.
	 * @var array
	 * @access private
	 */
	private $errors = array();

	/**
	 * Time in microseconds to sleep between process state checks.
	 * @var integer
	 * @access private
	 */
	private $sleep = 100000; // microseconds (.1 second)

	/**
	 * Filename of PHP script that updates that SimplePie cache.
	 * @var string
	 * @access private
	 */
	private $updaterFileName = 'simplepie_accelerator_updater.php';

	/**
	 * All options are held here.
	 * - 'urls'=>null,			// Feed urls
	 * - 'maxProcesses'=>5,		// Maximum simultaneous processes
	 * - 'timeout'=>5,			// Maximum time a process can run
	 * - 'cacheDuration'=>0,	// Simplepie cache duration. 0 = force update immediately.
	 * - 'debug'=>0,			// Echo debug messages
	 * - 'enableCache'=>1;		// For testing only. Usually always 1.
	 * @var array
	 * @access private
	 */
	private $options = array(
		'urls'=>null,
		'maxProcesses'=>5,	// Maximum simultaneous processes
		'timeout'=>5,		// Maximum time a process can run
		'cacheDuration'=>0,	// Simplepie cache duration. 0 = force update immediately.
		'debug'=>0,			// Echo debug messages
		'enableCache'=>1	// For testing only. Usually always 1.
	);


	/**
	 * Constructor is where everything happens.
	 * @access public
	 * @param array $options
	 */
	public function __construct($options)
	{
		// Merge user supplied options with defaults
		$this->options = array_merge($this->options,$options);

		// Test for urls
		if(empty($this->options['urls']))
		{
			$fatalErrorMsg = 'FATAL ERROR: no urls';
			$this->debug($fatalErrorMsg);
			$this->fatalErrorMsg = $fatalErrorMsg;
			return;
		}

		// Test for exec
		if(!function_exists('exec'))
		{
			$fatalErrorMsg = 'FATAL ERROR: exec disabled';
			$this->debug($fatalErrorMsg);
			$this->fatalErrorMsg = $fatalErrorMsg;
			return;
		}

		// Test for wget
		$command = 'wget';
		$ret = exec($command, $o, $r);
		if(!strstr($ret,'wget'))
		{
			$fatalErrorMsg = 'FATAL ERROR: wget not found';
			$this->debug($fatalErrorMsg);
			$this->fatalErrorMsg = $fatalErrorMsg;
			return;
		}

		// Test for existance of updater script. Should be in the same diretory as simplepie_accelerator.php
		$pathToSimplePie_Accelerator = __FILE__;
		$updaterPath = dirname($pathToSimplePie_Accelerator);
		$updaterFilePath = $updaterPath . '/' . $this->updaterFileName;

		if(!file_exists($updaterFilePath))
		{
			$fatalErrorMsg = 'FATAL ERROR: updater script not found at ' . $updaterFullPath;
			$this->debug($fatalErrorMsg);
			$this->fatalErrorMsg = $fatalErrorMsg;
			return;
		}

		// Create updater url
		$updaterURI = str_replace($_SERVER['DOCUMENT_ROOT'], '' , $updaterFilePath );
		$host = $_SERVER['HTTP_HOST'];
		$updaterURL = 'http://' . $host . $updaterURI;

		// main loop
		$urls = $this->options['urls'];
		foreach($urls as $urlKey=>$feedUrl)
		{
			$msg = ($urlKey+1) . '. Processing: ' . $feedUrl;
			$this->debug($msg);

			// wait for an open process slot
			$this->wait();

			// process slot open, start another process
			$urlEncoded = urlencode($feedUrl);
			$command = 'wget -q -O - ';
			$command .= '"';
			$command .= $updaterURL;
			$command .= "?url=$urlEncoded";
			$command .= "&cacheDuration={$this->options['cacheDuration']}";
			$command .= "&timeout={$this->options['timeout']}";
			$command .= "&enableCache={$this->options['enableCache']}";
			$command .= '"';
			$command .= ' &>/dev/null & echo $!';
			$this->debug($command);
			$pid = exec($command, $o, $r);
			if(!$pid)
			{
				$this->debug('Could not create process.');
				continue;
			}

			// add process to process array
			$process = array();
			$process['pid'] = $pid;
			$process['url'] = $feedUrl;
			$process['timeout'] = time() + $this->options['timeout'];
			$this->processes[] = $process;

			$msg = 'Process ID: ' . $pid;
			$this->debug($msg);
		}

		// finished all the feeds
		$this->debug('Waiting for all processes to finish.');
		$this->flush(); // flush processor queue
		$this->debug('All processes have finished.');
	}

	/**
	 * Check for fatal errors. Returns empty if none.
	 *
	 * @access private
	 */
	public function fatal_error()
	{
		return $this->fatalErrorMsg;
	}

	/**
	 * Echos debug info if debug option is set.
	 *
	 * @access public
	 */
	private function debug($string)
	{
		if($this->options['debug'])
		{
			echo 'time: '.time() . ': ' . $string;
			echo '<br>';
		}
	}

	/**
	 * Returns process errors.
	 *
	 * @access public
	 */
	public function get_errors()
	{
		return $this->errors;
	}

	/**
	 * Waits for open process slot.
	 *
	 * @access private
	 */
	private function wait()
	{
		// wait for open process sslot
		while(count($this->processes) == $this->options['maxProcesses'])
		{
			$this->checkProcesses();
			if(count($this->processes) < $this->options['maxProcesses'])
				break;
			$this->debug('Waiting for a process to finish.');
			usleep($this->sleep);
		} // while
	}

	/**
	 * Waits for all processes to finish
	 *
	 * @access private
	 */
	private function flush()
	{
		while(count($this->processes))
		{
			$this->checkProcesses();
			if(!count($this->processes))
				break;
			$this->debug('Waiting for a process to finish.');
			usleep($this->sleep); // sleep .1 seconds
		} // while
	}

	/**
	 * Polls processes for any that have terminated or timed out.
	 *
	 * @access private
	 */
	private function checkProcesses()
	{
		// if a process has finished, remove from process list
		foreach($this->processes as $key=>$process)
		{
			if(!$this->is_active($process['pid']))
			{
				// check for errors
				$filename = $this->encode($process['url']);
				if(file_exists($filename))
				{
					$this->errors[] = unserialize(file_get_contents($filename));
					unlink($filename);
				}
				$this->debug('Process ' . $process['pid'] . ' finished.');
				unset($this->processes[$key]);
			}
		}

		// if  process  exceeds timeout, kill it and remove from proc list
		foreach($this->processes as $key=>$process)
		{
			if($process['timeout'] <= time())
			{
				$error = array();
				$error['url'] = $process['url'];
				$error['errorMsg'] = 'timed out';
				$this->errors[] = $error;
				$this->debug('Killing: ' . $process['pid']);
				$this->killProcess($process['pid']);
				unset($this->processes[$key]);
				$filename = $this->encode($process['url']);
				if(file_exists($filename))
				{
					$this->errors[] = unserialize(file_get_contents($filename));
					unlink($filename);
				}
			}
		}
	}

	/**
	 * Returns true if a process is still active
	 *
	 * @access private
	 */
	private function is_active($pid)
	{
		exec("ps $pid", $ProcessState);
		return(count($ProcessState) >= 2);
	}

	/**
	 * Kills a process
	 *
	 * @access private
	 */
	private function killProcess($pid)
	{
		exec("kill -KILL $pid");
	}

	/**
	 * Returns encoded url
	 *
	 * @access private
	 */
	private function encode($url)
	{
		return 	md5($url);
	}
}
?>