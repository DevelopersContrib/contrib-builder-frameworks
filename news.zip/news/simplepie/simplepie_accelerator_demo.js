function run_benchmark()
{
		var benchmarkdiv;
		var http;

		benchmarkdiv = document.getElementById("benchmark_result");
		benchmarkdiv.innerHTML = '<p><img src="animated-pie.gif"></p>';

	if (window.XMLHttpRequest)
	{
		var http = new XMLHttpRequest();
	}
	else if (window.ActiveXObject)
	{
		var http = new ActiveXObject('Microsoft.XMLHTTP')
	}
	else
	{
		benchmarkdiv.innerHTML = "cant get xmlhttp";
		return true;
	}
	http.onreadystatechange = function()
	{
		if(http.readyState == 4)
		{
			if(http.status != 200)
			{
				http.responseText =  "<p><strong>http error: " + http.status + "</strong></p>" + http.responseText;
			}
			benchmarkdiv.innerHTML = http.responseText;
			return false;			
		}
	}
	var url = document.URL;
	var params = "ajax=yes";
	http.open("POST", url, true);
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	http.setRequestHeader("Content-length", params.length);
	http.send(params);
	return false;
}
