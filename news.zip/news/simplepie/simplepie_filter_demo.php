<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SimplePie Filter Addon Demo</title>
</head>
<body>
<?php

// load SimplePie Class
require_once 'simplepie.inc';

// extend SimplePie class and instantiate
require_once 'simplepie_filter.php';
$feed = new SimplePie_Filter();

// turn off caching since this is just a demo
$feed->enable_cache(false);

// these are the test feeds (clinton, obama)
$urls = array
(
		'http://blogsearch.google.com/blogsearch_feeds?q=clinton&oe=utf-8&client=firefox-a&um=1&ie=utf-8&num=10&output=rss',
		'http://blogsearch.google.com/blogsearch_feeds?hl=en&oe=utf-8&client=firefox-a&um=1&q=obama&ie=utf-8&num=10&output=rss'
);
$feed->set_feed_url($urls);

// set words to filter by
$words = 'clinton obama';

// set filter mode (and/or)
$mode = 'or';

// set the filter words and mode
$feed->set_filter($words,$mode);

// go speed racer
$feed->init();

if($feed->error())
{
	echo '<p>',$feed->error(),'</p>';
	die;
}
else
{
	$items = $feed->get_items(0,20);
	$itemsFiltered = $feed->filter($items);
	echo '<h3>Search Results</h3>';
	if(!count($itemsFiltered))
	{
		echo '<p><strong>' , $words , '</strong> not found</p>';
	}
	else
	{
		foreach($itemsFiltered as $item)
		{
			echo '<div style="margin-bottom:3em">';
			echo '<a href="',$item->get_link(),'">',highlight($words,strip_tags($item->get_title())),'</a><br />';
			echo $item->get_date(),'<br />';
			$content = strip_tags($item->get_content());
			$content = highlight($words,$content);
			echo $content,'<br />';
			echo '</div>';
		}
	}
}
function highlight($wordsToHighlight,$text)
{
	$w = addslashes($wordsToHighlight);
	$w = explode(' ',$w);
	foreach($w as $word)
	{
		$pattern = "#(^|[^\w])($word)($|[^\w])#ui";
		$replacement = '$1<span style="color:black;background-color:yellow">$2</span>$3';
		$text = preg_replace($pattern,$replacement,$text);
	}
	return $text;
}
?>
</body>
</html>
