<?
include_once('site_config.php');

include('includes/header.php');

include('includes/content_topwrap.php');

include('includes/content_left.php');

$ext_array = array(".com",".net",".org");	
?>
	<iframe src="http://ajchat.contrib.com/chat/<? echo str_replace($ext_array,"",$domainname)?>" style="width: 50%;min-height: 610px;"></iframe>
<?

include('includes/content_right.php');

include('includes/content_footerwrap.php');

include('includes/footer.php');

?>
















