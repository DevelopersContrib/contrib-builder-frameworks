<?
include_once('site_config.php');

include('includes/header.php');

include('includes/content_topwrap.php');

include('includes/content_left.php');
$error = "";
$sender_name ="";
$sender_email = "";
$sender_subject = "";
$sender_message = "";
   

if (isset($_POST['sendcontact'])){
   $sender_name = $_POST['sender_name'];
   $sender_email = $_POST['sender_email'];
   $sender_subject = $_POST['subject'];
   $sender_message = $_POST['message'];
   
   if ($sender_name==""){
    $error = "Please enter name.";
   }else if ($sender_email==""){
    $error = "Please enter email.";
   }else if ($sender_subject==""){
    $error = "Please enter subject.";
   }else if ($sender_message==""){
    $error = "Message should not be empty.";
   }else {
     if (SendContact($memberid,$sender_email,$sender_name,$sender_subject,$sender_message)=="1"){
        $error = "You successfully sent your message.";
     }else{
        $error = "Something wrong in sending message.";
     }
   
   }
   

}
if(empty($contactus)){
     $contact =  $sitename."&nbsp; is about &nbsp;".$title."
    <br /><br>Its key topic is about &nbsp;".$keyword.".&nbsp;If you want to contact us please
    feel free to do so by <a href=\"./contactus.html\">clicking here</a> and we will get back to you as soon as possible.";

   }else{
     $contact = "<p>".strip_tags($contactus)."</p>";
   }

?>
<div id="center">
<br class="clear" /><br />
<h1 class="post-title-block font">Contact <?=$sitename?></h1>

<div class="contact-box">

<p class="contact-text">
<?=$contact?>
</p>
<p class="contact-error"><?=$error?></p>


	<iframe width="400px" height="800px" src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?=$sitename?>"></iframe>


<!--form action="contact.php" method="POST">
	<div class="contact-form">
    	<span>Name:</span>
        <input name="sender_name" type="text" class="contact-input" value="<?=$sender_name?>"/>
    </div>
    <div class="contact-form">
    	<span>Email:</span>
        <input name="sender_email" type="text" class="contact-input" value="<?=$sender_email?>"/>
    </div>
    <div class="contact-form">
    	<span>Subject:</span>
        <input name="subject" type="text" class="contact-input" value="<?=$sender_subject?>"/>
    </div>
    <div class="contact-form">
    	<span>Message:</span>
        <textarea name="message" cols="" rows="" class="contact-textarea"><?=$sender_message?></textarea>
    </div>
    
	<div class="contact-form">
    	<span>&nbsp;</span>
        <input name="send" type="image" src="images/send-btn.jpg" />
        <input name="sendcontact" type="hidden" value="1"/>
    </div>
</form -->


</div><!--contact-box -->
</div>

<?

include('includes/content_right.php');

include('includes/content_footerwrap.php');

include('includes/footer.php');

?>
















