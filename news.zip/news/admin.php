<?
session_start();
include_once('site_config.php');
include('includes/mode.php');
include('includes/header.php');
include('includes/content_topwrap.php');
include('includes/content_left.php');
?>
<div id="center">
<br><br>
<?
  if (isset($_SESSION['admin_username'])){
?>
  <div id="tabs-container">
     <div id="tabs">
        <ul class="tabs-menu">
          <li><a href="#tab-1">Domain</a></li>
          <li><a href="#tab-2">Profile</a></li>
          <li><a href="#tab-3">Pages</a></li>
        </ul>
        <div id="tab-1" class="tabs-content tabs-content-first">
        <?include('includes/admin_domain_info.php');?>
        </div>
        <div id="tab-2" class="tabs-content">
        <?include('includes/admin_profile_info.php');?>
        </div>
        <div id="tab-3" class="tabs-content">
        <?include('includes/admin_pages.php');?>
        </div>
   </div>
  </div>
 <?
   }else {
   ?>
<h1 class="post-title-block font">Admin Login</h1>
     <div class="contact-box">
<?
if (isset($_SESSION['msg'])){
?>
<p class="contact-text">
<?=$_SESSION['msg']?>
</p>
<?
}
?>

<form action="" method="POST">
	<div class="contact-form">
    	<span>Username:</span>
        <input name="username" type="text" class="contact-input" value=""/>
    </div>
    <div class="contact-form">
    	<span>Password:</span>
        <input name="password" type="password" class="contact-input" value=""/>
    </div>
 	<div class="contact-form">
    	<span>&nbsp;</span>
        <input name="send" type="image" src="images/send-btn.jpg" />
        <input name="mode" type="hidden" value="adminlogin"/>
    </div>
</form>


</div><!--contact-box -->

   <?
   
   }
 ?> 
</div>
<?
include('includes/content_right.php');
include('includes/content_footerwrap.php');
include('includes/footer.php');

?>
















