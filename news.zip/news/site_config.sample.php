<?
/*
 * SITE CONFIG TEMPLATE
 */
//ADD THE PATH FOR THE SESSION_TRACKING.PHP LIBRARY
require_once(' ');//please input here
//1110 - we transferred tracking here for debugging purposes 


 //database for RDB
 $db_server = "localhost";
 $db_name = "";
 $db_sessionname = "";
 $db_username = "";
 $db_userpassword = "";

 $dbhandle = mysql_connect($db_server, $db_username, $db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($db_name, $dbhandle) or die("Couldn't open
 database $db_name");

 //for News Letter Subscription DB
 $sub_db_server = "localhost";
 $sub_db_name = "";
 $sub_db_username = "";
 $sub_db_userpassword = "";


 $sitename = $_SERVER["HTTP_HOST"];//input sitename without www
 $sitename = str_replace("http://","",$sitename);
 $sitename = str_replace("www.","",$sitename);

include('library/constants.php');// for news functions
require_once("simplepie/simplepie.inc");
require_once('library/news.php');// for news functions


?>




