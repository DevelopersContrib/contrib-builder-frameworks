﻿<?
include_once('site_config.php');

include('includes/header.php');

include('includes/content_topwrap.php');

include('includes/content_left.php');

?>
<div id="center">
<br /><br />
 <h1 class="post-title-block font"> <span class="pp1">About <?=$sitename?></span>  </h1>

<div class="post-box">
<? if(empty($about)){
     echo "<p>".$sitename."&nbsp; is about &nbsp;".$title."</p>
    <br /><p>Its key topic is about &nbsp;".$keyword.".&nbsp;If you want to contact us please
    feel free to do so by <a href=\"./contactus.html\">clicking here</a> and we will get back to you as soon as possible.</p>";

   }else{
     echo strip_tags($about);
   }
?>
</div><!--post-box -->
</div>

<?

include('includes/content_right.php');

include('includes/content_footerwrap.php');

include('includes/footer.php');

?>
















