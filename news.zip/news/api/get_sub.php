<?php
include "../site_config.php";

$dbhandle = mysql_connect( $sub_db_server,  $sub_db_username, $sub_db_userpassword)
	or die("Couldn't connect to SQL Server on $db_server");
 
$selected = mysql_select_db($sub_db_name, $dbhandle) or die("Couldn't open database $db_name");
$id =$_GET['id'];
$orderBy = isset($_GET['order'])?$_GET['order']:'Email';
$sort = isset($_GET['sort'])?$_GET['sort']:'ASC';

$sql = "select * from NewsLetterSubscriptions where DomainId = '$id' order by $orderBy $sort";

$result = mysql_query($sql);
if (!$result) {
	die('Invalid query: ' . mysql_error());
}

$num_rows = mysql_num_rows($result);

$array = array();

if ($num_rows > 0){
	while($res = mysql_fetch_array($result)){
		$array[] = array("NewsLetterSubscriptionId"=>$res['NewsLetterSubscriptionId'],"Email" => $res['Email'],"DateSubscribed" => $res['DateSubscribed']);
	}
}
echo json_encode( $array );
?>