<?

include_once('site_config.php');
include('includes/header.php');

include('includes/content_topwrap.php');

include('includes/content_left.php');




?>


<div id="center">
<br /><br />
<?
  $sub_email = $_POST['sub_email'];
  if (!empty($sub_email)){
     if (Subscribe($domainid,$sub_email)=="1"){
     
?>
 <h1 class="post-title-block font">Thank you for signing up!</h1>

 <br />
<h2>Hello there!</h2>
<br />
<p>First off, thank you for signing up. Now you will be able to get the latest on <?=$keyword?> every month via email and or rss feed.</p>
<br />
<p>Please don't forget to tell your friends!</p>



<?
  }else {
     echo "<h1 class=\"post-title-block font\">You already subscribed in this site.!</h1>";
     }
     
  }else {
     echo "<h1 class=\"post-title-block font\">Please enter email!</h1>";
  }
?>
</div>
<?
include('includes/content_right.php');

include('includes/content_footerwrap.php');

include('includes/footer.php');

?>
















