﻿<?php
header("Content-Type: application/xml; charset=ISO-8859-1");
$xml = '<?xml version="1.0" encoding="ISO-8859-1" ?><rss version="2.0"><channel>';
include 'rss_config.php';
 $feed = "";$item="";$news="";
$content = array();
$feed = new SimplePie('http://blogsearch.google.com/blogsearch_feeds?q='.$keyword.'&oe=utf-8&client=firefox-a&um=1&ie=utf-8&num=10&output=rss');
//$feed->enable_cache(true);
//$feed->set_cache_location('cache');
//$feed->set_cache_duration(24000);
$feed->init();
$feed->handle_content_type();
$i = 1; $noofitems=10;
        $xml.='<title>Latest News for '.$sitename.':'.$title.'</title><description>'.
        $tagline.'</description><link>'. $domain .'</link>';
foreach ($feed->get_items(4, $noofitems) as $item){
$post_link = $item->get_link();
$post_title = $item->get_title();
$post_date = $item->get_date();
$post_category = $item->get_category();
$post_description = $item->get_content();
                $xml .= '<item>
                         <title>'. $post_title .'</title>
                         <link>'. $post_link.'</link>
                         <description>'. $post_description.'</description></item>';
}

         $xml .= '</channel>';
         $xml .= '</rss></xml>';

        echo $xml;

?>