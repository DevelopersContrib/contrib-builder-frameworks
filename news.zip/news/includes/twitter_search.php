<?php
/*
	Twitter oauth registered by @sheinavi via greennews
	july 10, 2013
	
	sample codes from
	http://www.webdevdoor.com/jquery/twitter-feed-authentication-search/
*/

require_once("twitteroauth/twitteroauth/twitteroauth.php"); //Path to twitteroauth library
 


$consumerkey = "fNNGslK0y0nIN9ZdbMdb5Q";
$consumersecret = "dfBRleC7uybitdVSOEz9lhshkYTJ1yKImBHBTljQ338";
$accesstoken = "49571712-92QTwj1yeHzGAAjXTL8yL9Vlv7Hbooz3o0b6jns";
$accesstokensecret = "KQN0QRZHx8QzQTkGrFYS8y7lY6SpOK0OlLEYTTBp5Q";
  
function getConnectionWithAccessToken($cons_key, $cons_secret, $oauth_token, $oauth_token_secret) {
  $connection = new TwitterOAuth($cons_key, $cons_secret, $oauth_token, $oauth_token_secret);
  return $connection;
}
   




function getSiteNews($search = "domaindirectory", $notweets = 8){
	global $consumerkey;
	global $consumersecret;
	global $accesstoken;
	global $accesstokensecret;
	
	$connection = getConnectionWithAccessToken($consumerkey, $consumersecret, $accesstoken, $accesstokensecret);
  
	$tweets = $connection->get("https://api.twitter.com/1.1/search/tweets.json?q=".$search."&count=".$notweets);
	
	$resultarr = $tweets->statuses;
	
	foreach($resultarr AS $result){	
		echo '<div class="tweet">
			<div class="user_icon">
				<img src="'.$result->user->profile_image_url.'">
			</div>
			<div class="tweet_text">
				'.$result->text.'
				<a href="https://twitter.com/MonkiesFist/status/'.$result->id_str.'">
				<img src="http://d2qcctj8epnr7y.cloudfront.net/sheina/icons/search_small.png" alt="read"/>
				</a>
			</div>
		</div>';
	}

}
?>

