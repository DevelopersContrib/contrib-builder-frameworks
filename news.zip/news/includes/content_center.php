<div id="center">
<div class="slider-box">
<div id="slideshow">
            <div class="slides">
                <ul>
                    <li id="slide-one"><img src="<?=$banner1?>" width="450" height="130" alt="<?=$title?>" />  </li>
                    <li id="slide-two"><img src="<?=$banner2?>" width="450" height="130" alt="<?=$keyword?>" />  </li>
                    <li id="slide-three"><img src="<?=$banner3?>" width="450" height="130" alt="<?=$tagline?>" />  </li>
                    <li id="slide-four"><img src="<?=$banner4?>" width="450" height="130" alt="<?=$sitename?>" />   </li>
                    <li id="slide-five"><img src="<?=$banner5?>" width="450" height="130" alt="<?=$keyword?>" />  </li>
                </ul>
        </div>
            <ul class="slides-nav">
                <li class="on"><a href="#slide-one">1</a></li>
                <li><a href="#slide-two">2</a></li>
                <li><a href="#slide-three">3</a></li>
                 <li><a href="#slide-four">4</a></li>
                 <li><a href="#slide-five">5</a></li>
            </ul>
        </div> <!--slideshow -->
</div><!--slider-box -->

<h1 class="post-title-block font">Blog and News <span class="pp1">posts on <?=$keyword;?></span></h1>



<? echo show_news($keyword);?>

<br class="clear" /><br />
<h1 class="post-title-block font">Video <span class="pp1">posts on Topic</span>  <span  class="pp2"><?=$keyword?></span></h1>
<div class="post-video">
<?php
	$keys = explode(",",$keyword);
	$items = 0;
	foreach($keys as $key){
		echo show_video($key,$items);
		if($items>8)break;
	}
 ?>
</div><!--post-video -->




</div><!--center -->