<?php
	$email = $_POST['email'];
	$domain = $_POST['domain'];
	$logo = $_POST['logo'];
	$user_ip = $_POST['user_ip'];
	
	$db = new PDO('mysql:host=localhost;dbname=domaindi_sites;charset=utf8', 'domaindi_maida', 'bing2k');
	try {
		$result = $db->exec("INSERT INTO `leads`(email,domain_name,datetime_created,ip) VALUES('".$email."','".$domain."',NOW(),'".$user_ip."')");
		$insertId = $db->lastInsertId();
			/*send email notification*/
			/*$message = '
				<html>
				<table width="100%" cellpadding="0" cellspacing="0" border="0">
					<tbody>
						<tr>
							<td align="center" bgcolor="#c7c7c7">
							<table   style="margin:0 10px;" width="640" cellpadding="0" cellspacing="0" border="0">
								<tbody>
									<tr><td width="640" height="20"></td></tr>
												
												<tr>
											<td   width="640">
												<table id="top-bar" style=" border-radius:6px 6px 0px 0px; -moz-border-radius: 6px 6px 0px 0px; -webkit-border-radius:6px 6px 0px 0px; -webkit-font-smoothing: antialiased; background-color: #2E2E2E; color: #888888;" width="640" cellpadding="0" cellspacing="0" border="0" bgcolor="#000000">
							<tbody><tr>
								
									
									
								
								<td>
									<div style="font-size: 12px;color:#888;padding: 10px;">
										<a href="http://domaindirectory.com" style="font-size: 12px;color:#888;padding: 10px; text-decoration:none">DomainDirectory</a>
									</div>
								</td>
								
								<td>
									<div style="float:right">
										<a href="#" style="font-size: 12px;color:#888;padding: 10px; text-decoration:none"><img src="https://img.createsend1.com/img/templatebuilder/like-glyph.png" border="0" width="8" height="14" alt="Facebook icon"=""> Like </a>
										<a href="#" style="font-size: 12px;color:#888;padding: 10px; text-decoration:none"><img src="https://img.createsend1.com/img/templatebuilder/tweet-glyph.png" border="0" width="17" height="13" alt="Twitter icon"="">Tweet</a> 
									</div>
								</td>
								
							</tr>
						</tbody></table>
												
											</td>
										</tr>
									
									
									<tr>
							<td width="640" align="center" bgcolor="#000000">
				
				<table   width="640" cellpadding="0" cellspacing="0" border="0">
					
					
				
					<tbody><tr><td   width="30"></td><td   width="580" height="30"></td><td   width="30"></td></tr>
					<tr>
						<td   width="30"></td>
						<td   width="580">
							<div align="center">
								<p style="color: #EEE;font-family: Arial, Helvetica, Geneva, sans-serif;font-size: 36px;text-align: center; margin-top: 0px; margin-bottom: 30px;">
									<strong><a href="http://'.$domain.'" style="text-decoration: none;"><img style="width: 295px;height: 90px;" src="'.$logo.'" alt="'.ucfirst($domain).'"></img></a></strong>
								</p>
							</div>
						</td>
						<td   width="30"></td>
					</tr>
				</tbody></table>
				
				
			</td>
							</tr>
							 <tr>
								<td>
									<div style="width:100%;height: 10px;">
										<div style="float:left;width:170px;background-color:#f0f0f0">&nbsp;</div>
										<div style="float:right;width:470px;background-color: #F5F5F5">&nbsp;</div>
									</div>
								</td>
							 </tr>
							 <tr>
								<td>
								<div style="width:100%">
									<div style="height: 198px;float:left;width:170px;background-color:#f0f0f0">
										<div style="float:left;margin:0px 10px 0px 10px">
											<h4>Please check out <a href="http://globalventures.com">Global Ventures</a> other great companies and Opportunities below. </h4>
											&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://referrals.com">Referrals.com</a><br>
											&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://handyman.com">HandyMan.com</a><br>
											&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://venturecamp.com">VentureCamp.com</a><br>
											&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://domainpower.com">DomainPower.com</a><br>
											&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://talentdirect.com">TalentDirect.com</a><br>
										</div>
									</div>
									<div style="float:right;width:470px;background-color: #F5F5F5;min-height: 223px;">
										<p style="padding:10px"><font color = "gray" size = "3">Hi,
										<br><br>
										
										You are now in our private and exclusive beta list! <br />
											Thanks for your interest in <a href="http://'.$domain.'">'.ucwords($domain).'</a>! You&#39;ve been added to our queue for Beta access to the <a href="http://'.$domain.'">'.ucwords($domain).'</a> platform. We&#39;ll be in touch soon! </b> <br><br><br>
										</font>
										</p>
									</div>
								</div>
								</td>
							</tr>
							<tr>
								<td>
									<div style="width:100%;height: 10px;">
										<div style="float:left;width:170px;background-color:#f0f0f0">&nbsp;</div>
										<div style="float:right;width:470px;background-color: #F5F5F5">&nbsp;</div>
									</div>
								</td>
							 </tr>
							<tr>
							<td   width="640">
				<table id="footer" style="border-radius:0px 0px 6px 6px; -moz-border-radius: 0px 0px 6px 6px; -webkit-border-radius:0px 0px 6px 6px; -webkit-font-smoothing: antialiased;"   width="640" cellpadding="0" cellspacing="0" border="0" bgcolor="#000000">
					<tbody><tr><td   width="30"></td><td   width="360" height="30"></td><td   width="60"></td><td   width="160"></td><td   width="30"></td></tr>
					<tr>
						<td   width="30"></td>
						<td   width="360" valign="top">
						<span class="hide"><p id="permission-reminder" align="left" style="font-size: 12px; line-height: 15px; color: #888;" class="footer-content-left"></p></span>
						<p align="left" style="font-size: 12px; line-height: 15px; color: #888; margin-top: 0px; margin-bottom: 15px;"><preferences lang="en">You are receiving this email because you created an account at <a href="http://'.$domain.'" style="text-decoration:none">'.ucwords($domain).'</a>.</preferences></p>
						</td>
						<td   width="60"></td>
						<td   width="160" valign="top">
						<p id="street-address" align="right" class="footer-content-right"></p>
						</td>
						<td   width="30"></td>
					</tr>
					<tr><td   width="30"></td><td width="360" height="15"></td><td   width="60"></td><td   width="160"></td><td   width="30"></td></tr>
				</tbody></table>
			</td>
							</tr>
								</tbody>
							</table>
							</td>
						</tr>
					</tbody>
				</table>
			</html>'; */
			
			$message = '
				<table cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed;color:#555;font-family:Arial,sans-serif;font-size:12px;line-height:22px">
				<tbody>
					<tr>
						<td bgcolor="#545454"><br>
							<table cellpadding="0" cellspacing="0" width="90%" bgcolor="#ffffff" border="0" rules="none" frame="border" align="center" style="border-width: 10px 0px 0px 0px;border-color: #E4E2E4;color:#555;font-family:Arial,sans-serif;font-size:12px;line-height:22px">
								<tbody>
									<tr>
										<td valign="top">
											<br><br>
											<table cellpadding="0" cellspacing="0" width="90%" align="center" style="color:#555;font-family:Arial,sans-serif;font-size:12px;line-height:22px">
												<tbody>
													<tr>
														<td width="55%" valign="top"><a href="http://'.ucfirst($domain).'"><img style="width: 295px;height: 90px;" src="'.$logo.'" alt="'.ucfirst($domain).'"></img></a></td>
														<td width="5%">&nbsp;</td>
														<td width="35%" valign="top" align="right">'.date("F d, Y").' <br>
															<b><a href="http://'.ucfirst($domain).'">'.ucfirst($domain).'</a></b></td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
									<tr><td style="background: rgb(255, 249, 249);"><br></td></tr>
									<tr><td><br></td></tr>
									<tr>
										<td>
											<table width="100%">
												<tr>
													<td width="20%" valign="top">
																<h4>Please check out <a href="http://globalventures.com">Global Ventures</a> other great companies and Opportunities below. </h4>
																&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://referrals.com">Referrals.com</a><br>
																&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://handyman.com">HandyMan.com</a><br>
																&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://venturecamp.com">VentureCamp.com</a><br>
																&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://domainpower.com">DomainPower.com</a><br>
																&raquo;&nbsp;<a style="text-decoration:none;line-height:25px;" href="http://talentdirect.com">TalentDirect.com</a><br>
													</td>
													<td width="70%" valign="top">
														<p style="padding:0px 20px;">Hi,
															<br><br>
																You are now in our private and exclusive beta list! <br />
																Thanks for your interest in <a href="http://'.$domain.'">'.ucwords($domain).'</a>! 
																You&#39;ve been added to our queue for Beta access to the <a href="http://'.$domain.'">'.ucwords($domain).'</a> platform. 
																We&#39;ll be in touch soon! </b> <br><br><br></p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
									<tr><td><br><br></td></tr>
									<tr>
										<td width="80%" valign="top" align="center" style="background: #E4E2E4;padding:10px 0;font-size: 11px;line-height: 15px;"> 
											'.ucwords($domain).' is a member of <a href="http://domaindirectory.com">DomainDirectory.com</a> and a venture of <a href="http://globalventures.com">GlobalVentures.com</a><br> 
										</td>
									</tr>
									<tr>
										<td style="background: #E4E2E4;padding: 10px;">
											<table cellpadding="0" cellspacing="0" width="80%" align="center" style="color:#555;font-family:Arial,sans-serif;font-size:12px;line-height:22px">
												<tbody>
													<tr>
													<td width="120">Connect with us:</td>
													<td width="35"><img src="http://domaindirectory.com/servicepage/images/facebook.png" width="24" height="24" border="0" alt=""></td>
													<td width="80"><a href="http://www.facebook.com/GlobalVenturescom">Facebook</a> </td>
													<td width="35"><img src="http://domaindirectory.com/servicepage/images/twitter.png" width="24" height="24" border="0" alt=""></td>
													<td width="80"><a href="https://twitter.com/gventurescom">Twitter</a> </td>
													<td width="35"><img src="http://domaindirectory.com/servicepage/images/contact.png" width="24" height="24" border="0" alt=""></td>
													<td width="90"><a href="http://domaindirectory.com/contactus.html">Contact Us</a></td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							 </table>
						  <br>
						  <br>
						</td>
					</tr>
				</tbody>
			</table>
			
			';
			
			$headers = "From: ".$domain."\r\n"; 
			$headers .= 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";  
			$subject = "Your ".$domain." Submission";
			
			mail($email, $subject, $message, $headers);	
			
			echo $insertId;
		
	} catch(PDOException $ex) {
	   echo $ex;
	}

?>