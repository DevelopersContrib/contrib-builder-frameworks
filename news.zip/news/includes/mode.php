<?php
 if (isset($_REQUEST['mode'])){
    $mode = $_REQUEST['mode'];
    switch ($mode){
       case "savedomaininfo":
          $query = "Update Domains set Title = '".mysql_escape_string($_POST['Title'])."',
                    Tagline = '".mysql_escape_string($_POST['Tagline'])."',
                    HeaderContent = '".$_POST['HeaderContent']."',
                    TrackerContent = '".$_POST['TrackerContent']."' 
                    Where DomainId=1";
             $result = mysql_query($query);
             if (!$result) {
               die('Invalid query: ' . mysql_error());
             }                   
          
          $query = "Update NewsAttributes set FooterCopyright = '".mysql_escape_string($_POST['FooterCopyRight'])."',
                     AboutContent = '".mysql_escape_string($_POST['AboutContent'])."',
                     ContactUsContent = '".mysql_escape_string($_POST['AboutContent'])."'      
                     Where DomainId=1";
             $result = mysql_query($query);
             if (!$result) {
               die('Invalid query: ' . mysql_error());
             }                   
       break;
       case "saveprofileinfo":
              $query = "Update Members set EmailAddress= '".mysql_escape_string($_POST['EmailAddress'])."',
                        FirstName = '".mysql_escape_string($_POST['FirstName'])."',
                        LastName = '".mysql_escape_string($_POST['LastName'])."'
                    Where MemberId=1";
             $result = mysql_query($query);
             if (!$result) {
               die('Invalid query: ' . mysql_error());
             }                   
        
       break;
       
       case "savenewspage":
             $query = "Insert into NewsPages (PageName,Category,Keyword,DomainId) 
             Values (
             '".mysql_escape_string($_POST['PageName'])."',
             '".mysql_escape_string($_POST['Category'])."',
             '".mysql_escape_string($_POST['Keyword'])."',1
             )";
              $result = mysql_query($query);
             if (!$result) {
               die('Invalid query: ' . mysql_error());
             }
       break;
       
       case "deletepage":
            $id = $_REQUEST['pageid'];
            $query = "Delete from NewsPages where NewspageId = $id";
            $result = mysql_query($query);
            if (!$result) {
               die('Invalid query: ' . mysql_error());
            }
            header("Location: admin.php");
            exit;
       break;
       
       case "adminlogin":
         $username = $_POST['username'];
         $password = $_POST['password'];
         if (($username == $admin_username) && ($password == $admin_password)){
             $_SESSION['admin_username'] = $admin_username;
             header("Location: admin.php");   
             exit; 
         }else {
            $_SESSION['msg'] = "<font color='red'>Incorrect Username or Password!</font>";
            header("Location: admin.php");
            exit;    
         } 
       break;
       
       case "logout":
          unset($_SESSION['admin_username']);
          unset($_SESSION['msg']);
          header("Location: admin.php");
          exit;
       break;
    }
 }
?>
