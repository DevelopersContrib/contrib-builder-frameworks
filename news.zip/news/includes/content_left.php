<div id="left">
	<div class="subcribe-box">
    	<div id="leads_box">
		<h1 class="subs-heading font" style="font-size: 17px;">Enter your email to join our</h1>
        <h2 class="subs-subheading font">Exclusive Invite List</h2>
        <form id="submitLead">
        	<input name="subscriber_email" type="text" id="subscriber_email" onfocus="if(this.value=='Enter email'){ this.value = '';  }" value="Enter email" class="subs-input-text" />
			<input id="subscribe" name="subscribe" type="image" class="subscribe-btn" src="images/subscribe-btn.png" />
			<input type="hidden" name="sitename" id="sitename" value="<?=$domain?>" />
			<input type="hidden" name="user_ip" id="user_ip" value="<?=$_SERVER['REMOTE_ADDR']?>" />
			<input type="hidden" name="logo_url" id="logo_url" value="<?=$logo?>" />
		</form>
		</div>
    </div>
    <br class="clear" />
  <!--  <h2 class="title-block font">Popular Sites</h2>
    	<ul class="popular-site">
		   <?
            show_popularsites($domainid);
           ?>
        </ul>
   -->     
        <br class="clear" />
        <? //echo ShowSocialSites($domainid);?>
        <br class="clear" />
 <h2 class="title-block font">Twitter on <?=$keyword?></h2>
<div class="twitter-box">
 	<?php
		//$keys = explode(",",$keyword);
		$keys = str_replace('OR',',',$keyword);
		getSiteNews($keys,8)
		
	?>


 </div><!--twitter-box -->



     <br class="clear" />


</div><!--left -->
<script type="text/javascript">
	$(document).ready(function() {
		$('#submitLead').submit(function(){
			var subscriber_email = $('#subscriber_email').val();
			if(validateEmail(subscriber_email) == true){
				var domainname = $('#sitename').val();
				var logo_url = $('#logo_url').val();
				var user_ip = $('#user_ip').val();
				$.post("includes/leads_post.php",{domain:domainname,email:subscriber_email,logo:logo_url,user_ip:user_ip}
				,function(data){
					if(data > 0){
						
						$('#leads_box').html('<p class="lead_post_message_success">You successfully joined our <br> Exclusive Invite List ! </p>');
					}else{
						alert(data);
						$('#leads_box').html('<p class="lead_post_message_error">'+data+'</p>');
					}
				});
				
				return false;
			}else{
				alert('false');
			}
			return false;
		});
	});
	
	function validateEmail(email) { 
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}
</script>