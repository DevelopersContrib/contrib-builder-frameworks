<h1 class="post-title-block font"> <span class="pp1">Profile Information</h1>
   <div class="contact-box" id="domain_info">
  <?
   $query = "Select * from Members where MemberId=1";
   $result = mysql_query($query);
   if (!$result) {
     die('Invalid query: ' . mysql_error());
   }
   $num_rows = mysql_num_rows($result);
   if ($num_rows > 0){
       while($res = mysql_fetch_array($result))
      	{
      	?>
    <form action="" method="POST">
	  <div class="contact-form">
    	<span>Email Address:</span>
        <input name="EmailAddress" type="text" class="contact-input" value="<?=$res['EmailAddress']?>"/>
    </div>
    <div class="contact-form">
    	<span>First Name:</span>
        <input name="FirstName" type="text" class="contact-input" value="<?=$res['FirstName']?>"/>
    </div>
    <div class="contact-form">
    	<span>Last Name:</span>
        <input name="LastName" type="text" class="contact-input" value="<?=$res['LastName']?>"/>
    </div>
    
	<div class="contact-form">
    	<span>&nbsp;</span>
        <input name="send" type="image" src="images/send-btn.jpg" />
        <input name="mode" type="hidden" value="saveprofileinfo"/>
    </div>
</form>
      	<?
        }
    }     
 
  ?>
  </div>