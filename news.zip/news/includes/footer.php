<br class="clear" />
<div id="footer">
<p style="text-align:center"><?=strip_tags($footercontent)?></p>
<br />

	 <p class="copyright">&copy;  <?=date('Y')?> <a href="http://<?=$sitename?>"><?=$sitename?></a> | A member of <a href="http://globalventures.com">GlobalVentures.com</a> | Distributed by <a href="http://eCorp.com">eCorp.com</a></p>
		<ul class="foot-menu">
      <li><a href="about.html">About Us</a></li>

      <li><span>|</span></li>
      <li><a href="contactus.html">Contact Us</a></li>

      <li><span>|</span></li>
      <li><a href="rss">RSS Feed</a></li>
    </ul><!--foot-menu -->
  <div id="foot-left">

  </div><!--foot-left -->
  <div id="foot-right">

  </div><!--foot-right -->
</div><!--footer -->

<div class="dev-wanted rotate">
<a href="http://www.developers.contrib.com" target="_blank">Developers Wanted<i>!</a></i>
</div>


<script type="text/javascript" src="http://tags.crwdcntrl.net/c/380/cc.js"></script><script type="text/javascript" language="javascript">LOTCC.bcp();</script>
