<h1 class="post-title-block font"> <span class="pp1">Domain Information</h1>
   <div class="contact-box" id="domain_info">
  <?
   $query = "Select * from Domains Left Join NewsAttributes On (NewsAttributes.DomainId = Domains.DomainId) where Domains.DomainId=1";
   $result = mysql_query($query);
   if (!$result) {
     die('Invalid query: ' . mysql_error());
   }
   $num_rows = mysql_num_rows($result);
   if ($num_rows > 0){
       while($res = mysql_fetch_array($result))
      	{
      	?>
    <form action="" method="POST">
	  <div class="contact-form">
    	<span>Title:</span>
        <input name="Title" type="text" class="contact-input" value="<?=$res['Title']?>"/>
    </div>
    <div class="contact-form">
    	<span>Tagline:</span>
        <textarea name="Tagline" cols="" rows="" class="contact-textarea"><?=$res['Tagline']?></textarea>
    </div>
    <div class="contact-form">
    	<span>Header Content:</span>
        <textarea name="HeaderContent" cols="" rows="" class="contact-textarea"><?=$res['HeaderContent']?></textarea>
    </div>
    <div class="contact-form">
    	<span>Tracker Content:</span>
        <textarea name="TrackerContent" cols="" rows="" class="contact-textarea"><?=$res['TrackerContent']?></textarea>
    </div>
    <div class="contact-form">
    	<span>Logo Url:</span>
        <input name="Logo" type="text" class="contact-input" value="<?=$res['Logo']?>"/>
    </div>
    <div class="contact-form">
    	<span>Footer Copyright:</span>
        <textarea name="FooterCopyRight" cols="" rows="" class="contact-textarea"><?=$res['FooterCopyRight']?></textarea>
    </div>
    <div class="contact-form">
    	<span>About Content:</span>
        <textarea name="AboutContent" cols="" rows="" class="contact-textarea"><?=$res['AboutContent']?></textarea>
    </div>
    <div class="contact-form">
    	<span>Contact Us Content:</span>
        <textarea name="ContactUsContent" cols="" rows="" class="contact-textarea"><?=$res['ContactUsContent']?></textarea>
    </div>
    
	<div class="contact-form">
    	<span>&nbsp;</span>
        <input name="send" type="image" src="images/send-btn.jpg" />
        <input name="mode" type="hidden" value="savedomaininfo"/>
    </div>
</form>
      	<?
        }
    }     
 
  ?>
  </div>