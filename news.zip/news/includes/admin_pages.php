<h1 class="post-title-block font"> <span class="pp1">News Pages</h1>
   <div class="contact-box" id="domain_info">
  <?
   $query = "Select * from NewsPages where DomainId=1";
   $result = mysql_query($query);
   if (!$result) {
     die('Invalid query: ' . mysql_error());
   }
   $num_rows = mysql_num_rows($result);
   if ($num_rows > 0){
   ?>
   <table width="80%" border="1">
   <tr><td><b>Page Name</b></td><td><b>Category</b></td><td><b>Keyword</b></td><td><b>Actions</b></td> </tr>
   <?
       while($res = mysql_fetch_array($result))
      	{
      	?>
      	<tr><td><?=$res['PageName']?></td><td><?=$res['Category']?></td><td><?=$res['Keyword']?></td><td><a href="?mode=deletepage&pageid=<?=$res['NewspageId']?>">[X]<a></td> </tr>
      	<?
      }
    ?>
    </table>
    <br><br>
    <?  
   }   	
      	?>
    <h1 class="post-title-block font"> <span class="pp1">Add New Page</h1>  	
    <form action="" method="POST">
	  <div class="contact-form">
    	<span>Category:</span>
        <input name="Category" type="text" class="contact-input" value=""/>
    </div>
    <div class="contact-form">
    	<span>Page Name:</span>
        <input name="PageName" type="text" class="contact-input" value=""/>
    </div>
    
    <div class="contact-form">
    	<span>Keyword:</span>
        <input name="Keyword" type="text" class="contact-input" value=""/>
    </div>
    
	<div class="contact-form">
    	<span>&nbsp;</span>
        <input name="send" type="image" src="images/send-btn.jpg" />
        <input name="mode" type="hidden" value="savenewspage"/>
    </div>
</form>
      	
  </div>