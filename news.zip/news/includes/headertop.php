	<div class="head-top-left">
  	<a href="" class="logo"><span><?=$title?></span></a> 


    </div>
    <div class="head-top-right">
    	<ul class="top_social_links">
            <li><a onclick="this.style.behavior='url(#default#homepage)';this.setHomePage('');" href="#">
            <img src="images/icons/socialbar-icon-home.gif"> Make HomePage</a></li>
            <li><a onclick="window.print();return false;" title="Print" href="http://<?=$sitename?>">
<img src="images/icons/socialbar-icon-print.gif"> Print</a></li>
            <li><a title="View This Page on your Mobile" href="http://www.google.com/gwt/n?u=http://<?=$sitename?>"><img src="images/icons/socialbar-icon-mobile.gif"> Mobile</a></li>
            <li><a title="Feedback" href="http://<?=$sitename?>/contact.html">Feedback</a></li>
            <li><a href="http://www.addtoany.com/share_save#url=http%3A%2F%2F<?=$sitename?>&amp;title=3d.org&amp;description=" class="a2a_dd"><img alt="Share/Save/Bookmark" src="images/icons/socialbar-icon-save.gif" style="border-width: 0pt;">Share</a></li>
        </ul><!--mt_social_links -->



    <ul class="main_top_event">

	<li>Today is <? echo $today = date("F j, Y");?></li>
    <li><span>|</span></li>
	<li><a href="rss.php">Subscribe to our Feed</a></li>

	</ul><!--main_top_event -->
    </div>
</div><!--head-top -->
