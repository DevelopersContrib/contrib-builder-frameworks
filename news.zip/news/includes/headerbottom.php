<style type="text/css">
.head-bot-left img{ max-width:240px !important; max-height:105px !important; border:none !important;}
</style>

<div class="head-bot">
  <!--	<div class="head-bot-left"><a href="#" class="logo2"><img src="images/logo.jpg" width="187" height="30" alt=" " /></a></div>-->
  	<div class="head-bot-left">  <a href="#" class="logo2 subs-heading font"><?//=$sitename?></a> 

   <? if(empty($logo)){?>
         <p style="font-size: 50px;line-height: 62px;font-color:black;"> <?echo ucfirst($sitename);?></p>
     <?  }else{
          echo "<img src='".$logo."' alt='".$sitename."' title='".$sitename."' />";
	  }
    ?>


</div>

    <div class="head-bot-right">
    <?
	/*if(!($header_ads_html == ""))
		echo stripslashes($header_ads_html);
	else*/
    //show ads here via this function
    echo $footer_banner;
	
	?>
  <!--  	<p class="ads-text"><a href="#">Advertise on this site for 0.00 per month</a></p>-->
    </div>
</div><!--head-bot -->
