<div id="right">
<br />
  <h2 class="title-block font">Latest Site News</h2>
<div class="twitter-box">
  <? //echo show_micro_news($domainid);?>
  <? //echo show_twitter_username('domaindirectory');?>
	<? echo getSiteNews(); ?>
 <br style="clear:both;">
<div class="twitter-box">
	<script type="text/javascript" src="http://contrib.com/widgets?ma=micronews&d=<?=$domainid?>"></script>
</div>



 </div><!--twitter-box -->



</div><!--right -->