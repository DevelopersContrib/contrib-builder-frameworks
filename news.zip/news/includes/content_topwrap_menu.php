<div class="menu-holder">
          <ul class="main-menu ">
            <li><a href="index.html">Home  </a></li>
            <li><a href="about.html">About </a></li>
           <?=menu_home();?>
            <li><a href="contactus.html">Contact Us </a></li>
            <li><a href="discussion.html">Discussion </a></li>
           
          </ul><!--main-menu -->
      </div><!--menu-holder -->