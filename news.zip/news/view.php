<?
include_once('site_config.php');


include('includes/header.php');

include('includes/content_topwrap.php');

include('includes/content_left.php');

?>
<br />
<div id="center">
<br />
 <?=$_SESSION["snews".$_REQUEST['post_link']]?>
<br class="clear" />
<?=show_share();?>
<br class="clear" />
<script>
var idcomments_acct = '5552958eef2ae7fe597118d968514483';
var idcomments_post_id;
var idcomments_post_url;
</script>
<span id="IDCommentsPostTitle" style="display:none"></span>
<script type='text/javascript' src='http://www.intensedebate.com/js/genericCommentWrapperV2.js'></script>
<br /><br />
<hr />

<h2>Other related news</h2>
<br /><br />
<?=show_news_list($keyword); ?>
</div>

<?

include('includes/content_right.php');

include('includes/content_footerwrap.php');

include('includes/footer.php');

?>
















