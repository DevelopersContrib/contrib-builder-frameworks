﻿<?

include_once('site_config.php');
$pagename = trim($_REQUEST['pagename']);
$keywordcat = getCategoryKeyword($domainid,$pagename);
include('includes/header.php');

include('includes/content_topwrap.php');

include('includes/content_left.php');

?>
<div id="center">
<br /><br />
 <h1 class="post-title-block font">Category  &nbsp;:&nbsp;<span class="pp1"><?=getCategoryName($domainid,$pagename)?></span></h1>

 <br />
 <?=show_news($keywordcat);?>


</div>

<?

include('includes/content_right.php');

include('includes/content_footerwrap.php');

include('includes/footer.php');

?>
















