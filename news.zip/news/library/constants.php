<?php
require('curl_client.php');
$max_redirect = 3;  // Skipable: default => 3
$client = new Curl_Client(array(

	CURLOPT_FRESH_CONNECT => 1,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_USERAGENT => ''

), $max_redirect);

$monetize_url = "http://manage.vnoc.com/monetize/getcode";



$sitename =  $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];

if(stristr($sitename, '~') ===FALSE) {
	$sitename = $_SERVER["HTTP_HOST"];								
	$sitename = str_replace("http://","",$sitename);
	$sitename = str_replace("www.","",$sitename);	
	 $key = md5('vnoc.com');
}else {
   $key = md5('vnoc.com');
   $d = explode('~',$sitename);
   $user = str_replace('/','',$d[1]);
   $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
   $client->get($url);
   $result = $client->currentResponse('body');
   $data_domain = json_decode($result,true);
   $error = 0;
   $sitename =   $data_domain[0]['domain'];
	
}


$url = $api_url.'getdomaininfo?domain='.$sitename.'&key='.$key;
$client->get($url);
$result = $client->currentResponse('body');
$data_domain = json_decode($result,true);

$error = 0;
if (!$data_domain['error'])
       {
            $domainid = $data_domain[0]['DomainId'];
            $domainname = $data_domain[0]['DomainName'];
            $memberid = $data_domain[0]['MemberId'];
            $title = $data_domain[0]['Title'];
            $tagline = $data_domain[0]['Tagline'];
            $footer = $data_domain[0]['FooterCopyright'];
            $about = $data_domain[0]['Description'];
            $contactus  = $data_domain[0]['ContactUsContent'];
            $useads = $data_domain[0]['UseAds'];
            $headercontent = $data_domain[0]['HeaderContent'];
            $footercontent = $data_domain[0]['TrackerContent'];
            $logo = $data_domain[0]['Logo'];
            $account_ga = $data_domain[0]['AccountGA'];
      	}else {
      		$error++;
}
      	
$client->get($api_url.'getmemberinfo/?member_id='.$memberid.'&key='.$key);
$result = $client->currentResponse('body');
$data_member = json_decode($result,true);

if (!$data_member['error']){
	$site_owners_email = $data_member[0]['EmailAddress'];
    $site_owners_name = $data_member[0]['FirstName'];
}else {
	$error++;
}
    

$client->get($api_url.'gettag/?domainid='.$domainid.'&key='.$key);
$result = $client->currentResponse('body');
$data_tag = json_decode($result,true);
if (!$data_tag['error']){
     $tagname = $data_tag[0]['tag'];
}else {
	$error++;
}      	       

$domainorig = $sitename;
$domain = $sitename;
$keyword = $tagname;
if ($keyword == ""){
  $keyword = "news";
}



$client->get($api_url.'getnewspages/?domainid='.$domainid.'&key='.$key);
$result = $client->currentResponse('body');
$pages = json_decode($result,true);
$i=0;

if (!$pages['error']){
       foreach ($pages as $k=>$page){
       	  $nav[$i]['category'] = $page['Category'];
      	  $nav[$i]['keyword']  = $page['Keyword'];
      	  $nav[$i]['pagename']  = $page['PageName'];
          $i++;  
        
     }
}else {
	  $error++;
}

$client->get($api_url.'getnewsinfo/?domainid='.$domainid.'&key='.$key);
$result = $client->currentResponse('body');
$newsdata = json_decode($result,true);
if(!$newsdata['error']){
	$footercontent = $newsdata[0]['FooterContent'];
	$meta_description = $newsdata[0]['Description'];
	$keywords = $newsdata[0]['Keywords'];
	$header_ads_html = $newsdata[0]['HeaderAdsHTML'];
	$banner1 = $newsdata[0]['Banner1'];
	$banner2 = $newsdata[0]['Banner2'];
	$banner3 = $newsdata[0]['Banner3'];
	$banner4 = $newsdata[0]['Banner4'];
	$banner5 = $newsdata[0]['Banner5'];
}else{
	$error++;
}

if ($error > 0){
	 echo "<center><h3>Problem with Api</h3></center>";
	 exit;
}

//get monetize ads from vnoc
$url = $monetize_url.'?d='.$sitename.'&p=footer';
$client->get($url);
$result = $client->currentResponse('body');
$data_ads = json_decode($result,true);
$footer_banner = "";


?>
