<?
error_reporting(E_ALL);
 ini_set("display_errors", 1);
//function menu_home($domain,$page){
//this is a dynamic menu depending on category or page if
//home, about, contactus, category1, 2, 3, and or 4

function menu_home(){
  global $nav;
  global $domain;
  $menu = "";
  
  for ($i=0;$i<count($nav);$i++){
  $link = "category-".$nav[$i]['pagename'].".html";
  $menu .= ' <li><a href="'.$link.'">'.$nav[$i]['category'].'</a></li>';
  }          
return $menu;
}

function show_ads_top($domainid){
	$html = '<script type="text/javascript"><!--// <![CDATA[
   OA_show(3);
// ]]> --></script><noscript><a target="_blank" href="http://adring.ecorp.com/www/delivery/ck.php?n=dca2eb0"><img border="0" alt="" src="http://adring.ecorp.com/www/delivery/avw.php?zoneid=3&amp;n=dca2eb0" /></a></noscript>
	';
  // echo '<a href="#"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/banner-728x80-domainholdings.png" width="720" height="80" alt=" " /></a>';
  echo $html;
return;
}

function show_popularsites($domainid){
  echo '
  	<li><a href="#">Ecorp.com</a></li>
			<li><a href="#">Domainbuild.com</a></li>
			<li><a href="#">Handyman.com</a></li>
			<li><a href="#">Contractorpage.com</a></li>
			<li><a href="#">DSL.com</a></li>
			<li><a href="#">RapidDomainBuilder.com</a></li>
			<li><a href="#">VentureChallenge.com</a></li>
			<li><a href="#">1800bet.com</a></li>
			<li><a href="#">Barchallenge.com</a></li>
			<li><a href="#">Contentcentral.com</a></li>
			<li><a href="#">Worldtop.com</a></li>
			<li><a href="#">StartupWeb.org</a></li>
			<li><a href="#">Digihosting.com</a></li>
    ';
return;
}




function show_twitter($domainid,$keyword,&$items){
$noofitems = 5;

if(empty($keyword)){
$keyword = "world news";
}  
//$keywords = str_replace(",",",+",$keyword);
$keyword = str_replace(" ","+",$keyword);
//$key = explode(",",$keyword);
//$keywords=$key[0];

$timestamp = time();
$date_time_array = getdate($timestamp);

$hours = $date_time_array['hours'];
$minutes = $date_time_array['minutes'];
$seconds = $date_time_array['seconds'];
$month = $date_time_array['mon'];
$day = $date_time_array['mday'];
$year = $date_time_array['year'];

// use mktime to recreate the unix timestamp
// adding 19 hours to $hours
$timestamp = mktime($hours + 0,$minutes,$seconds,$month,$day,$year);
$theDate = strftime('%Y-%m-%d %H:%M:%S',$timestamp);

$search = "http://search.twitter.com/search.atom?q=".$keyword."";
//echo $search; 
$tw = curl_init();
curl_setopt($tw, CURLOPT_URL, $search);
curl_setopt($tw, CURLOPT_RETURNTRANSFER, TRUE);
$twi = curl_exec($tw);
$search_res = new SimpleXMLElement($twi);

//echo "<h3>Twitter search results for '".$keywords."'</h3>";

## Echo the Search Data
$limno = 0;

foreach ($search_res->entry as $twit1) {

	$description = $twit1->content;

	$description = preg_replace("#(^|[\n ])@([^ \"\t\n\r<]*)#ise", "'\\1<a href=\"http://www.twitter.com/\\2\" >@\\2</a>'", $description);
	$description = preg_replace("#(^|[\n ])([\w]+?://[\w]+[^ \"\n\r\t<]*)#ise", "'\\1<a href=\"\\2\" >\\2</a>'", $description);
	$description = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#ise", "'\\1<a href=\"http://\\2\" >\\2</a>'", $description);

	$retweet = "http://twitter.com/home?status=RT+@".$twit1->author->name."+".strip_tags($description);


	$date =  strtotime($twit1->updated);
	$dayMonth = date('d M', $date);
	$year = date('y', $date);
	$message = "";
	$datediff = "";
	//$message = $twit1->content;
	$datediff = date_diff($theDate, $date);


	if($limno <= $noofitems){
		//echo "<div class='user'><a href=\"",$twit1->author->uri,"\" target=\"_blank\"><img border=\"0\" width=\"36\" border=\"1px solid #ccc;\" class=\"twitter_thumb\" src=\"",$twit1->link[1]->attributes()->href,"\" title=\"", $twit1->author->name, "\" /></a>\n";
		//echo "<div class='text'>".$description."<div class='description'>From: ", $twit1->author->name," <a href='http://twitter.com/home?status=RT: ".$retweet."' target='_blank'>Retweet!</a></div><strong>".$datediff."</strong></div><div class='clear'></div></div>";
		echo '<div class="user">
			<a target="_blank" href="'.$twit1->author->uri.'" class="user-img"><img width="36" border="0" title="" src="'.$twit1->link[1]->attributes()->href.'" class="twitter_thumb"></a>
			<div class="text">
			'.$description.'    </div>
			<div class="description">'.$twit1->author->name.'
				<a target="_blank" href="'.$retweet.'">Retweet!</a>
			</div>
			<strong>'.$datediff.'</strong>
			</div>

		';
		$items++;
		$limno=$limno+1;
	}else{
		$items = $limno;
		break;
	}

	if($items>8)break;
}

curl_close($tw);

//show twitter news depending on keyword
return;

}

function show_twitter_username($username){
$noofitems = 5;

if(empty($keyword)){
$keyword = "world news";
}  
//$keywords = str_replace(",",",+",$keyword);
$keyword = str_replace(" ","+",$keyword);
//$key = explode(",",$keyword);
//$keywords=$key[0];

$timestamp = time();
$date_time_array = getdate($timestamp);

$hours = $date_time_array['hours'];
$minutes = $date_time_array['minutes'];
$seconds = $date_time_array['seconds'];
$month = $date_time_array['mon'];
$day = $date_time_array['mday'];
$year = $date_time_array['year'];

// use mktime to recreate the unix timestamp
// adding 19 hours to $hours
$timestamp = mktime($hours + 0,$minutes,$seconds,$month,$day,$year);
$theDate = strftime('%Y-%m-%d %H:%M:%S',$timestamp);

$search = "https://api.twitter.com/1/statuses/user_timeline.rss?screen_name=domaindirectory";
$tw = curl_init();
curl_setopt($tw, CURLOPT_URL, $search);
curl_setopt($tw, CURLOPT_RETURNTRANSFER, TRUE);
$twi = curl_exec($tw);
$search_res = new SimpleXMLElement($twi);

//echo "<h3>Twitter search results for '".$keywords."'</h3>";

## Echo the Search Data
$limno = 0;

foreach($search_res->channel->item as $twit1) {

$description = $twit1->description;

$description = preg_replace("#(^|[\n ])@([^ \"\t\n\r<]*)#ise", "'\\1<a href=\"http://www.twitter.com/\\2\" >@\\2</a>'", $description);
$description = preg_replace("#(^|[\n ])([\w]+?://[\w]+[^ \"\n\r\t<]*)#ise", "'\\1<a href=\"\\2\" >\\2</a>'", $description);
$description = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#ise", "'\\1<a href=\"http://\\2\" >\\2</a>'", $description);

$retweet = "http://twitter.com/home?status=RT+@".$twit1->author->name."+".strip_tags($description);


$date =  strtotime($twit1->pubDate);
$dayMonth = date('d M', $date);
$year = date('y', $date);
$message = "";
$datediff = "";
//$message = $twit1->content;
$datediff = date_diff($theDate, $date);


if($limno <= $noofitems){
//echo "<div class='user'><a href=\"",$twit1->author->uri,"\" target=\"_blank\"><img border=\"0\" width=\"36\" border=\"1px solid #ccc;\" class=\"twitter_thumb\" src=\"",$twit1->link[1]->attributes()->href,"\" title=\"", $twit1->author->name, "\" /></a>\n";
//echo "<div class='text'>".$description."<div class='description'>From: ", $twit1->author->name," <a href='http://twitter.com/home?status=RT: ".$retweet."' target='_blank'>Retweet!</a></div><strong>".$datediff."</strong></div><div class='clear'></div></div>";
echo '<div class="user">
    
	<div class="text">
    '.$twit1->description.'    
    </div>
    
    <strong>'.$datediff.'</strong>
    </div>

';

}
 $limno=$limno+1;
}

curl_close($tw);

//show twitter news depending on keyword
return;

}


function show_share(){
echo'
<!-- AddThis Button BEGIN -->
<div style="width:320px;text-align:left;">
<div class="addthis_toolbox addthis_default_style">
<a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
<a class="addthis_button_tweet"></a>
<a class="addthis_counter addthis_pill_style"></a>
</div>
</div>
<script type="text/javascript">var addthis_config = {"data_track_clickback":true};</script>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=mypagenetwork"></script>
';
return;
}

function show_news($keyword){
require_once('simplepie/simplepie.inc');
if(empty($keyword)){
$keyword = "world+news";
}
$keyword = str_replace(" ","+",$keyword);
$noofitems = 10;
$feed = "";$item="";$news="";
$snews="";
$content = array();
$feed = new SimplePie('http://blogsearch.google.com/blogsearch_feeds?q='.$keyword.'&oe=utf-8&client=firefox-a&um=1&ie=utf-8&num=10&output=rss');
//$feed->enable_cache(true);
//$feed->set_cache_location('cache');
//$feed->set_cache_duration(24000);
$feed->init();
$feed->handle_content_type();
$i = 1;
foreach ($feed->get_items(4, $noofitems) as $item):
$post_link = $item->get_link();
$post_title = $item->get_title();
$convtitle = generateSlug($post_title,50);
$post_date = $item->get_date();
$post_category = $item->get_category();
$post_description = $item->get_content();

$news .= '<div class="post-box"><h2 class="post-title"><a href="view-'. $i.'-'.$convtitle.'.html">';
$news .= $post_title;
$news .= '</a></h2>';
$news .= '<p class="post-date">';
$news .= $post_date;
$news .= '&nbsp;'. $post_category .'</p><p>';
$news .= $post_description;
//print $item->get_content();
$news .= '</p></div>';

$snews = '<div class="post-box"><h1 class="post-title-block font"><a href="view-'. $post_link.'-'.$convtitle.'.html" target="_blank">';
$snews .= $post_title;
$snews .= '</a></h1>';
$snews .= '<p class="post-date">';
$snews .= $post_date;
$snews .= '&nbsp;'. $post_category .'</p><p>';
$snews .= $post_description;
$snews .= '</p></div>';
$content[$i] = $snews;
$snews = "";
$_SESSION["snews$i"] =$content[$i];
$i++;
endforeach;
/*
echo '<div class="post-box">
	<h2 class="post-title"><a href="#">Saw 3D French TV Spot &amp; FB Poster « NEWS Gate</a></h2>
    <p class="post-date">12 October 2010, 8:34 pm</p>
    <p>Tomorrow at the 2010 Comic-Con panel for Saw 3D, Lionsgate officials and Jigsaw himself (Tobin Bell) will announce that the seventh film will indeed be the final chapter in the franchise. Those devastated to hear this news (I suppose ...Tomorrow  at the 2010 Comic-Con panel for Saw 3D, Lionsgate officials and Jigsaw himself (Tobin Bell) will announce that the seventh film will indeed be the final chapter in the franchise. Those devastated to hear this news (I suppose ...</p>
</div>';
*/

return $news;
}


function show_news_list($keyword){
require_once('simplepie/simplepie.inc');
if(empty($keyword)){
$keyword = "world+news";
}
$keyword = str_replace(" ","+",$keyword);
$noofitems = 10;
$feed = "";$item="";$news="";
$snews="";
$content = array();
$feed = new SimplePie('http://blogsearch.google.com/blogsearch_feeds?q='.$keyword.'&oe=utf-8&client=firefox-a&um=1&ie=utf-8&num=10&output=rss');
//$feed->enable_cache(true);
//$feed->set_cache_location('cache');
//$feed->set_cache_duration(24000);
$feed->init();
$feed->handle_content_type();
$i = 1;
foreach ($feed->get_items(4, $noofitems) as $item):
$post_link = $item->get_link();
$post_title = $item->get_title();
$convtitle = generateSlug($post_title,50);
$post_date = $item->get_date();
$post_category = $item->get_category();
$post_description = $item->get_content();

$news .= '<div class="post-box"><h1 class="post-title-block font"><a href="view-'.$i.'-'.$convtitle.'.html">';
$news .= $post_title;
$news .= '</a></h1>';
$news .= '</div>';
$snews = '<div class="post-box"><h2 class="single-post-title"><a href="view-'.$i.'-'.$convtitle.'.html" target="_blank">';
$snews .= $post_title;
$snews .= '</a></h2>';
$snews .= '</div>';
$content[$i] = $snews;
$snews = "";
$_SESSION["snews$i"] =$content[$i];
$i++;
endforeach;
/*
echo '<div class="post-box">
	<h2 class="post-title"><a href="#">Saw 3D French TV Spot &amp; FB Poster « NEWS Gate</a></h2>
    <p class="post-date">12 October 2010, 8:34 pm</p>
    <p>Tomorrow at the 2010 Comic-Con panel for Saw 3D, Lionsgate officials and Jigsaw himself (Tobin Bell) will announce that the seventh film will indeed be the final chapter in the franchise. Those devastated to hear this news (I suppose ...Tomorrow  at the 2010 Comic-Con panel for Saw 3D, Lionsgate officials and Jigsaw himself (Tobin Bell) will announce that the seventh film will indeed be the final chapter in the franchise. Those devastated to hear this news (I suppose ...</p>
</div>';
*/

return $news;
}

function show_video($keyword,&$items){
   $keyword = str_replace(" ","+",$keyword);
   $keyword = preg_replace("/,/","+",$keyword);
 //$feedURL = 'http://gdata.youtube.com/feeds/api/standardfeeds/most_viewed';
    $feedURL = "http://gdata.youtube.com/feeds/api/videos/-/".$keyword."?orderby=viewCount&max-results=8";

    // read feed into SimpleXML object
    $sxml = simplexml_load_file($feedURL);
    // iterate over entries in feed
    $content = array(); $i = 1;
    foreach ($sxml->entry as $entry) {
      // get nodes in media: namespace for media information
      $media = $entry->children('http://search.yahoo.com/mrss/');

      // get video player URL
      $attrs = $media->group->player->attributes();
      $watch = $attrs['url'];

      // get video thumbnail
      $attrs = $media->group->thumbnail[0]->attributes();
      $thumbnail = $attrs['url'];
      $title = $media->group->title;
      $convtitle = generateSlug($title,50);
      //$attrs = $media->group->title->attributes();
      $keywords = $media->group->keywords;
      $description = $media->group->content;
      $date = $media->group->date;



      // get <yt:duration> node for video length
      $yt = $media->children('http://gdata.youtube.com/schemas/2007');
      $attrs = $yt->duration->attributes();
      $length = $attrs['seconds'];



      // get <yt:stats> node for viewer statistics
      $yt = $entry->children('http://gdata.youtube.com/schemas/2007');
      $attrs = $yt->statistics->attributes();
      $viewCount = $attrs['viewCount'];


      // get <gd:rating> node for video ratings
      $gd = $entry->children('http://schemas.google.com/g/2005');
      if ($gd->rating) {
        $attrs = $gd->rating->attributes();
        $rating = $attrs['average'];
      } else {
        $rating = 0;
      }
    echo '
      <div class="item">
            <span class="thumbnail">
            <a href="view-'.$i.'-'.$convtitle.'.html"><img style="width: 100px; height: 95px;" title="'.$title.'" src="'.$thumbnail.'"></a>
            </span>
      </div>
      ';
$snews = '<div class="post-box"><h1 class="post-title-block font"><a href="view.php?post_link='. $watch.'" target="_blank">';
$snews .= $title;
$snews .= '</a></h1>';
$snews .= '<p class="post-date">';
$snews .= $date;
$snews .= '&nbsp;'. $keywords .'</p><p>';
$snews .= '<div class="item">
            <span class="thumbnail">
            <a href="'.$watch.'"><img style="width: 100px; height: 95px;" title="'.$title.'" src="'.$thumbnail.'"></a>
            </span>
      </div>';
$snews .= $description;
$snews .= '</p></div>';
$content[$i] = $snews;
$snews = "";
$_SESSION["snews$i"] =$content[$i];
$i++;
		$items++;
		if($items>8)break;
    }
return;
}

function generateSlug($phrase, $maxLength)
{
  //function to return seo friendly string
    $result = strtolower($phrase);

    $result = preg_replace("/[^a-z0-9\s-]/", "", $result);
    $result = trim(preg_replace("/[\s-]+/", " ", $result));
    $result = trim(substr($result, 0, $maxLength));
    $result = preg_replace("/\s/", "+", $result);

    return $result;
}

function show_micro_news($domainid){
 global $db_server;
 global $db_name;
 global $db_username;
 global $db_userpassword;

 $dbhandle = mysql_connect($db_server, $db_username, $db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($db_name, $dbhandle) or die("Couldn't open
 database $db_name");

$news = "";
$query = "SELECT * FROM `NewsMicroNews` where DomainId=$domainid";
$result = mysql_query($query);
if (!$result) {
               die('Invalid query: ' . mysql_error());
             }
$num_rows = mysql_num_rows($result);
    if ($num_rows > 0){
        while($res = mysql_fetch_array($result))
      
      	{ 
         $news .= '<div class="user micronews">
  <div class="text">
    '.$res['Message'].'
    </div>
    <div class="description">
    &nbsp;
    </div>
    <strong>'.strftime("%b %d, %Y %I:%M %P",strtotime($res['DatePosted'])).'</strong>
    </div>
    <br class="clear" />';      	   
        }
     }else {
       $news .= '<div class="user micronews">
  <div class="text">
    No news/announcement posted.
    </div>
    <div class="description">
    &nbsp;
    </div>
    <strong>&nbsp;</strong>
    </div>
    <br class="clear" />';
     }

return $news;
}

function show_ads_right($domainid){
echo '		<p class="sponsor-ads"><a href="#" ><img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/banner-160x600-rdb.png" width="160" height="600" alt=" " /></a></p>';
return;

}

function getCategoryKeyword($domainid,$pagename){
 global $db_server;
 global $db_name;
 global $db_username;
 global $db_userpassword;

 $dbhandle = mysql_connect($db_server, $db_username, $db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($db_name, $dbhandle) or die("Couldn't open
 database $db_name");

$news = "";
$query = "SELECT * FROM `NewsPages` where DomainId=$domainid AND PageName LIKE '$pagename'";
$result = mysql_query($query);
if (!$result) {
               die('Invalid query: ' . mysql_error());
             }
$num_rows = mysql_num_rows($result);
    if ($num_rows > 0){
        while($res = mysql_fetch_array($result))
           $keyword = $res['Keyword'];
      	{ 
         
     }
   }
   
   if ($keyword==""){
     $keyword = "news";
   }
   $keyword = str_replace(" ","+",$keyword);
return $keyword;
}

function getCategoryName($domainid,$pagename){
 global $db_server;
 global $db_name;
 global $db_username;
 global $db_userpassword;

 $dbhandle = mysql_connect($db_server, $db_username, $db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($db_name, $dbhandle) or die("Couldn't open
 database $db_name");

$news = "";
$query = "SELECT * FROM `NewsPages` where DomainId=$domainid AND PageName LIKE '$pagename'";
$result = mysql_query($query);
if (!$result) {
               die('Invalid query: ' . mysql_error());
             }
$num_rows = mysql_num_rows($result);
    if ($num_rows > 0){
        while($res = mysql_fetch_array($result))
           $category = $res['Category'];
      	{ 
         
     }
   }
   
  
return $category;
}

function Subscribe($domainid,$email){
 global $sub_db_server;
 global $sub_db_name;
 global $sub_db_username;
 global $sub_db_userpassword;
 $message="";
 $sub_dbhandle = mysql_connect($sub_db_server, $sub_db_username, $sub_db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($sub_db_name, $sub_dbhandle) or die("Couldn't open
 database $sub_db_name");

 $query = "Insert into NewsLetterSubscriptions (Email,DomainId,DateSubscribed) values ('$email','$domainid',NOW())";
 $result = mysql_query($query);
 if (!$result) {
               
               $message = "0";
             
             }else {
              $message = "1";     
             }
   
  
 return $message;
}

function SendContact($ownerid,$sender_email,$sender_name,$subject,$message){
 global $db_server;
 global $db_name;
 global $db_username;
 global $db_userpassword;
 global $sitename;
 $m = "";
 $dbhandle = mysql_connect($db_server, $db_username, $db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($db_name, $dbhandle) or die("Couldn't open
 database $db_name");
 
 $msg = "From: ".$sender_name."<br>";
 $msg .="Email: ".$sender_email."<br>";
 $msg .= $message;
 $msg = wordwrap($msg);
 
 $query = "Insert into `Messages`(`MemberId`,`From`,`FromEmail`,`Date`,`Subject`,`Message`,`Read`) Values ";
 $query .= "('$ownerid','$sender_name','$sender_email',NOW(),'$subject','".mysql_real_escape_string($msg)."','0')";
 $result = mysql_query($query);
 if (!$result) {
                die('Invalid query: ' . mysql_error());
               $m = "0";
             }else {
               $m = "1";
             }
 
 return $m;
}

function ShowSocialSites($domainid){
 global $db_server;
 global $db_name;
 global $db_username;
 global $db_userpassword;
 global $sitename;
 $social = "";
 $dbhandle = mysql_connect($db_server, $db_username, $db_userpassword)
 or die("Couldn't connect to SQL Server on $db_server");
 $selected = mysql_select_db($db_name, $dbhandle) or die("Couldn't open
 database $db_name");
  
  $query = "SELECT * FROM `NewsSocialValues` where DomainId=$domainid";
  $result = mysql_query($query);
  if (!$result) {
               die('Invalid query: ' . mysql_error());
             }
  $num_rows = mysql_num_rows($result);
    if ($num_rows > 0){
        $social .= "<center>";
        while($res = mysql_fetch_array($result)){
           $dig = $res['DigFeed'];
           $twitter = $res['TwitterProfile'];
           $flickr = $res['FlickrProfile'];
           $facebook = $res['FacebookProfile'];
           if ($dig!=""){
            $social .= "<a href=\"$dig\" target=\"_blank\"><img src=\"images/digg.png\"></a>&nbsp;";
           }
           if ($twitter!=""){
            $social .= "<a href=\"$twitter\" target=\"_blank\"><img src=\"images/twitter.png\"></a>&nbsp;";
           }
           if ($flickr!=""){
            $social .= "<a href=\"$flickr\" target=\"_blank\"><img src=\"images/flickr_1.png\"></a>&nbsp;";
           }
           if ($facebook!=""){
            $social .= "<a href=\"$facebook\" target=\"_blank\"><img src=\"images/facebook.png\"></a>&nbsp;";
           }
           
     }
   $social .= "</center>";  
   }else {
     $social = "";
   }
   
  
 return $social;
}
?>