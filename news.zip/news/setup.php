<?
include_once('site_config.php');
include('includes/header.php');
include('includes/content_topwrap.php');
include('includes/content_left.php');

?>
<div id="center">
<br /><br />
 <h1 class="post-title-block font"> <span class="pp1">Domain Information</h1>
   <div class="contact-box">
  <?
   $query = "Select * from Domains where DomainId=1";
   $result = mysql_query($query);
   if (!$result) {
     die('Invalid query: ' . mysql_error());
   }
   $num_rows = mysql_num_rows($result);
   if ($num_rows > 0){
       while($res = mysql_fetch_array($result))
      	{
      	
        }
    }     
 
  ?>
  </div>
</div>

<?
include('includes/content_right.php');
include('includes/content_footerwrap.php');
include('includes/footer.php');

?>
















