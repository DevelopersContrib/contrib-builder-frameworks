<?php

    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $keywords = "{{KEYWORDS}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
	$header_text = "{{HEADER_TEXT}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $piwik_id = '{{PIWIK_ID}}';
    $related_domains = {{RELATED_DOMAINS}};
    $related_nologo = {{RELATED_NOLOGO}};
    $social_fb = '{{SOCIAL_FB}}';
    $social_gplus = '{{SOCIAL_GPLUS}}';
    $social_twitter = '{{SOCIAL_TWITTER}}';
    $social_linkedin = '{{SOCIAL_LINKEDIN}}';
    $social_gtube = '{{SOCIAL_GTUBE}}';
    $topsites = {{TOPSITES}};
    $programs = {{PROGRAMS}};
    $domain_affiliate_id = "{{AFF_ID}}";
    
?>