<?php

class Referral extends Controller {
	
	function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$programs = $api->getprograms();
		$attr = $api->getdomainattributes();

		$background_image = $attr['background_image_url'];

		$template = $this->loadView('referral');
		$template->set('info',$info);
		$template->set('base_url',$helper->base_url());
		$template->set('title',ucwords($info['domain']).' :: Referral');
		$template->set('page','referral');
		$template->set('background_image',$background_image);
		$template->set('programs',$programs);
		$template->render();
	}
}

?>