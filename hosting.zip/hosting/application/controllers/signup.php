<?php

class Signup extends Controller {
	
	function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();

		if(isset($_POST['email'])){
			$email = $_POST['email'];			
		}

		$domain_affiliate_id = $api->getaffiliateid();

		$template = $this->loadView('signup');
		$template->set('info',$info);
		$template->set('base_url',$helper->base_url());				
		$template->set('title',ucwords($info['domain']).' :: Signup');
		$template->set('email',$email);
		$template->set('domain_affiliate_id',$domain_affiliate_id);
		$template->set('page','signup');
		$template->render();	
	}
}

?>