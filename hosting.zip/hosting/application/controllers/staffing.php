<?php

class Staffing extends Controller {
	
	function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$attr = $api->getdomainattributes();

		$background_image = $attr['background_image_url'];	
		
		$template = $this->loadView('staffing');
		$template->set('info',$info);
		$template->set('base_url',$helper->base_url());
		$template->set('title',ucwords($info['domain']).' :: Staffing');
		$template->set('page','staffing');
		$template->set('background_image',$background_image);
		$template->render();
	}
}

?>