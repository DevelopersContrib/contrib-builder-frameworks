<?php

class Home extends Controller {
	
	function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$attr = $api->getdomainattributes();
		$program_attributes = $api->getprogramattributes();		
		$tmp_array = array();	

    foreach($program_attributes as $program){
			$tmp_array[] = explode(', ',$program['row']);			
		}

		foreach($tmp_array as $tmp){
			$a = array();
			foreach($tmp as $arr){					
				$arr = explode('::',$arr);
				// $a[] = array($arr[0]=>$arr[1]);
				$a[$arr[0]] = $arr[1];		
			}
			$hosting[] = $a;
			unset($a);
		}

		for($i=0; $i<count($hosting); $i++){
			$package = $hosting[$i]['package'];
			$package = json_decode($package,TRUE);

			$hosting[$i]['fname'] = ucwords($hosting[$i]['fname']);
			$hosting[$i]['lname'] = ucwords($hosting[$i]['lname']);
			$hosting[$i]['package'] = $package['name'];
			$hosting[$i]['date'] = $program_attributes[$i]['date'];
		}	
		
		$background_image = $attr['background_image_url'];

		$title = strtoupper($info['domain']).' - Dedicated website hosting and iphost network monitor services for you.';
		$info['description'] = $title;

		$template = $this->loadView('index');
		$template->set('info',$info);
		$template->set('base_url',$helper->base_url());
		$template->set('title', $title);
		$template->set('page','index');
		$template->set('background_image',$background_image);
		$template->set('program_attributes',json_encode($hosting));
		$template->render();
	}
}

?>