<?php

class Success extends Controller {
	
	function index(){
		$session = $this->loadHelper('Session_helper');		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$attr = $api->getdomainattributes();

		$background_image = $attr['background_image_url'];
		$base_url = $helper->base_url();

		if(isset($_POST['referralProgram'])){
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			$email = $_POST['email'];
			$package = json_decode($_POST['package'],TRUE);

			$name = ucfirst($fname).' '.ucfirst($lname);			

			$date = date('Y-m-d H:i:s');			

			$_SESSION['name'] = $name;
			$_SESSION['package'] = $package['name'];
			$_SESSION['date_registered'] = $date;

			$this->sendNotification($name,$info['domain'],$email,$package['name'],$info['logo'],$info['socials']['fb'],$info['socials']['twitter']);
			
		} else {
			header("Location: ".$base_url);
			exit;
		}

		$template = $this->loadView('success');
		$template->set('info',$info);
		$template->set('base_url',$base_url);
		$template->set('title',ucwords($info['domain']).' :: Success');
		$template->set('page','succes');
		$template->set('background_image',$background_image);
		$template->render();
	}

	function sendNotification($name,$domain,$email,$package,$logo,$fb,$twitter){
		// $username = $fname.' '.$lname;

		$toEmail = $email;

		$defaultMessage = '<body style="background:#333;"><div id="mailsub" class="notification" align="center" style="background:#333"><table width="100%" border="0" cellspacing="0" cellpadding="0" style="min-width: 320px;"><tr><td align="center" bgcolor="#333"><table border="0" cellspacing="0" cellpadding="0" class="table_width_100" width="100%" style="max-width: 680px; min-width: 300px;"><tr><td><!-- padding --><div style="height: 80px; line-height: 80px; font-size: 10px;"></div></td></tr><!--header --><tr><td align="center" bgcolor="#ffffff"><!-- padding --><div style="height: 30px;line-height: 30px; font-size: 10px;"></div><table width="90%" border="0" cellspacing="0" cellpadding="0"><tr><td align="left"><!-- Item --><div class="mob_center_bl" style="float: left; display: inline-block; width: 115px;"><table class="mob_center" width="115" border="0" cellspacing="0" cellpadding="0" align="left" style="border-collapse: collapse;"><tr><td align="left" valign="middle"><!-- padding --><div style="height: 20px; line-height: 20px; font-size: 10px;"> </div><table width="115" border="0" cellspacing="0" cellpadding="0"><tr><td align="left" valign="top" class="mob_center"><a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><font face="Arial, Helvetica, sans-seri; font-size: 13px;" size="3" color="#596167"><img src="'.$logo.'" alt="'.$domain.'" border="0" style="display: block; width: 221px; height:80px" /></font></a></td></tr></table></td></tr></table></div><div class="mob_center_bl" style="float: right; display: inline-block; width: 88px;"><table width="88" border="0" cellspacing="0" cellpadding="0" align="right" style="border-collapse: collapse;"><tr><td align="right" valign="middle"><!-- padding --><div style="height: 20px; line-height: 20px; font-size: 10px;"> </div><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td align="right"><!--social --><div class="mob_center_bl" style="width: 88px;"><table border="0" cellspacing="0" cellpadding="0"><tr><td width="30" align="center" style="line-height: 19px;"><a href="'.$fb.'" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 12px;"><font face="Arial, Helvetica, sans-serif" size="2" color="#596167"><img src="http://image.flaticon.com/icons/png/128/124/124010.png" width="20" height="20" alt="Facebook" border="0" style="display: block;"/></font></a></td><td width="30" align="center" style="line-height: 19px;"><a href="'.$twitter.'" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 12px;"><font face="Arial, Helvetica, sans-serif" size="2" color="#596167"><img src="http://image.flaticon.com/icons/png/128/124/124021.png" width="20" height="20" alt="Twitter" border="0" style="display: block;"/></font></a></td></tr></table></div><!--social END--></td></tr></table></td></tr></table></div><!-- Item END--></td></tr></table><!-- padding --><div style="height: 50px; line-height: 50px; font-size: 10px;"> </div></td></tr><!--header END--><!--content 1 --><tr><td align="center" bgcolor="#fbfcfd"><table width="90%" border="0" cellspacing="0" cellpadding="0"><tr><td align="center"><!-- padding --><div style="height: 60px; line-height: 60px; font-size: 10px;"> </div><div style="line-height: 44px;"><font face="Arial, Helvetica, sans-serif" size="5" color="#57697e" style="font-size: 34px;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 34px; color: #57697e;">Congratulations! '.$name.'</span></font></div><!-- padding --><div style="height: 40px; line-height: 40px; font-size: 10px;"> </div></td></tr><tr><td align="center"><div style="line-height: 24px;"><font face="Arial, Helvetica, sans-serif" size="4" color="#57697e" style="font-size: 15px;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 15px; color: #57697e;">You have successfully signed up as a user.<br>You have ordered <strong>'.$package.'</strong> Plan.</span></font></div><!-- padding --><div style="height: 40px; line-height: 40px; font-size: 10px;"> </div></td></tr><tr><td align="center"><div style="line-height: 24px;"><a href="'.$domain.'" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; font-size: 15px; border:1px solid #ddd; background:#333; color:#fff; text-decoration:none; padding:10px 15px;">Proceed to '.$domain.' </a></div><!-- padding --><div style="height: 60px; line-height: 60px; font-size: 10px;"> </div></td></tr></table></td></tr><!--content 1 END--><!--footer --><tr><td class="iage_footer" align="center" bgcolor="#ffffff"><!-- padding --><div style="height: 80px; line-height: 80px; font-size: 10px;"> </div><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td align="center"><font face="Arial, Helvetica, sans-serif" size="3" color="#96a5b5" style="font-size: 13px;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #96a5b5;">2016 Search. All Rights Reserved.</span></font></td></tr></table><!-- padding --><div style="height: 30px; line-height: 30px; font-size: 10px;"> </div></td></tr><!--footer END--><tr><td><!-- padding --><div style="height: 80px; line-height: 80px; font-size: 10px;"> </div></td></tr></table></td></tr></table></div></body>';

		$subject   = ucwords($domain)." Forum Signup Notification";
		$content   = $defaultMessage;
		$from      = 'VNOC Admin <admin@vnoc.com>';
		$headers   = "From: " .($from) . "\r\n";
		$headers  .= "Reply-To: ".($from) . "\r\n";
		$headers  .= "Return-Path: ".($from) . "\r\n";;
		$headers  .= "MIME-Version: 1.0\r\n";
		$headers  .= "Content-Type: text/html; charset=UTF-8\r\n";
		$headers  .= "X-Priority: 3\r\n";
		$headers  .= "X-Mailer: PHP". phpversion() ."\r\n";
		mail($toEmail, $subject, $content, $headers);
	}
} ?>