<div class="content-section-a">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
			   <h2>Featured Partners</h2>
			</div>
			<div class="col-md-12"><hr></div>
			<div class="col-md-3">
			<a href="http://eservices.com/"><img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-eservices-1-1.png" alt="Eservices.com" title="Eservices.com" style="padding: 16px;"></a>
			</div>				
			<div class="col-md-3">
				<a href="http://contrib.com/"><img class="img-responsive" src="https://www.contrib.com/images/assets/logo-contrib.png" alt="Contrib.com" title="Contrib.com" style="padding: 31px 24px;"></a>
			</div>
			<div class="col-md-3">
				<a href="http://vnoc.com/"><img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-vnoc4.png" alt="Vnoc.com" title="Vnoc.com" style="padding: 18px 15px;"></a>
			</div>
			<div class="col-md-3">
				<a href="http://referrals.com/"><img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta9-small.png" alt="Referrals.com" title="Referrals.com" style="padding: 35px 12px;"></a>
			</div>			
		</div>
	</div>
</div>