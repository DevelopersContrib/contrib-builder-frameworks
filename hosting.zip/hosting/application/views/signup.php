<?php include('header.php'); ?>
<style>	
.btn-group > .btn {
	font-size: 17px;
	border-radius:0px;
	margin-bottom:5px;
}
#input-fname, #input-lname {
	text-transform: capitalize;
}
.pc-box {
	background: #fff;
	padding: 30px 60px 80px;
}
.pc-box img {
	height:200px;
}
</style>
<script src="https://tools.contrib.com/referral/"></script>
<script type="text/javascript">
var contrib_referral = {
	buttonId:'btn-submit-referral',
	idev_id: <?=$domain_affiliate_id?>,
	idev_domain: '<?=$info['domain']?>',
	idev_product: 33
}
</script>
	<div id="navigation">
		<?php include('navigation.php'); ?>
	</div>
   
    <div class="signup-container content-section-b" style="padding: 150px 0 50px;">		
        <div class="container">
            <div class="row">                
				<div class="col-md-7 sc-box">
					<form role="form" action="<?=$base_url.'success'?>" method="post" id="referral-form" autocomplete="off">
						<div class="form-group">
							<label for="fname" class="sr-only">First Name</label>
							<input type="text" name="fname" id="input-fname" class="form-control" placeholder="First Name" />
							<div class="alert alert-warning" role="alert" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="lname" class="sr-only">Last Name</label>
							<input type="text" name="lname" id="input-lname" class="form-control" placeholder="Last Name" />
							<div class="alert alert-warning" role="alert" style="display:none;"></div>
						</div>	
						<div class="form-group">
							<label for="email" class="sr-only">Email</label>
							<input type="email" name="email" id="input-email" class="form-control" placeholder="somebody@example.com" value="<?=$email?>" />
							<div class="alert alert-warning" role="alert" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="domain" class="sr-only">Domain</label>
							<input type="text" name="website" id="input-domain" class="form-control" placeholder="example.com" /">
							<div class="alert alert-warning" role="alert" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="package" class="sr-only">Domain</label>
							<input type="hidden" name="package" id="input-package" class="form-control" value="">
							<div class="alert alert-warning" role="alert" style="display:none;"></div>
						</div>	
						<div class="form-group">
							<label for="contact" class="sr-only">Contact</label>
							<input type="text" name="contact" id="input-contact" class="form-control" placeholder="Contact Number" /">
							<div class="alert alert-warning" role="alert" style="display:none;"></div>
						</div>
						<div class="text-center">
							<h2 class="label label-warning">Select Your Hosting Package Below</h2>
						</div>
						<button type="submit" name="referralProgram" style="display:none" id="btn-submit-referral">Submit</button>
					</form>
				</div>
				<div class="col-md-5 sc-box2 checkout-container">
					<h3 class="text-center">Hosting Package Preferred</h3>
						<div class="table-responsive text-center">
							<table class="table table-hover" id="host-table">	
							  <div class="npy">
									<h5>No hosting package yet.<br>Fill the form and select hosting package below.</h5>
							  </div>
							  
							</table> 
						</div>							
						<div class="text-center">
							<button type="submit" class="btn btn-lg btn-primary" id="btn-submit-form" style="display:none;">Submit</button>							
						</div>
				</div>
				<div id="hosting_package">
					<?php include('package.php'); ?>
				</div>
            </div>
        </div>
    </div> 
    
	
	<div id="footer">
		<?php include('footer.php'); ?>
	</div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
		<script src="js/script.js"></script>
		<script>
			$(document).ready(function () {
				$('#btn-submit-form').on('click',function(e){
					if(validateForm()){
						$('#btn-submit-referral').trigger('click');
						$('#referral-form').submit();
					}

					e.preventDefault();
				});	
				
				$('.star').on('click', function () {
					$(this).toggleClass('star-checked');
				});
				$('.ckbox label').on('click', function () {
					$(this).parents('tr').toggleClass('selected');
				});
				$('.btn-filter').on('click', function () {
					var $target = $(this).data('target');
					if ($target != 'all') {
					$('.table-2 tr').css('display', 'none');
					$('.table-2 tr[data-status="' + $target + '"]').fadeIn('slow');
					} else {
					$('.table-2 tr').css('display', 'none').fadeIn('slow');
					}
				});

				/*** Select package script ***/
				$('#btn-best-value-package').on('click',function(e){
					var package = {};
					var packageItems = [];
					$('.best-value-package-item').each(function(){
						packageItems.push($(this).html());
					});

					package.name = 'Best Value';
					package.processor = packageItems[0];
					package.ram = packageItems[1];
					package.storage = packageItems[2];
					package.outboundBandwidth = packageItems[3];
					package.incomingBandwidth = packageItems[4];
					package.controlPanel = packageItems[5];

					var html = '<tbody><tr><td><h4>Best Value</h4></td></tr>';

					for(item in packageItems){
						html += '<tr><td>'+packageItems[item]+'</td></tr>';
					}
					
					html += '</tbody>';

					$('#host-table').html(html);
					$('#input-package').val(JSON.stringify(package));
					$('.npy').css('display','none');
					$('#btn-submit-form').css('display','inline-block');
					$('html, body').animate({ scrollTop: 0 }, 'slow');

					e.preventDefault();
				});

				$('#btn-advanced-package').on('click',function(e){
					var package = {};
					var packageItems = [];
					$('.advanced-package-item').each(function(){
						packageItems.push($(this).html());
					});

					package.name = 'Advanced';
					package.processor = packageItems[0];
					package.ram = packageItems[1];
					package.storage = packageItems[2];
					package.outboundBandwidth = packageItems[3];
					package.incomingBandwidth = packageItems[4];
					package.controlPanel = packageItems[5];

					var html = '<tbody><tr><td><h4>Advanced</h4></td></tr>';

					for(item in packageItems){
						html += '<tr><td>'+packageItems[item]+'</td></tr>';
					}
					
					html += '</tbody>';

					$('#host-table').html(html);
					$('#input-package').val(JSON.stringify(package));
					$('.npy').css('display','none');
					$('#btn-submit-form').css('display','inline-block');
					$('html, body').animate({ scrollTop: 0 }, 'slow');

					e.preventDefault();
				});

				$('#btn-performance-package').on('click',function(e){
					var package = {};
					var packageItems = [];
					$('.performance-package-item').each(function(){
						packageItems.push($(this).html());
					});

					package.name = 'Performance';
					package.processor = packageItems[0];
					package.ram = packageItems[1];
					package.storage = packageItems[2];
					package.outboundBandwidth = packageItems[3];
					package.incomingBandwidth = packageItems[4];
					package.controlPanel = packageItems[5];

					var html = '<tbody><tr><td><h4>Performance</h4></td></tr>';
					
					for(item in packageItems){
						html += '<tr><td>'+packageItems[item]+'</td></tr>';
					}
					
					html += '</tbody>';

					$('#host-table').html(html);
					$('#input-package').val(JSON.stringify(package));
					$('.npy').css('display','none');
					$('#btn-submit-form').css('display','inline-block');
					$('html, body').animate({ scrollTop: 0 }, 'slow');

					e.preventDefault();
				});

				$('.btn-order').on('click',function(e){
					var package = {};
					var packageItems = [];
					$(this).parents('tr').find('td').each(function(){
						packageItems.push($(this).html());
					});

					packageItems.pop();

					var html = '<tbody><tr><td><h4>'+packageItems[0]+'</h4></td></tr>';														
					var item = packageItems[0]			
							packageItems[0] = item.replace('<br>','');					
					
					package.name = packageItems[0];
					package.processor = packageItems[1];
					package.speed = packageItems[2];
					package.ram = packageItems[3];
					package.storage = packageItems[4];
					package.bandwidth = packageItems[5];
					package.monthlyFee = packageItems[6];

					for(item in packageItems){
						html += '<tr><td>'+packageItems[item]+'</td></tr>';
					}

					html += '</tbody>';

					$('#host-table').html(html);
					$('#input-package').val(JSON.stringify(package));
					$('.npy').css('display','none');
					$('#btn-submit-form').css('display','inline-block');
					$('html, body').animate({ scrollTop: 0 }, 'slow');

					console.log(packageItems);
					console.log(JSON.stringify(package));
					e.preventDefault();
				});
				/*** end of Select package script ***/
			});
		</script>
</body>

</html>
