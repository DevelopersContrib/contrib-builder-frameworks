<div class="col-lg-12 text-center">
   <br>
</div>
<div class="col-lg-12">
	<table class="table table-striped table-bordered ctable-list">
	  <thead>
		<tr>
			<th class="col1">Choose Your Package</th>
			<th class="col2"><div class="thead"><h3>Best Value</h3><h4>Xeon Quad Core</h4><div class="ribbon50"><img src="http://codero.cachefly.net/design/discount-80-off-ribbon.png" alt="80% Discount" title="80% Discount"></div><span class="tprice"><span class="slashed">$159</span><br>$25/First Month<br>then $128/month</span></div></th>
			<th class="col3"><div class="thead"><h3>Advanced</h3><h4>Xeon Quad Core</h4><div class="ribbon75"><img src="http://codero.cachefly.net/design/discount-75-off-ribbon.png" alt="75% Discount" title="75% Discount"></div><span class="tprice"><span class="slashed">$135</span><br>$34/First Month<br>then $108/month</span></div></th>
			<th class="col4"><div class="thead"><h3>Performance</h3><h4>Xeon Hex Core</h4><div class="ribbon75"><img src="http://codero.cachefly.net/design/discount-75-off-ribbon.png" alt="75% Discount" title="75% Discount"></div><span class="tprice"><span class="slashed">$309</span><br>$78/First Month<br>then $248/month</span></div></th>
		</tr> 
	  </thead>
	  <tbody>
		  <tr>
			<td class="col1"><b>Processor</b></td>
			<td class="col2 best-value-package-item">3.5 GHz Processor (E3-1270v2)</td>
			<td class="col3 advanced-package-item">3.3 GHz Processor (E3-1231v3)</td>
			<td class="col4 performance-package-item">3.5 GHz Processor (E5-1650v3)</td>
		  </tr>
		  <tr>
			<td class="col1"><b>RAM</b></td>
			<td class="col2 best-value-package-item">8 GB DDR3 RAM</td>
			<td class="col3 advanced-package-item">8 GB DDR3 RAM</td>
			<td class="col4 performance-package-item">16 GB DDR4 RAM</td>
		  </tr>
		  <tr>
			<td class="col1"><b>Storage</b></td>
			<td class="col2 best-value-package-item">1 TB SATA Hard Drive</td>
			<td class="col3 advanced-package-item">1 TB SATA Hard Drive</td>
			<td class="col4 performance-package-item">1 TB SATA Hard Drive</td>
		  </tr>
		  <tr>
			<td class="col1"><b>Outbound Bandwidth</b></td>
			<td class="col2 best-value-package-item">20 TB Outbound Bandwidth</td>
			<td class="col3 advanced-package-item">20 TB Outbound Bandwidth</td>
			<td class="col4 performance-package-item">30 TB Outbound Bandwidth</td>
		  </tr>
		  <tr>
			<td class="col1"><b>Incoming Bandwidth</b></td>
			<td class="col2 best-value-package-item">Unlimited Incoming Bandwidth</td>
			<td class="col3 advanced-package-item">Unlimited Incoming Bandwidth</td>
			<td class="col4 performance-package-item">Unlimited Incoming Bandwidth</td>
		  </tr>
		  <tr>
			<td class="col1"><b>Control Panel</b></td>
			<td class="col2 best-value-package-item">FREE Plesk Control Panel</td>
			<td class="col3 advanced-package-item">FREE Plesk Control Panel</td>
			<td class="col4 performance-package-item">FREE Plesk Control Panel</td>
		  </tr>
		  <tr>
			<td class="col1"></td>
			<td class="col2"><a href="" class="btn btn-primary btn-lg" id="btn-best-value-package">Order Now</a></td>
			<td class="col3"><a href="" class="btn btn-primary btn-lg" id="btn-advanced-package">Order Now</a></td>
			<td class="col4"><a href="" class="btn btn-primary btn-lg" id="btn-performance-package">Order Now</a></td>
		  </tr>
	  </tbody>
	</table>
</div>

<div class="row2">
	<section class="content">
		<div class="col-md-12"><hr></div>
		<div class="col-md-12">
			<h3>Fully Configurable Dedicated Hosting</h3>
			<h4 class="text-center">All Dedicated Servers Include:</h4>
			<div class="row">
				<div class="col-md-10 col-md-offset-1 ds-fa text-center">
					<div class="col-md-4">
					<i class="fa fa-tachometer" aria-hidden="true"></i>&nbsp;Fast Deployment		
					</div>
					<div class="col-md-4">
					<i class="fa fa-gear" aria-hidden="true"></i>&nbsp;Up to 30TB Outbound
					</div>
					<div class="col-md-4">
					<i class="fa fa-list-alt" aria-hidden="true"></i>&nbsp;Unlimited Incoming Bandwidth	
					</div>
					<div class="col-md-4">
					<i class="fa fa-globe" aria-hidden="true"></i>&nbsp;100% Network Uptime Guaranteed		
					</div>
					<div class="col-md-4">
					<i class="fa fa-trophy" aria-hidden="true"></i>&nbsp;Seamless Connection To Cloud Servers				
					</div>
					<div class="col-md-4">
					<i class="fa fa-star" aria-hidden="true"></i>&nbsp;SSAE 16 (SAS 70) Data Centers
					</div>
				</div>
			</div>
			<br>
			<div class="panel2 panel-default2">
				<div class="panel-body2">
					<div class="pull-right">
						<div class="btn-group">
							<button type="button" class="btn btn-info btn-filter" data-target="dual"><b>Dual Core</b></button>
							<button type="button" class="btn btn-info btn-filter" data-target="quad"><b>Quad Core</b></button>
							<button type="button" class="btn btn-info btn-filter" data-target="hexa"><b>Hexa Core</b></button>
							<button type="button" class="btn btn-info btn-filter" data-target="octa"><b>Octa Core</b></button>
							<button type="button" class="btn btn-info btn-filter" data-target="dell"><b>Dell</b></button>
							<button type="button" class="btn btn-info btn-filter" data-target="all"><b>All</b></button>
						</div>
					</div>
					<div class="table-container">
						<table class="table table-2 table-striped table-bordered table-filter">
							<thead>
								<tr>
									<th>Package Type</th>
									<th>Processor</th>
									<th>Speed</th>
									<th>RAM</th>
									<th>Storage</th>
									<th>Bandwidth</th>
									<th>Monthly</th>
									<th></th>
								</tr> 
							  </thead>
							<tbody>
								<tr data-status="dual">
									<td>Dedicated Package <b>A</b></td>
									<td class="col-core">Core i3 Dual Core I3-4130 <br>Dedicated Server</td>	
									<td>3.4 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$25/First mo Then $80/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="dual">
									<td>Smart Package <b>A</b></td>
									<td class="col-core">Core i3 Dual Core I3-4130 <br>Smart Server</td>	
									<td>3.4 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$25/First mo Then $80/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>B</b></td>
									<td class="col-core">Core i5 Quad Core I5-750 <br>Dedicated Server</td>	
									<td>2.66 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$27/First mo Then $84/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>C</b></td>
									<td class="col-core">Core i7 Quad Core I7-860 <br>Dedicated Server</td>	
									<td>2.8 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$28/First mo Then $88/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>D</b></td>
									<td class="col-core">Core i7 Quad Core I7-870 <br>Dedicated Server</td>	
									<td>2.93 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$29/First mo Then $91/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>E</b></td>
									<td class="col-core">Core i5 Quad Core I5-2400 <br>Dedicated Server</td>	
									<td>3.1 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$29/First mo Then $92/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>E1</b></td>
									<td class="col-core">Core i7 Quad Core I7-2600 <br>Dedicated Server</td>	
									<td>3.4 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$30/First mo Then $96/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>F</b></td>
									<td class="col-core">Xeon Quad Core E3-1230v1 <br>Dedicated Server</td>	
									<td>3.2 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$30/First mo Then $96/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>G</b></td>
									<td class="col-core">Xeon Quad Core E3-1230v2 <br>Dedicated Server</td>	
									<td>3.3 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$33/First mo Then $104/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Smart Package <b>B</b></td>
									<td class="col-core">Xeon Quad Core E3-1230v2 <br>Smart Server</td>	
									<td>3.3 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$33/First mo Then $104/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>H</b></td>
									<td class="col-core">Xeon Quad Core E3-1230v3 <br>Dedicated Server</td>	
									<td>3.3 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$34/First mo Then $108/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Smart Package <b>C</b></td>
									<td class="col-core">Xeon Quad Core E3-1230v3 <br>Smart Server</td>	
									<td>3.3 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$34/First mo Then $108/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>I</b></td>
									<td class="col-core">Xeon Quad Core E3-1270v2 <br>Dedicated Server</td>	
									<td>3.5 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$40/First mo Then $128/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Smart Package <b>D</b></td>
									<td class="col-core">Xeon Quad Core E3-1270v2 <br>Smart Server</td>	
									<td>3.5 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$40/First mo Then $128/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>J</b></td>
									<td class="col-core">Xeon Quad Core E5-2603 <br>Dedicated Server</td>	
									<td>1.80 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$43/First mo Then $136/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Smart Package <b>E</b></td>
									<td class="col-core">Xeon Quad Core E5-2603 <br>Smart Server</td>	
									<td>1.80 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$43/First mo Then $136/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>K</b></td>
									<td class="col-core">Xeon Quad Core E3-1270v3 <br>Dedicated Server</td>	
									<td>3.5 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$48/First mo Then $152/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>L</b></td>
									<td class="col-core">Xeon Quad Core E3-1271v3 <br>Dedicated Server</td>	
									<td>3.5 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$48/First mo Then $152/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Smart Package <b>F</b></td>
									<td class="col-core">Xeon Quad Core E3-1270v3 <br>Smart Server</td>	
									<td>3.5 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$48/First mo Then $152/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>M</b></td>
									<td class="col-core">2x Xeon Quad Core E5-2603 <br>Dedicated Server</td>	
									<td>1.80 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$55/First mo Then $176/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>N</b></td>
									<td class="col-core">Xeon Quad Core E5-2603v2 <br>Dedicated Server</td>	
									<td>1.80 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$55/First mo Then $176/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Smart Package <b>G</b></td>
									<td class="col-core">2x Xeon Quad Core E5-2603 <br>Smart Server</td>	
									<td>1.80 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$55/First mo Then $176/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="hexa">
									<td>Dedicated Package <b>O</b></td>
									<td class="col-core">Xeon Hex Core E5-2620 <br>Dedicated Server</td>	
									<td>2.0 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$56/First mo Then $180/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="hexa">
									<td>Smart Package <b>H</b></td>
									<td class="col-core">Xeon Hex Core E5-2620 <br>Smart Server</td>	
									<td>2.0 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$56/First mo Then $180/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>P</b></td>
									<td class="col-core">Xeon Quad Core E5-1630v3 <br>Dedicated Server</td>	
									<td>3.7 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$62/First mo Then $199/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="octa">
									<td>Dedicated Package <b>Q</b></td>
									<td class="col-core">Xeon Octa Core E5-2650 <br>Dedicated Server</td>	
									<td>2.0 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$68/First mo Then $216/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="quad">
									<td>Dedicated Package <b>R</b></td>
									<td class="col-core">2x Xeon Quad Core E5-2603v2 <br>Dedicated Server</td>	
									<td>1.8 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$68/First mo Then $216/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="octa">
									<td>Smart Package <b>I</b></td>
									<td class="col-core">Xeon Octa Core E5-2650 <br>Smart Server</td>	
									<td>2.0 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$68/First mo Then $216/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="hexa">
									<td>Dedicated Package <b>S</b></td>
									<td class="col-core">Xeon Hex Core E5-2620v2 <br>Dedicated Server</td>	
									<td>2.1 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$70/First mo Then $224/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="hexa">
									<td>Dedicated Package <b>T</b></td>
									<td class="col-core">Xeon Hex Core E5-1650v3 <br>Dedicated Server</td>	
									<td>3.5 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$78/First mo Then $248/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="hexa">
									<td>Dedicated Package <b>U</b></td>
									<td class="col-core">2x Xeon Hex Core E5-2620v2 <br>Dedicated Server</td>	
									<td>2.1 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$80/First mo Then $256/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="octa">
									<td>Dedicated Package <b>V</b></td>
									<td class="col-core">2x Xeon Octa Core E5-2650 <br>Dedicated Server</td>	
									<td>2.0 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$83/First mo Then $264/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="octa">
									<td>Smart Package <b>J</b></td>
									<td class="col-core">Xeon Octa Core E5-2650 <br>Smart Server</td>	
									<td>2.0 GHz</td>
									<td>8 GB</td>
									<td>1 TB SATA</td>
									<td>20 TB</td>
									<td>$83/First mo Then $264/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="octa">
									<td>Dedicated Package <b>W</b></td>
									<td class="col-core">2x Xeon Octa Core E5-2650 <br>Dedicated Server</td>	
									<td>2.6 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$90/First mo Then $288/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="octa">
									<td>Dedicated Package <b>X</b></td>
									<td class="col-core">2x Xeon 8 Core E5-2650v2 <br>Dedicated Server</td>	
									<td>2.6 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$105/First mo Then $336/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="dell">
									<td>Dedicated Package <b>Y</b></td>
									<td class="col-core">Dell R620 2xE5 E5-2620v2 <br>Dedicated Server</td>	
									<td>2.1 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$105/First mo Then $336/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="dell">
									<td>Dedicated Package <b>Z</b></td>
									<td class="col-core">Dell R620 2xE5 E5-2650v2 <br>Dedicated Server</td>	
									<td>2.6 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$120/First mo Then $384/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="dell">
									<td>Dedicated Package <b>Z1</b></td>
									<td class="col-core">Dell R620 2x E5-2680v2 <br>Dedicated Server</td>	
									<td>2.8 GHz</td>
									<td>16 GB</td>
									<td>1 TB SATA</td>
									<td>30 TB</td>
									<td>$145/First mo Then $464/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="dell">
									<td>Dedicated Package <b>Z2</b></td>
									<td class="col-core">Dell R430 2x E5-2650v2 <br>Dedicated Server</td>	
									<td>2.3 GHz</td>
									<td>16 GB</td>
									<td>1 TB SAS</td>
									<td>30 TB</td>
									<td>$160/First mo Then $512/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
								<tr data-status="dell">
									<td>Dedicated Package <b>Z3</b></td>
									<td class="col-core">Dell R630 2x E5-2680v2 <br>Dedicated Server</td>	
									<td>2.5 GHz</td>
									<td>16 GB</td>
									<td>1 TB SAS</td>
									<td>30 TB</td>
									<td>$218/First mo Then $696/mo</td>
									<td><a href="" class="btn btn-primary btn-order">Order Now</a></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>