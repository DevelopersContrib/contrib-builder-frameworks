<?php include('header.php');?>
<style>	
.pc-box {
	background: #fff;
	padding: 20px 30px 60px;
}
.blur-box {
	border-bottom: 1px solid rgb(222, 222, 222);
	margin-bottom: 20px;
}
.blur-box h3 {
	margin-top: 0px;
}
</style>
<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

	<div id="navigation">
		<?php include('navigation.php'); ?>
	</div>
   
    <div class="page-container">		
        <div class="container">
            <div class="row">
				<div class="col-md-8 col-md-offset-2 pc-box">
					<!-- -->
					<h3 class="text-center">Our Staffing Needs at <? echo $info['domain']?></h3>
					<hr>					
					<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<? echo $info['domain']?>&f=staffing"></script>
					<!-- -->
				</div>
            </div>
        </div>
    </div> 
    	
	<div id="footer">
		<?php include('footer.php'); ?>
	</div>    
</body>

</html>
