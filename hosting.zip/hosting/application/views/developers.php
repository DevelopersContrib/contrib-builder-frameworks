<?php include('header.php');?>
<style>	
.pc-box {
	background: #fff;
	padding: 20px 30px 60px;
}
.blur-box {
	border-bottom: 1px solid rgb(222, 222, 222);
	margin-bottom: 20px;
}
.blur-box h3 {
	margin-top: 0px;
}
</style>
	<div id="navigation">
		<?php include('navigation.php'); ?>
	</div>
   
    <div class="page-container">		
        <div class="container">
            <div class="row">
				<div class="col-md-8 col-md-offset-2 pc-box">
					<!-- -->
					<h3 class="text-center">Developers <? echo $info['domain']?></h3>
					<hr>					
					<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Do you have code or an app that could run this brand? <?php echo ucfirst($info['domain'])?> is connected with Contrib. </h4>
					<p></p>
					<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?php echo ucfirst($info['domain'])?> </h4>
					<p class="text-center">
					<br>
					<a href="<?php echo BASE_URL?>contact" class="btn btn-primary btn-lg">Inquire Here</a>
					<!-- -->
				</div>
            </div>
        </div>
    </div> 
    
	
	<div id="footer">
		<?php include('footer.php'); ?>
	</div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>	
</body>

</html>
