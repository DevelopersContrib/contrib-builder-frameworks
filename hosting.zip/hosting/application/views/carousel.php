<div class="content-section-b">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
			   <h2>Check out these websites built with IPhost's</h2>
			   <div class="col-md-12"><hr></div>
			   <div class="clearfix"></div>
			   <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
					<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
					<li data-target="#carousel-example-generic" data-slide-to="1"></li>
					<li data-target="#carousel-example-generic" data-slide-to="2"></li>
				  </ol>
				  <!-- Wrapper for slides -->
				  <div class="carousel-inner" role="listbox">
					<div class="item active">
						<div class="row">
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://contrib.com/"><img class="img-responsive" src="./img/carousel-contrib2.png" alt="Contrib.com" title="Contrib.com"></a></div>
							</div>
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://vnoc.com/"><img class="img-responsive" src="./img/carousel-vnoc2.png" alt="Vnoc.com" title="Vnoc.com"></a></div>
							</div>
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://referrals.com/"><img class="img-responsive" src="./img/carousel-referrals2.png" alt="Referrals.com" title="Referrals.com"></a></div>
							</div>
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://applications.com/"><img class="img-responsive" src="./img/carousel-applications2.png" alt="Applications.com" title="Applications.com"></a></div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="row">
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://eservices.com/"><img class="img-responsive" src="./img/carousel-eservices2.png" alt="Eservices.com" title="Eservices.com"></a></div>
							</div>
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://handyman.com/"><img class="img-responsive" src="./img/carousel-handyman2.png" alt="Handyman.com" title="Handyman.com"></a></div>
							</div>
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://beta.search.com/"><img class="img-responsive" src="./img/carousel-search2.png" alt="Beta.search.com" title="Beta.search.com"></a></div>
							</div>
							<div class="col-md-3">
								<div class="web-carousel"><a href="http://photostream.com/"><img class="img-responsive" src="./img/carousel-photostream2.png" alt="Photostream.com" title="Photostream.com"></a></div>
							</div>
						</div>
					</div>
				  </div>
				  <!-- Controls -->
				  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				  </a>
				  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				  </a>
				</div>
			</div>
			<div class="col-lg-12 text-center">
				<br>
				<a href="<?=$base_url.'signup'?>" class="btn btn-primary btn-lg"><h4>Check Our Dedicated Hosting Package!</h4></a>
			</div>
		</div>
	</div>
</div>