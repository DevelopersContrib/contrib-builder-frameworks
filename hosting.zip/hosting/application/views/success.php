<?php include('header.php');?>
<style>	
.pc-box {
	background: #fff;
	padding: 30px 60px 80px;
}
.pc-box img {
	height:200px;
}
</style>
	<div id="navigation">
		<?php include('navigation.php'); ?>
	</div>
   
    <div class="page-container">		
        <div class="container">
            <div class="row">
				<div class="col-md-8 col-md-offset-2 pc-box text-center">
					  <img src="./img/thankyou.png">					  
					  <h3>Your information has been successfully submitted.</h3>					 
					  <p>Please Check Your Email for Further Instructions.</p>
					   <hr>
					  <a href="<?=$base_url?>" class="btn btn-lg btn-primary">Back</a>
				</div>
            </div>
        </div>
    </div> 
    
	
	<div id="footer">
		<?php include('footer.php'); ?>
	</div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>	
</body>

</html>
