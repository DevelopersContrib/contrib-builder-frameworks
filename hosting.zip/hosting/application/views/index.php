<?php include('header.php');?>
	<div id="navigation">
		<?php include('navigation.php'); ?>
	</div>
    <div class="intro-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="intro-message">
                        <h1>Managed, Cloud & Dedicated Hosting Powered</h1>
                        <h3>by Exceptional Service</h3><img src="./img/bar.png">
						<div class="text-center">
						<p><i class="fa fa-check" aria-hidden="true"></i>&nbsp;100% Network Uptime Guarantee</p>
						<p><i class="fa fa-check" aria-hidden="true"></i>&nbsp;24/7/365 U.S.-based expert support</p>
						<p><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Up to 30TB of top-tier bandwidth included FREE</p>
						<p><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Fully managed solutions for complete peace of mind</p>
						<p><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Superior automated network enables less than 1 hour deployment</p> 
						</div>
                        <a href="<?=$base_url.'signup'?>" class="btn btn-primary"><h5>Check Our Dedicated Hosting Package!</h5></a>
                    </div>
                </div>
            </div>
        </div>
		<div class="get-container">
			<div class="container">
				<div class="row">
					<h3 class="text-center">Get Exceptional Service At The Best Price</h3>
				</div>
			</div>
		</div>
    </div>	
    <div class="content-section-a csa" style="padding: 25px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12"> 
					<div class="row">
						<form action="/signup" method="POST" id="submit-form">
							<div class="col-md-8 col-md-offset-2 plan-intro" id="focus-div">
								<div class="input-group input-group-lg">
									<input type="text" class="form-control" placeholder="Your Email Here" id="input-email" name="email" />
									<div class="input-group-btn">
									<button class="btn btn-primary" id="btn-submit-email">Get Started&nbsp;&nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i></button>								
									</div>							  
								</div>
								<div class="alert alert-warning email-alert" role="alert" style="display:none;">Please provide a valid email address!</div>
								<img class="arrow" src="./img/arrow.png" style="display:none;">
							</div>
						</form>
					</div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-section-b">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                   <h2>The IPhost Difference: Exceptional Service</h2>
                </div>
				<div class="col-md-12"><hr></div>
				<div class="col-md-1">
					<i class="fa fa-users" aria-hidden="true"></i>
				</div>
				<div class="col-md-5">
					<p class="ptitle">Expert Support Team</p>
					<p>35 Second Response via Chat</p>
					<p>20 Minute Response via Help Desk</p>
					<p>24/7 Phone Support</p>
				</div>
				<div class="col-md-1">
					<i class="fa fa-envelope" aria-hidden="true"></i>
				</div>
				<div class="col-md-5">
					<p class="ptitle">The Most Competitive Pricing</p>
					<p>Price Match Guarantee</p>
					<p>Quick-Response Support Included</p>
					<p>Unmetered Inbound + 30TB Outbound Bandwidth</p>
				</div>
				<div class="col-md-1">
					<i class="fa fa-dropbox" aria-hidden="true"></i>
				</div>
				<div class="col-md-5">
					<p class="ptitle">Fast Deployment</p>
					<p>1 Minute Cloud Deployment</p>
					<p>20 Minute Smart Server Deployment</p>
					<p>1 Hour Dedicated Server Deployment</p>
				</div>
				<div class="col-md-1">
					<i class="fa fa-gears" aria-hidden="true"></i>
				</div>
				<div class="col-md-5">
					<p class="ptitle">Best-in-Class Network and Data Centers</p>
					<p>SSAE 16 SOC I Certified (SAS 70)</p>
					<p>Redundant 10GB Backbones</p>
					<p>Brocade, Cisco, and Arista Infrastructure</p>					
				</div>
            </div>
        </div>
    </div>
	<div class="content-section-a">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 text-center">
					<h2>IPhost's Excellent Support Experience</h2>
				</div>
				<div class="col-md-12"><hr></div>
				<div class="col-md-6 text-right">
					<img src="./img/247.png" style="margin-bottom:-53px;">
				</div>
				<div class="col-md-6">
				<h3>Managed Services</h3>
				<h4>IPhost delivers exceptional service behind every product we sell. From Essential to Proactive Managed Hosting, we meet your business's demand for professional, timely, and informative service.</h4>
				<h3>On-Demand Hybrid Cloud™</h3>
				<h4>Securely connect your dedicated servers and cloud instances. Host the right application on the right infrastructure. Patented hybrid control technology available exclusively at IPhost.</h4>
				</div>
			</div>
		</div>
	</div>
	<div id="web-carousel">
		<?php include('carousel.php'); ?>
	</div>
	
	<div id="featured-websites">
		<?php include('featured.php'); ?>
	</div>
	
	<div id="footer">
		<?php include('footer.php'); ?>
	</div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

	<!-- JavaScript -->
	<script src="js/script.js"></script>
</body>

</html>
