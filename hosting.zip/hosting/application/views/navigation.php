<div class="top-head navbar-fixed-top">
	<div class="container">
		<?php if($info['logo'] != ''){ ?>
			<a href="<?=$base_url?>" class="logo pull-left">
				<img src="<?=$info['logo']?>" alt="<?=ucwords($info['domain'])?>" title="<?=ucwords($info['domain'])?>">
			</a>
		<?php } else { ?>
			<span class="logo-header"><?=ucwords($info['domain'])?></span>
		<?php } ?>
		
		<div class="social-top pull-right">
			<ul class="nav navbar-nav">				
				<li>
					<a target="_blank" href="" class="lsupport" style="padding: 10px 0px 10px 15px;">
						<img src="./img/support.png">
					</a>
				</li>
			</ul>
			<div class="clearfix"></div>
			<ul class="nav navbar-nav pull-right lsocials">
				<li>
					<span>Follow Us On:&nbsp;</span>
					<a href="<?=$info['socials']['fb']?>"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
					<a href="<?=$info['socials']['twitter']?>"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
					<a href="<?=$info['socials']['gplus']?>"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a>
				</li>
			</ul>				
		</div>
	</div>		
</div>
<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="margin-top: 96px;">		
	<div class="container topnav">            
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<li>
					<a href="<?=$base_url?>">Home</a>
				</li>
				<li>
					<a href="<?=$base_url.'about'?>">About Us</a>
				</li>
				<li>
					<a href="<?=$base_url.'partners'?>">Partner with Us</a>
				</li>
				<li>
					<a href="<?=$base_url.'contact'?>">Contact Us</a>
				</li>				
			</ul>
			<ul class="nav navbar-nav pull-right">
				<li>
					<a href="<?=$base_url.'signup'?>" class="btn btn-signup" data-page="<?=$page?>"><i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Sign Up</a>
				</li>				
			</ul>
		</div>
	</div>
</nav>