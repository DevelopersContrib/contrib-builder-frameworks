<?php include('header.php');?>
<style>	
.about-year {
	border: 2px solid #6d6d6d;
	display: inline-block;
	font-size: 40px !important;
	height: 178px;
	margin-bottom: 40px;
	padding: 10px;
	width: 180px;
}
.about-year span { font-size: 50px; font-weight: 600; left: -4px; letter-spacing: -5px; position: relative; top: 13px; }
.timeline-number { font-family: "Oswald",sans-serif; font-size: 25px; padding: 15px; line-height:25px;}
.timeline-year {font-size: 20px; font-weight: 600; line-height:60px;}
.text-uppercase {
	text-transform: uppercase;
	font-size: 25px;
}	
.pc-box {
	background: #fff;
	padding: 80px 30px;
}
</style>
	<div id="navigation">
		<?php include('navigation.php'); ?>
	</div>
   
    <div class="page-container">		
        <div class="container">
            <div class="row">
				<div class="col-md-8 col-md-offset-2 pc-box">
					  <div class="text-center">
						<div class="about-year text-uppercase white-text"><span class="clearfix">20</span> Years</div>
						<p class="title-small text-uppercase letter-spacing-1 white-text font-weight-100">We have been in the forefront of domain development and technologies since 1996</p>
					  </div>
				</div>
            </div>
        </div>
    </div> 
    
	
	<div id="footer">
		<?php include('footer.php'); ?>
	</div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>	
</body>

</html>
