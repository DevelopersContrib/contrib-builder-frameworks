$(function(){
  $('.btn-signup').on('click',function(e){    
    var dis = $(this);
    var page = dis.data('page');

    if(page == 'index'){
      $('#input-email').trigger('focus');
    } else if(page == 'signup'){
     $('#input-fname').focus();
    } else {
      window.location.href = dis.attr('href');
    }

    e.preventDefault();
  });

  $('#input-email').on('focus',function(){ 
    $('#focus-div').addClass('plan-intro-focus');
    $('.arrow').fadeIn();
  });

  $('#input-email').on('focusout',function(){
    $('#focus-div').removeClass('plan-intro-focus');
    $('.arrow').fadeOut();
  });

  $('#btn-submit-email').on('click',function(e){
    var email = $('#input-email').val();

    if(validateEmail(email)){
      $('#submit-form').submit();
    } else {
      var alert = $('.email-alert');
      alert.fadeIn();
      setTimeout(function(){
        alert.fadeOut();
      },4000);
    }

    e.preventDefault();
  });

  $('#input-email').on('keyup',function(e){
    var key = e.which || e.keyCode;

    if(key == 13){
      $('#btn-submit-email').trigger('click');
    }
  });  

  $('#input-contact').on('keyup',function(e){
    var key = e.which || e.keyCode;

    if((key > 47 && key < 69) || (key > 95 && key < 106)){
      return;
    } else {
      return false;
    }
    
  });
});

var validateEmail = function(email){
  var regex = new RegExp(/^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/);

  return regex.test(email);
};

var validateDomain = function(domain){
  var regex = new RegExp(/^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,6})$/); 

  return domain.match(regex);
};

var validateForm = function(){
  var fname = $('input[name="fname"]').val();
  var lname = $('input[name="lname"]').val();
  var email = $('input[name="email"]').val();
  var website = $('input[name="website"]').val();
  var package = $('input[name="package"]').val();
  var contact = $('input[name="contact"]').val();
  var error = 0;

  if(!fname){
    showErrorMessage('fname','Please enter a value for the required field!');
    error++;
  }
  if(!lname){
    showErrorMessage('lname','Please enter a value for the required field!');
    error++;
  }
  if(!email){
    showErrorMessage('email','Please enter a value for the required field!');
    error++;
  } else {
    if(!validateEmail(email)){
      showErrorMessage('email','Please provide a valid email address!');
      error++;
    }
  }
  if(!website){
    showErrorMessage('website','Please enter a value for the required field!');
    error++;
  } else {
    if(!validateDomain(website)){
      showErrorMessage('website','Please provide a valid domain!');
      error++;
    }
  }
  if(contact){
    var regex = new RegExp(/^[0-9\-+]+[0-9]$/);
    if(!regex.test(contact)){
      showErrorMessage('contact','Please provide a valid phone number format!');
      error++;      
    }
  } else {
    showErrorMessage('contact','Please enter a value for the required field!');
    error++;
  }

  if(error == 0){
    return true;
  } else {
    return false;
  }
};

var showErrorMessage = function(fieldName,msg){    
  $('input[name="'+fieldName+'"]').siblings('.alert')
    .html(msg)
      .fadeIn();
  
  setTimeout(function(){
    $('input[name="'+fieldName+'"]').siblings('.alert').fadeOut();
  },2000);
};