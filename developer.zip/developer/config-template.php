<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $keywords = "{{KEYWORDS}}";
    $background_image = "{{BACKGROUND_IMAGE}}";

	$forsaletext = "{{FOR_SALE_TEXT}}";
    
    $footer_banner = "{{FOOTER_BANNER}}";
    
    
    $domain_affiliate_link = "{{AFF_LINK}}";
    
    
    $related_domains = {{RELATED_DOMAINS}};
    $additional_html = "{{ADDITIONAL_HTML}}";
    $footer_html = "{{FOOTER_HTML}}";
	
	$partners = {{PARTNERS}};
	$partnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
    $programs = {{PROGRAMS}};
    
    
?>