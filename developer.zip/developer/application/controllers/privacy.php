<?php

class Privacy extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
        	
		$template = $this->loadView('privacy');
		$metatitle = 'Privacy';
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('content', $api->getcontent($info['domain'],'privacy'));
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
    
}

?>