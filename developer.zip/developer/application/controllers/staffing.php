<?php

class Staffing extends Controller{
	function index(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		//if ($formdata['success']){
		$rolesarray = $formdata['data']['roles'];
		$countriesarray = $formdata['data']['countries'];
		$industriesarray = $formdata['data']['industries'];
		$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
		// }	
		
		$template = $this->loadView('staffing');
		$template->set('countriesarray',$countriesarray);
		$template->set('rolesarray',$rolesarray);
		$template->set('industriesarray',$industriesarray);
		$template->set('parnershiptypes',$parnershiptypes);
		$template->set('formdata', $formdata);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
}

?>