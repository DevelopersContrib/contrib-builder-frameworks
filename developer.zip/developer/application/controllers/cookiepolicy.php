<?php

class CookiePolicy extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
			
		$template = $this->loadView('cookiepolicy');
		$metatitle = 'Cookie Policy';
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('content', $api->getcontent($info['domain'],'cookie'));
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
    
}

?>
