<?php global $footer_html?>
<style>
.footer-dark-1 h3 {
    margin-top: 0px;
    margin-bottom: 8px;
    color: #999999;
}
.animated {
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
}
@-webkit-keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}

@keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        -ms-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        -ms-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}
.rotateIn {
    -webkit-animation-name: rotateIn;
    animation-name: rotateIn;
}
.r-d{
    -webkit-animation-delay: 2.5s;
    -moz-animation-delay: 2.5s;
    -ms-animation-delay: 2.5s;
    -o-animation-delay: 2.5s;
    animation-delay: 2.5s;
}
.r-d.rotateIn{
    position: absolute; 
    z-index: 10; 
    top: -20px; 
    left: 190px;
}
.arrw-rela {
    position: relative;
}
</style>
       <!-- footer -->
        <footer>
    		<div style="position:relative;">
		        <div class="animated rotateIn r-d">
		            <a alt="Contrib" target="_blank" href="http://referrals.contrib.com/idevaffiliate.php?id=71952&url=http://www.contrib.com/signup/firststep?domain=veteransrehab.com">
		                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-8.png">
		            </a>
		        </div>
		    </div>
           <div class="footer-dark-1">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="row">
								<div class="col-md-3">
									<h3 class="fnt-bold text-uppercase">
										<?php echo $info['domain']; ?>
									</h3>
									<p>
										<?php echo $info['description']; ?>
									</p>
								</div>
								<div class="col-md-3">
									<h3 class="fnt-bold text-uppercase">
										get started
									</h3>
									<ul class="list-unstyled f-a-links">
										<li>
											<a href="/partner" class="text-capitalize">
												Partner with us
											</a>
										</li>
										<li>
											<a href="/staffing" class="text-capitalize">
												Apply now
											</a>
										</li>
										<li>
											<a href="/referral" class="text-capitalize">
												referral
											</a>
										</li>
										<!-- <li>
											<a href="/fund" class="text-capitalize">
												fund
											</a>
										</li> -->
										<li>
											<a href="/developers" class="text-capitalize">
												developers
											</a>
										</li>										
									</ul>
								</div>
								<div class="col-md-3">
									<h3 class="fnt-bold text-uppercase">
										company
									</h3>
									<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
										<li>
											<a href="/about" class="text-capitalize">
												About us
											</a>
										</li>
										<li>
											<a href="/terms" class="text-capitalize">
												Terms
											</a>
										</li>
										<li>
											<a href="/privacy" class="text-capitalize">
												Privacy
											</a>
										</li>
										<li>
											<a href="/contact" class="text-capitalize">
												Contact us
											</a>
										</li>
										<li>
											<a href="/apps" class="text-capitalize">
												Apps
											</a>
										</li>
									</ul>
								</div>
								<div class="col-md-3">
									<!-- <h3 class="fnt-bold text-uppercase">
										partners
									</h3>
									<p>
										<a href="http://www.rackspace.com">
											<img style="height:45px;" title="Rackspace" alt="Rackspace" src="http://c15162226.r26.cf2.rackcdn.com/Rackspace_Cloud_Company_Logo_clr_300x109.jpg">
										</a>
									</p> -->
									<h3 class="fnt-bold text-uppercase">
										partners
									</h3>
									<p>
										<?if($footer_html != ""):?>
										<?echo base64_decode($footer_html)?>
										<?php else:?>
										<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
										<?endif;?>							
									</p>
									<h3 class="fnt-bold text-uppercase">
										Socials
									</h3>
									<ul class="list-inline socials-ul">
										<li>
											<a href="https://plus.google.com/u/0/107137956951125091896/" class="icon-button google-plus" alt="google-plus" title="google-plus">
												<i class="fa fa-google-plus"></i>
												<span></span>
											</a>
										</li>
										<li>
											<a title="facebook" alt="facebook" class="icon-button facebook" href="https://www.facebook.com/pages/Javapoint/646287392104713">
												<i class="fa fa-facebook"></i>
												<span></span>
											</a>
										</li>										
										<li>
											<a title="linkedin" alt="linkedin" class="icon-button linkedin" href="http://www.linkedin.com/company/javapoint">
												<i class="fa fa-linkedin"></i>
												<span></span>
											</a>
										</li>										
										<li>
											<a href="https://www.youtube.com/user/javapointcom" class="icon-button youtube" title="youtube" alt="youtube">
												<i class="fa fa-youtube"></i>
												<span></span>
											</a>
										</li>
									</ul>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-dark-2">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="row">
								<div class="col-md-6 f-a-links">
									© <?=date("Y")?> <a href="" class="text-capitalize "><?php echo $info['domain']; ?></a> All Rights Reserved. 
								</div>
								<div class="col-md-6">
									<ul class="list-inline text-right f-a-links">
										<li>
											<a href="/about" class="text-capitalize">
												<i class="fa fa-bookmark-o"></i>
												About us
											</a>
										</li>
										<li>
											<a href="/terms" class="text-capitalize">
												<i class="fa fa-book"></i>
												Terms
											</a>
										</li>
										<li>
											<a href="/privacy" class="text-capitalize">
												<i class="fa fa-cube"></i>
												privacy
											</a>
										</li>
										<li>
											<a href="/contact" class="text-capitalize">
												<i class="fa fa-phone-square"></i>
												contact us
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
                <!-- scroll to top --> 
                <a href="javascript:;" class="scrollToTop"><i class="fa fa-angle-up"></i></a> 
                <!-- scroll to top end... --> 
        </footer>
        <!-- end footer -->

        <!-- javascript libraries --> 
        <!--<script type="text/javascript" src="js/jquery.min.js"></script>-->
        <script type="text/javascript" src="js/modernizr.js"></script>
        <script type="text/javascript" src="js/bootstrap.js"></script> 
        <script type="text/javascript" src="js/bootstrap-hover-dropdown.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
        <script type="text/javascript" src="js/skrollr.min.js"></script>  
        <script type="text/javascript" src="js/jquery.viewport.mini.js"></script>
        <script type="text/javascript" src="js/smooth-scroll.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="js/page-scroll.js"></script>
        <!-- easy piechart-->
        <script type="text/javascript" src="js/jquery.easypiechart.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
        <!--portfolio with shorting tab --> 
        <script type="text/javascript" src="js/jquery.isotope.min.js"></script> 
        <!-- owl slider  -->
        <script type="text/javascript" src="js/owl.carousel.min.js"></script>
        <!-- magnific popup  -->
        <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
        <script type="text/javascript" src="js/popup-gallery.js"></script>
        <!-- text effect  -->
        <script type="text/javascript" src="js/text-effect.js"></script>
        <!-- revolution slider  -->
        <script type="text/javascript" src="js/jquery.tools.min.js"></script>
        <script type="text/javascript" src="js/jquery.revolution.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="js/counter.js"></script>
        <!-- fit videos  -->
        <script type="text/javascript" src="js/jquery.fitvids.js"></script>
        <!-- imagesloaded  -->
        <script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
        <!-- one page navigation-->
        <script type="text/javascript" src="js/one-page-main.js"></script>
        <!-- setting --> 
        <script type="text/javascript" src="js/main.js"></script>
		<!-- Go to www.addthis.com/dashboard to customize your tools -->
		<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-56e0ce2de211f317"></script>
    </body>
</html>      