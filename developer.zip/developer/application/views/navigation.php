<style>
.dom-title {
	padding-top: 25px;
	font-size: 20px;
	font-weight: bold;
}
.dom-title-2 {
	padding-top: 0px;
	font-size: 20px;
	font-weight: bold;
}
</style>
  <!-- navigation --> 
        <nav class="navbar navbar-default navbar-fixed-top nav-transparent overlay-nav sticky-nav nav-border-bottom bg-white" role="navigation">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-6">
						<?php if(!empty($info['logo'])): ?>
						<a class="logo-light" href="/home">
							<img alt="<?php echo $info['domain']; ?>" alt="<?php echo $info['domain'] ?>" title="<?php echo $info['domain']; ?>" src="<?php echo $info['logo']; ?>" class="logo" />
						</a>
						<a class="logo-dark" href="/home">
							<img alt="<?php echo $info['domain']; ?>" alt="<?php echo $info['domain'] ?>" title="<?php echo $info['domain']; ?>" src="<?php echo $info['logo']; ?>" class="logo" />
						</a>
						<?php else: ?>
						<a class="sticky-nav logo-light dom-title" href="/home"><?php echo strtoupper($info['domain']); ?></a>
						<a class="logo-dark dom-title-2" href="/home"><?php echo strtoupper($info['domain']); ?></a>	
						<?php endif;?>
					</div>
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                    </div>
                    <div class="col-md-9 text-right">
                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="/home" class="inner-link">Home</a> </li>
                                <li><a href="/about" class="inner-link">About</a> </li>
                                <li><a href="/contact" class="inner-link">Join Us</a></li>
                                <li><a href="/partner" class="inner-link">Partners</a> </li>
								<li><a href="/apps" class="inner-link">Apps</a> </li>
                                <li><a href="/fund" class="inner-link">Donate Today</a> </li>
                              
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <!-- end of navigation -->   
<style>
    .opacity-full.opacity-full-cust{
        z-index: 0;
    }
    p.margin-two.text-med.width-90.center-col{
        color: #828282;
    }
	.blur-box {
    background-color: #f5f5f5;
    padding: 15px;
    margin-bottom: 25px;
	}
</style>