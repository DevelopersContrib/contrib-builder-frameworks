<?php include 'header.php'; ?>
<!-- <link rel="stylesheet" href="css/owl.carousel-2.css"> -->
<style>
    .opacity-full.opacity-full-cust{
        z-index: 0;
    }
    p.margin-two.text-med.width-90.center-col{
        color: #828282;
    }
	#topstreamsites {
		/* background:#fafafa; */
	}
    .smoke-bckgrnd{
        background-color: #fafafa;
    }
    .btn-cust-form.btn{
        margin:0;
    }
    .form-control.form-cust-control{
        background-color: #222;
        border-color: #666;
        border-radius: 4px;
        color: #fff;
    }
    .btn-black-cust{
        border: 2px solid #fff;
        color: #fff;
        letter-spacing:3px;
        cursor: pointer;
    }
    .btn-black-cust:hover{
        background-color: #fff;
        color: #000;
    }
    /* Domain brand found */
    .wrap-marketplace-box-item {
        background-color: #fff;
        border-radius: 2px;
        border-top: 1px solid #d9d9d9;
        box-shadow: 0 1px 0 1px #d9d9d9;
        display: block;
        padding: 15px;
        text-align: center;
        word-wrap: break-word;
        color: #000;
        text-shadow: none;
        margin-bottom: 25px;
    }
    /* Logo Found */
    .wmbi-img-logo {
        display: block;
        margin-bottom: 15px;
    }
    .wmbi-img-logo img {
        display: inline-block;
        max-height: 60px;
    }
    /* Title Brand */
    .wmbi-ttle {
        background-color: #f5f5f5;
        color: #2e9f3e;
        font-size: 1.3em;
        font-weight: bold;
        padding: 10px 5px;
    }
    .marg-m-ttlTop {
        margin-top: 0;
    }
    .p-marg-btm {
        margin-bottom: 0;
    }
    .ul-wmbi-zero li {
        padding: 0;
    }
    .ul-wmbi-zero li .btn{
        margin: 0;
    }
    /* Carousel Custom Brands */
    #brandsCarousel .owl-item{
        padding:15px;
    }
    #brandsCarousel .owl-prev::before,#brandsCarousel .owl-next::before{
        background-color: #e1e1e1;
    }

    /* Note */
    .note {
        border-left: 5px solid #eee;
        border-radius: 0 4px 4px 0;
        margin: 0 0 20px;
        padding: 15px 30px 15px 15px;
    }
    .note.note-success {
        background-color: #fef7f8;
        border-color: #58d0da;
        color: #000;
    }
    .note h1, .note h2, .note h3, .note h4, .note h5, .note h6 {
        margin-top: 0;
        padding-bottom: 10px;
        padding-top: 10px;
    }
    .note p{
        font-size: 13px;
        margin:0;
    }
    .note p:last-child {
        margin-bottom: 0;
    }

    .share{
        height:auto;
        padding:10px;
        font-size:25px;
        line-height:auto;
        text-align:center;
        background: rgb(255,255,255); /* Old browsers */
        /* IE9 SVG, needs conditional override of 'filter' to 'none' */
        background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2ZmZmZmZiIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjQ3JSIgc3RvcC1jb2xvcj0iI2Y2ZjZmNiIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNlZGVkZWQiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
        background: -moz-linear-gradient(top,  rgba(255,255,255,1) 0%, rgba(246,246,246,1) 47%, rgba(237,237,237,1) 100%); /* FF3.6+ */
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,255,255,1)), color-stop(47%,rgba(246,246,246,1)), color-stop(100%,rgba(237,237,237,1))); /* Chrome,Safari4+ */
        background: -webkit-linear-gradient(top,  rgba(255,255,255,1) 0%,rgba(246,246,246,1) 47%,rgba(237,237,237,1) 100%); /* Chrome10+,Safari5.1+ */
        background: -o-linear-gradient(top,  rgba(255,255,255,1) 0%,rgba(246,246,246,1) 47%,rgba(237,237,237,1) 100%); /* Opera 11.10+ */
        background: -ms-linear-gradient(top,  rgba(255,255,255,1) 0%,rgba(246,246,246,1) 47%,rgba(237,237,237,1) 100%); /* IE10+ */
        background: linear-gradient(to bottom,  rgba(255,255,255,1) 0%,rgba(246,246,246,1) 47%,rgba(237,237,237,1) 100%); /* W3C */
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#ededed',GradientType=0 ); /* IE6-8 */
        border-radius:5px;margin-bottom:25px;

    }
    .share a{
        color: #23527c;
    }

    /* Form Signup CSS */
    .step-signup .form-group{
        padding:5px 5px 0;
        position: relative;
    }
    .step-signup .form-group input.form-control{
        margin:0;
    }
    .form-group.has-error{
        background-color: #ff4c4c;
        border-radius: 5px;
    }
    .has-error .form-control {
        border-color: #a94442;
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
    }
    .form-group.success:after {
        font-family: "FontAwesome";
        content: "\f00c";
        color: #44b27b;
        position: absolute;
        right: 20px;
        top: 12px;
        font-size: 1.5em;
    }
    .form-group.has-error small.help-block {
        color: #fff;
        font-weight: 700;
        padding: 0 10px 5px;
        text-align: left;
    }
	#response h3, #response p {
		color: #fff;
	}
	#response form .btn {
		border-radius: 2px;
	}
</style>
<!-- slider section -->
<script type="text/javascript" src="/js/lead.js"></script>
<script>
    $(document).ready(function(){
        $('.btn-step-signUp').click(function(e){
            flagEmail = false;
            flagFname = false;
            flagCpass = false;

            //nameuser
            if(!$('input[name=nameuser]').val()==""){
                $('.nameuser-msg').removeClass("help-block");
                $('.nameuser-msg').text('');
                $('input[name=nameuser]').parents('.form-group').removeClass("has-error").addClass("success");
                flagFname = true;
            }else{
                $('.nameuser-msg').addClass("help-block");
                $('.nameuser-msg').text('Please enter your name.');
                $('input[name=nameuser]').parents('.form-group').removeClass("success").addClass("has-error");
            }

            //emailaddress
            var sEmail = $('input[name=emailaddress]').val();
            if($.trim(sEmail).length == 0){
                $('.emailaddress-msg').addClass("help-block");
                $('.emailaddress-msg').text('Please enter your email address.');
                $('input[name=emailaddress]').parents('.form-group').removeClass("success").addClass("has-error");
            }else if(validateEmail(sEmail)) {
                $('.emailaddress-msg').removeClass("help-block");
                $('.emailaddress-msg').text('');
                $('input[name=emailaddress]').parents('.form-group').removeClass("has-error").addClass("success");
                flagEmail = true;
            }else{
                $('.emailaddress-msg').addClass("help-block");
                $('.emailaddress-msg').text('Please enter valid email address.');
                $('input[name=emailaddress]').parents('.form-group').removeClass("success").addClass("has-error");
            }

            //password
            if(!$('input[name=password]').val()=="" && !$('input[name=confirm-password]').val()==""){
				if($('input[name=password]').val() != $('input[name=confirm-password]').val()){
					$('.password-msg').addClass("help-block");
					$('.password-msg').text('Password did not matach.');
					$('.confirm-password-msg').addClass("help-block");
					$('.confirm-password-msg').text('Password did not matach.');
					$('input[name=password]').parents('.form-group').removeClass("success").addClass("has-error");
					$('input[name=confirm-password]').parents('.form-group').removeClass("success").addClass("has-error");
				}else{
					$('.password-msg').removeClass("help-block");
					$('.password-msg').text('');
					$('.confirm-password-msg').removeClass("help-block");
					$('.confirm-password-msg').text('');
					$('input[name=password]').parents('.form-group').removeClass("has-error").addClass("success");
					$('input[name=confirm-password]').parents('.form-group').removeClass("has-error").addClass("success");
					flagCpass = true;
				}                
            }else if($('input[name=password]').val()=="" && !$('input[name=confirm-password]').val()==""){
                $('.password-msg').addClass("help-block");
                $('.password-msg').text('Please enter your password.');				
                $('input[name=password]').parents('.form-group').removeClass("success").addClass("has-error");
            } else if(!$('input[name=password]').val()=="" && $('input[name=confirm-password]').val()==""){
				$('.confirm-password-msg').addClass("help-block");
                $('.confirm-password-msg').text('Please enter your password.');
                $('input[confirm-password]').parents('.form-group').removeClass("success").addClass("has-error");
			} else if($('input[name=password]').val()=="" && $('input[name=confirm-password]').val()==""){
				$('.password-msg').addClass("help-block");
                $('.password-msg').text('Please enter your password.');				
                $('input[name=password]').parents('.form-group').removeClass("success").addClass("has-error");
				$('.confirm-password-msg').addClass("help-block");
                $('.confirm-password-msg').text('Please enter your password.');
                $('input[name=confirm-password]').parents('.form-group').removeClass("success").addClass("has-error");
			}

            if(flagEmail == true && flagFname==true && flagCpass==true){
                ifEmailExist(sEmail);
                return false;
            }

            return false;
			e.preventDefault();
        });
        
        function validateEmail(sEmail) {
            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (filter.test(sEmail)) {
                return true;
            }
            else {
                return false;
            }
        }
		
    });
	
	function ifEmailExist(email){
		$.ajax({
			type: 'POST',
			url: 'http://developers.contrib.com/home/checkEmailIfExist',
			data: {'email': email},
			success: function(data){
				if(data.exist === true){
					console.log('email exist.');
					$('.emailaddress-msg').addClass("help-block");
					$('.emailaddress-msg').text('Please use another email address.');
					$('input[name=emailaddress]').parents('.form-group').removeClass("success").addClass("has-error");
				}else{
					console.log('email available.');
					register();
				}
			}
		});
	}
	
	function register(){
        var domain_name = $('#domain_name').val();
		var name = $('input[name=nameuser]').val()
		var password = $('input[name=password]').val()
		var email = $('input[name=emailaddress]').val();
		// $.session.set('domain_name', domain_name);
		$.ajax({
			type: 'POST',
			url: 'http://developers.contrib.com/home/register_success2',
			data: {'name':name, 'password':password, 'email': email, 'domain_name': domain_name},
			dataType: 'json',
			success: function(data){
				console.log(data.message);
				$('.javaform').hide();
				$('.success-msg').removeClass('hide');
				submitLead();
			}
		});
	}
</script>

<section id="slider" class="no-padding">
    <div id="owl-demo" class="owl-carousel owl-theme light-pagination dark-pagination-without-next-prev-arrow">
        <!-- slider item #1 -->
        <!-- set the background image using inline CSS below. -->
		<div class="item owl-bg-img section-1">
			<div class="opacity-light bg-black"></div>
			<div class="container full-screen position-relative" >
				<div class="slider-typography margin-five no-margin-bottom">
					<div class="slider-text-middle-main">
						<div class="slider-text-middle">
							<!-- <span class="text-uppercase white-text letter-spacing-3">Welcome To <?=$domain?></span>
                            <h1 class="letter-spacing-2 white-text margin-three no-margin-bottom"><?=$description?></h1> -->
                            <div class="javaform">
                                <h1 class="letter-spacing-2 white-text margin-three ">#Hello there!</h1>
                                <span class="text-uppercase white-text letter-spacing-3 margin-three">If you're kickass or would like to get more startup <br> experience, signup with us and earn equity while you're at it.</span>
                                <br><br>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="step-signup">
											<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
                                            <input type="hidden" id="domain" value="<?php echo $info['domain']; ?>">
                                            <div class="form-group">
                                                <input name="nameuser" type="text" id="name" class="form-control input-lg form-cust-control" placeholder="Name *">
                                                <small class="nameuser-msg"></small>
                                            </div>
                                            <div class="form-group">
                                                <input name="emailaddress" type="text" id="email" class="form-control input-lg form-cust-control" placeholder="Email Address *">
                                                <small class="emailaddress-msg"></small>
                                            </div>
                                            <div class="form-group">
                                                <input name="password" type="password" class="form-control input-lg form-cust-control" placeholder="Password *">
                                                <small class="password-msg"></small>
                                            </div>
											<div class="form-group">
                                                <input name="confirm-password" id="confirm-password" type="password" class="form-control input-lg form-cust-control" placeholder="Confirm password *">
                                                <small class="confirm-password-msg"></small>
                                            </div>
                                            
                                            <div class="form-group">
                                                <a id="" class="btn btn-black-cust btn-block btn-lg btn-cust-form btn-step-signUp">
                                                    Signup if You're Kickass
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hide success-msg">
                                <div class="row">
                                    <div class="col-md-8 col-md-offset-2">
                                        <div class="note note-success text-left">
                                            <h4 class="block">
                                                <b>Success! Thank you!</b>
                                            </h4>
                                            <p>
                                                We have a vision. We want to turn these brands into money making companies and we can't do that alone. We need people like you who understand how startup works and who knows the value of equity distribution via valuable contribution. We need your help to do this.
                                            </p>
                                            <p>
                                                Let's kick ass together!
                                            </p>
                                            <p>
                                                <span class="text-capitalize"><?php echo $info['domain']; ?></span> is part of the Contrib Network and we allow people from all over the world to contribute for equity or cash grants. Please join us!
                                            </p>
                                            <br>
                                            <p>
                                                Fyi. You'll be receiving two emails from us. Please check your spam inbox just for safe measure if you don't see it in your inbox in a second or two.
                                            </p>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="share">
                                                   SHARE IT LIKE A NERD!<br>
                                                   <span><a addthis:userid="pages/Contrib/555101101181671" href="https://www.facebook.com/contribs">FACEBOOK</a></span>
                                               </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="share">
                                                   SHOUT IT WHILE ITS HOT!
                                                   <br>
                                                   <span>
                                                       <a addthis:userid="Contribcom" href="http://www.twitter.com/contrib">TWITTER</a></span>
                                                   </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row-fluid" id="response" style="margin-top: 20px;display:none">							
								<div class="span12 text-center"><h3>Thanks, your spot is reserved!</h3> 
									<p>Share <?php echo ucfirst($info['domain'])?> with you friends to move up in line and reserve your username.</p>
									<div class="addhtml" style="margin:10px;">
										<?php if($attr['additional_html'] != ""): ?>
											<?php echo base64_decode($attr['additional_html']); ?>
										<?php endif; ?>
									</div>
								
								</div>								
							</div><!-- response -->
						</div>
					</div>
				</div>
			</div>
		</div>
        <!-- end slider item #1 -->
        <!-- slider item #2 -->
        <!-- set the background image using inline CSS below. -->
        
        <!-- end slider item #2 -->
       
    </div>
</section>
<!-- end slider section -->
<!-- what we do section -->
<section>
    <div class="container">
        <div class="row">
            <!-- section title -->
            <div class="col-md-5 col-sm-8 dividers-header double-line center-col text-center margin-ten no-margin-top">
                <div class="subheader bg-white">
                    <h3 class="title-med no-padding-bottom letter-spacing-2">why contribute code?</h3>
                </div>
            </div>
            <!-- end section title -->
        </div>
        <div class="row margin-five no-margin-top">
            <div class="col-md-4 col-sm-4 xs-margin-bottom-ten">
                <p class="text-uppercase letter-spacing-2 black-text font-weight-600 margin-ten no-margin-bottom">Build Brands</p>
                <p class="margin-two text-med width-90">We have the best techonology contributors and inhouse staff that builds great brands.</p>
            </div>
            <div class="col-md-4 col-sm-4 xs-margin-bottom-ten">
                <p class="text-uppercase letter-spacing-2 black-text font-weight-600 margin-ten no-margin-bottom">Build Products</p>
                <p class="margin-two text-med width-90">Using our Contrib/VNOC model we are able to build web products vertically but still we need help.</p>
            </div>
            <div class="col-md-4 col-sm-4">
                <p class="text-uppercase letter-spacing-2 black-text font-weight-600 margin-ten no-margin-bottom">Build Verticals</p>
                <p class="margin-two text-med width-90">Using Globalventures portfolio, we build products around our verticals and create synergy within and outside our portfolio.</p>
            </div>
        </div>
       
    </div>
</section>
<!-- end what we do section -->

<!-- why choose section -->
<section class="smoke-bckgrnd">
    <div class="container position-relative">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1>Check out these brands you can contribute code to</h1>
            </div>
            <div class="col-md-12">
                <div id="brandsCarousel" class="owl-carousel">
					<?php foreach($featuredsites as $featuredsite): ?>
                    <div>
                        <div class="wrap-marketplace-box-item">
                            <a class="wmbi-img-logo" href="http://<?php echo $featuredsite['domain_name']; ?>">
                                <?php if(!empty($featuredsite['logo'])):?>
									<img src="<?php echo $featuredsite['logo']; ?>" class="img-responsive" alt="<?php echo $featuredsite['domain_name']; ?>" title="<?php echo $featuredsite['domain_name']; ?>">
								<?php else: ?>
									<img src="https://d2qcctj8epnr7y.cloudfront.net/contrib/logo-contrib-brand2.png" class="img-responsive" alt="<?php echo $featuredsite['domain_name']; ?>" title="<?php echo $featuredsite['domain_name']; ?>">
								<?php endif; ?>
                            </a>
                            <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
                                <?php echo $featuredsite['domain_name']; ?>
                            </h3>
                            <p class="p-marg-btm">
                                Join our exclusive community of like minded people
                            </p>
                            <p>
                                <a target="_blank" href="http://<?php echo $featuredsite['domain_name']; ?>"><?php echo $featuredsite['domain_name']; ?></a>
                            </p>
                            <ul class="list-inline ul-wmbi-zero">
                                <li>
                                    <a class="btn btn-success btn-lg" target="_blank" href="http://<?php echo $featuredsite['domain_name']; ?>">Visit</a>
                                </li>
                                <li>
                                    <a class="btn btn-success btn-lg" target="_blank" href="https://contrib.com/brand/details/<?php echo $featuredsite['domain_name']; ?>">Details</a>
                                </li>
                            </ul>
                        </div>
                    </div>
					<?php endforeach; ?>
                </div>
                <div class="row">
                    
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end why choose section -->
<!-- top survey section-->
<!-- <section id="top-survey" style="display:none;">
	
</section> -->
<section id="topstreamsites">
	<div class="container topstream">
		<div class="row">
			<div class="col-md-5 col-sm-8 dividers-header double-line center-col text-center margin-ten no-margin-top">
				<div class="subheader bg-white">
					<h3 class="title-med no-padding-bottom letter-spacing-2">Top Technology Sites</h3>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="streambg">				
				<?php if(count($related_domains)>0){ ?>
				<?php $limit = FALSE; //change with number of limit, if no limit change to FALSE ?>
				<?php $cnt = 0; ?>
				<div class="row">
					<div class="col-md-12">
						<div class="topsurvey">
							<ul class="list-unstyled">
								<?php foreach($related_domains as $relatedsite){ ?>
									<li class="col-md-4"><a href="http://<?php echo $relatedsite['domain_name']?>"><i class="fa fa-globe"></i>&nbsp;<?php echo $relatedsite['domain_name']?></a></li>
									<?php $cnt++; ?>
									<?php if($limit==$cnt) break; ?>
								<?php } ?>
							</ul>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
			</div>
		</div>
	</div>
</section>
<? include_once 'footer.php';?>
<script>
    jQuery(document).ready(function(){
        jQuery("#brandsCarousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            items: 3,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        });
    });	
</script>