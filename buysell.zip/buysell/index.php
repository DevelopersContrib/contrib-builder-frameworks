<?php
/*
 * PIP v0.5.3
 */

//Start the Session
//session_start(); 

// Defines
define('ROOT_DIR', realpath(dirname(__FILE__)) .'/');
define('APP_DIR', ROOT_DIR .'application/');
//define('ENV', 'staging');

// Includes
require(APP_DIR .'config/config.php');
require(ROOT_DIR .'system/model.php');
require(ROOT_DIR .'system/view.php');
require(ROOT_DIR .'system/controller.php');
require(ROOT_DIR .'system/pip.php');

// Define base URL
global $config;
global $domain;
global $domainid;
global $title;
global $logo;
global $description;
global $account_ga;
global $description;

global $background_image;
global $top_description;
global $forsale;
global $forsaletext;
global $follow_count;
global $domain_affiliate_link;

global $data_widget_users;
global $data_widget_jobs;
global $rolesarray ;
global $countriesarray;
global $industriesarray;
global $parnershiptypes;


define('BASE_URL', $config['base_url']);

//create robots.txt

pip();

?>
