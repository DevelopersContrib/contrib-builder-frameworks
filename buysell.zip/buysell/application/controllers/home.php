<?php

class Home extends Controller {
	
	function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
	{
	        if (($method == 'PUT') || ($method=='DELETE'))
	        {
	            $headers[] = 'X-HTTP-Method-Override: '.$method;
	        }
	
	        $handle = curl_init();
	        curl_setopt($handle, CURLOPT_URL, $url);
	        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
	        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
	        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
	        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
	        if ($user){
	         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
	        } 
	
	        switch($method)
	        {
	            case 'GET':
	                break;
	            case 'POST':
	                curl_setopt($handle, CURLOPT_POST, true);
	                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
	                break;
	            case 'PUT':
	                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
	                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
	                break;
	            case 'DELETE':
	                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
	                break;
	        }
	        $response = curl_exec($handle);
	        return $response;
	}
	public function index()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		$featuredsites = $api->getfeaturedsites();

		$metatitle = 'Homepage';
    	$template = $this->loadView('index');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('featuredsites', $featuredsites);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
	public function about()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'About page';
    	$template = $this->loadView('about');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
	public function terms()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

	     $api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
		  $url = $api_content_url.'GetFooterContents?domain='.$info['domain'].'&key=5c1bde69a9e783c7edc2e603d8b25023&page=terms';
		  $result =  $this->createApiCall($url, 'GET', $headers, array());
		  $data_domain = json_decode($result,true);
		  if (isset($data_domain['data']['content'])){
		   $terms =   $data_domain['data']['content'];
		  }else {
			$terms = "";
		  }
		  
		$metatitle = 'Terms';
    	$template = $this->loadView('terms');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->set('content',$terms);
		$template->render();
	}
	
	public function privacy()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

	     $api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
		  $url = $api_content_url.'GetFooterContents?domain='.$info['domain'].'&key=5c1bde69a9e783c7edc2e603d8b25023&page=privacy';
		  $result =  $this->createApiCall($url, 'GET', $headers, array());
		  $data_domain = json_decode($result,true);
		  if (isset($data_domain['data']['content'])){
		   $content =   $data_domain['data']['content'];
		  }else {
			$content = "";
		  }
		  
		$metatitle = 'Privacy';
    	$template = $this->loadView('privacy');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->set('content',$content);
		$template->render();
	}
	
   public function cookie()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
   
		$api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
		  $url = $api_content_url.'GetFooterContents?domain='.$info['domain'].'&key=5c1bde69a9e783c7edc2e603d8b25023&page=cookie';
		  $result =  $this->createApiCall($url, 'GET', $headers, array());
		  $data_domain = json_decode($result,true);
		  if (isset($data_domain['data']['content'])){
		   $content =   $data_domain['data']['content'];
		  }else {
			$content = "";
		  }
		  
		$metatitle = 'Cookie Policy';
    	$template = $this->loadView('cookie');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->set('content',$content);
		$template->render();
	}
	
	public function contact()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Terms';
    	$template = $this->loadView('contact_us');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
		public function apps()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Apps page';
    	$template = $this->loadView('apps');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
    
}

?>
