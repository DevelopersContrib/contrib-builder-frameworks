<?php

class Home extends Controller {
	
	public function index()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Homepage';
    	$template = $this->loadView('index');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	public function about()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'About page';
    	$template = $this->loadView('about');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	public function terms()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Terms';
    	$template = $this->loadView('terms');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	public function privacy()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Privacy';
    	$template = $this->loadView('privacy');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	public function contact()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Terms';
    	$template = $this->loadView('contact_us');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	
	
    
}

?>
