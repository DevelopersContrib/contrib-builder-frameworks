<?php

class Home extends Controller {
	
	public function index()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		$featuredsites = $api->getfeaturedsites();

		$metatitle = 'Homepage';
    	$template = $this->loadView('index');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('featuredsites', $featuredsites);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
	public function about()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'About page';
    	$template = $this->loadView('about');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
	public function terms()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Terms';
    	$template = $this->loadView('terms');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
	public function privacy()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Privacy';
    	$template = $this->loadView('privacy');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
	public function contact()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Terms';
    	$template = $this->loadView('contact_us');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
		public function apps()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Apps page';
    	$template = $this->loadView('apps');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
			$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
    
}

?>
