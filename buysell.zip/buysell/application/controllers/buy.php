<?php

class Buy extends Controller {
	
	public function index()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		$countries = $api->getcountries();

		$metatitle = 'Buy Domain';
    	$template = $this->loadView('buy2');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('countries', $countries);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}

	public function buy2()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		$countries = $api->getcountries();
		$metatitle = 'Buy Domain';
    	$template = $this->loadView('buy2');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('countries', $countries);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		$template->render();
	}
	
	public function buynext(){
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$autologin_values = array();
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		$countries = $api->getcountries();
		$country_select = $_POST['country'];
		$country_id = $_POST['country_id'];
		$phone = $_POST['myphone'];
		$amount = $_POST['amount'];
		$fname = $_POST['fname'];
		$password = $_POST['password'];
		$message = $_POST['message'];
		$lname = $_POST['lname'];
		$email = $_POST['email'];
		$pushed_value = array_push($autologin_values,$email,$password);
		//var_dump(json_encode( $autologin_values ));
		$encoded_values = base64_encode( json_encode( $autologin_values ));
		//$decoded_values = base64_decode($encoded_values);
		//var_dump(json_decode($decoded_values));
		$metatitle = 'Buy Domain';
    	$template = $this->loadView('buy-pagev2');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('code', $encoded_values);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('amount',$amount);
		$template->set('fname',$fname);
		$template->set('lname',$lname);
		$template->set('email',$email);
		$template->set('password',$password);
		$template->set('message',$message);
		$template->set('country_select', $country_select);
		$template->set('country_id', $country_id);
		$template->set('phone', $phone);
		$template->set('countries',$countries);
		$template->render();
		
	}
	
	public function verify(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Buy Domain';
    	$template = $this->loadView('verify-page');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();

	}
	
	
}

?>
