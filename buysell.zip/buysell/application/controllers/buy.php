<?php

class Buy extends Controller {
	
	public function index()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Buy Domain';
    	$template = $this->loadView('buyiframe');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	public function buynext(){
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		$countries = $api->getcountries();

		$amount = $_POST['amount'];
		$fname = $_POST['fname'];
		$password = $_POST['password'];
		$message = $_POST['message'];
		$lname = $_POST['lname'];
		$email = $_POST['email'];
		
		$metatitle = 'Buy Domain';
    	$template = $this->loadView('buy-pagev2');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('amount',$amount);
		$template->set('fname',$fname);
		$template->set('lname',$lname);
		$template->set('email',$email);
		$template->set('password',$password);
		$template->set('message',$message);
		$template->set('countries',$countries);
		$template->render();
		
		
	}
	
	public function verify(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Buy Domain';
    	$template = $this->loadView('verify-page');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();

	}
	
	
    
}

?>
