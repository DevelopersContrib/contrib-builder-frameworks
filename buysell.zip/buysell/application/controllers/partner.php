<?php

class Partner extends Controller {
	
	public function index()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		$countries = $api->getcountries();

		$metatitle = 'Buy Domain';
    	$template = $this->loadView('partnership');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->set('countries',$countries);
		$template->set('social_fb',$api->get_social_fb());
		$template->set('social_gplus',$api->get_social_gplus());
		$template->set('social_twitter',$api->get_social_twitter());
		$template->set('social_linkedin',$api->get_social_linkedin());
		$template->set('social_gtube',$api->get_social_gtube());
		
		$template->render();
	}
	
	public function partnershipnext(){
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();

		$metatitle = 'Buy Domain';
    	$template = $this->loadView('partnership-page2');
		$template->set('metatitle', $metatitle);
		$template->set('info', $info);
		$template->set('attr', $attr);
		$template->set('domain_affiliate_link',$api->getaffiliatelink());
		$template->set('formdata', $formdata);
		$template->set('footer_banner', $api->getbanner());
		$template->set('forsale', $api->getbanner());
		$template->set('base_url',$helper->base_url());
		$template->render();
		
		
		
		
	}
	

	
	
    
}

?>
