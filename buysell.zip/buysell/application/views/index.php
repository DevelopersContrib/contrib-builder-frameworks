<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>


<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<div class="row">
				<div class="col-md-4 text-center">
					<div class="cbox cbox2 br-h2">
						<h2>BUY</h2>
						<h4><?=ucwords($info['domain'])?></h4>
						 <p><a href="<?php echo $base_url?>buy" class="btn btn-success btn-lg btn-wider">Make An Offer</a></p>
						 <p>Invest in a premium domain<br> name to be your brand.</p>
					</div>
				</div>
				<div class="col-md-4 text-center">
					<div class="cbox cbox2 br-h2">
						<h2>PARTNER</h2>
						<h4><?=ucwords($info['domain'])?></h4>
						 <p><a href="<?php echo $base_url?>partner" class="btn btn-success btn-lg btn-wider">Submit Partnership</a></p>
						 <p>Get a premium domain name<br> without the premium price tag.</p>
					</div>
				</div>
				<div class="col-md-4 text-center">
					<div class="cbox qfacts">
						<h4>QUICK FACTS</h4>
						<hr>
						 <table class="table">
						  <tr>
							<td><b>Length</b></td>
							<td><? echo strlen($info['domain'])?> Characters</td>
						  </tr>
						  <tr>
							<td><b>Rating</b></td>
							<td><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></td>
						  </tr>
						  <tr>
							<td><!--<b>Category</b>--></td>
							<td><!--<a href="javascript:;">Education</a>--></td>
						  </tr>
						</table>
					</div>
				</div>
			</div> 
			<div class="row">
				<div class="col-md-12">
					<div class="cbox">
						<h3 class="text-center">How buying and partner with domain names works</h3><br>
							<div class="col-md-4 howorks">
								<div class="row">
									<div class="col-md-1">
										<span class="badge">1</span>
									</div>
									<div class="col-md-11">
										<h4>Make An Offer</h4>
										<p>Find a domain and decide to buy or rent it. Submit your best offer for the owner's consideration. </p>
										<!--<a href="#">Learn More</a>-->
									</div>
								</div>
							</div>
							<div class="col-md-4 howorks">
								<div class="row">
									<div class="col-md-1">
										<span class="badge">2</span>
									</div>
									<div class="col-md-11">
										<h4>Negotiate the price</h4>
										<p>Your offer may be accepted, countered or declined. Negotiations can take as little as one day or up to a few weeks. </p>
										<!--<a href="#">Learn More</a>-->
									</div>
								</div>
							</div>
							<div class="col-md-4 howorks">
								<div class="row">
									<div class="col-md-1">
										<span class="badge">3</span>
									</div>
									<div class="col-md-11">
										<h4>Make a deal</h4>
										<p>Once you have agreed on the price, Mark will facilitate the contract, payment and transfer or use of the domain name. </p>
										<!--<a href="#">Learn More</a>-->
									</div>
								</div>
							</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<? include('footer.php'); ?>