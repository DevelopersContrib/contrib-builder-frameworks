<? include_once('header.php');
?>



<script>
    /*$(document).ready(function(){
        $(window).resize(function() {
            $('.main-container-content').height($(window).height() - 201);
        });

        $(window).trigger('resize');
    });*/
    /*$(document).ready(function() {
        function setHeight() {
            windowHeight = $(window).innerHeight();
            windowFinalHeight = windowHeight - 853;
            $('.main-container-content').css('min-height', windowFinalHeight);
        };
        setHeight();

        $(window).resize(function() {
            setHeight();
        });
    });*/
</script>
<style>
    <?php if ($attr['background_image'] != "" ) {
        /*if(strpos($attr['background_image'],'cdn.vnoc') < -1) {
            $pos = strrpos($attr['background_image'],'/');
            $bg = "https://cdn.vnoc.com/background".substr($attr['background_image'],$pos);
        } else {
            $bg = $attr['background_image'];
        }*/

        if(strpos($attr['background_image'],'https') === FALSE){
            $bg = str_replace('http','https',$attr['background_image']);
        }else{
            $bg = $attr['background_image'];
        } 
    }?>     
    .main-container-content{
        position: relative;
        /* background-image: url('<?php //echo $bg ?>'); */
        background-image: url('https://cdn.vnoc.com/framework/buyandsell/contrib-background.jpg');
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
        margin-top: -20px;
        padding-top: 100px;
        padding-bottom: 200px;
        min-height: 100vh;
        overflow: hidden;
    }
    .main-container-content:before,.main-container-content:after{
        content: "";
        display: table;
    }
    .main-container-content:after{
        clear: both;
    }
    .main-container-content .jumbotron{
        background-color: transparent;
        color: #fff;
    }
    .footer{
        margin-top: auto;
    }
    .text-overlay-white {
        background-color: rgba(3, 38, 51, 0.7);
        /* background-image: url("https://s3.amazonaws.com/assets.zipsite.net/images/jayson/contrib/bg/overlay-dot-min.png"); */
        bottom: 0;
        left: 0;
        position: absolute;
        right: 0;
        top: 0;
    }
    .section {
        background: #fafafa;
        border-top: 1px solid #ccc;
        padding-bottom: 10px;
    }
    .section-2{
        background-color: #ffffff;
        padding-top: 100px;
        padding-bottom: 100px;
        color: #222222;
    }

    .section-3{
        background-color: #F6F1F1;
        padding-top: 100px;
        padding-bottom: 100px;
        color: #000;
    }

    .section-3 h1{
         font-weight: 700;
         line-height: 45px;
           color: #38464F;
            margin: 0;
            padding: 0;
            text-transform: uppercase;
    }
    .icon-circle-bs{
        background-color: #fafafa;
        border-radius: 50%;
        display: inline-block;
        padding-bottom: 25px;
        padding-top: 25px;
        width: 100px;
        box-shadow: 0 0 16px 1px rgba(0,0,0,.20);
    }

    /* carousel css here */

    .wrap-marketplace-box-item {
        background-color: #fff;
        border-radius: 2px;
        /* border-top: 1px solid #d9d9d9;
        box-shadow: 0 1px 0 1px #d9d9d9; */
        display: block;
        padding: 15px;
        text-align: center;
        word-wrap: break-word;
        color: #000;
        text-shadow: none;
        margin-bottom: 25px;
    }
    /* Logo Found */
    .wmbi-img-logo {
        display: block;
        margin-bottom: 15px;
    }
    .wmbi-img-logo img {
        display: inline-block;
        max-height: 60px;
    }
    /* Title Brand */
    .wmbi-ttle {
        background-color: #f5f5f5;
        color: #2e9f3e;
        font-size: 1.3em;
        font-weight: bold;
        padding: 10px 5px;
    }
    .marg-m-ttlTop {
        margin-top: 0;
    }
    .p-marg-btm {
        margin-bottom: 0;
    }
    .ul-wmbi-zero li {
        padding: 0;
    }
    .ul-wmbi-zero li .btn{
        margin: 0;
    }
    /* Carousel Custom Brands */
    #brandsCarousel .owl-item{
        padding:15px;
    }
    #brandsCarousel .owl-prev::before,#brandsCarousel .owl-next::before{
        background-color: #e1e1e1;
    }
     /* ===================================
        Owl carousel
    ====================================== */

    .owl-carousel { overflow: hidden; }
    .owl-buttons { position: static; }
    .owl-prev, .owl-next { color: #111; display: block; font-size: 16px; height: 105px; line-height: 105px; margin-top:-35px; opacity: 0; position: absolute; text-align: center; top: 50%; width: 105px; z-index: 6; }
    .owl-prev {left: -70px;}
    .owl-next {right: -70px;}
    .owl-prev:before, .owl-next:before { background-color:#fff; border-radius:2px; box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1); content: ""; display: block; height: 66%; left: 0; position: absolute; width: 66%; }
    .owl-next:before { left: auto; right: 0; }
    .owl-prev .fa, .owl-next .fa {color: #000; font-size: 24px; position: relative; top: -15%;}
    .owl-prev .fa{ right: 4%}
    .owl-next .fa { left: 4%;}
    .owl-carousel:hover .owl-prev {left: -35px; opacity: 1; }
    .owl-carousel:hover .owl-next { opacity: 1; right: -35px; }
    .owl-pagination { bottom: 30px; display: none; left: 0; position: absolute; text-align: center; width: 100%; z-index: 100 !important; }
    .owl-page { display: inline-block; padding: 6px 5px; }
    .owl-page span { background: none repeat scroll 0 0 rgba(255, 255, 255, 0.7); border-radius: 4px; box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1); display: block; height: 7px; transition: all 0.27s cubic-bezier(0, 0, 0.58, 1) 0s; width: 7px; }
    .owl-page:hover span { background: none repeat scroll 0 0 rgba(255, 255, 255, 1); }
    .owl-page.active span { background: none repeat scroll 0 0 transparent; border: 1px solid rgba(255, 255, 255, 0.8); transform: scale(1.33333); }
    .owl-bg-img { background-position: center center; background-repeat: no-repeat; background-size: cover; display: block; overflow: hidden; position: relative; width: 100%; }
    .owl-subtitle { font-size: 14px; letter-spacing: 10px; text-transform: uppercase; font-weight: 400; line-height: 80px; display:block}
    .owl-title { font-size: 35px; font-weight: 600; text-transform: uppercase; display: block; letter-spacing: 7px;}
    .owl-title-big { background: rgba(0, 0, 0, 0.5); display: inline-block; font-size: 25px; font-weight: 600; letter-spacing: 7px; line-height: 40px; padding: 35px 50px; text-transform: uppercase; width: 60% }
    .dark-pagination .owl-page span { background: none repeat scroll 0 0 rgba(0, 0, 0, 1); box-shadow: none }
    .dark-pagination .owl-page.active span {background:transparent; border: 1px solid rgba(0, 0, 0, 1); }
    .dark-pagination .owl-prev, .owl-next { opacity: 1; }
    .dark-pagination .owl-next:before { left: auto; right: 0; }
    .dark-pagination .owl-prev {left: -35px; opacity: 1; }
    .dark-pagination .owl-next { opacity: 1; right: -35px; }
    .light-pagination .owl-page.active span {background: transparent; border: 1px solid rgba(255, 255, 255, 1); }
    .text-how {
        font-size: 40px;
        font-weight: 600;
    }


    #contentVideo{
	    position: absolute;
	    top: 0;
	    left: 0;
	    right: 0;
	    bottom: 0;
	    width: 100%;
	    z-index: 1;
    }
    .text-overlay-white{
    	z-index: 2;
    }
    .video-content-main{
    	z-index: 3;
    	position: relative;
    }
</style>

<div class="main-container-content">
    <div class="text-overlay-white"></div>
    <video id="contentVideo" loop muted autoplay poster="https://cdn.vnoc.com/framework/buyandsell/contrib-background.jpg">
        <source src="https://cdn.vnoc.com/framework/buyandsell/contrib-background.mp4" type="video/mp4" />
        <source src="https://cdn.vnoc.com/framework/buyandsell/contrib-background.ogg" type="video/ogg" />
        <source src="https://cdn.vnoc.com/framework/buyandsell/contrib-background.webm" type="video/webm" />
    </video>
    <div class="video-content-main">
	    <? include_once('header-content.php'); ?>
	    <div class="container">
	        <div class="row">
	            <div class="col-md-10 col-md-offset-1">
	                <div class="row">
	                    <div class="col-md-4 text-center">
	                        <div class="cbox cbox2 br-h2">
	                            <h2>BUY/LEASE</h2>
	                            <h4><?=ucwords($info['domain'])?></h4>
	                             <p><a href="/buy/index/?domain=<?php echo $_SESSION['domain']?>" class="btn btn-success btn-lg btn-wider">Make An Offer</a></p>
	                             <p>Invest in a premium domain<br> today.</p>
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="cbox cbox2 br-h2">
	                            <h2>PARTNER</h2>
	                            <h4><?=ucwords($info['domain'])?></h4>
	                             <p><a href="/partner/index/?domain=<?php echo $_SESSION['domain']?>" class="btn btn-success btn-lg btn-wider">Submit Partnership</a></p>
	                             <p>Access this premium domain name<br> without the premium price tag.</p>
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="cbox cbox2 br-h2" style="padding-right: 15px;padding-left: 15px;">
	                            <h2>JOIN</h2>
	                            <h4><?=ucwords($info['domain'])?> Community</h4>
	                            <p>
	                                <a href="https://www.contrib.com/signup/firststep?domain=<?=ucwords($_SESSION['domain'])?>" class="btn btn-success btn-lg btn-wider">JOIN NOW</a>
	                            </p>
	                            <p>
	                                Join our community of 150,000 <?=ucwords($_SESSION['domain'])?> members over at Contrib.
	                            </p>
	                        </div>
	                    </div>
	                </div> 
	            </div>
	        </div>
	    </div>
    </div>
</div>
<div class="section-2 how-buy-container">
    <div class="container">
        <div class="row"></div>
            <div class="col-md-10 col-md-offset-1">
                <div class="row">
                    <div class="col-md-12">
                        <div class="">
                            <h1 class="text-center text-how">How Buying or Partnering with <?php echo ucwords($info['domain']); ?> Works</h1>
                            <br /><br /><br />
                            <div class="col-md-4 text-center">
                                <img class="how-icon" src="https://cdn.vnoc.com/icons/icon-diamond.png" alt="Make an offer">
                                <h3>Make An Offer</h3>
                                <p>Find a domain and decide to buy,lease or rent it. Submit your best offer for the owner's consideration. </p>
                                <!--<a href="#">Learn More</a>-->
                            </div>
                            <div class="col-md-4 text-center">
                                <img class="how-icon" src="https://cdn.vnoc.com/icons/icon-briefcase.png" alt="Negotiate the price">
                                <h3>Negotiate the price</h3>
                                <p>Your offer may be accepted, countered or declined. Negotiations can take as little as one day or up to a few weeks. </p>
                                <!--<a href="#">Learn More</a>-->
                            </div>
                            <div class="col-md-4 text-center">
                                <img class="how-icon" src="https://cdn.vnoc.com/icons/icon-handshake.png" alt="Make a deal">
                                <h3>Make a deal</h3>
                                <p>Once you have agreed on the price, We will facilitate the contract, payment and transfer or use of the domain name. </p>
                                <!--<a href="#">Learn More</a>-->
                            </div>
                            <div class="clearfix"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
</div>
<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                
            </div>
            <div class="col-md-12 text-center">
            
            <h2><?=ucwords($info['domain'])?> Partners</h2>
                
                <div class="col-md-4">
                            <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                        <!-- Rectangle Box -->
                        <ins class="adsbygoogle"
                             style="display:inline-block;width:300px;height:250px"
                             data-ad-client="ca-pub-0390821261465417"
                             data-ad-slot="1688859506"></ins>
                        <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                        </script>
                                            
                        
                </div>
                <div class="col-md-4">
                            <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                        <!-- Rectangle Box -->
                        <ins class="adsbygoogle"
                             style="display:inline-block;width:300px;height:250px"
                             data-ad-client="ca-pub-0390821261465417"
                             data-ad-slot="1688859506"></ins>
                        <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                        </script>
                                            
                        
                </div>
                <div class="col-md-4">
                            <script src="https://tools.contrib.com/cwidget?d=<?=ucwords($info['domain'])?>&p=ur&c=lc"></script>
                                            
                        
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section-3">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1>Our Top Brands</h1>
                <div class="col-md-12">
                    <div id="brandsCarousel" class="owl-carousel">
                    <?php foreach($featuredsites as $featuredsites): ?>
                        <?php if (!empty($featuredsites['domain_name'])): ?>
                                <div class="wrap-marketplace-box-item">
                                <a class="wmbi-img-logo" href="https://<?php echo $featuredsites['domain_name']; ?>">
                                    <?php if(!empty($featuredsites['logo'])):?>
                                    <?php 
                                        if(strpos($featuredsites['logo'],'https') === FALSE){
                                            $logo = str_replace('http','https',$featuredsites['logo']);
                                        }else{
                                            $logo = $featuredsites['logo'];
                                        }
                                    ?>
                                        <img src="<?php echo $logo; ?>" class="img-responsive" alt="<?php echo $featuredsites['domain_name']; ?>" title="<?php echo $featuredsites['domain_name']; ?>">
                                    <?php else: ?>
                                        <img src="https://cdn.vnoc.com/logos/logo-contrib-brand2.png" class="img-responsive">
                                    <?php endif; ?>
                                </a>
                                <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
                                    <?php echo $featuredsites['domain_name']; ?>
                                </h3>
                                <p class="p-marg-btm">
                                    Join our exclusive community of like minded people on 
                                </p>
                                <p>
                                    <a target="_blank" href="https://<?php echo $featuredsites['domain_name']; ?>"><?php echo $featuredsites['domain_name']; ?></a>
                                </p>
                                <ul class="list-inline ul-wmbi-zero">
                                    <li>
                                        <a class="btn btn-success btn-lg" target="_blank" href="https://<?php echo $featuredsites['domain_name']; ?>">Visit</a>
                                    </li>
                                    <li>
                                        <a class="btn btn-success btn-lg" target="_blank" href="https://contrib.com/brand/details/<?php echo $featuredsites['domain_name']; ?>">Details</a>
                                    </li>
                                </ul>
                            </div>
                        <?php endif ?>
                    <?php endforeach; ?>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo $base_url?>js/owl.carousel.js"></script>
<script src="<?php echo $base_url?>js/owl.carousel.min.js"></script>
<script>
    jQuery(document).ready(function(){
        jQuery("#brandsCarousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            items: 3,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        });
    }); 
</script>
<? include('footer.php'); ?>