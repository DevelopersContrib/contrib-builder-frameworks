<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>


	<div class="container buyrent-page">
	<div class="row">
	  <div class="col-md-8 col-md-offset-2">
		<div class="well verify-box aboutus">
			<h2 class="text-center">About Us</h2>
			<p>Contrib is a transparent Platform-as-a-Service specifically designed to utilize a
				sustainable and socially responsible business network model that turns valuable domain
				assets into successful operating companies.</p>
			<h3 class="text-center vmsion">Our Vision</h3>
			<p>We envision people around the world with complementary skills, passion, time and resources coworking online building sustainable electronic businesses, part-time. Our focus will continue to support Contrib members with a system to grow and learn new skills, help build a company from scratch using the worlds best assets, and to contribute with other great, like-minded and talented people. </p>
			<h3 class="text-center vmsion">Our Story</h3>
			<p>Contrib was created out of necessity to build, manage and monetize thousands of premium Urls acquired over the 18 years of its parent company, GV, llc. Premium assets such as Streaming.com, Staffing.com, Linked and others were losing opportunity value so we build a model and technology to leverage the opportunities and offer it to our visitors. </p>
		</div>
	  </div>
	</div>
</div> 


<? include('footer.php'); ?>