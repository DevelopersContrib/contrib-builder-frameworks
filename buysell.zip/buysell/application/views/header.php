<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="canonical" href="https://<?=$info['domain']?>/<?=basename($_SERVER['PHP_SELF'])?>/" />
		<link rel="icon" type="image/icon" href="favicon.ico">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta name="robots" content="index, follow" />
    <?php if($info['title'] == ''): ?>
    <title><?=ucfirst($info['domain'])?> - <?=$metatitle?></title>
    <?php else: ?>
		<title><?=ucfirst($info['domain'])?> - <?=$metatitle?></title>
    <?php endif; ?>
		<meta name="generator" content="VNOC Site Generator - Buy, Sale Lease Framework" />
		<meta name="description" content="<?=$info['domain']?> - <?=$info['description']?>" />
<meta name="keywords" content="<?=$info['domain']?>" />
<meta name="author" content="VNOC" />
<meta name="copyright" content="<?=$info['domain']?>" />
<meta name="application-name" content="Powered by VNOC" />
<meta property="og:title" content="<?=$info['domain']?> - <?=$info['description']?>" />
<meta property="og:type" content="website" />
<meta property="og:image" content="" />
<meta property="og:url" content="https://<?=$info['domain']?>/<?=basename($_SERVER['PHP_SELF'])?>" />
<meta property="og:description" content="<?=$info['description']?>" />


		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="title" content="<?=$info['title']?> - Buy or Lease this domain today!" />
		<meta name="description" content="<?=ucwords($info['domain'])?> - <?=$info['description']?>" />
    <meta name="keywords" content="<? echo $info['keywords']; ?>" />
    <meta name="author" content="<?php echo $info['domain']; ?>">	
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<script srce="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="/css/styles.css" rel="stylesheet">
      <!-- owl carousel -->
    <link rel="stylesheet" href="/css/owl.carousel.css" />
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

      ga('create', '<?=$info['account_ga'] ?>', '<?=$info['domain'] ?>');
      ga('send', 'pageview');

    </script>
    <script data-ad-client="ca-pub-0390821261465417" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    
	</head>
<body>
<div class="navbar navbar-inverse">
    <div class="container">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>      
      <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav text-center">
            <li><a href="<? echo $base_url?>" class="text-uppercase">Home</a></li>
            <li><a href="https://www.contrib.com/brand/details/<?=ucwords($_SESSION["domain"])?>" class="text-uppercase">Contribute</a></li>
            <li><a href="https://www.contrib.com/signup/firststep?domain=<?=ucwords($_SESSION["domain"])?>" class="text-uppercase">JOIN</a></li>
		        <li><a href="https://www.contrib.com" class="text-uppercase">LOGIN</a></li>
            <!--<li><a href="<? //echo $base_url?>home/contact">Contact</a></li>-->
          </ul>
        </div><!--/.nav-collapse -->
    </div><!-- /.container -->
</div><!-- /.navbar -->
  
<!-- HEADER 
=================================-->