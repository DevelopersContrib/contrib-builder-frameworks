<? include_once('includes/header.php'); ?>

<style>
.left-inner-addon {
    position: relative;
}
.left-inner-addon input {
    padding-left: 22px;    
}
.left-inner-addon i {
    position: absolute;
	padding: 10px 12px;
	pointer-events: none;
	color: #000;
}
.well {
    min-height: 20px;
    padding: 20px 50px 40px 50px;
    margin-bottom: 20px;
	margin-top: 20px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
    box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
}
.contrib-box-in {
	background:#fafafa;
	padding: 20px 10px 10px 10px;
	border:1px solid #dedede;
	border-radius:4px;
	margin:20px 0px 20px 0px;
}

.loading-div-128{ position: absolute; top: 0; left: 0; bottom: 0; right: 0; background-image: url('https://s3.amazonaws.com/assets.zipsite.net/images/jayson/gif-loading/vnoc-preloader128x128.gif'); background-repeat: no-repeat; background-position: center; background-color: #fff;}
</style>

<div class="section-content container">    
	<div class="col-md-12 text-center">
					<h1 class="bg-ttle fnt-300">
						<?=ucwords($info['domain'])?>
					</h1>
					<h3 class="sm-ttle-sub fnt-400">
						You can either <span class="text-blue">BUY</span> or <span class="text-blue">PARTNER</span> with this domain.
					</h3>
					<p class="desc-p">
						If you're interested in this domain, contact us to check for the availability <br> for partnership, ownership or other development opportunities via Contrib. 
					</p>
					<br/>
					<br/>
					
				</div>
    <div class="row" id="showform">
        <div class="col-md-12">
			<div class="cbox cbox3">
				<div class="col-md-5 buyrent-form">
					<h2 class="text-center">Purchase <?=ucwords($info['domain'])?> today</h2>
					<p class="text-center">Create your Profile to make an offer</p>
				
					   		<div class="form-group ">
								<div id="amount-container" class="fg-error-container">
									<span class="meta-aes">*</span>	
									<input type="text" id="amount" class="form-control" placeholder="Amount">
									<span id="amount-error" class="error-text">Amount is required</span>
								</div>
							</div>
							<div class="form-group">
								<div id="fname-container" class="fg-error-container">
									<span class="meta-aes">*</span>	
									<input type="text" id="fname" class="form-control" placeholder="First Name">
									<span id="fname-error" class="error-text">first name is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="lname-container" class="fg-error-container">
									<span class="meta-aes">*</span>	
									<input type="text" id="lname" class="form-control" placeholder="Last Name">
									<span id="lname-error" class="error-text">last name is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="email-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<input type="text" id="email" class="form-control" placeholder="Email">
									<span id="email-error" class="error-text">Email is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="password-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<input type="password" id="password" class="form-control" placeholder="Password">
									<span id="password-error" class="error-text">password is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="cpassword-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<input type="password" id="cpassword" class="form-control" placeholder="Confirm Password">
									<span id="cpassword-error" class="error-text">confirm password is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div class="fg-error-container">
									<span class="meta-aes">*</span>
									<select name="country" id="country" class="form-control">
										<option value="1" name="United States">United States</option>
										 <? foreach ($countries['data'] as $country){ ?>
										  <option value="<?php echo $country['id']?>" name="<? echo $country['name']?>"><?php echo $country['name']?></option>
										 <?}?>
									</select>
									<span class="error-text">Choose Country</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="phoneno-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<input type="text" id="phoneno" class="form-control" placeholder="Phone">
									<span id="phoneno-error" class="error-text">Phone is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="message-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<textarea rows="5" id="message" class="form-control" placeholder="Message..."></textarea>
									<span id="message-error" class="error-text">message is required</span>
								</div>
							</div>
							<div class="form-group">
								<a href="javascript:;" id="nextpageoffer" class="btn btn-block btn-info btn-lg">
									Next
								</a>
							</div>	
							<div class="form-group">
								<a href="/partner" class="text-link-white">
									Or you can partner with this domain!
								</a>
							</div>
							<div id="loader" class="loading-div-128 hide"></div>
				</div>
				<div class="col-md-7 strategy">
					<h2>A great domain name is a great asset</h2>
					<h4>Invest in a great domain name as part of your brand strategy and take your business to the next level</h4>
					<ul class="list-group">
					  <li class="list-group-item"><i class="fa fa-check"></i>Secure your online identity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Enhance your brand equity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Boost your credibility</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Improve conversion rates</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
    </div> 
	<div class="row" id="showform2"></div>
	<div class="container buyrent-page" id="success_page" style="display:none">
	<div class="row">
	  <div class="col-md-8 col-md-offset-2">
		<div class="well verify-box aboutus">
			<img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" style="width:250px; margin:0px auto;">
			<h2 class="text-center">for submitting your offer.</h2>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> You will be receiving three (3)-emails from Contrib.</h4>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> Please check your spam box for safe measure.</h4>
			<div class="clearfix"><br></div>
			<div class="contrib-box-o">
				<p class="text-center">Contrib is our contribution platform and it allows us to get people to help contribute, make offer or partner with premium world class brands. You could check your Offer submission in your <br><b>"My Offers Contrib App"</b>.</p>
				<h4 class="text-center"><i class="fa fa-envelope"></i> Please check your email for your Contrib access.</h4>
			</div>
			<div class="clearfix"><br></div>
			<div class="row">
				<div class="contrib-box-in">
					<h2 class="text-center">How It Works?</h2>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-search"></i><br>Step 1</h3>
						<h4>Browse the Marketplace</h4>
						<p>Browse the marketplace and search for sites to submit offers. </p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-file-text-o"></i><br>Step 2</h3>
						<h4>Submit an Offer</h4>
						<p>Click on sumbit offer and fill up the form.</p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-desktop"></i><br>Step 3</h3>
						<h4>View Offers</h4>
						<p>View all your offer applications that you have submitted to here. </p>
					</div>
					<div class="clearfix"><br></div>
				</div>
			</div>
		</div>		
	  </div>
	</div>
	<div class="push"></div>
	</div> 
	<div class="col-md-12">
					<br />
					<hr />
					<div class="row">
						<div class="col-xs-6">
							<div class="box-padd-steps">
								<div class="row">
									<div class="col-md-8 text-right">
										<h4>
											Select Your Domain
										</h4>
										<p>
											Search Ecorp’s database for the ultimate domain name for your business, project or brand.
										</p>
									</div>
									<div class="col-md-4">
										<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/domain.jpg" alt="" class="img-responsive img-circle">
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-6">
							<div class="box-padd-steps">
								<div class="row">
									<div class="col-md-4">
										<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/offer.jpg" alt="" class="img-responsive img-circle">
									</div>
									<div class="col-md-8 text-left">
										<h4>
											Submit your best offer
										</h4>
										<p>
											We’ll let you know if it's too low for consideration.
										</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-6">
							<div class="box-padd-steps">
								<div class="row">
									<div class="col-md-8 text-right">
										<h4>
											Agree to the terms
										</h4>
										<p>
											Once the price is decided, agree to the terms of the domain name sales agreement.
										</p>
									</div>
									<div class="col-md-4">
										<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/agreement.jpg" alt="" class="img-responsive img-circle">
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-6">
							<div class="box-padd-steps">
								<div class="row">
									<div class="col-md-4">
										<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/transfer.jpg" alt="" class="img-responsive img-circle">
									</div>
									<div class="col-md-8 text-left">
										<h4>
											Launch you website
										</h4>
										<p>
											Once payment has been confirmed the owner will transfer the domain to you.
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
	</div>
</div>
<script>

	var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var numeric = /^[0-9]+$/;

	jQuery('#phoneno').blur(function(){
		if (jQuery('#phoneno').val() === '') {
			jQuery('#phoneno-container').addClass('has-error-text');
			jQuery('#phoneno-error').html('Phone No. is required');
		}else if(!numeric.test(jQuery('#phoneno').val())){	
			jQuery('#phoneno-container').addClass('has-error-text');
			jQuery('#phoneno-error').html('Phone No. must be numeric');
		}else{
			jQuery('#phoneno-container').removeClass('has-error-text');
		}
	});

	jQuery('#country').blur(function(){
		if (jQuery('#country').val() === '') {
			jQuery('#country-container').addClass('has-error-text');
		}else{
			jQuery('#country-container').removeClass('has-error-text');
		}
	});

	jQuery('#amount').blur(function(){
		if (jQuery('#amount').val() === '') {
			jQuery('#amount-container').addClass('has-error-text');
			jQuery('#amount-error').html('amount is required');
		}else if(!numeric.test(jQuery('#amount').val())){
			jQuery('#amount-container').addClass('has-error-text');
			jQuery('#amount-error').html('amount must be numeric');
		}else if(jQuery('#amount').val() < 10000){
			jQuery('#amount-container').addClass('has-error-text');
			jQuery('#amount-error').html('amount must be atleast 10000');
		}else{
			jQuery('#amount-container').removeClass('has-error-text');
		}
	});

	jQuery('#fname').blur(function(){
		if (jQuery('#fname').val() === '') {
			jQuery('#fname-container').addClass('has-error-text');
		}else{
			jQuery('#fname-container').removeClass('has-error-text');
		}
	});

	jQuery('#lname').blur(function(){
		if (jQuery('#lname').val() === '') {
			jQuery('#lname-container').addClass('has-error-text');
		}else{
			jQuery('#lname-container').removeClass('has-error-text');
		}
	});

	jQuery('#email').blur(function(){
		if (jQuery('#email').val() === '') {
			jQuery('#email-container').addClass('has-error-text');
			jQuery('#email-error').html('email is required');
		}else if(!emailfilter.test(jQuery('#email').val())){
			jQuery('#email-container').addClass('has-error-text');
			jQuery('#email-error').html('email is invalid');
		}
		else{
			jQuery('#email-container').removeClass('has-error-text');
		}
	});

	jQuery('#password').blur(function(){
		if (jQuery('#password').val() === '') {
			jQuery('#password-error').html('password is required');
			jQuery('#password-container').addClass('has-error-text');
		}else if(jQuery('#password').val().length < 5){
			jQuery('#password-container').addClass('has-error-text');
			jQuery('#password-error').html('password should be atleast 5 characters');
		}else{
			jQuery('#password-container').removeClass('has-error-text');
		}
	});

	jQuery('#cpassword').blur(function(){
		if (jQuery('#cpassword').val() === '') {
			jQuery('#cpassword-container').addClass('has-error-text');
		}else if(jQuery('#password').val() != jQuery('#cpassword').val()){
			jQuery('#cpassword-container').addClass('has-error-text');
			jQuery('#cpassword-error').html('Password and confirm password are not match');
		}else{
			jQuery('#cpassword-container').removeClass('has-error-text');
		}
	});

	jQuery('#message').blur(function(){
		if (jQuery('#message').val() === '') {
			jQuery('#message-container').addClass('has-error-text');
		}else{
			jQuery('#message-container').removeClass('has-error-text');
		}
	});

	$('#nextpageoffer').click(function(){
		var myphone = $('#phoneno').val();
		var country_id = $('#country').val();
		var country = $("#country :selected").text();
		var amount = $('#amount').val();
		var fname = $('#fname').val();
		var lname = $('#lname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var cpassword = $('#cpassword').val();
		var message = $('#message').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var numeric = /^[0-9]+$/;
		var domain = '<?php echo $info['domain']?>';
		
		if(amount == ""){
			errormessage('#amount-container','#amount-error','Amount is required');
		}else if(amount < 10000){
			errormessage('#amount-container','#amount-error','Amount is must atleast 10000');
		}else if(fname == ""){
			errormessage('#fname-container','#fname-error','firstname is required');
		}else if(email == ""){
			errormessage('#email-container','#email-error','email is required');
		}else if(password == ""){
			errormessage('#password-container','#password-error','password is required');
		}else if(password.length < 5){
			errormessage('#password-container','#password-error','password should be atleast 5 characters');
		}else if(cpassword != password){
			errormessage('#cpassword-container','#cpassword-error','password and confirm password are not match');
		}else if(message == ""){
			errormessage('#message-container','#message-error','message is required');	
		}else if(!emailfilter.test(email)){
			errormessage('#email-container','#email-error','email is invalid');	
		}else if(!numeric.test(amount)){
			errormessage('#amount-container','#amount-error','Amount must be numeric');	
		}else if(lname == ''){
			errormessage('#lname-container','#lname-error','lastname is required');	
		}else if(myphone == '') {
			errormessage('#phoneno-container','#phoneno-error','phone is required');	
		}else if (!numeric.test(myphone)) {
			errormessage('#phoneno-container','#phoneno-error','phone must be numeric');	
		}else{

			jQuery('#loader').removeClass('hide');
			var formdata = {
				amount:amount,
				fname:fname,
				password:password,
				message:message,
				email:email,
				lname:lname,
				country_id:country_id,
				country:country,
				myphone:myphone
			}
			$.post("http://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){
				if(data.status){
					$.post('http://www.contrib.com/forms/save_offer_for_existing_account',{
								domain:domain,
								email:email,
								message:message,
								amount:amount						   
						   },function(){
							   sendOfferEmail(fname,email,domain)
							   $('#success_page').fadeIn();
							   $('#easysteps').fadeOut()
							   $('#reciever_email').text(email);
							   $('#showform').hide();
							 });
				}else{
						$.post('<?echo $base_url?>buy/buynext',{
							amount:amount,
							fname:fname,
							password:password,
							message:message,
							email:email,
							lname:lname,
							country_id:country_id,
							country:country,
							myphone:myphone
						},function(res){
							$('#showform2').html(res);
							$('nextform').hide();
							$('#submit_offer_not_member').trigger('click');
						});
				}
			});
		}
	})
	
	$('#resend_email').click(function(){
		
		var amount = $('#amount').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var domain = '<?php echo $info['domain']?>';
		
		if(amount != '' || email != '' || password != '' || message != ''){
			$.post('http://www.contrib.com/forms/save_offer_for_existing_account',{
				domain:domain,
				email:email,
				message:message,
				amount:amount						   
		   },function(){
			   $('#reciever_email').text(email);
			   $('#showform').hide();
			   $('#success_page').fadeIn();
			   $('#easysteps').fadeOut()
			});
			
		}else{
			
			alert('good skill, but we already saw this comming');
		}
	})

	function errormessage(container,error,html)
	{
		jQuery(container).addClass('has-error-text');
		jQuery(error).html(html);
	}
</script>

<script>
	
	$(document).ready(function(){
	    $('input[rel="txtTooltip"]').tooltip();
	});
	
	$(document).ready(function(){
	    $('textarea[rel="txtTooltip"]').tooltip();
	});

	function sendOfferEmail(firstname,email,domain){
		$.post(
			'http://www.contrib.com/forms/autoresponderEmail',
			{ firstname:firstname,email:email,domain:domain,template_name:'Offer' },
			function(response){
				console.log(response.result);
			}
		);
	}
</script>

<? include('footer.php'); ?>