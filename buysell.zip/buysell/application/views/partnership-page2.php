<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>


<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="cbox cbox3">
				<div class="col-md-8 buyrent-form">
					<h2 class="text-center">Complete partnership</h2>
					<p class="text-center">Please complete your profile in order to partner with [domain]*</p>
					<form>
						<div class="form-group">
							<div class="col-md-6">
							<input type="text" class="form-control" id="" placeholder="Andre">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="" placeholder="State/Province">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="" placeholder="Company">
							</div>
							<div class="col-md-6">
							<select class="form-control">
							  <option>Philippines</option>
							  <option>United States</option>
							</select>
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="" placeholder="Phone #">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="" placeholder="Postal/Zipcode">
							</div>	
							<div class="col-md-6">
							<input type="text" class="form-control" id="" placeholder="Street Address">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="" placeholder="City">
							</div>
							<div class="col-md-12">
							<p>By clicking the button below, I understand that the offer that I am about to submit is binding and I agree to Ecorp 
							<a href="">domain name sales and rental terms.</a></p>
							</div>
						 </div>
						  <div class="col-md-12"><a href="<? echo $base_url?>buy/verify" class="btn btn-info btn-block">Submit Partnership</a></div>	
						  <div class="col-md-12">*The domain name without content is being made available for sale or rent by its owner through Ecorp.</div>
					</form>
					  
				</div>
				<div class="col-md-4 strategy">
					<h3>Next Steps</h3>
					<ul class="list-group">
					  <li class="list-group-item"><b>1.&nbsp;Verify your email</b><br>Before we send your offer to the domain owner, we need to verify your email address. </li>
					   <li class="list-group-item"><b>2.&nbsp;Negotiate the deal</b><br>If the domain owner likes your offer, it will be accepted immediately. If not, you will receive a counter-offer or you may be asked to increase yours. </li>
					    <li class="list-group-item"><b>3.&nbsp;Launch Your Partnership</b><br>As soon as you come to an agreement with the domain owner, and admin has secured the funds, you can start using the domain name.  </li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
    </div> 
</div>


<? include('footer.php'); ?>