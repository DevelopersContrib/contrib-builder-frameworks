<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>
<style>
.left-inner-addon {
    position: relative;
}
.left-inner-addon input {
    padding-left: 22px;    
}
.left-inner-addon i {
    position: absolute;
	padding: 10px 12px;
	pointer-events: none;
	color: #000;
}
.well {
    min-height: 20px;
    padding: 20px 50px 40px 50px;
    margin-bottom: 20px;
	margin-top: 20px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
    box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
}
.contrib-box-in {
	background:#fafafa;
	padding: 20px 10px 10px 10px;
	border:1px solid #dedede;
	border-radius:4px;
	margin:20px 0px 20px 0px;
}
</style>
<div class="container">    
    <div class="row" id="showform">
        <div class="col-md-12">
			<div class="cbox cbox3">
				<div class="col-md-5 buyrent-form">
					<h2 class="text-center">Purchase <?=ucwords($info['domain'])?> today</h2>
					<p class="text-center">Create your Profile to make an offer</p>
					<form>
						<div class="form-group">							
							<div class="col-md-12">
								<div class="bp-alert" id="erroralert" style="display:none"></div>
								<div class="left-inner-addon ">
									<i class="fa fa-usd"></i>
									<input type="text" class="form-control" id="amount" placeholder="Amount" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter amount to offer in USD not less than 10000">
								</div>
							</div>
							<div class="col-md-12"><input type="text" class="form-control" id="name" placeholder="First Name" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Firstname"></div>						  
							<div class="col-md-12"><input type="text" class="form-control" id="lname" placeholder="Last Name" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Lastname"></div>						  
							<div class="col-md-12"><input type="text" class="form-control" id="email" placeholder="Email" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email"></div>						  
							<div class="col-md-12"><input type="password" class="form-control" id="password" placeholder="Password" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Password Must More Than 5 Characters"></div>						  
							<div class="col-md-12"><select class="form-control" id="country">
							 		<option value="1" name="United States">United States</option>
								 <? foreach ($countries['data'] as $country){ ?>
									  <option value="<?php echo $country['id']?>" name="<? echo $country['name']?>"><?php echo $country['name']?></option>
								 <?}?>
								</select>
							</div>
							<div class="col-md-12"><input type="text" class="form-control" id="phoneno" placeholder="Phone #" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Phone #"></div>
							<div class="col-md-12"><textarea class="form-control" rows="3" id="message" placeholder="Message" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Your Message Here"></textarea></div>							
						 </div>
						  <div class="col-md-12"><a href="javascript:;" id="nextpageoffer" class="btn btn-info btn-block">Submit Offer Now</a></div>
						   <p class="text-center oryoucan"><a href="<? echo $base_url?>partner">Or you can partner with this domain!</a></p>
					</form>
					  
				</div>
				<div class="col-md-7 strategy">
					<h2>A great domain name is a great asset</h2>
					<h4>Invest in a great domain name as part of your brand strategy and take your business to the next level</h4>
					<ul class="list-group">
					  <li class="list-group-item"><i class="fa fa-check"></i>Secure your online identity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Enhance your brand equity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Boost your credibility</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Improve conversion rates</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
    </div> 
	
	<div class="row" id="showform2"></div>
	
	<div class="container buyrent-page" id="success_page" style="display:none">
	<div class="row">
	  <div class="col-md-8 col-md-offset-2">
		<div class="well verify-box aboutus">
			<img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" style="width:250px; margin:0px auto;">
			<h2 class="text-center">for submitting your offer.</h2>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> You will be receiving three (3)-emails from Contrib.</h4>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> Please check your spam box for safe measure.</h4>
			<div class="clearfix"><br></div>
			<div class="contrib-box-o">
				<p class="text-center">Contrib is our contribution platform and it allows us to get people to help contribute, make offer or partner with premium world class brands. You could check your Offer submission in your <br><b>"My Offers Contrib App"</b>.</p>
				<a href=""><h4 class="text-center"><i class="fa fa-envelope"></i> Please check your email for your Contrib access.</h4></a>
			</div>
			<div class="clearfix"><br></div>
			<div class="row">
				<div class="contrib-box-in">
					<h2 class="text-center">How It Works?</h2>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-search"></i><br>Step 1</h3>
						<h4>Browse the Marketplace</h4>
						<p>Browse the marketplace and search for sites to submit offers. </p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-file-text-o"></i><br>Step 2</h3>
						<h4>Submit an Offer</h4>
						<p>Click on sumbit offer and fill up the form.</p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-desktop"></i><br>Step 3</h3>
						<h4>View Offers</h4>
						<p>View all your offer applications that you have submitted to here. </p>
					</div>
					<div class="clearfix"><br></div>
				</div>
			</div>
		</div>		
	  </div>
	</div>
	<div class="push"></div>
</div> 
	<div class="row" id="easysteps">
		<div class="col-md-12">			
			<h2 class="text-center">Buy a great domain in 4 easy steps! </h2>
			<h3 class="text-center sc-hd">Investing in a great domain name is a smart choice for your organization. </h3>
			<hr>
		</div>
        <div class="col-md-3 text-center brpop">
			<a id="popoverData" class="btn" href="#" data-content="Search Ecorp’s database for the ultimate domain name for your business, project or brand." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-search"></i></h1>
				<h4>Select Your <br>Domain </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData1" class="btn" href="#" data-content="We’ll let you know if it's too low for consideration." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-dollar"></i></h1>
				<h4>Submit Your <br>Best Offer </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData3" class="btn" href="#" data-content="Once the price is decided, agree to the terms of the domain name sales agreement." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-check"></i></h1>
			<h4>Agree <br>To The Terms</h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData5" class="btn" href="#" data-content="Once payment has been confirmed the owner will transfer the domain to you." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-globe"></i></h1>
			<h4>Launch <br>Your Website </h4>
			</a>
		</div>
		<div class="col-md-12 text-center brpop"><br></div>
	</div>
</div>

<script>

	$('#nextpageoffer').click(function(){

		var myphone = $('#phoneno').val();
		var country_id = $('#country').val();
		var country = $("#country :selected").text();
		var amount = $('#amount').val();
		var fname = $('#name').val();
		var lname = $('#lname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var numeric = /^[0-9]+$/;
		var domain = '<?php echo $info['domain']?>';
		
		if(amount == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Account should not be blank</p>');
			$('#amount').focus();
			
		}else if(amount < 10000){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Amount should not be less than $10000</p>');
			$('#amount').focus();
			
		}else if(fname == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >First name should not be blank</p>');
			$('#name').focus();
			
		}else if(email == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >email should not be blank</p>');
			$('#email').focus();
			
		}else if(password == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should not be blank</p>');
			$('#password').focus();
			
		}else if(password.length < 5){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should be more than 5 characters</p>');
			$('#password').focus();

		}else if(message == ""){

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >message should not be blank</p>');
			$('#message').focus();
		
		}else if(!emailfilter.test(email)){

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >invalid email</p>');
			$('#email').focus();

		}else if(!numeric.test(amount)){

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Numbers only</p>');
			$('#amount').focus();
			
		}else if(lname == ''){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Last name should not be blank</p>');
			$('#lname').focus();

		}else if(myphone == '') {
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >phone should not be blank</p>');
			$('#phoneno').focus();

		}else if (!numeric.test(myphone)) {

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Your Phone # must be a Number</p>');
			$('#phoneno').focus();

		}else{

			var formdata = {
				amount:amount,
				fname:fname,
				password:password,
				message:message,
				email:email,
				lname:lname,
				country_id:country_id,
				country:country,
				myphone:myphone
			}

			console.log(formdata);
			$('#nextpageoffer').html('<a href="javascript:;" class="btn btn-info btn-block disabled">Please wait..</a>');
			$.post("http://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){
		
				if(data.status){
					$.post('http://www.contrib.com/forms/save_offer_for_existing_account',{
								domain:domain,
								email:email,
								message:message,
								amount:amount						   
						   },function(){
								 sendOfferEmail(fname,email,domain)
							   $('#reciever_email').text(email);
							   $('#showform').hide();
							   $('#success_page').fadeIn();
							   $('#easysteps').fadeOut()
							 });
							
				}else{
						$.post('<?echo $base_url?>buy/buynext',{
							amount:amount,
							fname:fname,
							password:password,
							message:message,
							email:email,
							lname:lname,
							country_id:country_id,
							country:country,
							myphone:myphone
						},function(res){
							$('#showform2').html(res);
							$('nextform').hide();
							$('#submit_offer_not_member').trigger('click');
						})
				}
			})
		}
		
		
		
	})
	
	$('#resend_email').click(function(){
		
		var amount = $('#amount').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var domain = '<?php echo $info['domain']?>';
		
		if(amount != '' || email != '' || password != '' || message != ''){
			$.post('http://www.contrib.com/forms/save_offer_for_existing_account',{
				domain:domain,
				email:email,
				message:message,
				amount:amount						   
		   },function(){
			   $('#reciever_email').text(email);
			   $('#showform').hide();
			   $('#success_page').fadeIn();
			   $('#easysteps').fadeOut()
			});
			
		}else{
			
			alert('good skill, but we already saw this comming');
		}
		
	})



</script>
<script>
	$(document).ready(function(){
	    $('input[rel="txtTooltip"]').tooltip();
	});
	$(document).ready(function(){
	    $('textarea[rel="txtTooltip"]').tooltip();
	});

	function sendOfferEmail(firstname,email,domain){
		$.post(
			'http://www.contrib.com/forms/autoresponderEmail',
			{ firstname:firstname,email:email,domain:domain,template_name:'Offer' },
			function(response){
				console.log(response.result);
			}
		);
	}
</script>
<? include('footer.php'); ?>