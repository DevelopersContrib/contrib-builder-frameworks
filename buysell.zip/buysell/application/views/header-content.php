<div class="jumbotron text-center">
    <div class="container">
      <div class="row">
        <div class="col col-lg-12 col-sm-12">
            <? if($info['logo']!=''){ 

                if(strpos($info['logo'],'https') === FALSE){
                    $logo_domain = str_replace('http','https',$info['logo']);
                }else{
                    $logo_domain = $info['logo'];
                }

            ?>

            <a href="https://<?=$info['domain']?>"><img class="responsive" src="<?=$logo_domain?>" alt="<?=$info['title']?>" title="<?=$info['domain']?>"/></a>         
            <? }else{ ?>
            <h1><?=ucwords($info['domain'])?></h1>
            <? } ?>
			<br>
			<p>
			 <a href="https://contrib.com/">Proud Member of CONTRIB</a> | <a href="https://vnoc.com">Powered by VNOC</a>
			</p>
            <p style="display:none;">
                If you’re interested, contact us today to check for <?=ucwords($info['domain'])?> availability, <br> partnership or other development opportunities via our <a href="https://www.contrib.com">Contribution Platform</a>
            </p>       
        </div>
    </div>
</div> 
</div>