<div class="jumbotron text-center">
    <div class="container">
      <div class="row">
        <div class="col col-lg-12 col-sm-12">
            <? if($info['logo']!=''){ ?>
            <a href="http://<?=$info['domain']?>"><img class="img-domain" src="<?=$info['logo']?>" alt="<?=$info['title']?>" title="<?=$info['domain']?>"/></a>         
            <? }else{ ?>
            <h1><?=ucwords($info['domain'])?></h1>
            <? } ?>
			<br>
            <p>You can either BUY or PARTNER with this domain.</p>  
            <p>
                If you're interested in this domain, contact us to check for the availability<br> for partnership, ownership or other development opportunities via Contrib.
            </p>       
        </div>
    </div>
</div> 
</div>