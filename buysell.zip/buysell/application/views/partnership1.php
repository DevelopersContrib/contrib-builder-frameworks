<!-- header -->
<?php include_once('includes/header.php');  ?>

<style type="text/css">
	.loading-div-128{ position: absolute; top: 0; left: 0; bottom: 0; right: 0; background-image: url('https://s3.amazonaws.com/assets.zipsite.net/images/jayson/gif-loading/vnoc-preloader128x128.gif'); background-repeat: no-repeat; background-position: center; background-color: #fff;}
	.blue-form-2 {
		min-height: 464px;
	}
	.working {
		    background-color: transparent;
		    background-image:  url("https://s3.amazonaws.com/assets.zipsite.net/images/jayson/preloader/spin-loading-white.gif");
		    background-position: right center;
		    background-attachment: scroll;
		    background-repeat: no-repeat;
		    padding-right: 2px;
		}
</style>

<!-- end of the header  -->
<div class="section-content">
	<div id="process-form" class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<h1 class="bg-ttle fnt-300">
					<?=ucwords($info['domain'])?>
				</h1>
				<h3 class="sm-ttle-sub fnt-400">
					You can either <span class="text-blue">BUY</span> or <span class="text-blue">PARTNER</span> with this domain.
				</h3>
				<p class="desc-p">
					If you're interested in this domain, contact us to check for the availability <br> for partnership, ownership or other development opportunities via Contrib. 
				</p>
			</div>
			<div id="first-form" class="col-md-12">
				<div class="box-bordered">
					<div class="row">
						<div class="col-md-7 text-right">
							<div class="padd-box">
								<h1 class="fnt-400 ttle-bg-box">
									A great domain name is a great asset
								</h1>
								<p class="sub-desc">
									Invest in a great domain name as part of your brand strategy and take your business to the next level
								</p>
								<div class="row">
									<div class="col-md-12">
										<br>
										<div class="row">
											<div class="col-md-7">
												<br><br>
												<ul class="list-unstyled cust-list-desc fnt-600">
													<li>
														Secure your online identity
														<i class="fa fa-check"></i>
													</li>
													<li>
														Enhance your brand equity
														<i class="fa fa-check"></i>
													</li>
													<li>
														Boost your credibility
														<i class="fa fa-check"></i>
													</li>
													<li>
														Improve conversion rates
														<i class="fa fa-check"></i>
													</li>
												</ul>
											</div>
											<div class="col-md-5 text-center">
												<img src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/icons/800x800/login-800x800.jpg" alt="" class="img-responsive img-circle">
											</div>
										</div>
									</div>
								</div>
							</div>
							<br>
						</div>
						<div class="col-md-5 blue-form text-center ">
							<h3 class="fnt-600">Partner with Swarmstream.com today</h3>
							<p>
								Create your Profile to make a partnership
							</p>
							<div class="form-group ">
								<div id="pt-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<select id="partnershiptype" class="form-control">
										<option value="">Partnership Type</option>
										<option value="Sponsorship Marketing Partnerships">Sponsorship Marketing Partnerships</option>
										<option value="Distribution Marketing Partnerships">Distribution Marketing Partnerships</option>
										<option value="Affiliate Marketing Partnerships">Affiliate Marketing Partnerships</option>
										<option value="Added Value Marketing Partnerships">Added Value Marketing Partnerships</option>
									</select>
									<span id="partnershiptype-error" class="error-text">Choose Partnership Type</span>
								</div>
							</div>
							<div class="form-group">
								<div id="fn-container" class="fg-error-container">
									<span class="meta-aes">*</span>	
									<input type="text" id="firstname" class="form-control" placeholder="First Name">
									<span id="firstname-error" class="error-text">first name is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="ln-container" class="fg-error-container">
									<span class="meta-aes">*</span>	
									<input type="text" id="lastname" class="form-control" placeholder="Last Name">
									<span id="lastname-error" class="error-text">last name is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="em-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<input type="text" id="email" class="form-control" placeholder="Email">
									<span id="email-error" class="error-text">Email is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="ps-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<input type="password" id="password" class="form-control" placeholder="Password">
									<span id="password-error" class="error-text">password is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="cps-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<input type="password" id="cpassword" class="form-control" placeholder="Confirm Password">
									<span id="cpassword-error" class="error-text">confirm password is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="m-container" class="fg-error-container">
									<span class="meta-aes">*</span>
									<textarea rows="5" id="message" class="form-control" placeholder="Message..."></textarea>
									<span id="message-error" class="error-text">message is required</span>
								</div>
							</div>
							<div class="form-group">
								<a href="javascript:;" id="first-btn" class="btn btn-block btn-info btn-lg">
									Next
								</a>
							</div>	
							<div class="form-group">
								<a href="/buy" class="text-link-white">
									Or you can buy this domain!
								</a>
							</div>
							<div class="loading-div-128 hide"></div>
						</div>
					</div>
				</div>
			</div>
			<div id="second-form" class="col-md-12 hide">
				<div class="box-bordered">
					<div class="row">
						<div class="col-sm-4 text-right">
							<div class="padd-box">
								<h1 class="fnt-400 ttle-bg-box">
									Next Steps
								</h1>
								<br />
								<p>
									<b>1. Verify your email</b> <br>
									Before we send your offer to the domain owner, we need to verify your email address. 
								</p>
								<p>
									<b>2. Negotiate the deal</b> <br>
									If the domain owner likes your offer, it will be accepted immediately. If not, you will receive a counter-offer or you may be asked to increase yours.
								</p>
								<p>
									<b>3. Launch Your Website</b> <br>
									As soon as you come to an agreement with the domain owner, and admin has secured the funds, you can start using the domain name.
								</p>
							</div>
							<br>
						</div>
						<div id="second-first" class="col-sm-8 blue-form blue-form-2 text-center">
							<h3 class="fnt-600">
								Complete your Partnership
							</h3>
							<p>
								Please complete your profile in order to present your partnership to the domain owner.*
							</p>

							<div class="row">
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group ">
												<div id="w-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input type="text" id="website" class="form-control" placeholder="Website">
													<span id="website-error" class="error-text">Website url link required</span>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group ">
												<div id="s-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="state" type="text" class="form-control" placeholder="State/Province">
													<span id="state-error" class="error-text">State/Province is required</span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group ">
												<div id="company-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="company" type="text" class="form-control" placeholder="Company">
													<span id="company-error" class="error-text">Company is Required</span>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group ">
												<div class="fg-error-container">
													<span class="meta-aes">*</span>
													<select name="country" id="country" class="form-control">
														<option value="1" name="United States">United States</option>
														 <? foreach ($countries['data'] as $country){ ?>
														  <option value="<?php echo $country['id']?>" name="<? echo $country['name']?>"><?php echo $country['name']?></option>
														 <?}?>
													</select>
													<span class="error-text">Choose Country</span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group ">
												<div id="phone-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="phone" type="text" class="form-control" placeholder="Phone">
													<span id="phone-error" class="error-text">Phone required</span>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group ">
												<div id="postal-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="postal" type="text" class="form-control" placeholder="Postal/Zipcode">
													<span id="postal-error" class="error-text">Postal/Zipcode</span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group ">
												<div id="street-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="street" type="text" class="form-control" placeholder="Street Address">
													<span id="street-error" class="error-text">Street Address required</span>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group ">
												<div id="city-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="city" type="text" class="form-control" placeholder="City">
													<span id="city-error" class="error-text">City required</span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<a href="javascript:;" id="second-btn" class="btn btn-block btn-lg btn-info">
											Next
										</a>
									</div>
								</div>
								<divclass="loading-div-128 hide"></div>
						</div>
						<div id="second-second" class="col-sm-8 blue-form blue-form-2 text-center hide">
							<h3 class="fnt-600">
								Complete your Offer
							</h3>
							<p>
								Please complete your profile in order to present your partnership to the domain owner.*
							</p>
							<div class="row">
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group ">
												<div id="companytitle-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input type="text" id="companytitle" class="form-control" placeholder="Company Title">
													<span id="companytitle-error" class="error-text">Company Title required</span>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group ">
												<div id="companydesc-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="companydesc" type="text" class="form-control" placeholder="Company Description">
													<span id="companydesc-error" class="error-text">Company Description Required</span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group ">
												<div id="companyimage-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="companyimage" type="text" class="form-control" placeholder="Company Image">
													<span id="companyimage-error" class="error-text">Company Image required</span>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group ">
												<div id="companylink-container" class="fg-error-container">
													<span class="meta-aes">*</span>
													<input id="companylink" type="text" class="form-control" placeholder="Company Link">
													<span id="companylink-error" class="error-text">Company Link required</span>
												</div>
											</div>
										</div>
								  </div>
								</div>
								 <div class="col-md-12">
								 	<p>By clicking the button below, I understand that the offer that I am about to submit is binding and I agree to Ecorp 	
									domain name sales and rental terms.</p>
								 </div>
								
								<div class="col-md-12">
									<div class="form-group">
										<a href="javascript:;" id="third-btn" class="btn btn-block btn-lg btn-info">
											Submit
										</a>
									</div>
								</div>
								<div class="col-md-12">*The domain name without content is being made available for sale or rent by its owner through Ecorp.</div>
								<div id="loader-end" class="loading-div-128 hide"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-12 text-center">
				<h1 class="fnt-400">Buy a great domain in 4 easy steps! </h1>
				<h2 class="fnt-300">
					Investing in a great domain name is a smart choice for your organization. 
				</h2>
			</div>
			<div class="col-md-12">
				<br />
				<hr />
				<div class="row">
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-8 text-right">
									<h4>
										Select Your Domain
									</h4>
									<p>
										Search Ecorp’s database for the ultimate domain name for your business, project or brand.
									</p>
								</div>
								<div class="col-md-4">
									<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/domain.jpg" alt="" class="img-responsive img-circle">
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-4">
									<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/offer.jpg" alt="" class="img-responsive img-circle">
								</div>
								<div class="col-md-8 text-left">
									<h4>
										Submit your best offer
									</h4>
									<p>
										We’ll let you know if it's too low for consideration.
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-8 text-right">
									<h4>
										Agree to the terms
									</h4>
									<p>
										Once the price is decided, agree to the terms of the domain name sales agreement.
									</p>
								</div>
								<div class="col-md-4">
									<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/agreement.jpg" alt="" class="img-responsive img-circle">
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-4">
									<img src="https://s3.amazonaws.com/assets.zipsite.net/images/icons/transfer.jpg" alt="" class="img-responsive img-circle">
								</div>
								<div class="col-md-8 text-left">
									<h4>
										Launch you website
									</h4>
									<p>
										Once payment has been confirmed the owner will transfer the domain to you.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container buyrent-page hide" id="success_page">
		<div class="row">
		  <div class="col-md-6 col-md-offset-3">
		  <br>
			<br>
			<div class="well verify-box">
				<center>
					<h2>Thank you for your Partnership application.</h2>
					<p>You are now minutes away to joining <?php echo $info['domain']?> team. All you need to do right now is click the link in the Verification email that we have just sent you. If you still haven’t received it, please check your spam inbox. Your verification link will redirect you to our Marketplace hub where you can login and check out your application status.</p>
					<p>You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.  </p>
					<p id="button_redirect"></p>
				</center>
			</div>
		  </div>
		</div>
	</div> 
</div>
<!-- footer -->
<?php include_once('footer.php');  ?>
<!-- end of the footer  <-->
	</body>
</html>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<script  src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="crossorigin="anonymous"></script>
<script type="text/javascript">
	
	var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var url_check = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
	var image_url = /(https?:\/\/.*\.(?:png|jpg))/i;
	var numeric = /^[0-9]+$/;

	jQuery('#firstname').blur(function(){
		if (jQuery('#firstname').val() === '') {
			jQuery('#fn-container').addClass('has-error-text');
		}else{
			jQuery('#fn-container').removeClass('has-error-text');
		}
	});

	jQuery('#lastname').blur(function(){
		if (jQuery('#lastname').val() === '') {
			jQuery('#ln-container').addClass('has-error-text');
		}else {
			jQuery('#ln-container').removeClass('has-error-text');
		}
	});

	jQuery('#partnershiptype').blur(function(){
		if (jQuery('#partnershiptype').val() === '') {
			jQuery('#partnershiptype').addClass('has-error-text');
		}else {
			jQuery('#partnershiptype').removeClass('has-error-text');
		}
	});

	jQuery('#email').blur(function(){
		if (jQuery('#email').val() === '') {
			jQuery('#email-error').html('Email is Required');
			jQuery('#em-container').addClass('has-error-text');
		} else if(!emailfilter.test(jQuery('#email').val())) {
			jQuery('#email-error').html('your email is invalid ');
			jQuery('#em-container').addClass('has-error-text');
		}else {
			$.post("http://www.contrib.com/signup/checkexist",
				{
					'field':'EmailAddress','value':jQuery('#email').val()
				},
				function(data)
				{
					if (data.status) {
						jQuery('#email-error').html('your email is already taken');
						jQuery('#em-container').addClass('has-error-text');
					}else{
						jQuery('#em-container').removeClass('has-error-text');
					}
				});
			}
	});

	jQuery('#password').blur(function(){
		if (jQuery('#password').val() === '') {
			jQuery('#password-error').html('Password is required');
			jQuery('#ps-container').addClass('has-error-text');
		}else if(jQuery('#password').val().length < 6){
			jQuery('#password-error').html('the password must be atleast 6 characters long');
			jQuery('#ps-container').addClass('has-error-text');
		}else {
			jQuery('#ps-container').removeClass('has-error-text');
		}
	});

	jQuery('#cpassword').blur(function(){
		if (jQuery('#cpassword').val() === '') {
			jQuery('#cpassword-error').html('Confirm Password is Required');
			jQuery('#cps-container').addClass('has-error-text');
		}else if(jQuery('#password').val() != jQuery('#cpassword').val()) {
			jQuery('#cpassword-error').html('Password and Confirm Password is not match');
			jQuery('#cps-container').addClass('has-error-text');
		}else{
			jQuery('#cps-container').removeClass('has-error-text');
		}
	});

	jQuery('#message').blur(function(){
		if (jQuery('#message').val() === '') {
			jQuery('#m-container').addClass('has-error-text');
		}else{
			jQuery('#m-container').removeClass('has-error-text');
		}
	});

	jQuery('#website').blur(function(){
		if (!url_check.test(jQuery('#website').val())) {
			jQuery('#w-container').addClass('has-error-text');
			jQuery('#website-error').html('Please Enter A valid website');
		}else if(jQuery('#website').val() === ''){
			jQuery('#w-container').addClass('has-error-text');
			jQuery('#website-error').html('Website is Required');
		}else{
			jQuery('#w-container').removeClass('has-error-text');
		}
	});

	jQuery('#company').blur(function(){
		if (jQuery('#company').val() === '') {
			jQuery('#company-error').html('Company is required');
			jQuery('#company-container').addClass('has-error-text');
		}else{
			jQuery('#company-container').removeClass('has-error-text');
		}
	});

	jQuery('#state').blur(function(){
		if (jQuery('#state').val() === '') {
			jQuery('#s-container').addClass('has-error-text');
		}else{
			jQuery('#s-container').removeClass('has-error-text');
		}
	});

	jQuery('#phone').blur(function(){
		if (jQuery('#phone').val() === '') {
			jQuery('#phone-container').addClass('has-error-text');
			jQuery('#phone-error').html('Phone Number is required');
		}else if(!numeric.test(jQuery('#phone').val())){
			jQuery('#phone-container').addClass('has-error-text');
			jQuery('#phone-error').html('please enter a valid number');
		}else{
			jQuery('#phone-container').removeClass('has-error-text');
		}
	});

	jQuery('#postal').blur(function(){
		if (jQuery('#postal').val() === '') {
			jQuery('#postal-container').addClass('has-error-text');
			jQuery('#postal-error').html('Postal / Zipcode is required');
		}else if(!numeric.test(jQuery('#postal').val())){
			jQuery('#postal-container').addClass('has-error-text');
			jQuery('#postal-error').html('provide a valid postal / zipcode');
		}else{
			jQuery('#postal-container').removeClass('has-error-text');
		}
	});

	jQuery('#street').blur(function(){
		if (jQuery('#street').val() === '') {
			jQuery('#street-container').addClass('has-error-text');
		}else{
			jQuery('#street-container').removeClass('has-error-text');
		}
	});

	jQuery('#city').blur(function(){
		if (jQuery('#city').val() === '') {
			jQuery('#city-container').addClass('has-error-text');
		}else{
			jQuery('#city-container').removeClass('has-error-text');
		}
	});

	jQuery('#companytitle').blur(function(){
		if (jQuery('#companytitle').val() === '') {
			jQuery('#comapnytitle-error').html('Company Title is Required');
			jQuery('#companytitle-container').addClass('has-error-text');
		}else{
			jQuery('#companytitle-container').removeClass('has-error-text');
		}
	});

	jQuery('#companydesc').blur(function(){
		if (jQuery('#companydesc').val() === '') {
			jQuery('#companydesc-container').addClass('has-error-text');
		}else{
			jQuery('#companydesc-container').removeClass('has-error-text');
		}
	});

	jQuery('#companyimage').blur(function(){
		if (jQuery('#companyimage').val() === '') {
			jQuery('#companyimage-container').addClass('has-error-text');
			jQuery('#companyimage').html('Company Image is Required');
		}else if(!image_url.test(jQuery('#companyimage').val())){
			jQuery('#companyimage-container').addClass('has-error-text');
			jQuery('#companyimage').html('Provide a Valid Company Image Url');
		}else{
			jQuery('#companyimage-container').removeClass('has-error-text');
		}
	});

	jQuery('#companylink').click(function(){
		jQuery('#companylink').val('http://');
	});

	jQuery('#companylink').focus(function(){
		jQuery('#companylink').val('http://');
	});

	jQuery('#companyimage').click(function(){
		jQuery('#companyimage').val('http://');
	});

	jQuery('#companyimage').focus(function(){
		jQuery('#companyimage').val('http://');
	});
	
	jQuery('#website').click(function(){
		jQuery('#website').val('http://');
	});

	jQuery('#website').click(function(){
		jQuery('#website').val('http://');
	});

	jQuery('#companylink').blur(function(){
		if(jQuery('#companylink').val() === ''){
			jQuery('#companylink-container').addClass('has-error-text');
			jQuery('#companylink-error').html('Company Link is Required');
		}else if(!url_check.test(jQuery('#companylink').val())){
			jQuery('#companylink-container').addClass('has-error-text');
			jQuery('#companylink-error').html('Provide a Valid Company Link');
		}else{
			jQuery('#companylink-container').removeClass('has-error-text');
		}
	});	

	jQuery('#first-btn').click(function(){
		first();
	});

	jQuery('#second-btn').click(function(){
		second();
	});

	jQuery('#third-btn').click(function(){
		third();
	});

	function first() {
		var partner_type = $('#partnershiptype').val();
		var fname = $('#firstname').val();
		var lname = $('#lastname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var cpassword = jQuery('#cpassword').val();
		var message = $('#message').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var numeric = /^[0-9]+$/;
		var domain = '<?php echo $info['domain']?>';
		
		if(partner_type == ""){
			jQuery('#pt-container').addClass('has-error-text');
			jQuery('#partnershiptype-error').html('Please Choose a Partnership Type');
		}else if(fname == ""){
			jQuery('#f-container').addClass('has-error-text');
			jQuery('#firstname-error').html('First Name is Required');
		}else if(email == ""){
			jQuery('#em-container').addClass('has-error-text');
			jQuery('#email-error').html('Email is Required');
		}else if(password == ""){
			jQuery('#ps-container').addClass('has-error-text');
			jQuery('#password-error').html('Password is Required');
		}else if(password.length < 5){
			jQuery('#ps-container').addClass('has-error-text');
			jQuery('#password-error').html('Password is Required');
		}else if(cpassword == ""){
			jQuery('#cps-container').addClass('has-error-text');	
			jQuery('cpassword-error').html('Confirm password is required');
		}else if(message == ""){
			jQuery('#m-container').addClass('has-error-text');
			jQuery('message-error').html('Message is Required');
		}else if(!emailfilter.test(email)){
			jQuery('#em-container').addClass('has-error-text');
			jQuery('#email-error').html('Provide a Valid Email');
		}else if(lname == ''){
			jQuery('#ln-container').addClass('has-error-text');
			jQuery('#lastname-error').html('Lastname is Required');
		}else{
			jQuery('#first-form').fadeOut();
			jQuery('#second-form').fadeIn();
		   	jQuery('#first-form').addClass('hide');
			jQuery('#second-form').removeClass('hide');
		}
	}

	function second() {
		var state = $('#state').val();
		var company = $('#company').val();
		var phone = $('#phone').val();
		var zip = $('#postal').val();
		var country_id = $('#country').val();
		var country =   $("#country :selected").text();
		var address = $('#address').val();
		var city = $('#city').val();
		var numeric = /^[0-9]+$/;
		var website = $('#website').val();
		var url_check = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		
		if(state == ''){
			jQuery('#s-container').addClass('has-error-text');
			jQuery('#state-error').html('State is Required');
		}else if(address == ''){
			errormessage('#address-container','#address-error','address is required');
		}else if(phone == ''){
			errormessage('#phone-container','#phone-error','phone is required');
		}else if(city == ''){
			errormessage('#city-container','#city-error','city is required');
		}else if(company == ''){
			errormessage('#company-container','#company-error','company name is required');
		}else if(zip == ''){
			errormessage('#postal-container','#postal-error','Zipcode is required');
		}else if(!numeric.test(zip)){
			errormessage('#postal-container','#postal-error','Zipcode is invalid , accept only numeric');
		}else if(website==""){
			errormessage('#w-container','#website-error','website is required');
		}else if(!url_check.test(website)){
			errormessage('#w-container','#website-error','website is invalid');
		}else{
			jQuery('#second-first').fadeOut('hide');
			jQuery('#second-second').fadeIn('hide');
			jQuery('#second-first').addClass('hide');
			jQuery('#second-second').removeClass('hide');
		}
	}

	function third() {

		var state = $('#state').val();
		var company = $('#company').val();
		var phone = $('#phone').val();
		var zip = $('#postal').val();
		var country_id = $('#country').val();
		var country =   $("#country :selected").text();
		var address = $('#street').val();
		var city = $('#city').val();
		var partner_type = $('#partnershiptype').val();
		var fname = $('#firstname').val();
		var lname = $('#lastname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var domain = '<?php echo $info['domain']?>';
		var company_title = $('#companytitle').val();
		var company_description = $('#companydesc').val();
		var company_image = $('#companyimage').val();
		var company_link = $('#companylink').val();
		var website = $('#website').val();
		var url_check = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		
		if(company_title == ""){
			errormessage('#companytitle-container','#companytitle-error','Company Title is Required');			
		}else if(company_description == ""){
			errormessage('#companydesc-container','#companydesc-error','Company Description is required');			
		}else if(!url_check.test(company_link)){
			errormessage('#companylink-container','#companylink-error','Company Link is invalid');			
		}else if(company_link == ""){
			errormessage('#companylink-container','#companylink-error','company link is required');			
		}else if(company_image == ''){
			errormessage('#companyimage-container','#companyimage-error','company image is required');
		}else if(!image_url.test(company_image)){
			errormessage('#companyimage-container','#companyimage-error','company image url is invalid');
		}else{

			jQuery('#loader-end').removeClass('hide');

			$.post("http://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){

				if(data.status){

					alert(data);
				
				}else{

					$.post("http://www.contrib.com/forms/save_partner",
						{
							city:city,
							company:company_title,
							companydesc:company_description,
							companyimage:company_image,	
							companyurl:company_link,
							country:country,
							country_id:country_id,
							domain:domain,
							email:email,
							exchange_url:'',
							firstname:fname,
							lastname:lname,
							message:message,
							partnertype:partner_type,	
							password:password,
							website:website
						
						},function(data){
							if(data.success){
								jQuery('#loader-end').fadeOut();
								jQuery('#process-form').fadeOut();
								jQuery('#success_page').fadeIn();
								jQuery('#loader-end').addClass('hide');
								jQuery('#process-form').addClass('hide');
								jQuery('#success_page').removeClass('hide');
								$('#button_redirect').htmll('<a class="btn btn-success btn-lg btn-block" id="resend_email" href="http://www.contrib.com/account/autologinforms?email='+data.email+'&form=partnership">Go to your contrib account</a>');
							}
						});
						
					$.post("http://www.manage.vnoc.com/salesforce/addlead",
					{
						
						city:city,
						country:country,
						domain:domain,
						email:email,
						firstName:fname,
						form_type:'VNOC Partnership',
						lastName:lname,
						message:message,
						partner_type:partner_type,
						phone:phone,
						state:state,
						street:address,
						title:company_title,
						zip:zip
					});
				}
			});
		}
	}

	function errormessage(container,error,html)
	{
		jQuery(container).addClass('has-error-text');
		jQuery(error).html(html);
	}

	$(document).ready(function(){
		$('#city').keyup(function(){
			var country_name = $('#country').children('option').filter(':selected').text();
			$('#city').autocomplete({
				search  : function(){$(this).addClass('working');},
				open    : function(){	
							$(this).removeClass('working');
							$('ul.ui-menu').css({'z-index':'1000','border-radius':'0','border-color':'#fff','class':'form-control'});
						},
				source: 'http://www.contrib.com/network/autocompleteCity/'+country_name,
				minLength: 2,
				select: function (event, ui) {   
					var selectedObj = ui.item;
					var cityname = selectedObj.value;
					$('#city').text(cityname);	
					$(this).removeClass('working');
				},
				 error:function() {
	                $(this).removeClass('working');
	                alert('error sys');
	            },
	            failure: function() {
	                $(this).removeClass('working');
	            	alert('error fasds');
	            },
	             response: function(event, ui) {
	                if (ui.content.length === 0) {
	                     $(this).val("No results found");
	                     $(this).removeClass('working');
	                     $(this).removeClass(' ui-autocomplete-input');
		             } else {
		                  $(this).empty();
		                  $(this).removeClass('working');
	                      $(this).removeClass(' ui-autocomplete-input');
		             }
		         }
			});
		});
	});	
</script>