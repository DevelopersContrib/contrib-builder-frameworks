<!-- header -->
<?php //include_once('includes/header.php');
include_once('header.php');?>

<style type="text/css">
	.loading-div-128{ position: absolute; top: 0; left: 0; bottom: 0; right: 0; background-image: url('https://cdn.vnoc.com/icons/loading-128x128.gif'); background-repeat: no-repeat; background-position: center; background-color: #fff;}
	.blue-form-2 {
		min-height: 464px;
	}
	.working {
		    background-color: transparent;
		    background-image:  url("https://cdn.vnoc.com/icons/spin-loading-white.gif");
		    background-position: right center;
		    background-attachment: scroll;
		    background-repeat: no-repeat;
		    padding-right: 2px;
		}
	.section-content {
		margin-bottom:0px;
	}
	.sectionm{
	    background:#fff;
	    text-align:center;
	}
	.cust-list-desc {font-size:larger;}
	.padd-box {
   background: #fafafa;
    padding: 25px;
    height: auto;
    min-height: 800px;
    margin-top: 20px;
}
.sub-desc {

    margin-top: 25%;

}
.blue-form{background:#333 !important;color:#fff !important;}

</style>


<!-- end of the header  -->
<div class="section-content text-center">
   				<h1 class="bg-ttle fnt-300">
					<?=ucwords($info['domain'])?>
					
				</h1>
			<h2 class="fnt-400 ttle-bg-box">
									A great domain name is a great asset
								</h2>
	<div id="process-form" class="container">
		<div class="row">
		
			<div id="first-form" class="col-md-12">
				<div class="box-bordered">
					<div class="row">
						<div class="col-md-6 text-right">
							<div class="padd-box" style="padding-bottom:10%;">
								
								<h2 class="sub-desc">
									Invest in a great domain name as part of your brand strategy and take your business to the next level
								</h2>
								<div class="row">
									<div class="col-md-12">
										<br>
										<div class="row">
											<div class="col-md-6">
												<br><br>
												<ul class="list-unstyled cust-list-desc fnt-600">
													<li>
														Secure your online identity
														<i class="fa fa-check"></i>
													</li>
													<li>
														Enhance your brand equity
														<i class="fa fa-check"></i>
													</li>
													<li>
														Boost your credibility
														<i class="fa fa-check"></i>
													</li>
													<li>
														Improve conversion rates
														<i class="fa fa-check"></i>
													</li>
												</ul>
											</div>
											<div class="col-md-5 text-center">
												<img src="https://cdn.vnoc.com/icons/login-800x800.jpg" alt="" class="img-responsive img-circle">
											</div>
										</div>
									</div>
								</div>
							</div>
							<br>
						</div>
						<div class="col-md-6 blue-form text-center padd-box">
							<h3 class="fnt-600">Partner with <?=ucwords($info['domain'])?> today</h3>
							<p>
								Create A Contrib Profile to Send A Partnership Request
							</p>
							<div class="form-group ">
								<div id="pt-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<select id="partnershiptype" class="form-control">
										<option value="">Partnership Type</option>
										<option value="Sponsorship Marketing Partnerships">Sponsorship Marketing Partnerships</option>
										<option value="Distribution Marketing Partnerships">Distribution Marketing Partnerships</option>
										<option value="Affiliate Marketing Partnerships">Affiliate Marketing Partnerships</option>
										<option value="Added Value Marketing Partnerships">Added Value Marketing Partnerships</option>
									</select>
									<span id="partnershiptype-error" class="error-text">Choose Partnership Type</span>
								</div>
							</div>
							<div class="form-group">
								<div id="fn-container" class="fg-error-container">
									<span class="meta-aes"></span>	
									<input type="text" id="firstname" class="form-control input-form-1" placeholder="First Name">
									<span id="firstname-error" class="error-text">first name is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="ln-container" class="fg-error-container">
									<span class="meta-aes"></span>	
									<input type="text" id="lastname" class="form-control input-form-1" placeholder="Last Name">
									<span id="lastname-error" class="error-text">last name is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="em-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<input type="text" id="email" class="form-control input-form-1" placeholder="Email">
									<span id="email-error" class="error-text">Email is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="ps-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<input type="password" id="password" class="form-control input-form-1" placeholder="Password">
									<span id="password-error" class="error-text">password is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="cps-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<input type="password" id="cpassword" class="form-control input-form-1" placeholder="Confirm Password">
									<span id="cpassword-error" class="error-text">confirm password is required</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="m-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<textarea rows="3" id="message" class="form-control" placeholder="Message..."></textarea>
									<span id="message-error" class="error-text" style="top:78px;">message is required</span>
								</div>
							</div>
							<div class="form-group">
								<a href="javascript:;" id="first-btn" class="btn btn-block btn-primary btn-lg">
									Next
								</a>
							</div>	
							<div class="form-group">
								<a href="/buy" class="text-link-color">
									Or you can buy this domain!
								</a>
							</div>
							<div class="loading-div-128 hide"></div>
						</div>
					</div>
				</div>
			</div>
			<div id="second-form" class="col-md-12 hide">
				<div class="box-bordered">
					<div class="row">
						<div class="col-sm-7 text-right">
							<div class="padd-box">
								<h1 class="fnt-400 ttle-bg-box">
									Next Steps
								</h1>
								<br />
								<p>
									<b>1. Verify your email</b> <br>
									Before we send your offer to the domain owner, we need to verify your email address. 
								</p>
								<p>
									<b>2. Negotiate the deal</b> <br>
									If the domain owner likes your offer, it will be accepted immediately. If not, you will receive a counter-offer or you may be asked to increase yours.
								</p>
								<p>
									<b>3. Launch Your Website</b> <br>
									As soon as you come to an agreement with the domain owner, and admin has secured the funds, you can start using the domain name.
								</p>
							</div>
							<br>
						</div>
						<div class="col-sm-5 blue-form blue-form-2 text-center">
						<div id="second-first">
							<h3 class="fnt-600">
								Complete your Partnership
							</h3>
							<p>
								Please complete your profile in order to present your partnership to the domain owner.*
							</p>
							<div class="form-group ">
								<div id="w-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<input type="text" id="website" class="form-control input-form-2-1" placeholder="Website (https://)">
									<span id="website-error" class="error-text"></span>
								</div>
							</div>											
							<div class="form-group " style="display:none;">
								<div id="company-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<input id="company" type="text" class="form-control input-form-2-1" placeholder="Company">
									<span id="company-error" class="error-text">Company is Required</span>
								</div>
							</div>
							<div class="form-group">
								<div id="phone-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<input id="phone" type="text" class="form-control input-form-2-1" placeholder="Phone">
									<span id="phone-error" class="error-text">Phone required</span>
								</div>
							</div>
							<div class="form-group ">
								<div class="fg-error-container">
									<span class="meta-aes"></span>
									<select name="country" id="country" class="form-control">
										<option value="1" name="United States">United States</option>
										 <? foreach ($countries['data'] as $country){ ?>
										  <option value="<?php echo $country['id']?>" name="<? echo $country['name']?>"><?php echo $country['name']?></option>
										 <?}?>
									</select>
									<span class="error-text">Choose Country</span>
								</div>
							</div>
							<div class="form-group ">
								<div id="city-container" class="fg-error-container">
									<span class="meta-aes"></span>
									<input id="city" type="text" class="form-control" placeholder="City">
									<span id="city-error" class="error-text">City required</span>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<a href="javascript:;" id="second-btn-back" class="btn btn-block btn-lg btn-primary">
											Back
										</a>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<a href="javascript:;" id="second-btn" class="btn btn-block btn-lg btn-primary">
											Next
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="loading-div-128 hide"></div>
						<div id="second-second" class="blue-form blue-form-2 text-center hide">
							<h3 class="fnt-600">
								Complete your Partnership Request
							</h3>
							<p>
								Please complete your profile in order to present your partnership to the domain owner.*
							</p>										
								<div class="form-group">
									<div id="companytitle-container" class="fg-error-container">
										<span class="meta-aes"></span>
										<input type="text" id="companytitle" class="form-control input-form-2-2" placeholder="Company Title">
										<span id="companytitle-error" class="error-text">Company Title</span>
									</div>
								</div>
								<div class="form-group">
									<div id="companydesc-container" class="fg-error-container">
										<span class="meta-aes"></span>										
										<textarea rows="3" id="companydesc" class="form-control input-form-2-2" placeholder="Company Description"></textarea>
										<span id="companydesc-error" class="error-text" style="top:78px;">message</span>
									</div>
								</div>
								<div class="form-group">
									<div id="companyimage-container" class="fg-error-container">
										<!-- <span class="meta-aes">*</span> -->
										<input id="companyimage" type="text" class="form-control input-form-2-2" placeholder="Company Image (https://)">
										<span id="companyimage-error" class="error-text"></span>
									</div>
								</div>
								<div class="form-group">
									<div id="companylink-container" class="fg-error-container">
										<span class="meta-aes"></span>
										<input id="companylink" type="text" class="form-control input-form-2-2" placeholder="Company URL (https://)">
										<span id="companylink-error" class="error-text"></span>
									</div>
								</div>											
								 <div class="form-group">
								 	<p>By clicking the button below, I understand that the offer that I am about to submit is binding and I agree to Ecorp 	
									domain name sales and rental terms.</p>
								 </div>
								 <div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<a href="javascript:;" id="third-btn-back" class="btn btn-block btn-lg btn-primary">
												Back
											</a>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<a href="javascript:;" id="third-btn" class="btn btn-block btn-lg btn-primary">
												Submit Partnership Request
											</a>
										</div>
									</div>
								</div>
								
								<div class="col-md-12">*The domain name without content is being made available for sale or rent by its owner through Ecorp.</div>
								<div id="loader-end" class="loading-div-128 hide"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-12 text-center">
				<h1 class="fnt-400">Buy a great domain in 4 easy steps! </h1>
				<h2 class="fnt-300">
					Investing in a great domain name is a smart choice for your organization. 
				</h2>
			</div>
			<div class="col-md-12">
				<br />
				<hr />
				<div class="row">
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-8 text-right">
									<h4>
										Select Your Domain
									</h4>
									<p>
										Search Ecorp’s database for the ultimate domain name for your business, project or brand.
									</p>
								</div>
								<div class="col-md-4">
									<img src="https://cdn.vnoc.com/icons/domain.jpg" alt="" class="img-responsive img-circle">
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-4">
									<img src="https://cdn.vnoc.com/icons/offer.jpg" alt="" class="img-responsive img-circle">
								</div>
								<div class="col-md-8 text-left">
									<h4>
										Submit your best offer
									</h4>
									<p>
										We’ll let you know if it's too low for consideration.
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-8 text-right">
									<h4>
										Agree to the terms
									</h4>
									<p>
										Once the price is decided, agree to the terms of the domain name sales agreement.
									</p>
								</div>
								<div class="col-md-4">
									<img src="https://cdn.vnoc.com/icons/agreement.jpg" alt="" class="img-responsive img-circle">
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="box-padd-steps">
							<div class="row">
								<div class="col-md-4">
									<img src="https://cdn.vnoc.com/icons/transfer.jpg" alt="" class="img-responsive img-circle">
								</div>
								<div class="col-md-8 text-left">
									<h4>
										Launch you website
									</h4>
									<p>
										Once payment has been confirmed the owner will transfer the domain to you.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	
</div>

<div class="container buyrent-page hide" id="success_page">
	<div class="row">
	  <div class="col-md-6 col-md-offset-3">
	  <br>
		<br>
		<div class="verify-box">
			<center>
				<img src="https://image.flaticon.com/icons/svg/2618/2618116.svg" height="150">
				<h2>Thank you for your <br>Partnership Application!</h2>
				<p>You are now minutes away to joining <?php echo $info['domain']?> team. All you need to do right now is click the link in the Verification email that we have just sent you. If you still haven’t received it, please check your spam inbox. Your verification link will redirect you to our Marketplace hub where you can login and check out your application status.</p>
				<p>You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.  </p>
				<p id="button_redirect"></p>
			</center>
			<br /><br />
		</div>
	  </div>
	</div>
</div> 
	
<!-- footer -->
<?php include_once('footer.php');  ?>
<!-- end of the footer  <-->
	</body>
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<script  src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="crossorigin="anonymous"></script>
<?php include_once('partnership_js.php');  ?>
</html>
