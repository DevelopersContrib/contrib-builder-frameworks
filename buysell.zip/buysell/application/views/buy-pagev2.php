 <style>
.well {
    min-height: 20px;
    padding: 20px 50px 40px 50px;
    margin-bottom: 20px;
	margin-top: 20px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
    box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
}
.contrib-box-in {
	background:#fafafa;
	padding: 20px 10px 10px 10px;
	border:1px solid #dedede;
	border-radius:4px;
	margin:20px 0px 20px 0px;
}
.text-white{
	color: #fff;
}
</style>
	 <div class="col-md-12 hide" id="nextform">
				<div class="cbox cbox3">
					<div class="col-md-5 buyrent-form">
						<h1 class="text-center">Complete your offer <b><?php echo $fname. " " .$lname ?></b> </h1>
						<p class="text-center hide">Please complete your profile in order to present your offer to the domain owner.*</p>
						<form>
							<div class="form-group">
								<div class="bp-alert" id="erroralert" style="display:none">
								</div>
								<div class="col-md-6 hide">
								<input type="text" class="form-control" id="name" placeholder="Name" value="<?php echo $fname." ".$lname?> " disabled>
								</div>
								<div class="col-md-6 hide">
								<input type="text" class="form-control" id="state" placeholder="State/Province">
								</div>
								<div class="col-md-6 hide">
								<input type="text" class="form-control" id="company" placeholder="Company">
								</div>
								<div class="col-md-6 hide">
								<select class="form-control" id="country">
								 <? foreach ($countries['data'] as $country){ ?>
								  <option value="<?php echo $country['id']?>" name="<? echo $country['name']?>"><?php echo $country['name']?></option>
								 <?}?>
								</select>
								</div>
								<div class="col-md-6 hide">
								<input type="text" class="form-control" id="phone" placeholder="Phone #">
								</div>
								<div class="col-md-6 hide">
								<input type="text" class="form-control" id="zip" placeholder="Postal/Zipcode">
								</div>	
								<div class="col-md-6 hide">
								<input type="text" class="form-control" id="address" placeholder="Street Address">
								</div>
								<div class="col-md-6 hide">
								<input type="text" class="form-control" id="city" placeholder="City">
								</div>
								<div class="col-md-12">
								<p>By clicking the button below, I understand that the offer that I am about to submit is binding and I agree to Ecorp 
								<a href="" class="text-white">domain name sales and rental terms.</a></p>
								</div>
							 </div>
							  <div class="col-md-12"><a href="javascript:;" id="submit_offer_not_member" class="btn btn-info btn-block">Submit Offer Now</a></div>	
							  <div class="col-md-12">*The domain name without content is being made available for sale or rent by its owner through Ecorp.</div>
							  <input type="hidden" id="phone" value="<?php echo $phone ?>">
							  <input type="hidden" id="country_id" value="<?php echo $country_id ?>">
							  <input type="hidden" id="country" value="<?php echo $country_select?>">
						</form>
					</div>
					<div class="col-md-7 strategy">
						<h3>Next Steps</h3>
						<ul class="list-group">
						  <li class="list-group-item"><b>1.&nbsp;Verify your email</b><br>Before we send your offer to the domain owner, we need to verify your email address. </li>
						   <li class="list-group-item"><b>2.&nbsp;Negotiate the deal</b><br>If the domain owner likes your offer, it will be accepted immediately. If not, you will receive a counter-offer or you may be asked to increase yours. </li>
						    <li class="list-group-item"><b>3.&nbsp;Launch Your Website</b><br>As soon as you come to an agreement with the domain owner, and admin has secured the funds, you can start using the domain name.  </li>
						</ul>
					</div>
					<div class="clearfix"></div>
				</div>			
	 </div>
    <div class="container buyrent-page" id="success_page2" style="display:none">
		<div class="row">
		  <div class="col-md-8 col-md-offset-2">
			<div class="well verify-box aboutus">
				<img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" style="width:250px; margin:0px auto;">
				<h2 class="text-center">for submitting your offer.</h2>
				<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> You will be receiving three (3)-emails from Contrib.</h4>
				<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> Please check your spam box for safe measure.</h4>
				<div class="clearfix"><br></div>
				<div class="contrib-box-o">
					<p class="text-center">Contrib is our contribution platform and it allows us to get people to help contribute, make offer or partner with premium world class brands. You could check your Offer submission in your <br><b>"My Offers Contrib App"</b>.</p>
					<a href=""><h4 class="text-center"><i class="fa fa-envelope"></i> Please check your email for your Contrib access.</h4></a>
				</div>
				<div class="clearfix"><br></div>
				<div class="row">
					<div class="contrib-box-in">
						<h2 class="text-center">How It Works?</h2>
						<div class="col-md-4 text-center">
							<h3><i class="fa fa-search"></i><br>Step 1</h3>
							<h4>Browse the Marketplace</h4>
							<p>Browse the marketplace and search for sites to submit offers. </p>
						</div>
						<div class="col-md-4 text-center">
							<h3><i class="fa fa-file-text-o"></i><br>Step 2</h3>
							<h4>Submit an Offer</h4>
							<p>Click on sumbit offer and fill up the form.</p>
						</div>
						<div class="col-md-4 text-center">
							<h3><i class="fa fa-desktop"></i><br>Step 3</h3>
							<h4>View Offers</h4>
							<p>View all your offer applications that you have submitted to here. </p>
						</div>
						<div class="clearfix"><br></div>
					</div>
				</div>
			</div>		
		  </div>
		</div>
		<div class="push"></div>
	</div> 
	
<script>

	// $('#submit_offer_not_member').click(function(){
		
	// 		var state = $('#state').val();
	// 		var company = $('#company').val();
	// 		var phone = $('#phone').val();
	// 		var zip = $('#zip').val();
	// 		var country_id = $('#country').val();
	// 		var country =   $("#country :selected").text();
	// 		var address = $('#address').val();
	// 		var city = $('#city').val();
	// 		var numeric = /^[0-9]+$/;
	// 		var amount = '<?php echo $amount?>';
	// 		var password = '<?php echo $password?>';
	// 		var message = '<?php echo $message?>';
	// 		var lname = '<?php echo $lname?>';
	// 		var fname = '<?php echo $fname?>';
	// 		var domain = '<?php echo $info['domain']?>';
	// 		var email = '<?php echo $email?>';

	// 		if(state == ''){
	// 			$('#erroralert').css('display','block');
	// 			$('#erroralert').html('<p role="alert" class="alert alert-danger" >State/Province should not be blank</p>');
	// 			$('#state').focus();
				
	// 		}else if(address == ''){
	// 			$('#erroralert').css('display','block');
	// 			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Address should not be blank</p>');
	// 			$('#address').focus();
				
	// 		}else if(phone == ''){
	// 			$('#erroralert').css('display','block');
	// 			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Phone should not be blank</p>');
	// 			$('#phone').focus();
				
	// 		}else if(city == ''){
	// 			$('#erroralert').css('display','block');
	// 			$('#erroralert').html('<p role="alert" class="alert alert-danger" >City should not be blank</p>');
	// 			$('#city').focus();
				
	// 		}else if(company == ''){
	// 			$('#erroralert').css('display','block');
	// 			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Company should not be blank</p>');
	// 			$('#company').focus();
				
	// 		}else if(zip == ''){
				
	// 			$('#erroralert').css('display','block');
	// 			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Zipcode should not be blank</p>');
	// 			$('#zip').focus();
				
	// 		}else if(!numeric.test(zip)){
	// 			$('#erroralert').css('display','block');
	// 			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Zip should be numbers only</p>');
	// 			$('#zip').focus();
				
	// 		}else{
	// 			$('#submit_offer_not_member').html('<a href="javascript:;" class="btn btn-info btn-block disabled">Please wait..</a>');
	// 			$.post('http://www.contrib.com/forms/save_offer',{
	// 								domain:domain,
	// 								firstname:fname,
	// 								lastname:lname,
	// 								email:email,
	// 								country_id:country_id,
	// 								country:country,
	// 								city:city,
	// 								password:password,
	// 								contact:phone,
	// 								message:message,						   
	// 								amount:amount,
	// 								zip:zip,
	// 								address:address,
	// 								company:company
					
	// 			},function(){
	// 			   $('#reciever_email').text(email);
	// 			   $('#nextform').hide();
	// 			   $('#success_page2').fadeIn();
	// 			   $('#easysteps').fadeOut()
					
	// 			})
	// }
 // })
		
	$('#submit_offer_not_member').click(function(){

			var amount = '<?php echo $amount?>';
			var password = '<?php echo $password?>';
			var message = '<?php echo $message?>';
			var lname = '<?php echo $lname?>';
			var fname = '<?php echo $fname?>';
			var domain = '<?php echo $info['domain']?>';
			var email = '<?php echo $email?>';
			var country = '<?php echo $country_select ?>';
			var country_id = '<?php echo $country_id ?>';
			var contact = '<?php echo $phone ?>';

			var formdata = {
				amount:amount,
				password:password,
				message:message,
				lname:lname,
				fname:fname,
				domain:domain,
				email:email,
				country:country,
				country_id:country_id,
				contact:contact
			}
			console.log(formdata);
		    $('#submit_offer_not_member').html('<a href="javascript:;" class="btn btn-info btn-block disabled">Please wait..</a>');
			$.post('http://www.contrib.com/forms/save_offer',{
									domain:domain,
									firstname:fname,
									lastname:lname,
									email:email,
									country_id:country_id,
									country:country,
									password:password,
									contact:contact,
									message:message,						   
									amount:amount,
									city:'null'
				},function(){
					sendOfferEmail(fname,email,domain)
				   $('#reciever_email').text(email);
				   $('#nextform').hide();
				   $('#success_page2').fadeIn();
				   $('#easysteps').fadeOut()
				   
				   $('#showform').hide();
			});

	});

	function sendOfferEmail(firstname,email,domain){
		$.post(
			'http://www.contrib.com/forms/autoresponderEmail',
			{ firstname:firstname,email:email,domain:domain,template_name:'Offer' },
			function(response){
				console.log(response.result);
			}
		);
	}

	// $('#resend_email2').click(function(){
	// 		var state = $('#state').val();
	// 		var company = $('#company').val();
	// 		var phone = $('#phone').val();
	// 		var zip = $('#zip').val();
	// 		var country_id = $('#country').val();
	// 		var country =   $("#country :selected").text();
	// 		var address = $('#address').val();
	// 		var city = $('#city').val();
	// 		var numeric = /^[0-9]+$/;
	// 		var amount = '<?php echo $amount?>';
	// 		var password = '<?php echo $password?>';
	// 		var message = '<?php echo $message?>';
	// 		var lname = '<?php echo $lname?>';
	// 		var fname = '<?php echo $fname?>';
	// 		var domain = '<?php echo $info['domain']?>';
	// 		var email = '<?php echo $email?>';
			
	// 		if(state != '' || company != '' || phone != '' || zip != '' || country_id != '' || country != '' || address != '' || city != '' )
	// 		{
				
	// 			$.post('http://www.contrib.com/forms/save_offer',{
	// 						domain:domain,
	// 						firstname:fname,
	// 						lastname:lname,
	// 						email:email,
	// 						country_id:country_id,
	// 						country:country,
	// 						city:city,
	// 						password:password,
	// 						contact:phone,
	// 						message:message,						   
	// 						amount:amount,
	// 						zip:zip,
	// 						address:address,
	// 						company:company
			
	// 			},function(){
	// 			   $('#reciever_email').text(email);
	// 			   $('#nextform').hide();
	// 			   $('#success_page2').fadeIn();
	// 			   $('#easysteps').fadeOut()
					
	// 			})
	// 		}else{
		
		
	// 			alert('good skill, but we already saw this comming');
	// 		}
	// });
		
	
	



</script>