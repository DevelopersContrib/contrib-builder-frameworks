 <div class="col-md-12" id="nextform">
			<div class="cbox cbox3">
				<div class="col-md-8 buyrent-form">
					<h2 class="text-center">Complete your offer</h2>
					<p class="text-center">Please complete your profile in order to present your offer to the domain owner.*</p>
					<form>
						<div class="form-group">
							<div class="bp-alert" id="erroralert" style="display:none">
								
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="name" placeholder="Name" value="<?php echo $fname." ".$lname?> " disabled>
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="state" placeholder="State/Province">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="company" placeholder="Company">
							</div>
							<div class="col-md-6">
							<select class="form-control" id="country">
							 <? foreach ($countries['data'] as $country){ ?>
							  <option value="<?php echo $country['id']?>" name="<? echo $country['name']?>"><?php echo $country['name']?></option>
							 <?}?>
							</select>
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="phone" placeholder="Phone #">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="zip" placeholder="Postal/Zipcode">
							</div>	
							<div class="col-md-6">
							<input type="text" class="form-control" id="address" placeholder="Street Address">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="city" placeholder="City">
							</div>
							<div class="col-md-12">
							<p>By clicking the button below, I understand that the offer that I am about to submit is binding and I agree to Ecorp 
							<a href="">domain name sales and rental terms.</a></p>
							</div>
						 </div>
						  <div class="col-md-12"><a href="javascript:;" id="submit_offer_not_member" class="btn btn-info btn-block">Submit Offer Now</a></div>	
						  <div class="col-md-12">*The domain name without content is being made available for sale or rent by its owner through Ecorp.</div>
					</form>
					  
				</div>
				
				
			
				
				
				<div class="col-md-4 strategy">
					<h3>Next Steps</h3>
					<ul class="list-group">
					  <li class="list-group-item"><b>1.&nbsp;Verify your email</b><br>Before we send your offer to the domain owner, we need to verify your email address. </li>
					   <li class="list-group-item"><b>2.&nbsp;Negotiate the deal</b><br>If the domain owner likes your offer, it will be accepted immediately. If not, you will receive a counter-offer or you may be asked to increase yours. </li>
					    <li class="list-group-item"><b>3.&nbsp;Launch Your Website</b><br>As soon as you come to an agreement with the domain owner, and admin has secured the funds, you can start using the domain name.  </li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
	<div class="container buyrent-page" id="success_page2" style="display:none">
			<div class="row">
			  <div class="col-md-6 col-md-offset-3">
				<div class="well verify-box">
					<h2>Check Your Email Now</h2>
					<p>We need to verify your email address. We've sent an email to <b id="reciever_email">andrecartagena@gmail.com</b> to verify your address.</p>
					<p>Please click the link inside that email in order to send your offer to the domain owner. </p>
					<h4>Didn't receive the email?</h4>
					<p>Check your spam folder for an email from <b>noreply@ecorp.com.</b> </p>
					<h4>Still don't see it?</h4>
					<a href="javascript:;" id="resend_email2" class="btn btn-success btn-lg btn-block">Send Another Verification Email</a>
				</div>
			  </div>
			</div>
		</div> 
<script>

	$('#submit_offer_not_member').click(function(){
		
		
		
		var state = $('#state').val();
		var company = $('#company').val();
		var phone = $('#phone').val();
		var zip = $('#zip').val();
		var country_id = $('#country').val();
		var country =   $("#country :selected").text();
		var address = $('#address').val();
		var city = $('#city').val();
		var numeric = /^[0-9]+$/;
		var amount = '<?php echo $amount?>';
		var password = '<?php echo $password?>';
		var message = '<?php echo $message?>';
		var lname = '<?php echo $lname?>';
		var fname = '<?php echo $fname?>';
		var domain = '<?php echo $info['domain']?>';
		var email = '<?php echo $email?>';

		if(state == ''){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >State/Province should not be blank</p>');
			$('#state').focus();
			
		}else if(address == ''){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Address should not be blank</p>');
			$('#address').focus();
			
		}else if(phone == ''){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Phone should not be blank</p>');
			$('#phone').focus();
			
		}else if(city == ''){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >City should not be blank</p>');
			$('#city').focus();
			
		}else if(company == ''){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Company should not be blank</p>');
			$('#company').focus();
			
		}else if(zip == ''){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Zipcode should not be blank</p>');
			$('#zip').focus();
			
		}else if(!numeric.test(zip)){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Zip should be numbers only</p>');
			$('#zip').focus();
			
		}else{
			
			$.post('http://www.contrib.com/forms/save_offer',{
								domain:domain,
								firstname:fname,
								lastname:lname,
								email:email,
								country_id:country_id,
								country:country,
								city:city,
								password:password,
								contact:phone,
								message:message,						   
								amount:amount,
								zip:zip,
								address:address,
								company:company
				
			},function(){
			   $('#reciever_email').text(email);
			   $('#nextform').hide();
			   $('#success_page2').fadeIn();
			   $('#easysteps').fadeOut()
				
			})
			
		}
		
		$('#resend_email2').click(function(){
				var state = $('#state').val();
				var company = $('#company').val();
				var phone = $('#phone').val();
				var zip = $('#zip').val();
				var country_id = $('#country').val();
				var country =   $("#country :selected").text();
				var address = $('#address').val();
				var city = $('#city').val();
				var numeric = /^[0-9]+$/;
				var amount = '<?php echo $amount?>';
				var password = '<?php echo $password?>';
				var message = '<?php echo $message?>';
				var lname = '<?php echo $lname?>';
				var fname = '<?php echo $fname?>';
				var domain = '<?php echo $info['domain']?>';
				var email = '<?php echo $email?>';
				
				if(state != '' || company != '' || phone != '' || zip != '' || country_id != '' || country != '' || address != '' || city != '' )
				{
					
					$.post('http://www.contrib.com/forms/save_offer',{
								domain:domain,
								firstname:fname,
								lastname:lname,
								email:email,
								country_id:country_id,
								country:country,
								city:city,
								password:password,
								contact:phone,
								message:message,						   
								amount:amount,
								zip:zip,
								address:address,
								company:company
				
					},function(){
					   $('#reciever_email').text(email);
					   $('#nextform').hide();
					   $('#success_page2').fadeIn();
					   $('#easysteps').fadeOut()
						
					})
				}else{
			
			
					alert('good skill, but we already saw this comming');
				}
			
			
		});
		
		
		
		
		
		
	})
	



</script>