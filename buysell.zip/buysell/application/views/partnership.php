<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>

<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="cbox cbox3">
				<div class="col-md-5 buyrent-form">
					<h2 class="text-center">Partner with <?=ucwords($info['domain'])?> today</h2>
					<p class="text-center">Create your Profile to make partnership</p>
					<form>
						<div class="form-group">
							<div class="col-md-8">
							<input type="text" class="form-control" id="" placeholder="Amount">
							</div>
							<div class="col-md-4">
							<select class="form-control">
							  <option>12 Months</option>
							  <option>6 Months</option>
							</select>
							</div>
							<div class="col-md-12"><input type="text" class="form-control" id="" placeholder="Name"></div>						  
							<div class="col-md-12"><input type="text" class="form-control" id="" placeholder="Email"></div>						  
							<div class="col-md-12"><input type="password" class="form-control" id="" placeholder="Password"></div>						  
							<div class="col-md-12"><textarea class="form-control" rows="3"></textarea></div>
						  </div>
						  <div class="col-md-12"><a href="<?echo $base_url?>partner/partnershipnext" class="btn btn-info btn-block">Submit Partnership</a></div>
							<p class="text-center oryoucan"><a href="<?echo $base_url?>buy">Or you can buy this domain!</a></p>
					</form>
					  
				</div>
				<div class="col-md-7 strategy">
					<h2>A great domain name is a great asset</h2>
					<h4>Partner with <?=ucwords($info['domain'])?> as part of your brand strategy and take your business to the next level</h4>
					<ul class="list-group">
					  <li class="list-group-item"><i class="fa fa-check"></i>Secure your online identity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Enhance your brand equity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Boost your credibility</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Improve conversion rates</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Partner with <?=ucwords($info['domain'])?> today</li>					  
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
    </div> 
	<div class="row">
		<div class="col-md-12">			
			<h2 class="text-center">Partner with <?=ucwords($info['domain'])?> in 4 easy steps! </h2>
			<h3 class="text-center sc-hd">Investing in a great domain name is a smart choice for your organization. </h3>
			<hr>
		</div>
        <div class="col-md-3 text-center brpop">
			<a id="popoverData" class="btn" href="#" data-content="Search Ecorp’s database for the ultimate domain name for your business, project or brand." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-search"></i></h1>
				<h4>Select Your <br>Domain </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData1" class="btn" href="#" data-content="We’ll let you know if it's too low for consideration." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-dollar"></i></h1>
				<h4>Submit Your <br>Partner </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData3" class="btn" href="#" data-content="Once the price is decided, agree to the terms of the domain name sales agreement." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-check"></i></h1>
			<h4>Agree <br>To The Terms</h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData5" class="btn" href="#" data-content="Once payment has been confirmed the owner will transfer the domain to you." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-globe"></i></h1>
			<h4>Launch <br>Your Partnership </h4>
			</a>
		</div>
		<div class="col-md-12 text-center brpop"><br></div>
	</div>
</div>


<? include('footer.php'); ?>