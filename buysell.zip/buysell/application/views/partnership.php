<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>
 <style>
.well {
    min-height: 20px;
    padding: 20px 50px 40px 50px;
    margin-bottom: 20px;
	margin-top: 20px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
    box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
}
.contrib-box-in {
	background:#fafafa;
	padding: 20px 10px 10px 10px;
	border:1px solid #dedede;
	border-radius:4px;
	margin:20px 0px 20px 0px;
}
</style>
<div class="container">    
    <div class="row" id="showform">
        <div class="col-md-12">
			<div class="cbox cbox3">
				<div class="col-md-5 buyrent-form">
					<h2 class="text-center">Partner with <?=ucwords($info['domain'])?> today</h2>
					<p class="text-center">You need a Contrib Profile to Send a Partnership Request</p>
					<form>
						<div class="form-group">
							<div class="col-md-12">
							<div class="bp-alert" id="erroralert" style="display:none">
								
							</div>
							
							
							<select id="partner_type" name="partner_type" class="form-control" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Select Partnership">
								<option value="">Partnership Type</option>
								<option value="Sponsorship Marketing Partnerships">Sponsorship Marketing Partnerships</option>
								<option value="Distribution Marketing Partnerships">Distribution Marketing Partnerships</option>
								<option value="Affiliate Marketing Partnerships">Affiliate Marketing Partnerships</option>
								<option value="Added Value Marketing Partnerships">Added Value Marketing Partnerships</option>
							</select>
							</div>
							<!--<div class="col-md-4">
							<select class="form-control">
							  <option>12 Months</option>
							  <option>6 Months</option>
							</select>
							</div>-->
							<div class="col-md-12"><input type="text" class="form-control" id="name" placeholder="First Name" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Firstname"></div>						  
							<div class="col-md-12"><input type="text" class="form-control" id="lname" placeholder="Last Name" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Lastname"></div>						  
							<div class="col-md-12"><input type="text" class="form-control" id="email" placeholder="Email" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email"></div>						  
							<div class="col-md-12"><input type="password" class="form-control" id="password" placeholder="Password" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Password Must More Than 5 Characters"></div>						  
							<div class="col-md-12"><textarea class="form-control" rows="3" id="message" placeholder="Message" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Your Message Here"></textarea></div>
						  </div>
						  <div class="col-md-12"><a href="javascript:;" id="nextpageoffer" class="btn btn-info btn-block">Next</a></div>
							<p class="text-center oryoucan"><a href="<? echo $base_url?>partner">Or you can partner with this domain!</a></p>
					</form>
					  
				</div>
				<div class="col-md-7 strategy">
					<h2>A great domain name is a great asset</h2>
					<h4>Invest in a great domain name as part of your brand strategy and take your business to the next level</h4>
					<ul class="list-group">
					  <li class="list-group-item"><i class="fa fa-check"></i>Secure your online identity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Enhance your brand equity</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Boost your credibility</li>
					  <li class="list-group-item"><i class="fa fa-check"></i>Improve conversion rates</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
    </div> 
	
	
	
	<div class="row" id="nextform" style="display:none">
         <div class="col-md-12" >
			<div class="cbox cbox3">
				<div class="col-md-8 buyrent-form">
					<h2 class="text-center">Complete your partnership</h2>
					<p class="text-center">Please complete your profile in order to present your partnership to the domain owner.*</p>
					<form>
						<div class="form-group">
							<div class="bp-alert" id="erroralertnextpage" style="display:none">
								
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="website" placeholder="Website" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Website">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="state" placeholder="State/Province" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter State/Province">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="company" placeholder="Company" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Company">
							</div>
							<div class="col-md-6">
							<select class="form-control" id="country" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Country">
							 <? foreach ($countries['data'] as $country){ ?>
							  <option value="<?php echo $country['id']?>" name="<? echo $country['name']?>"><?php echo $country['name']?></option>
							 <?}?>
							</select>
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="phone" placeholder="Phone #" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Contact Number">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="zip" placeholder="Postal/Zipcode" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Postal Code">
							</div>	
							<div class="col-md-6">
							<input type="text" class="form-control" id="address" placeholder="Street Address" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Address">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="city" placeholder="City" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your City">
							</div>
							
						 </div>
						  <div class="col-md-12"><a href="javascript:;" id="submit_partnership_profile" class="btn btn-info btn-block">Next</a></div>	
						
					</form>
					  
				</div>
				
				
			
				
				
				<div class="col-md-4 strategy">
					<h3>Next Steps</h3>
					<ul class="list-group">
					  <li class="list-group-item"><b>1.&nbsp;Verify your email</b><br>Before we send your offer to the domain owner, we need to verify your email address. </li>
					   <li class="list-group-item"><b>2.&nbsp;Negotiate the deal</b><br>If the domain owner likes your offer, it will be accepted immediately. If not, you will receive a counter-offer or you may be asked to increase yours. </li>
					    <li class="list-group-item"><b>3.&nbsp;Launch Your Website</b><br>As soon as you come to an agreement with the domain owner, and admin has secured the funds, you can start using the domain name.  </li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
    </div> 
	
	
	<div class="row" id="lastform" style="display:none">
         <div class="col-md-12" >
			<div class="cbox cbox3">
				<div class="col-md-8 buyrent-form">
					<h2 class="text-center">Complete your offer</h2>
					<p class="text-center">Please complete your profile in order to present your offer to the domain owner.*</p>
					<form>
						<div class="form-group">
							<div class="bp-alert" id="erroralertlastpage" style="display:none">
								
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="company_title" placeholder="Company Title" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Company Name">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="company_description" placeholder="Company Description" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Company Description">
							</div>
							
							<div class="col-md-6">
							<input type="text" class="form-control" id="company_image" placeholder="Company Image" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Company Image">
							</div>
							<div class="col-md-6">
							<input type="text" class="form-control" id="company_link" placeholder="Company Link"  rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Company Website Link">
							</div>	
							
							<div class="col-md-12">
							<p>By clicking the button below, I understand that the offer that I am about to submit is binding and I agree to Ecorp 
							<a href="">domain name sales and rental terms.</a></p>
							</div>
						 </div>
						  <div class="col-md-12"><a href="javascript:;" id="submit_partnership" class="btn btn-info btn-block">Submit Offer Now</a></div>	
						  <div class="col-md-12">*The domain name without content is being made available for sale or rent by its owner through Ecorp.</div>
					</form>
					  
				</div>
				
				
			
				
				
				<div class="col-md-4 strategy">
					<h3>Next Steps</h3>
					<ul class="list-group">
					  <li class="list-group-item"><b>1.&nbsp;Verify your email</b><br>Before we send your offer to the domain owner, we need to verify your email address. </li>
					   <li class="list-group-item"><b>2.&nbsp;Negotiate the deal</b><br>If the domain owner likes your offer, it will be accepted immediately. If not, you will receive a counter-offer or you may be asked to increase yours. </li>
					    <li class="list-group-item"><b>3.&nbsp;Launch Your Website</b><br>As soon as you come to an agreement with the domain owner, and admin has secured the funds, you can start using the domain name.  </li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>			
		</div>
    </div> 
	
	
	
<div class="container buyrent-page" id="success_page" style="display:none">
	<div class="row">
	  <div class="col-md-6 col-md-offset-3">
		<div class="well verify-box">
			<center>
				<h2>Thank you for your Partnership application.</h2>
				<p>You are now minutes away to joining <?php echo $info['domain']?> team. All you need to do right now is click the link in the Verification email that we have just sent you. If you still haven’t received it, please check your spam inbox. Your verification link will redirect you to our Marketplace hub where you can login and check out your application status.</p>
				<p>You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.  </p>
				<p id="button_redirect"></p>
			</center>
		</div>
	  </div>
	</div>
</div> 
	
	<div class="row" id="easysteps">
		<div class="col-md-12">			
			<h2 class="text-center">Buy a great domain in 4 easy steps! </h2>
			<h3 class="text-center sc-hd">Investing in a great domain name is a smart choice for your organization. </h3>
			<hr>
		</div>
        <div class="col-md-3 text-center brpop">
			<a id="popoverData" class="btn" href="#" data-content="Search Ecorp’s database for the ultimate domain name for your business, project or brand." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-search"></i></h1>
				<h4>Select Your <br>Domain </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData1" class="btn" href="#" data-content="We’ll let you know if it's too low for consideration." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-dollar"></i></h1>
				<h4>Submit Your <br>Best Offer </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData3" class="btn" href="#" data-content="Once the price is decided, agree to the terms of the domain name sales agreement." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-check"></i></h1>
			<h4>Agree <br>To The Terms</h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData5" class="btn" href="#" data-content="Once payment has been confirmed the owner will transfer the domain to you." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-globe"></i></h1>
			<h4>Launch <br>Your Website </h4>
			</a>
		</div>
		<div class="col-md-12 text-center brpop"><br></div>
	</div>
</div>
<script>
	$('#nextpageoffer').click(function(){
		
		var partner_type = $('#partner_type').val();
		var fname = $('#name').val();
		var lname = $('#lname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var numeric = /^[0-9]+$/;
		var domain = '<?php echo $info['domain']?>';
		
		if(partner_type == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Partner type should not be blank</p>');
			$('#partner_type').focus();
			
		}else if(fname == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >First name should not be blank</p>');
			$('#name').focus();
			
		}else if(email == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >email should not be blank</p>');
			$('#email').focus();
			
		}else if(password == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should not be blank</p>');
			$('#password').focus();
			
		}else if(password.length < 5){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should be more than 5 characters</p>');
			$('#password').focus();
		}else if(message == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >message should not be blank</p>');
			$('#message').focus();
		}else if(!emailfilter.test(email)){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >invalid email</p>');
			$('#email').focus();
		}else if(lname == ''){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Last name should not be blank</p>');
			$('#lname').focus();
			
		}else{
			$('#showform').hide();
			 $('#nextform').fadeIn();
			
		}
		
		
		
	})
	
	$('#submit_partnership_profile').click(function(){
		
		var state = $('#state').val();
		var company = $('#company').val();
		var phone = $('#phone').val();
		var zip = $('#zip').val();
		var country_id = $('#country').val();
		var country =   $("#country :selected").text();
		var address = $('#address').val();
		var city = $('#city').val();
		var numeric = /^[0-9]+$/;
		var website = $('#website').val();
		var url_check = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		
		
		if(state == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >State/Province should not be blank</p>');
			$('#state').focus();
			
		}else if(address == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Address should not be blank</p>');
			$('#address').focus();
			
		}else if(phone == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Phone should not be blank</p>');
			$('#phone').focus();
			
		}else if(city == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >City should not be blank</p>');
			$('#city').focus();
			
		}else if(company == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Company should not be blank</p>');
			$('#company').focus();
			
		}else if(zip == ''){
			
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Zipcode should not be blank</p>');
			$('#zip').focus();
			
		}else if(!numeric.test(zip)){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Zip should be numbers only</p>');
			$('#zip').focus();
			
		}else if(website==""){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Website should be numbers only</p>');
			$('#website').focus();
			
		}else if(!url_check.test(website)){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Website invalid</p>');
			$('#website').focus();
			
		}else{
			
			$('#nextform').hide();
			$('#lastform').fadeIn();
			
			
		}
		
		
		
		
	});
	
	$('#submit_partnership').click(function(){
		var state = $('#state').val();
		var company = $('#company').val();
		var phone = $('#phone').val();
		var zip = $('#zip').val();
		var country_id = $('#country').val();
		var country =   $("#country :selected").text();
		var address = $('#address').val();
		var city = $('#city').val();
		var partner_type = $('#partner_type').val();
		var fname = $('#name').val();
		var lname = $('#lname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var domain = '<?php echo $info['domain']?>';
		var company_title = $('#company_title').val();
		var company_description = $('#company_description').val();
		var company_image = $('#company_image').val();
		var company_link = $('#company_link').val();
		var website = $('#website').val();
		var url_check = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		
		if(company_title == ""){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Company title should not be blank</p>');
			$('#company_title').focus();
			
		}else if(company_description == ""){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Company description should not be blank</p>');
			$('#company_description').focus();
			
		}else if(!url_check.test(company_link)){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Invalid url</p>');
			$('#zip').focus();
			
		}else if(company_link == ""){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Company link should not be blank</p>');
			$('#company_link').focus();
			
		}else{
			$('#submit_partnership').html('<a href="javascript:;" class="btn btn-info btn-block disabled">Please wait..</a>');
			
			$.post("https://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){
			
				if(data.status){
					
					$('#erroralertlastpage').css('display','block');
					$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >* Email already have an account. *<a target="_top" href="https://www.contrib.com">Please LOGIN here.</a></p>');
					
				}else{
					
					$.post("https://www.contrib.com/forms/save_partner",
							{
								city:city,
								company:company_title,
								companydesc:company_description,
								companyimage:company_image,	
								companyurl:company_link,
								country:country,
								country_id:country_id,
								domain:domain,
								email:email,
								exchange_url:'',
								firstname:fname,
								lastname:lname,
								message:message,
								partnertype:partner_type,	
								password:password,
								website:website
							
							},function(data){
								if(data.success){
									$('#lastform').hide();
									$('#success_page').fadeIn();
									$('#button_redirect').html('<a class="btn btn-success btn-lg btn-block" id="resend_email" href="https://www.contrib.com/account/autologinforms?email='+data.email+'&form=partnership">Go to your contrib account</a>');
									
								}
								
						});
						
						
					$.post("https://www.manage.vnoc.com/salesforce/addlead",
					{
						
						city:city,
						country:country,
						domain:domain,
						email:email,
						firstName:fname,
						form_type:'VNOC Partnership',
						lastName:lname,
						message:message,
						partner_type:partner_type,
						phone:phone,
						state:state,
						street:address,
						title:company_title,
						zip:zip
					});
					
					
				}
					
			})
		}
		
		
		
	});

</script>

<script>
$(document).ready(function(){
    //$('input[rel="txtTooltip"]').tooltip();
});
$(document).ready(function(){
    //$('textarea[rel="txtTooltip"]').tooltip();
});
$(document).ready(function(){
    //$('select[rel="txtTooltip"]').tooltip();
});
</script>

<? include('footer.php'); ?>