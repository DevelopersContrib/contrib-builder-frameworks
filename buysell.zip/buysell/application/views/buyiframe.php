<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>

<div class="container">    
    <div class="row" id="showform">
        <div class="col-md-8 col-md-offset-2">
			<div class="well verify-box aboutus">
				<center><iframe frameborder="0" style="width:335px;height:480px;" scrolling="no" src="https://www.contrib.com/forms/offer/<?=$info['domain']?>"></iframe></center>
			</div>			
		</div>
    </div> 
	

	
	<div class="row" id="easysteps">
		<div class="col-md-12">			
			<h2 class="text-center">Buy a great domain in 4 easy steps! </h2>
			<h3 class="text-center sc-hd">Investing in a great domain name is a smart choice for your organization. </h3>
			<hr>
		</div>
        <div class="col-md-3 text-center brpop">
			<a id="popoverData" class="btn" href="#" data-content="Search Ecorp’s database for the ultimate domain name for your business, project or brand." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-search"></i></h1>
				<h4>Select Your <br>Domain </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData1" class="btn" href="#" data-content="We’ll let you know if it's too low for consideration." rel="popover" data-placement="top" data-trigger="hover">
				<h1><i class="fa fa-dollar"></i></h1>
				<h4>Submit Your <br>Best Offer </h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData3" class="btn" href="#" data-content="Once the price is decided, agree to the terms of the domain name sales agreement." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-check"></i></h1>
			<h4>Agree <br>To The Terms</h4>
			</a>
		</div>
		<div class="col-md-3 text-center brpop">
			<a id="popoverData5" class="btn" href="#" data-content="Once payment has been confirmed the owner will transfer the domain to you." rel="popover" data-placement="top" data-trigger="hover">
			<h1><i class="fa fa-globe"></i></h1>
			<h4>Launch <br>Your Website </h4>
			</a>
		</div>
		<div class="col-md-12 text-center brpop"><br></div>
	</div>
</div>


<? include('footer.php'); ?>