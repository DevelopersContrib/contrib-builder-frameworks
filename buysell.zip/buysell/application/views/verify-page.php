<? include_once('header.php'); ?>
<? include_once('header-content.php'); ?>

<div class="container buyrent-page">
	<div class="row">
	  <div class="col-md-6 col-md-offset-3">
		<div class="well verify-box">
			<h2>Check Your Email Now</h2>
			<p>We need to verify your email address. We've sent an email to <b>andrecartagena@gmail.com</b> to verify your address.</p>
			<p>Please click the link inside that email in order to send your offer to the domain owner. </p>
			<h4>Didn't receive the email?</h4>
			<p>Check your spam folder for an email from <b>noreply@ecorp.com.</b> </p>
			<h4>Still don't see it?</h4>
			<a href="#" class="btn btn-success btn-lg btn-block">Send Another Verification Email</a>
		</div>
	  </div>
	</div>
</div> 






<? include('footer.php'); ?>