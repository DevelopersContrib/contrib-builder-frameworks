	<div class="footer-dark-1 footer-dark-b-1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase">
									Contrib.com
								</h3>
								<p>
									is a new business model, Technology, and Solution targeting the premium domain channel with a fast, affordable, high quality business creation and management platform. 
								</p>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase">
									get started
								</h3>
								<ul class="list-unstyled f-a-links">
									<li>
										<a href="<?php echo $base_url; ?>" class="text-capitalize">
											Partner with us
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>" class="text-capitalize">
											Apply now
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>" class="text-capitalize">
											referral
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>" class="text-capitalize">
											fund
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>" class="text-capitalize">
											developers
										</a>
									</li>
								</ul>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase">
									company
								</h3>
								<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
									<li>
										<a href="<?php echo $base_url ?>/home/about" class="text-capitalize">
											About us
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>/home/terms" class="text-capitalize">
											Terms
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>/home/privacy" class="text-capitalize">
											Privacy
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>/home/contact" class="text-capitalize">
											Contact us
										</a>
									</li>
								</ul>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase">
									partners
								</h3>
								<p>						
									<a href="https://contrib.io/" target="_blank"><img style="border:0px" src="https://cdn.vnoc.com/banner/banner-ctb-earn-ctb-tokens.png" width="205" height="58" alt="Contrib and Earn CTB Tokens" title="Contrib and Earn CTB Tokens"></a>
								</p>
								<h3 class="fnt-bold text-uppercase">
									Socials
								</h3>
								<ul class="list-inline socials-ul">
									<li>
										<a title="twitter" class="icon-button twitter" href="<?php echo $social_twitter ?>">
											<i class="fa fa-twitter"></i>
											<span></span>
										</a>
									</li>
									<li>
										<a title="facebook" class="icon-button facebook" href="<?php echo $social_fb ?>">
											<i class="fa fa-facebook"></i>
											<span></span>
										</a>
									</li>
									<li>
										<a title="google-plus" class="icon-button google-plus" href="<?php echo $social_gplus ?>">
											<i class="fa fa-google-plus"></i>
											<span></span>
										</a>

									</li>
									<li>
										<a title="youtube" class="icon-button youtube" href="<?php echo $social_gtube ?>">
											<i class="fa fa-youtube"></i>
											<span></span>
										</a>
									</li>
									<li>
										<a title="linkedin" class="icon-button linkedin" href="<?php echo $social_linkedin ?>">
											<i class="fa fa-linkedin"></i>
											<span></span>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-dark-2 footer-dark-b-2">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6 f-a-links">
								&copy; <?=date('Y')?> <a href="" class="text-capitalize ">contrib.com</a>. All Rights Reserved. 
							</div>
							<div class="col-md-6">
								<ul class="list-inline text-right f-a-links">
									<li>
										<a href="<?php echo $base_url ?>home/about" class="text-capitalize">
											<i class="fa fa-bookmark-o"></i>
											About us
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>home/terms" class="text-capitalize">
											<i class="fa fa-book"></i>
											Terms
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>home/privacy" class="text-capitalize">
											<i class="fa fa-cube"></i>
											privacy
										</a>
									</li>
									<li>
										<a href="<?php echo $base_url ?>home/contact" class="text-capitalize">
											<i class="fa fa-phone-square"></i>
											contact us
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				<!-- Piwik -->
		<script type="text/javascript">
		  var _paq = _paq || [];
		  _paq.push(['trackPageView']);
		  _paq.push(['enableLinkTracking']);
		  (function() {
		    var u="//www.stats.numberchallenge.com/";
		    _paq.push(['setTrackerUrl', u+'piwik.php']);
		    _paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
		    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
		    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
		  })();
		</script>
		<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>
		<!-- End Piwik Code -->