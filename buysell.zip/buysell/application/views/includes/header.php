<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="canonical" href="http://<?=$info['domain']?>/<?=basename($_SERVER['PHP_SELF'])?>/" />
		<link rel="icon" type="image/icon" href="favicon.ico">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta name="robots" content="index, follow" />
		<title><?=$info['title']?> - <?=$metatitle?></title>
		<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="title" content="<?=$info['title']?> " />
		<meta name="description" content="<?=ucwords($info['domain'])?> - <?=$info['description']?>" />
   		<meta name="keywords" content="<? echo $info['keywords']; ?>" />
  		<meta name="author" content="<?php echo $info['domain']; ?>">

		<!-- Latest compiled and minified CSS
		<script src="https://use.fontawesome.com/ada4e0ae79.js"></script> -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="/css/style.bs3.css">


		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<link href="<?php echo $base_url?>css/styles.css" rel="stylesheet">
        <!-- owl carousel -->
        <link rel="stylesheet" href="<?php echo $base_url?>css/owl.carousel.css" />
		
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', '<?=$info['account_ga'] ?>', '<?=$info['domain'] ?>');
		  ga('send', 'pageview');

		</script>
		<!-- Piwik -->
		<script type="text/javascript">
		  var _paq = _paq || [];
		  _paq.push(['trackPageView']);
		  _paq.push(['enableLinkTracking']);
		  (function() {
		    var u="//www.stats.numberchallenge.com/";
		    _paq.push(['setTrackerUrl', u+'piwik.php']);
		    _paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
		    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
		    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
		  })();
		</script>
		<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>
		<!-- End Piwik Code -->

	</head>
	<body>
		<nav class="navbar navbar-inverse navbar-static-top navbar-custom">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav text-center">
						<li>
							<a href="<?php echo $base_url ?>" class="text-uppercase fnt-800">
								<?=$info['domain'] ?>
							</a>
						</li>
						<li>
							<a href="/buy">
								Buy/Partner Domains
							</a>
						</li>
						<li>
							<a href="/home/about">
								About
							</a>
						</li>
						<li>
							<a href="/home/apps">
								Apps
							</a>
						</li>
					</ul>
				</div><!-- /.navbar-collapse -->
			</div><!-- /.container-fluid -->
		</nav>