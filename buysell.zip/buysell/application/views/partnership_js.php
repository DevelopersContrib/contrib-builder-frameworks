<script type="text/javascript">
$(document).ready(function() {
    /* var urlRegex = /(ftp|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/; */
    var urlRegex = /https:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;
    var numberRegex = /^[0-9]+$/;
    var emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var partnerData = {};

    $('.input-form-1').on('keypress',function(e) {
        let key = e.which || e.keyCode;
        
        if (key === 13) {
            $('#first-btn').trigger('click');
        }
    });

    $('.input-form-2-1').on('keypress',function(e) {
        let key = e.which || e.keyCode;
        
        if (key === 13) {
            $('#second-btn').trigger('click');
        }
    });

    $('.input-form-2-2').on('keypress',function(e) {
        let key = e.which || e.keyCode;
        
        if (key === 13) {
            $('#third-btn').trigger('click');
        }
    });

    /*$('#city').keyup(function(){
        var country = $('#country').children('option').filter(':selected').text();
        $('#city').autocomplete({
            search  : function(){$(this).addClass('working');},
            open    : function(){	
                        $(this).removeClass('working');
                        $('ul.ui-menu').css({'z-index':'1000','border-radius':'0','border-color':'#fff','class':'form-control'});
                    },
            source: 'https://www.contrib.com/network/autocompleteCity/'+country,
            minLength: 2,
            select: function (event, ui) {   
                var selectedObj = ui.item;
                var city = selectedObj.value;
                $('#city').text(city);	
                $(this).removeClass('working');
            },
                error:function() {
                $(this).removeClass('working');
                alert('error sys');
            },
            failure: function() {
                $(this).removeClass('working');
                alert('error fasds');
            },
            response: function(event, ui) {
            if (ui.content.length === 0) {
                    $(this).val('');
                    $(this).removeClass('working');
                    $(this).removeClass(' ui-autocomplete-input');
                } else {
                    $(this).empty();
                    $(this).removeClass('working');
                    $(this).removeClass(' ui-autocomplete-input');
                }
            }
        });
    });*/

    $('#first-btn').on('click',function() {
        var partnerType = $('#partnershiptype').val();
		var fname = $('#firstname').val();
		var lname = $('#lastname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var cpassword = jQuery('#cpassword').val();
		var message = $('#message').val();
		var domain = '<?php echo $info['domain']?>';

        $('.fg-error-container').removeClass('has-error-text');
		
		if (!partnerType) {
            showAlert('#pt-container','#partnershiptype-error','Please choose a partnership type');
        } else if (!fname) {
            $('#firstname').focus();
            showAlert('#fn-container','#firstname-error','Please enter your first name');
        } else if (numberRegex.test(fname)) {
            $('#firstname').focus();
            showAlert('#fn-container','#firstname-error','Please enter a valid name');
        } else if(fname.length < 3) {
            showAlert('#fn-container','#firstname-error','First name must be atleast 3 characters long.');
        } else if (!lname) {
            $('#lastname').focus();
            showAlert('#ln-container','#lastname-error','Please enter your name');
        } else if (numberRegex.test(lname)) {
            $('#lastname').focus();
            showAlert('#ln-container','#lastname-error','Please enter a valid name');
        } else if(lname.length < 3) {
            showAlert('#ln-container','#lastname-error','First name must be atleast 3 characters long.');
        } else if (!email) {
            $('#email').focus();
            showAlert('#em-container','#email-error','Please enter your email address');
        } else if (!emailRegex.test(email)) {
            $('#email').focus();
            showAlert('#em-container','#email-error','Please enter a valid email address');
        } else if (!password) {
            $('#password').focus();
            showAlert('#ps-container','#password-error','Please enter your password');
        } else if (password.length < 8) {
            $('#password').focus();
            showAlert('#ps-container','#password-error','Password must be atleast 8 characters long');
        } else if (!cpassword) {
            $('#cpassword').focus();
            showAlert('#cps-container','#cpassword-error','Please confirm your password');
        } else if (password !== cpassword) {
            $('#cpassword').focus();
            showAlert('#cps-container','#cpassword-error','Password does not match');
        } else if (!message) {
            $('#message').focus();
            showAlert('#m-container','#message-error','Please enter your message');
        } else {
            partnerData.partnertype = partnerType;
            partnerData.firstname = fname;
            partnerData.lastname = lname;
            partnerData.email = email;
            partnerData.password = password;
            partnerData.message = message;
            partnerData.domain = domain;

		   	$('#first-form').addClass('hide');
			$('#second-form').removeClass('hide');
        }
    });

    $('#second-btn-back').on('click',function() {
        $('#second-form').addClass('hide');
        $('#first-form').removeClass('hide');
    });

    $('#second-btn').on('click',function() {
        /* var state = $('#state').val(); */
		/* var company = $('#company').val(); */
		var phone = $('#phone').val();
		var countryId = $('#country').val();
		var country = $("#country :selected").text();
		var city = $('#city').val();
		var website = $('#website').val();
		
        $('.fg-error-container').removeClass('has-error-text');
        $('#website').focus();

        if (website && !urlRegex.test(website)) {
            $('#website').focus();
            showAlert('#w-container','#website-error','Please enter a valid URL (https://)');
        } /* else if (!company) {
            showAlert('#company-container','#company-error','Please enter your company name');
        } */ else if (!phone) {
            showAlert('#phone-container','#phone-error','Please enter your company phone number');
        } else if (!numberRegex.test(phone)) {
            $('#phone').focus();
            showAlert('#phone-container','#phone-error','Please enter a valid phone number');
        } else if (!city) {
            $('#city').focus();
            showAlert('#city-container','#city-error','City is required');
        } else {
            partnerData.website = website;
            partnerData.country_id = countryId; 
            partnerData.country = country; 
            partnerData.city = city;
            partnerData.phone = phone;
            partnerData.exchange_url = ''; 
			$('#second-first').addClass('hide');
			$('#second-second').removeClass('hide');
        }
    });

    $('#third-btn-back').on('click',function() {
        $('#second-second').addClass('hide');
        $('#second-first').removeClass('hide');
    });

    $('#third-btn').on('click',function() {
        var companyTitle = $('#companytitle').val();
		var companyDesc = $('#companydesc').val();
		var companyImage = $('#companyimage').val();
		var companyLink = $('#companylink').val();

        $('.fg-error-container').removeClass('has-error-text');
        $('#companytitle').focus();

       if (!companyTitle) {
            $('#companytitle').focus();
            showAlert('#companytitle-container','#companytitle-error','Please enter company title');
        } else if (!companyDesc) {
            $('#companydesc').focus();
            showAlert('#companydesc-container','#companydesc-error','Please enter company description.');
        } else if (companyImage && !urlRegex.test(companyImage)) {
            $('#companyimage').focus();
            showAlert('#companyimage-container','#companyimage-error','Invalid company image URL');
        //} // else if (!companyLink) {
            //$('#companylink').focus();
            //showAlert('#companylink-container','#companylink-error','Please enter your company URL');
        }  else if (companyLink && !urlRegex.test(companyLink)) {
            $('#companylink').focus();
            showAlert('#companylink-container','#companylink-error','Invalid company URL (https://)');
        } else {
            partnerData.company = companyTitle;
            partnerData.companydesc = companyDesc;
            partnerData.companyimage = companyImage;
            partnerData.companyurl = companyLink;
            checkEmail();
        }
    });

    var showAlert = (container,errorContainer,message) => {
        $(container).addClass('has-error-text');
		$(errorContainer).html(message);
    }

    var checkEmail = () => {
        $.ajax({
            url: 'https://www.contrib.com/signup/checkexist',
            method: 'POST',
            data: { 'field':'EmailAddress','value':partnerData.email },
            beforeSend: function() {
                $('#loader-end').removeClass('hide');
            },
            success: function(res) {
                if (res.status) {
                    $('#loader-end').addClass('hide');
                    alert('Email already exists');
                    return false;
                }
                savePartner();
            },
            complete: function() {
        
            },
        });
    }

    var savePartner = () => {
        $.ajax({
            url: 'https://www.contrib.com/forms/save_partner',
            method: 'POST',
            data: partnerData,
            beforeSend: function() {
        
            },
            success: function(res) {
                /* $('#loader-end').fadeOut();
                $('#process-form').fadeOut();
                $('#success_page').fadeIn(); */
                if (res.success) {
                    $('#loader-end').addClass('hide');
                    $('#process-form').addClass('hide');
                    $('#success_page').removeClass('hide');
                    $('#button_redirect').html('<a class="btn btn-success btn-lg btn-block" id="resend_email" href="https://www.contrib.com/account/autologinforms?email='+res.email+'&form=partnership">Go to your contrib account</a>');

                    saveLead();
                }
            },
            complete: function() {
        
            },
        });
    }

    var saveLead = () => {
        leadData = {
            city:partnerData.city,
            country:partnerData.country,
            domain:partnerData.domain,
            email:partnerData.email,
            firstName:partnerData.fname,
            form_type:'VNOC Partnership',
            lastName:partnerData.lname,
            message:partnerData.message,
            partner_type:partnerData.partner_type,
            phone:partnerData.phone,
            state:'',
            street:'',
            title:partnerData.company,
            zip:''
        }

        $.ajax({
            url: 'https://manage.vnoc.com/salesforce/addlead',
            method: 'POST',
            data: leadData,
            beforeSend: function() {
        
            },
            success: function(res) {
        
            },
            complete: function() {
        
            },
        });
    }
});
</script>