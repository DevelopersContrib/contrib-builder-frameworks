<?php global $footer_html?>
<footer class="footer text-center hide">
      <div class="container">
        <a href="<? echo $base_url?>">Home</a>
		<a href="<? echo $base_url?>home/about">About</a>
		<a href="<? echo $base_url?>home/terms">Terms</a>
		<a href="<? echo $base_url?>home/privacy">Privacy</a>
		<a href="<? echo $base_url?>home/apps">Apps</a>
		<!--<a href="<?// echo $base_url?>home/contact">Contact</a>-->
      </div>
</footer>

<style>
	/* Dark Footer */
	.text-capitalize{
		text-transform: capitalize;
	} 	
	.text-uppercase{
		text-transform: uppercase;
	}
	.footer-dark-1,.footer-dark-2{
		line-height: 20px;
	}
	.footer-dark-1 .text-g1,.footer-dark-2 .text-g1{
		color: #ccc;
	}
	.footer-dark-1 .f-a-links a,.footer-dark-2 .f-a-links a{
		color: #ccc;
	}
	.footer-dark-1 .f-a-links a:hover, .footer-dark-2 .f-a-links a:hover{
		color: #e1e1e1;
		text-decoration: none;
	}
	.footer-dark-1{
		color: #fff;
		padding: 60px 0 50px;
		background-color: #333;
	}
	.footer-dark-1 h3{
		margin-top: 0;
	}
	.fnt-bold{
		font-weight: bold;
	}
	.footer-dark-2{
		color: #fff;
		padding: 25px 0;
		background-color: #222;
	}
	.footer-dark-2 ul.list-inline{
		margin-bottom: 0;
	}
	.socials-ul li{
		padding-right: 0;
		padding-left: 0;
	}
	/* Black B */
	.footer-dark-1.footer-dark-b-1{
		background-color: #020202;
	}
	.footer-dark-2.footer-dark-b-2{
		background-color: #0e0e0e;
	}


	/* For Social Media Style Brand Details */
	/* Wrapper */
	.icon-button {
		border-radius: 0.6rem;
		cursor: pointer;
		display: inline-block;
		font-size: 2.0rem;
		height: 3rem;
		line-height: 3rem;
		position: relative;
		text-align: center;
		-webkit-user-select: none;
		-moz-user-select: none;
		-ms-user-select: none;
		user-select: none;
		width: 3rem;
	}

	/* Circle */
	.icon-button span {
		border-radius: 0;
		display: block;
		height: 0;
		left: 50%;
		margin: 0;
		position: absolute;
		top: 50%;
		-webkit-transition: all 0.3s;
		-moz-transition: all 0.3s;
		-o-transition: all 0.3s;
		transition: all 0.3s;
		width: 0;
	}
	.icon-button span {
		width: 3rem;
		height: 3rem;
		border-radius: 0.6rem;
		margin: -1.5rem;
	}
	.twitter span {
		background-color: #4099ff;
	}
	.facebook span {
		background-color: #3B5998;
	}
	.google-plus span {
		background-color: #dd4b39;
	}
	.youtube span {
		background-color: #bb0000;
	}
	.pinterest span {
		background-color: #cb2027;
	}
	.angellist span {
		background-color: #000;
	}
	.github span {
		background-color: #000;
	}
	.linkedin span {
		background-color: #007bb6 ;
	}
	.tumblr span {
		background-color: #36465d ;
	}
	.foursquare span {
		background-color: #0072b1 ;
	}

	/* Icons */
	.icon-button i {
		background: none;
		color: white;
		height: 3rem;
		left: 0;
		line-height: 3rem;
		position: absolute;
		top: 0;
		width: 3rem;
		z-index: 10;
	}
	/* For Image iCons */
	.social-img-icon-a{
		border-radius: 0.6rem;
		display: block;
		height: 30px;
		overflow: hidden;
		width: 30px;
	}
	.social-img-icon-a img{
		height: 30px;
	}
</style>
<div class="footer-dark-1 footer-dark-b-1">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							<?=ucwords($info['domain'])?>
						</h3>
						<p>
							is a new business model, Technology, and Solution targeting the premium domain channel with a fast, affordable, high quality business creation and management platform. 
						</p>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							company
						</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>">
									home
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/about">
									about
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/terms">
									terms
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/privacy">
									privacy
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/cookie">
									cookie policy
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="http://www.domaindirectory.com/policypage/unsubscribe?domain=<?=$info['domain']?>" target="_blank">
									Unsubscribe
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/apps">
									Apps
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3 col-md-offset-3">
						<h3 class="fnt-bold text-uppercase">
							partners
						</h3>
						<p>
							<?if($footer_html != ""):?>
							<?echo base64_decode($footer_html)?>
								<?php else:?>
								<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
							<?endif;?>							
						</p>
						<h3 class="fnt-bold text-uppercase">
							Socials
						</h3>
						<ul class="list-inline socials-ul">
							<li>
								<a title="twitter" class="icon-button twitter" href=" <?php echo $social_twitter ;?> ">
									<i class="fa fa-twitter"></i>
									<span></span>
								</a>
							</li>
							<li>
								<a title="facebook" class="icon-button facebook" href=" <?php echo $social_fb ?> ">
									<i class="fa fa-facebook"></i>
									<span></span>
								</a>
							</li>										
							<li>
								<a title="linkedin" class="icon-button linkedin" href=" <?php echo $social_linkedin; ?> ">
									<i class="fa fa-linkedin"></i>
									<span></span>
								</a>
							</li>
							
							<li>
								<a title="youtube" class="icon-button youtube" href="<?php echo $social_gtube;  ?> ">
									<i class="fa fa-youtube"></i>
									<span></span>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer-dark-2 footer-dark-b-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6 f-a-links">
						&copy; <?=date('Y')?> <a class="text-capitalize " href=""><?=ucwords($info['domain'])?></a>. All Rights Reserved. 
					</div>
					<div class="col-md-6">
						<ul class="list-inline text-right f-a-links">
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>">
									<i class="fa fa-home"></i>
									home
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/about">
									<i class="fa fa-bookmark-o"></i>
									About us
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/terms">
									<i class="fa fa-book"></i>
									Terms
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="<? echo $base_url?>home/privacy">
									<i class="fa fa-cube"></i>
									privacy
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- /CONTENT ============-->

	<!-- script references -->
		
		<script src="js/bootstrap.min.js"></script>
		<div id="chat_content" data="<?=$info['domain']?>"></div>
		<script type="text/javascript" src="https://tools.contrib.com/js/chat.js"></script>
		<!-- <script src="http://getbootstrap.com/assets/js/docs.min.js"></script> -->
		<script>
		$('#popoverData').popover();		
		$('#popoverData1').popover();
		$('#popoverData2').popover();
		$('#popoverData3').popover();
		$('#popoverData4').popover();
		$('#popoverData5').popover();
		$('#popoverOption').popover({ trigger: "hover" });
		</script>
	</body>
</html>