

<footer class="footer text-center">
      <div class="container">
        <a href="<? echo $base_url?>">Home</a>
		<a href="<? echo $base_url?>home/about">About</a>
		<a href="<? echo $base_url?>home/terms">Terms</a>
		<a href="<? echo $base_url?>home/privacy">Privacy</a>
		<!--<a href="<?// echo $base_url?>home/contact">Contact</a>-->
      </div>
</footer>
<!-- /CONTENT ============-->

	<!-- script references -->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="http://getbootstrap.com/assets/js/docs.min.js"></script>
		<script>
		$('#popoverData').popover();		
		$('#popoverData1').popover();
		$('#popoverData2').popover();
		$('#popoverData3').popover();
		$('#popoverData4').popover();
		$('#popoverData5').popover();
		$('#popoverOption').popover({ trigger: "hover" });
		</script>
	</body>
</html>