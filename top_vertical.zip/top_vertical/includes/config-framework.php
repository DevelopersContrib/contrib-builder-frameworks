<?php

    $domain =   "applications.com";
    $domainid = "";
    $memberid = "";
    $title = "";
    $logo =  "";
    $category_id = "162";
    $category_name = "Technology";
    $is_subdomain = "";
    $description = "";
    $keywords = "applications";
    $account_ga = "";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "https://cdn.vnoc.com/background/tech1.jpg";
    $fb_page =  "";
    $twitter = "";
    $bottom_text  = "";
    $forsale = "";
    $forsaledefault = "";
	$forsaletext = "";
    $footer_banner = "";
    $domain_affiliate_link = "https://referrals.contrib.com/idevaffiliate.php?id=77&url=https://www.contrib.com/signup/firststep?domain=applications.com";
    $affiliate_id = "77";
    $additional_html = "";
    $footer_html = "";
    $piwik_id = '';
    $related_domains = NULL;
    $fund_campaigns = NULL;
    $partners = array (
  0 => 
  array (
    'partner_id' => 25201,
    'summary' => 'Contribute your Skills, Services, Apps, Contacts or Capital, part-time. Help a team of other passionate people doing amazing things. Come learn and earn! Amazing things happen with the right people, technology, business model, resources and passion. Earn equity ownership, Learn from other great people, Lead a venture and distribute up to 2% of the shares to your charity.',
    'company_name' => 'Contrib.com',
    'domain' => 'applications.com',
    'url' => 'http://www.contrib.com',
    'approved_by' => 10,
    'date_applied' => '2014-11-04T01:42:44.000Z',
    'approved' => 1,
    'image' => 'http://cdn.vnoc.com/logos/logo-new-contrib-06.png',
    'member_id' => 7,
    'approved_status' => 'approved',
    'slug' => 'contrib-applications-com',
    'type' => 'Added Value Marketing Partnerships',
    'partner_views' => 0,
    'link_type' => 'link',
    'code' => NULL,
    'is_custom' => 0,
    'description' => 'We are a community of Entrepreneurs, Developers, Designers, Marketers and Specialists from around the world building, managing and monetizing virtual businesses on premium domains for equity and cash grants.',
    'exchange_url' => NULL,
    'ld_id' => 0,
    'ld_url' => NULL,
    'in_equity' => 1,
  ),
  1 => 
  array (
    'partner_id' => 1240,
    'summary' => 'Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.',
    'company_name' => 'GlobalVentures.com',
    'domain' => 'applications.com',
    'url' => 'http://globalventures.com',
    'approved_by' => 10,
    'date_applied' => '2014-11-04T01:32:37.000Z',
    'approved' => 1,
    'image' => 'http://cdn.vnoc.com/logos/image_logo-gventures10-420x60.png',
    'member_id' => 7,
    'approved_status' => 'approved',
    'slug' => 'globalventures-applications-com',
    'type' => 'Added Value Marketing Partnerships',
    'partner_views' => 0,
    'link_type' => 'link',
    'code' => NULL,
    'is_custom' => 0,
    'description' => 'With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.',
    'exchange_url' => NULL,
    'ld_id' => 0,
    'ld_url' => NULL,
    'in_equity' => 1,
  ),
);
    $programs = array (
  0 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=77_15_1_50&idev_domain=applications.com&idev_product=22" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/talentdirect-logo.jpg" width="243" height="131" alt="Become a Talent" title="Become a Talent"></a>',
    'title' => 'Featured Extras',
  ),
  2 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=77_16_1_55&idev_domain=applications.com&idev_product=15" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/50.jpg" width="110" height="140" alt="shareasale-magazinedealsnow" title="shareasale-magazinedealsnow"></a>',
    'title' => 'Refer Homeowner',
  ),
  3 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=77_5_1_36" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-socialId-728x90-1.png" width="728" height="90" alt="Social Id Banners" title="Social Id Banners"></a>',
    'title' => 'SocialId',
  ),
  4 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=77_4_1_25" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/handyman-badge-4.png" width="170" height="200" alt="handyman badge 4" title="handyman badge 4"></a>',
    'title' => 'Handyman',
  ),
  5 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=77_1_1_3" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-2.png" width="150" height="150" alt="Proud Member of Contrib" title="Proud Member of Contrib"></a>',
    'title' => 'Contrib',
  ),
  6 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=77_6_1_38" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-virtualinterns-250x250-1.png" width="250" height="250" alt="" title=""></a>',
    'title' => 'VirtualInterns',
  ),
);
    $social_fb = 'https://www.facebook.com/applicationsofficial';
    $social_gplus = 'google.com/+ApplicationsOfficial';
    $social_twitter = 'http://twitter.com/Applications_';
    $social_linkedin = 'https://www.linkedin.com/company/applications-com';
    $social_gtube = 'youtube.com/c/ApplicationsOfficial';
    $topsites = array (
  0 => 
  array (
    'domain_name' => 'startupchallenge.com',
    'logo' => 'https://cdn.vnoc.com/logos/image_startupchallenge-big-300x60.png',
    'description' => 'Join our exclusive community of like minded people on startupchallenge.com',
    'title' => '',
  ),
  1 => 
  array (
    'domain_name' => 'ifund.com',
    'logo' => 'https://cdn.vnoc.com/logos/ifund.png',
    'description' => 'iFund is a blockchain based insurance system and mechanism for digital smart entities.  The smart contract platform currently backs and stabilizes entity value of eShares (ESH) through a dynamic pledging system.  iFund is truly the first automated insurance system for digital assets, onchain.  ',
    'title' => 'iFund, i-Fund',
  ),
  2 => 
  array (
    'domain_name' => 'entrepreneurs.org',
    'logo' => 'https://cdn.vnoc.com/logos/logo-entrepreneurs1.png',
    'description' => 'Join our exclusive community of like minded people on entrepreneurs.org',
    'title' => 'Entrepreneurs.org',
  ),
  3 => 
  array (
    'domain_name' => 'venturebook.com',
    'logo' => 'https://cdn.vnoc.com/logos/logo-VentureBook.png',
    'description' => 'Join our exclusive community of like minded people on venturebook.com',
    'title' => 'Venturebook.com',
  ),
  4 => 
  array (
    'domain_name' => 'channeltv.com',
    'logo' => 'https://cdn.vnoc.com/logos/logo-ChannelTv.png',
    'description' => 'Help our TV community to grow! Join us and watch hundreds of movies everyday!',
    'title' => 'Welcome to channeltv.com : Help our TV community to grow! Join us and watch hundreds of movies everyday!',
  ),
  5 => 
  array (
    'domain_name' => 'referrals.com',
    'logo' => 'https://cdn.vnoc.com/logos/logo-new-referral-1.png',
    'description' => 'Most effective Business Referral Program and Tools Available. Find and share referrals locally.',
    'title' => 'Referrals.com - Find and share referrals locally.',
  ),
  6 => 
  array (
    'domain_name' => 'earthchallenge.com',
    'logo' => 'https://cdn.vnoc.com/logos/earthchallenge-white.png',
    'description' => 'Reduce, Reuse, Recycle. The ultimate game to educate, entertain and act around impact programs saving our Earth.   Owned by the players and Contributors, we are a proud IDAG member. 
',
    'title' => 'Welcome to EarthChallenge.com - Join our Challenge Today',
  ),
  7 => 
  array (
    'domain_name' => 'cowork.com',
    'logo' => 'https://cdn.vnoc.com/logos/logo-cowork-NEW-1.png',
    'description' => 'Come Learn and Earn and Contribute Value with other great professionals on leading Tech Ventures.',
    'title' => 'Cowork.com',
  ),
  8 => 
  array (
    'domain_name' => 'ethpoll.com',
    'logo' => 'https://vnoclogos.s3-us-west-1.amazonaws.com/LOGO-ETHPOLL-LOGO.png',
    'description' => 'Join our exclusive community of like minded people on ethpoll.com',
    'title' => 'Welcome to ethpoll.com',
  ),
  9 => 
  array (
    'domain_name' => 'consultants.com',
    'logo' => 'https://cdn.vnoc.com//logos//logo-consultants1.png',
    'description' => 'Join our exclusive community of like minded people on consultants.com',
    'title' => 'Consultants',
  ),
);

?>