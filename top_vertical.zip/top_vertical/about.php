<?php include('header.php');?>

<style>
.navbar-transparent {
    background-color: #222;
    border-color: #080808;
}
.top-container {
	padding: 135px 0px 50px;
}
footer {    
    padding-top: 0px;
}
.about-container {
	padding: 80px 0px 100px;
}
.about-container .about-title {
    font-size: 80px;
    font-weight: 900;
    margin: 0px 0px 10px;
	text-transform: uppercase;
}
.about-box {
    background: #fff;
    box-shadow: 0 5px 15px rgba(18,20,22,0.08);
    border: 1px solid #ddd;
    padding: 30px;
    border-radius: 4px;
    margin-bottom: 15px;
}
.about-box h3 {
	font-weight: 600;
	font-size: 40px;
	text-transform: uppercase;
}
</style>
    <!-- Main -->
    <div class="top-container">
        <div class="container">
			<div class="row">
				<div class="col-md-6 offset-md-3 text-center">
					<h1 class="display-3">
						About Us
					</h1>					
				</div>				
			</div>            
        </div>
    </div>	
	<div class="about-container">
		<div class="container text-center">
			<div class="row">
				<div class="col-md-12">
					<h2 class="about-title">20 Years</h2>
				</div>
				<div class="col-md-6 offset-md-3 text-center">
					<div class="about-box">
						<h3>
							We have been in the forefront of domain development and technologies since 1996
						</h3>						
					</div>
				</div>				
			</div>
		</div> 
	</div>	

	<!-- footer -->
	<?php include('footer.php');?>
