<?php include('header.php');?>
<!-- Main -->
<div class="top-container">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="intro-box">
					<h1 class="display-3">
						<?php echo $description; ?>
						<!-- <span class="text-warning"><?php echo ucfirst($domain); ?></span> -->
					</h1>
					<div class="col-md-12">
					    <?php if ($is_subdomain == '1'):?>
							<a class="btn btn-warning btn-lg" data-toggle="collapse" data-target="#collapseTodo" aria-expanded="false" aria-controls="collapseExample">Join Our <?php echo $category_name?> Vertical</a>
							<?php else:?>
							<a class="btn btn-warning btn-lg" data-toggle="collapse" data-target="#collapseTodo" aria-expanded="false" aria-controls="collapseExample">Join <?php echo ucfirst($domain)?></a>
						<?php endif;?>
						<div class="collapse" id="collapseTodo">
							<div class="todo-box mt-3">
								<div class="row">
									<div class="col-lg-12">
										<h3>What do you want to do?</h3>
									</div>
									<a href="#topverticals" class="col-lg-4">
										<div class="what-box">
											<h3>Partner With Our Top Sites</h3>
											<img class="img-fluid" src="https://cdn.vnoc.com/assets/referrals/icon-sites.png">
										</div>
									</a>
									<a href="#services" class="col-lg-4">
										<div class="what-box">
											<h3>Contribute To Our Eservices</h3>
											<img class="img-fluid" src="https://cdn.vnoc.com/assets/referrals/icon-services.png">
										</div>
									</a>
									<a href="#referralcampaign" class="col-lg-4">
										<div class="what-box">
											<h3>Join Our Referral Campaigns</h3>
											<img class="img-fluid" src="https://cdn.vnoc.com/assets/referrals/icon-campaigns.png">
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>					
				</div>				
			</div>				
		</div>            
	</div>
</div>	
<div class="what-container">
	<div class="container text-center">
		<div class="row">
			<div class="col-md-12">
				<h2 class="what-title">What We Do</h2>
			</div>
			<div class="col-lg-4">
				<div class="what-box">
					<h3>Build Brands</h3>
					<img class="img-fluid" src="https://rdbuploads.s3.amazonaws.com/vertical/icons/icon-build-brands.png">
					<p>We have the best techonology contributors and inhouse staff that builds great brands.</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="what-box">
					<h3>Build Products</h3>
					<img class="img-fluid" src="https://rdbuploads.s3.amazonaws.com/vertical/icons/icon-build-products.png">
					<p>Using our Contrib/VNOC model we are able to build web products vertically but still we need help.</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="what-box">
					<h3>Build Verticals</h3>
					<img class="img-fluid" src="https://rdbuploads.s3.amazonaws.com/vertical/icons/icon-build-verticals.png">
					<p>Using Globalventures portfolio, we build products around our verticals and create synergy within and outside our portfolio.</p>
				</div>
			</div>
		</div>
	</div> 
</div>
<div class="why-container">
	<div class="container text-center">
		<div class="row">
			<div class="col-md-12">
				<h2 class="why-title">Why Choose Us</h2>
				<h5 class="why-sub">We have build a reputation for great customer service and unique idea execution. Our model is unique in terms of a distributed managed and owned asset pool in which anyone can contribute to value creation and stakeholder ownership.</h5>
			</div>
			<div class="col-lg-3">
				<div class="why-icon">
					<img class="img-fluid" src="https://rdbuploads.s3.amazonaws.com/vertical/icons/icon-founded.png">
					<div class="why-desc">
						<h1 class="why-stats">1998</h1>
						<h5>Founded</h5>
					</div>
				</div>					
			</div>
			<div class="col-lg-3">
				<div class="why-icon">
					<img class="img-fluid" src="https://rdbuploads.s3.amazonaws.com/vertical/icons/icon-contributors.png">
					<div class="why-desc">
						<h1 class="why-stats"><?php echo number_format($count_contributors)?>+</h1>
						<h5>Active Contributors</h5>
					</div>
				</div>					
			</div>								
			<div class="col-lg-3">
				<div class="why-icon">
					<img class="img-fluid" src="https://rdbuploads.s3.amazonaws.com/vertical/icons/icon-domains.png">
					<div class="why-desc">
						<h1 class="why-stats"><?php echo number_format($count_domains)?></h1>
						<h5>Domains</h5>
					</div>
				</div>					
			</div>				
			<div class="col-lg-3">
				<div class="why-icon">
					<img class="img-fluid" src="https://rdbuploads.s3.amazonaws.com/vertical/icons/icon-members.png">
					<div class="why-desc">
						<h1 class="why-stats"><?php echo number_format($count_members)?></h1>
						<h5>Members</h5>
					</div>
				</div>					
			</div>				
		</div>
	</div> 
</div>
<?php if (count($referral_campaigns)>0):?>
<div class="campaign-container" id="referralcampaign">
	<div class="container text-center">
		<div class="row">
			<div class="col-md-12">
				<h2 class="campaign-title">Latest Referral Campaigns</h2>
			</div>
			<div class="col-md-12">
				<div class="row">
					<?php foreach ($referral_campaigns as $camp):?>
					<div class="col-md-4 d-flex col-cc">
					  <?php if ($camp['b_type']=='image'):?>
						  <div class="campaign-box text-left" style="background-image: url('<?php echo $camp['b_image']?>');">
						   <?php else:?> 
						    <div class="campaign-box text-left" style="background-image: url('https://cdn.vnoc.com/background/pexels-photo-1092373.jpeg');">
					  <?php endif?>	
					  	<h4 class="campaign-box-title"><?php echo $camp['name']?></h4>
							<p class="campaign-desc">Rewarded participants: <?php echo $camp['rewarded']?></p>
							<a href="<?php echo $camp['url']?>" class="btn btn-danger float-right" target="_blank">Refer and Earn</a>
							
							<div class="campaign-domain">
								<a target="_blank" href="<?php echo $camp['d_url']?>">
								<i class="fa fa-bullhorn" aria-hidden="true"></i>&nbsp;<?php echo ucfirst($camp['domain'])?></a>
							</div>
							
							</div>
						</div>
								
						<?php endforeach;?>
						</div>
					</div>			
				</div>			
				
	</div> 
</div>	
<?php endif?>
<div class="services-container" id="services">
	<div class="container text-center">
		<div class="row">
			<div class="col-md-12">
				<h2 class="services-title">Top Tasks on <?php echo ucfirst($category_name)?> Vertical</h2>
			</div>
			<div class="services-box">
				<script type="text/javascript" src="https://tools.contrib.com/eservice/latest?d=referrals.com"></script>
			</div>
		</div>
	</div>
</div>
<div class="vertical-container" id="topverticals">
	<div class="container text-center">
		<div class="row">
			<div class="col-md-12">
				<h2 class="vertical-title">Top <?php echo ucfirst($category_name)?> Sites </h2>
			</div>
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-8 offset-md-2">
					<form action="https://www.domaindirectory.com/search" id="searchform" target="_blank">
						<div class="search-group search-group-lg mb-3">
							<input type="text" class="search-control" placeholder="Search..." id="keyword" name="keyword" />
							<div class="search-group-append">
								<button class="search-btn search-btn-primary" type="submit">
									<i class="fa fa-search"></i>
								</button>
							</div>
						</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="vertical-middle-container pt-5">
	<div class="container text-center">
		<div class="row">
		  <?php if (count($top_domains)>0):?>
		     <?php foreach ($top_domains as $top):?>
        			<div class="col-md-3">
        				<a target="_blank" href="<?php echo $top['url']?>">
        				<i class="fa fa-globe" aria-hidden="true"></i>&nbsp;<?php echo ucfirst($top['domain'])?></a>
        			</div>
			<?php endforeach;?>
		 <?php endif;?>	
			
			
		</div>
	</div>		
</div>
<div class="back-to-top"><i class="fa fa-angle-up fa-3x"></i></div>

<script type="text/javascript">

	$('#btn-submit').click(function(){
		
		var txtEmail = $('#txt-email').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var url = 'https://www.contrib.com/forms/saveleads';
		var domain = $('#domain').val();
		var user_ip = $('#user_ip').val();
		var secret = $('#secret').val();

		if (txtEmail === '') {
			errorMessage('Email is Required');
		} else if(!emailfilter.test(txtEmail)) {
			errorMessage('Email is Invalid');
		} else {
			$.ajax({
				type: 'POST',
				url: url,
				data: { 'email':txtEmail, 'domain':domain,'user_ip':user_ip,'secret':secret },
				dataType:'json',
				beforeSend:function(){
					$('.warning-error').addClass('d-none');
					$('#btn-submit').attr('disabled','disabled').html('Please Wait ...');
				},
				success:function(data){
					if (data.success === 'success') {
						$('.success-box').removeClass('d-none');
						$('.intro-box').addClass("d-none");
						$('#btn-submit').removeAttr('disabled','disabled').html('Join Us');
						$('#pemail').val(txtEmail);
					} else {
						$('#btn-submit').removeAttr('disabled','disabled').html('Join Us');
						errorMessage('Sorry for Inconvenince Please try again later.');
					}
				},
				error:function(){
					alert('error');
				}
			});
		}
	});

	function errorMessage(msg) {
		$('.warning-error').removeClass('d-none');
		$('.warning-error').html(msg);
		setTimeout(function() {
			$('.warning-error').addClass('d-none');
		}, 4000);
	}

</script>
<!-- footer -->
<?php include('footer.php');?>
