<footer>
	   <div class="footer-dark-1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase text-warning">
									<?php echo ucfirst($domain) ?>									
								</h3>
								<p>
									<?php echo $description; ?>								
								</p>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase text-warning">
									get started
								</h3>
								<ul class="list-unstyled f-a-links">
									<li>
										<a href="/partners" class="text-capitalize">
											Partner with us
										</a>
									</li>
									<li>
										<a href="/staffing" class="text-capitalize">
											Apply now
										</a>
									</li>
									<li>
										<a href="/referral" class="text-capitalize">
											referral
										</a>
									</li>									
									<li>
										<a href="/developers" class="text-capitalize">
											developers
										</a>
									</li>
								</ul>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase text-warning">
									company
								</h3>
								<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
									<li>
										<a href="/about" class="text-capitalize">
											About us
										</a>
									</li>
									<li>
										<a href="/terms" class="text-capitalize">
											Terms
										</a>
									</li>
									<li>
										<a href="/policy" class="text-capitalize">
											Privacy
										</a>
									</li>
									<li>
										<a href="/contact" class="text-capitalize">
											Contact us
										</a>
									</li>
								</ul>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase text-warning">
									partners
								</h3>
								<p>
								<br><br> <a href="https://goo.gl/H1gdhi" target="_blank"><img style="border:0px;height: 65px !important;width: ;width: 225px !important;"
										src="https://rdbuploads.s3.amazonaws.com/banners/banner-ctb%20earn%20ctb%20tokens.png" alt="Crypto Contrib"
										title="Crypto Contrib"></a>
								<link rel="stylesheet" type="text/css" href="https://tools.contrib.com/css/jquery.glue.css">
								<script src="https://tools.contrib.com/js/jquery.glue.min.js"></script>
								<script src="https://tools.contrib.com/js/glue.js"></script>
								<div id="beforeyougo" style="display:none;" class="glue_popup glue_container">
									<div class="glue_close" onclick="$.glue_close()">X</div>
									<div class="glue_content">
										<div class="wrap-exit-content text-center"><img class="logo-exit-ctb" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/icons/currency-ctb-4.png"
												alt="">
											<h1 class="bg-ttle-exit"> Hello!</h1>
											<p> We invite you to our First Movers Opportunity with our <br>CTB crypto token sale starting <b class="text-danger">October
													12, 2017</b>.<br>Amazing Opportunities with world leading digital assets like Streaming.com,
												Applications.com and
												others. Learn more and get updates.<br></p>
											<p> <a href="https://goo.gl/YNSjTg" class="btn btn-lg btn-warning" target="_blank"> <i class="fa fa-check"></i>
													Get
													Started</a></p>
											<p> <a href="javascript:;" onclick="$.glue_close()" class="help-block"> <small>No, thanks I am not
														interested to be
														part owner.</small></a></p>
										</div>
									</div>
								</div>
								</p>
								<h3 class="fnt-bold text-uppercase text-warning">
									Socials
								</h3>
								<ul class="list-inline socials-ul">
									<li class="list-inline-item">
										<a title="twitter" class="icon-button twitter" href="<?php echo $social_twitter; ?>">
											<i class="fa fa-twitter-square"></i>
											<span></span>
										</a>
									</li>
									<li class="list-inline-item">
										<a title="facebook" class="icon-button facebook" href="<?php echo $social_fb; ?>">
											<i class="fa fa-facebook-square"></i>
											<span></span>
										</a>
									</li>
									<li class="list-inline-item">
										<a title="google-plus" class="icon-button google-plus" href="<?php echo $social_gplus; ?>">
											<i class="fa fa-google-plus-square"></i>
											<span></span>
										</a>

									</li>
									<li class="list-inline-item">
										<a title="youtube" class="icon-button youtube" href="<?php echo $social_gtube; ?>">
											<i class="fa fa-youtube-square"></i>
											<span></span>
										</a>
									</li>
									<li class="list-inline-item">
										<a title="linkedin" class="icon-button linkedin" href="<?php echo $social_linkedin; ?>">
											<i class="fa fa-linkedin-square"></i>
											<span></span>
										</a>
									</li>										
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-dark-2">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6 f-a-links">
								© <?php echo date("Y") ?> <a href="" class="text-capitalize "><?php echo ucfirst($domain);?></a>. All Rights Reserved. 
							</div>							
						</div>
					</div>
				</div>
			</div>
		</div>			
	</footer>
	<!-- end footer -->
		
    <!-- End Main-->
	
    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <!-- 
 	   <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"></script> 
     -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
	<script>
	$(window).scroll(function() {
	  if ($(document).scrollTop() > 50) {
		$('nav').addClass('solid');
	  } else {
		$('nav').removeClass('solid');
	  }
	});
	</script>
	</body>
</html>