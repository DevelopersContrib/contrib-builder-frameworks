<?php include('header.php');?>

<style>
.navbar-transparent {
    background-color: #222;
    border-color: #080808;
}
.top-container {
	padding: 135px 0px 50px;
}
footer {    
    padding-top: 0px;
}
.contact-container {
	padding: 80px 0px 100px;
}
.contact-container .contact-title {
    font-size: 80px;
    font-weight: 900;
    margin: 0px 0px 10px;
	text-transform: uppercase;
}
.contact-box {
    background: #fff;
    box-shadow: 0 5px 15px rgba(18,20,22,0.08);
    border: 1px solid #ddd;
    padding: 30px;
    border-radius: 4px;
    margin-bottom: 15px;
}
.contact-box h3 {
}
.iw-header {    
    width: 100%;
}
.col-md-6 {
	float: left;
}
</style>
    <!-- Main -->
    <div class="top-container">
        <div class="container">
			<div class="row">
				<div class="col-md-6 offset-md-3 text-center">
					<h1 class="display-3">
						Contact Us
					</h1>
				</div>				
			</div>            
        </div>
    </div>	
	<div class="contact-container">
		<div class="container text-center">
			<div class="row">				
				<div class="col-md-8 offset-md-2 text-left">
					<div class="contact-box">
						<div class="box-blck">													
							<script type="text/javascript" src="https://tools.contrib.com/contactform?d=<?echo $domain?>"></script>
						</div>
					</div>
				</div>				
			</div>
		</div> 
	</div>	

	<!-- footer -->
	<?php include('footer.php');?>
