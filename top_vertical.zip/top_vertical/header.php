<?php include('includes/config.php');?>
<!DOCTYPE html>
<html lang="en">
<head>       
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
	<title><?php echo ucfirst($domain); ?> - <?php echo $description ?></title>
	<meta name="description" content="<?php echo $description ?>">
	<meta name="keywords" content="<?php echo $description ?>">
	<meta name="author" content="<?php echo $domain; ?>">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto|Raleway:600" rel="stylesheet"> 
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<link rel="stylesheet" href="css/custom.css"/>        
	<script type="text/javascript">
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', '<?=$account_ga?>']);
		_gaq.push(['_trackPageview']);
		(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();
	</script>
	<!-- Piwik -->
	<script type="text/javascript">
		var _paq = _paq || [];
		_paq.push(['trackPageView']);
		_paq.push(['enableLinkTracking']);
		(function() {
			var u="//www.stats.numberchallenge.com/";
			_paq.push(['setTrackerUrl', u+'piwik.php']);
			_paq.push(['setSiteId', <?=$piwik_id?>]);
			var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
			g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
		})();
	</script>
	<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
	<?php if ($background_image == '') {
		$background_image = 'http://d22jxblfxvpcpi.cloudfront.net/backgrounds/watching-the-sun.jpg';
	} ?>
	<style type="text/css">
		html, body {
			height: 100%;
			scroll-behavior: smooth;
		}
		a:hover {
			text-decoration: none;
		}
		.navbar-brand {
			text-transform: capitalize;
			font-size: 21px;
			padding-top: 15px;
			padding-bottom: 15px;
		}
		.nav-link {
			color: rgba(255,255,255,.5);
		}
		.nav-link:hover {
			color: rgba(255,255,255,.9);
		}
		.top-container {
			background:linear-gradient(rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.75)), rgba(0,0,0,0.75) url(<?php echo $background_image; ?>);
			background-size: cover;
			position: relative;
			color: #fff;
			padding: 250px 0px;
		}
		.contrib-task-container .media-heading {
			font-size: 1.2rem;
		}
		.todo-box {
			position: relative;
			color: #ffffff;
			background: rgba(0,0,0,0.3);
			padding: 30px 30px 15px;
			border-radius: 4px;
			transition: 0.5s ease;
		}
		.todo-box a:hover {
			text-decoration: none;
			margin-top: -5px;
			transition: margin-top 0.5s ease;
		}
		.todo-box h3 {
			font-weight: 600;
			margin-bottom: 20px;
		}
		.todo-box .what-box h3 {
			font-weight: 300;
			color: #232323;
		}
		.todo-box .what-box {
			background: #fff;
			box-shadow: 0 5px 15px rgba(18,20,22,0.08);
			border: 1px solid #ddd;
			padding: 20px 20px 20px;
			border-radius: 4px;
			height: auto;
			margin-bottom: 15px;
		}
		.todo-box .what-box img {
			width: 65px;
			margin: 10px 0px;
		}
		.campaign-container {
			background: rgb(240,243,245);
			padding: 70px 0px;
		}
		.campaign-container .campaign-title {
			font-size: 60px;
			font-weight: 900;
			margin: 0px 0px 35px;
		}		
		.campaign-container a {
			color: #333;
			margin-bottom: 5px;
			display: block;
		}
		.campaign-container a:hover {
			opacity: .8;
		}
		.row-domains a {
			font-size: 2rem !important;
		}
		.campaign-domain {
			position: absolute;
			bottom: -20px;
			left: 16px;
		}
		.col-cc {
			margin-bottom: 25px;
		}
		.services-container {
			background: #ffffff;
			padding: 70px 0px;
		}	
		.services-container .services-title {
			font-size: 60px;
			font-weight: 900;
			margin: 0px 0px 35px;
		}
		.eservices-container {
			padding-top: 0px !important;
		}
		.eServices-features-title {
			display: none;
		}
		.vertical-middle-container {
			padding: 10px 0px 80px;
			background: #03072f;
			color: #fff;
		}
		.vertical-middle-container a {
			margin-bottom: 5px;
			display: block;
		}
		.vertical-middle-container a:hover {
			opacity: .8;
		}
		.back-to-top {
			cursor: pointer;
			position: fixed;
			bottom: 20px;
			right: 20px;
			display: none;
		}
		.back-to-top:hover {
			opacity: 1;
			filter: alpha(opacity=100);
		}
		footer {
			background: #001435;
			color: #fff;
			padding-top: 20px;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand navbar-inverse navbar-transparent fixed-top">
		<div class="container">
			<a class="navbar-brand" href="/">
				<? if($logo == "" || empty($logo) || $logo == "_"): ?>
				<?php echo $domain?>
			<?php else:?>
				<img class="img-brand img-fluid" src="<?php echo $logo?>">
			<?php endif?>   
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarCollapse">
			<ul class="navbar-nav mr-auto"></ul>
			<ul class="navbar-nav">
				<li class="nav-item active">
					<a class="nav-link" href="/">Home 
						<span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="about">About</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="/partners">Partner With Us</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="/developers">Developers</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="/contact">Contact Us</a>
					</li>						
				</ul>					
			</div>
		</div>
	</nav>
	
