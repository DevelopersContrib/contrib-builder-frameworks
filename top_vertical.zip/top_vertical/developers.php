<?php include('header.php');?>

<style>
.navbar-transparent {
    background-color: #222;
    border-color: #080808;
}
.top-container {
	padding: 135px 0px 50px;
}
footer {    
    padding-top: 0px;
}
.developer-container {
	padding: 80px 0px 100px;
}
.developer-container .developer-title {
    font-size: 80px;
    font-weight: 900;
    margin: 0px 0px 10px;
	text-transform: uppercase;
}
.developer-box {
    background: #fff;
    box-shadow: 0 5px 15px rgba(18,20,22,0.08);
    border: 1px solid #ddd;
    padding: 30px;
    border-radius: 4px;
    margin-bottom: 15px;
}
.developer-box h3 {
}
</style>
    <!-- Main -->
    <div class="top-container">
        <div class="container">
			<div class="row">
				<div class="col-md-6 offset-md-3 text-center">
					<h1 class="display-3">
						Are you a Developer?
					</h1>					
				</div>				
			</div>            
        </div>
    </div>	
	<div class="developer-container">
		<div class="container text-center">
			<div class="row">				
				<div class="col-md-8 offset-md-2 text-left">
					<div class="developer-box">
						<h3>
							<i class="fa fa-rocket" aria-hidden="true"></i>&nbsp;
							Do you have code or an app that could run this brand? <?php echo $domain?> is connected with Contrib. 
						</h3>
						<div><br></div>
						<h3>
							<i class="fa fa-rocket" aria-hidden="true"></i>&nbsp;
							Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?php echo $domain?>?  
						</h3>
						<br>
						<div class="text-center"><a href="/contact" class="btn btn-lg btn-warning">Contact Us</a></div>
					</div>
				</div>				
			</div>
		</div> 
	</div>	

	<!-- footer -->
	<?php include('footer.php');?>
