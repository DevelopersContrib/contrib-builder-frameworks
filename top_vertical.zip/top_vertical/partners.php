<?php include('header.php');?>

<style>
.navbar-transparent {
    background-color: #222;
    border-color: #080808;
}
.top-container {
	padding: 135px 0px 50px;
}
footer {    
    padding-top: 0px;
}
.partner-container {
	padding: 80px 0px 100px;
}
.partner-container .partner-title {
    font-size: 80px;
    font-weight: 900;
    margin: 0px 0px 10px;
	text-transform: uppercase;
}
.partner-box {
    background: #fff;
    box-shadow: 0 5px 15px rgba(18,20,22,0.08);
    border: 1px solid #ddd;
    padding: 30px;
    border-radius: 4px;
    margin-bottom: 15px;
}
.partner-box h4 {
	font-size: 1.3rem;
	text-transform: uppercase;
}
</style>
    <!-- Main -->
    <div class="top-container">
        <div class="container">
			<div class="row">
				<div class="col-md-6 offset-md-3 text-center">
					<h1 class="display-3">
						Join Our Partner Network
					</h1>					
				</div>				
			</div>            
        </div>
    </div>	
	<div class="partner-container">
		<div class="container">
		   <div class="row">	
    		   <div class="col-md-12">
    		   <script id="parts" src="https://tools.contrib.com/contactform/Widget?domain=referrals.com&option=partner"></script>
    		   </div>
		   </div>
		   </div>
		   <div class="container text-center">
			<div class="row">				
				<div class="col-md-8 offset-md-2 text-center">
					<div class="partner-box">
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>Contrib.com</h4>
								<p>Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today. </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>GlobalVentures.com</h4>
								<p>Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart. 
								With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people. 
								</p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://www.contrib.com/uploads/logo/ifund.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>iFund.com</h4>
								<p>iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform. iFund receives no compensation in connection with the purchase or sale of securities.</p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-socialid1.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>SocialId.com</h4>
								<p>SocialId helps you get the social name for all major social networking websites. </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>iChallenge.com</h4>
								<p>The best internet challenges. Solve and win online prizes. </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>Virtualinterns.com</h4>
								<p>Join our exclusive community of like minded people on virtualinterns.com  </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>Referrals.com</h4>
								<p>Most effective Business Referral Program and Tools Available. Find and share referrals locally. </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-adrate-3.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>Adrate.com</h4>
								<p>Insightful Ad Content Direct To Your Target Market Advertising That Will Reach. Attract. Target. & Engage Your Future Customers </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>Consultants.com</h4>
								<p>Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy. </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://www.domaindirectory.com/images/logo-domaindirectory300x82.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>Domaindirectory.com</h4>
								<p>Domain Directory - Buy, Sell, Trade, Develop, Partner with premium domains on the Domain Directory platform. </p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<a href="">
									<img class="img-fluid" src="https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png">
								</a>
							</div>
							<div class="col-sm-8 text-left">
								<h4>Handyman.com</h4>
								<p>Handyman.com is the best place to find a professional contractor.</p>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</div> 
	</div>	

	<!-- footer -->
	<?php include('footer.php');?>
