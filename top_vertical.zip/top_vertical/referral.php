<?php include 'header.php'; ?>
<style>
    .nav-pills.nav-pills-cust {
        background-color: #f8f8f8;
        border: 1px solid #e7e7e7;
        border-radius: 5px;
        margin-bottom: 5px;
        padding: 5px 10px;
    }
    .blck2-box{
        margin-top: auto
    }
.navbar-transparent {
    background-color: #222;
    border-color: #080808;
}
.top-container {
	padding: 135px 0px 50px;
}
.referral-container {
	margin-bottom: 15px;
}
.referral-box {
	background: #fafafa;
	padding: 20px;
}
footer {    
    padding-top: 0px;
}
</style>
<div class="top-container">
	<div class="container">
		<div class="row">
			<div class="col-md-6 offset-md-3 text-center">
				<h1 class="display-3">
					Referrals
				</h1>					
			</div>				
		</div>            
	</div>
</div>
<div class="referral-container">
<section class="container">
        <div class="row">
            <div class="col-md-12">
				<div class="referral-box">
					<script class="ctb-box" id='referral-script' src='https://www.referrals.com/extension/widget.js?key=356' type='text/javascript'></script>
					<div><br><br></div>
					
					
				</div>
            </div>
        </div>
</section>
</div>  

	

<?php include_once 'footer.php';?>       
