<?php include('header.php');?>

<style>
.navbar-transparent {
    background-color: #222;
    border-color: #080808;
}
.top-container {
	padding: 135px 0px 50px;
}
footer {    
    padding-top: 0px;
}
.staffing-container {
	padding: 80px 0px 100px;
}
.staffing-container .staffing-title {
    font-size: 80px;
    font-weight: 900;
    margin: 0px 0px 10px;
	text-transform: uppercase;
}
.staffing-box {
    background: #fff;
    box-shadow: 0 5px 15px rgba(18,20,22,0.08);
    border: 1px solid #ddd;
    padding: 30px;
    border-radius: 4px;
    margin-bottom: 15px;
}
.staffing-box h3 {
}
.staffing-step-one .col-md-6 {
	float: left;
}
.staffing-step-two .col-md-6 {
	float: left;
}
</style>
    <!-- Main -->
    <div class="top-container">
        <div class="container">
			<div class="row">
				<div class="col-md-6 offset-md-3 text-center">
					<h1 class="display-3">
						Wanna Join Our Team?
					</h1>
					<p>we believe in welcoming the challenge of building amazing brands and companies, but we also believe the experience of building should be amazing too.</p>
				</div>				
			</div>            
        </div>
    </div>	
	<div class="staffing-container">
		<div class="container text-center">
			<div class="row">				
				<div class="col-md-8 offset-md-2 text-left">
					<div class="staffing-box">
						<div class="box-blck">
							<h2 class="ttle text-capitalize">
								Our Staffing Needs at <?php echo $domain?>
							</h2>
							<p>
								We are looking for the best of the best, Full-Time, Part-Time, Moonlighting, Contractual and Freelance.
							</p>
							<p>
								We consult and manage over 100,000 domain name ventures and are always seeking Strategic Partnerships, Applications, Domains, Engineers, Developers, Specialist and just cool smart people around the Globe. Learn more about openings and opportunities with our partner companies and send us your resume or examples to accelerate the process.
							</p>
							<p>Learn more about <a href="/contact.php">openings and opportunities</a> with our partner companies.</p>
							<br>
							<script type="text/javascript" src="https://tools.contrib.com/contactform?d=<?echo $domain?>&f=staffing"></script>
						</div>
					</div>
				</div>				
			</div>
		</div> 
	</div>	

	<!-- footer -->
	<?php include('footer.php');?>
