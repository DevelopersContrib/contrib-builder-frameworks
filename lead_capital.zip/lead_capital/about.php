
<? include_once 'header.php'; ?>

<div id="container2">

<div id="middlebox">
<div id="logo" style="text-align:center">
	
		<h1><a href="http://<?=$domain?>"><img src="<?=$logo?>" alt="<?=$title?>" title="<?=$domain?>" style="max-width:465px" border="0" /></a></h1>
	
</div>
<div id="content2">

<h2>About <?=$domain?></h2>
<p><?=$title?> We are a proud member of the <a href="http://www.contrib.com" alt="Contrib for equity" title="contrib"> Contrib Network</a>.  The venture was formed through a partnership with <a href="http://www.globalventures.com">Global Ventures</a> and <a href="http://zcapital.com/" alt="zcapital" title="zcapital">ZCapital</a>.  We look forward to meeting other great people and companies in the space. 

							 
<p>Learn more about joining our team, becoming an iPartner, or leveraging one of our premium domain assets or companies to help grow your business.</p>
			




</div>

</div>

</div>





<? include_once 'footer.php';?>