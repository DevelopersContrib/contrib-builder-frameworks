<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    
    $background_image = "{{BACKGROUND_IMAGE}}";
    $fb_page =  "{{FB_PAGE}}";
    $twitter = "{{TWITTER}}";
    $bottom_text  = "{{BOTTOM_TEXT}}";
    
    $forsale = "{{SHOW_FOR_SALE}}";
	$forsaletext = "{{FOR_SALE_TEXT}}";
    
    $footer_banner = "{{FOOTER_BANNER}}";
    
    $domain_affiliate_link = "{{AFF_LINK}}";
	$approved_partner = {{PARTNERS}};
?>