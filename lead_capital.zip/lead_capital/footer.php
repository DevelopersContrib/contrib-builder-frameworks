
<? 
$count = 7;
$digits = strlen($follow_count);
$splittedString = str_split($follow_count);

?>
<center style="margin: 15px 30px 20px 30px;">
	<span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999999" data-stop="<?=$follow_count?>">
		<span class="part part0">
			<?
			for($i=$count; $i>0; $i--){
				if($i==$digits){
					for($j=0;$j<$digits;$j++){						
						echo '<span class="digit digit'.$splittedString[$j].'"></span>';
					}	
					break;					
				}else{
					echo '<span class="digit digit0"></span>';
				}
			}
			?>
		</span>							  
	</span>
</center>
<br />




<!-- /container -->
<br />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<div class="footer-dark-1">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							<?=$domain?>
						</h3>
						<p>
							is a new business model, Technology, and Solution targeting the premium domain channel with a fast, affordable, high quality business creation and management platform. 
						</p>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							get started
						</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a class="text-capitalize" href="/partners">
									Partner with us
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="/staffing">
									Apply now
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="/referral">
									referral
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							company
						</h3>
						<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
							<li>
								<a class="text-capitalize" href="/about">
									About us
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="/terms">
									Terms
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="/privacy">
									Privacy
								</a>
							</li>
							<li>
								<a class="text-capitalize" href="/contact">
									Contact us
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							partners
						</h3>
						<!--<p>
							<a href="http://www.rackspace.com">
								<img src="http://c15162226.r26.cf2.rackcdn.com/Rackspace_Cloud_Company_Logo_clr_300x109.jpg" alt="Rackspace" title="Rackspace" style="height:45px;">
							</a>
						</p>-->
						<p>
						<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png"
								width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
						<br><br> <a href="https://goo.gl/H1gdhi" target="_blank"><img style="border:0px;height: 65px !important;width: ;width: 225px !important;"
								src="https://rdbuploads.s3.amazonaws.com/banners/banner-ctb%20earn%20ctb%20tokens.png" alt="Crypto Contrib"
								title="Crypto Contrib"></a>
						<link rel="stylesheet" type="text/css" href="http://tools.contrib.com/css/jquery.glue.css">
						<script src="http://tools.contrib.com/js/jquery.glue.min.js"></script>
						<script src="http://tools.contrib.com/js/glue.js"></script>
						<div id="beforeyougo" style="display:none;" class="glue_popup glue_container">
							<div class="glue_close" onclick="$.glue_close()">X</div>
							<div class="glue_content">
								<div class="wrap-exit-content text-center"><img class="logo-exit-ctb" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/icons/currency-ctb-4.png"
										alt="">
									<h1 class="bg-ttle-exit"> Hello!</h1>
									<p> We invite you to our First Movers Opportunity with our <br>CTB crypto token sale starting <b class="text-danger">October
											12, 2017</b>.<br>Amazing Opportunities with world leading digital assets like Streaming.com,
										Applications.com and
										others. Learn more and get updates.<br></p>
									<p> <a href="https://goo.gl/YNSjTg" class="btn btn-lg btn-warning" target="_blank"> <i class="fa fa-check"></i>
											Get
											Started</a></p>
									<p> <a href="javascript:;" onclick="$.glue_close()" class="help-block"> <small>No, thanks I am not
												interested to be
												part owner.</small></a></p>
								</div>
							</div>
						</div>				
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer-dark-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				&copy; 2016 <a class="text-capitalize " href=""><?=$domain?></a>. All Rights Reserved. 
			</div>
		</div>
	</div>
</div>






<input type="hidden" name="domain_name" id="domain_name" value = "<?echo $domain?>">
<!--/* OpenX Javascript Tag v2.8.7 */-->

<!-- div class="dev-wanted rotate">
<a href="http://www.contrib.com" target="_blank">Developers Wanted<i>!</a></i>
</div -->
<style>
	.dev-wanted{position: fixed;background-color: rgb(251, 122, 58);border-color: rgb(251, 122, 58);top: 400px;left: 0;padding: 5px 15px;border-radius: 1px 1px 10px 10px;box-shadow: -1px 1px 1px rgb(158, 82, 0);}
	.dev-wanted a{color: rgb(255, 255, 255);font-weight: bold;font-family: Arial, Helvetica, sans-serif;font-size: 14px;text-decoration: none;}
	.dev-wanted:hover{background-color: rgb(233, 104, 40);border-color: rgb(197, 85, 29);}
	.rotate {
		-webkit-transform: rotate(270deg);-webkit-transform-origin: 0 0;
		-moz-transform: rotate(270deg);-moz-transform-origin: 0 0 0;
		-ms-transform: rotate(270deg);-ms-transform-origin: 0 0;
		-o-transform: rotate(270deg);-o-transform-origin: 0 0;
	}
</style>
<script src="js/jquery.counter.js" type="text/javascript"></script>
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script>


	
	$(function() {
	//$('.counter').counter();
	
	var domain_name = $('#domain_name').val();
	
	getsocial(domain_name,'fb','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251686_facebook_circle_color.png');
	getsocial(domain_name,'twitter','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251704_twitter_circle_color.png');
	
	
	
});

	function getsocial(domain_name,social,icon_src){

		$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
			var socialdata = data[0];
			if(socialdata.error == true){
						//do nothing
					}else if(socialdata.profile_url == ""){
						//do nothing
					}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
						//do nothing
					}else{
						$('#socials_container').append('&nbsp;<a href="'+socialdata.profile_url+'"><img src="'+icon_src+'" height="40px"></a>&nbsp;');
					}		
				});
	}

</script>


</body>
</html>