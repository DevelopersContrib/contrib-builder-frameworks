<?php include 'includes/config.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<title><?=$title?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- Bootstrap -->
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/main.css">
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://code.jquery.com/jquery.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <style type="text/css">
			.brdr{
				border: 1px solid;
			}
        </style>
	</head>
	<body>
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					
						<?if($logo == "" || empty($logo) || $logo == "_"){ ?>
                        
                           <h1> <a href="http://<?=$domain?>" target="_blank" alt="<?=$title?>" title="<?=$domain?>" style="font-size: 24px;font-weight: bold;">
                                <?=ucwords($domain)?>
                            </a></h1>
                        
                        <? }else{ ?>
							<a class="navbar-brand" href="http://<?=$domain?>" target="_blank" >
								<img class="img-responsive img-logo"  src="<?=$logo?>" alt="<?=$title?>" title="<?=$domain?>" border="0" />
							</a>
                        <? } ?>
						
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

					<ul class="nav navbar-nav navbar-right">
						<li>
							<h2><a href="#" style="font-size:18px;">Call Us. tel:+1 (317)414 3751</a></h2>
						</li>
					</ul>
				</div><!-- /.navbar-collapse -->
			</div><!-- /.container-fluid -->
		</nav>
		<div class="section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h3 class="text-center">
							The owners of this domain have recently changed their business plan.
						</h3>
						<h2 class="text-center">
							This Domain is Possibly for Sale.
						</h2>
						<hr class="lineLines">
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<h1 class="text-center">
							* All Offers Below $10,000 USD will be discarded *
						</h1>
						<br><br>
						<h4>
							<b>
								Please note that domains represented by Globalventures are considered premium domain names with prices ranging between $10,000 to well over six figures.
							</b>
						</h4>
						<br><br>
						<p>
							Every domain has a unique set of characteristics which all collectively determine the asking price.  To learn more about domain name values or inquire about a specific domain please contact one of our experienced professionals using the form.
						</p>
					</div>
					<div class="col-lg-6">
						<div class="row">
							<div class="wrap-forSale-form">
								<div class="col-lg-12 whiteBckg">
									<p>
										Complete this form to receive a free quote immediately
									</p>
									<div class="form-group">
										<label class="sr-only">Domain Name</label>
										<input class="form-control input-lg" type="text" value="<?=$domain?>" placeholder="" disabled="">
									</div>
									<div class="form-group">
										<label class="sr-only">Offer USD</label>
										<input type="text" class="form-control input-lg" placeholder="Offer USD*">
									</div>
									<div class="form-group">
										<label class="sr-only">First Name</label>
										<input type="text" class="form-control input-lg" placeholder="First Name">
									</div>
									<div class="form-group">
										<label class="sr-only">Last Name</label>
										<input type="text" class="form-control input-lg" placeholder="Last Name">
									</div>
									<div class="form-group">
										<label class="sr-only">Company</label>
										<input type="text" class="form-control input-lg" placeholder="Company*">
									</div>
									<div class="form-group">
										<label class="sr-only">Email</label>
										<input type="text" class="form-control input-lg" placeholder="Email*">
									</div>
									<div class="form-group">
										<label class="sr-only">Confirm Email</label>
										<input type="text" class="form-control input-lg" placeholder="Confirm Email*">
									</div>
									<div class="form-group">
										<label class="sr-only">Country</label>
										<select class="form-control input-lg">
											<option>Select Country</option>
										</select>
									</div>
									<div class="form-group">
										<label class="sr-only">Messege</label>
										<textarea rows="3" class="form-control input-lg" placeholder="Messege*"></textarea>
									</div>
									<div class="form-group">
										<a href="" class="btn btn-lg btn-primary pull-right"><i class="fa fa-check"></i> Submit your Offer</a>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer">
			<div class="container">
				<div class="row">
					<div class="row">
						<div class="col-lg-12">
						<ul class="list-inline text-center ul-link-footer-nav">
							<li>
								<a href="">Home</a>
							</li>
							<li>
								<a href="">Contact Us</a>
							</li>
							<li>
								<a href="">Partner with us</a>
							</li>
							<li>
								<a href="">Apply now</a>
							</li>
							<li>
								<a href="">Terms</a>
							</li>
							<li>
								<a href="">Privacy</a>
							</li>
							<li>
								<a href="">Referral</a>
							</li>
						</ul>
					</div>
					</div>
					<div class="col-lg-12">
						<p class="text-center">&copy; 2014 Domain Holdings Group. All rights reserved. </p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>