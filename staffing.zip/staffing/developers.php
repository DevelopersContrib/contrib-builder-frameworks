<?php include('includes/config.php');?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="custom.css">
<style>
.page-container {
	margin-top:50px;
	margin-bottom:190px;
}
.page-container .btn-pg {
	margin-bottom:30px;
}
.blur-box {
    background-color: #333;
    margin-bottom: 25px;
    padding: 15px;
    color:#ddd;
}
.devdesc {
    font-size: 21px;
    line-height: 27px;
    margin-bottom: 20px;
}
</style>
<!-- navigation -->
<?php include('navigation.php');?>
<!-- -->
<!-- page container-->
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 text-center">			
			<div class="page-container">
				<h2>Developer <?=$domain?></h2>
				<hr>
				    <div class="blur-box text-justify">
                        <h2 class="ttle text-capitalize text-center">
                            Are You a Coder ?
                        </h2>
                        <br /> 
                        <p class="devdesc">
                            <i class="fa fa-arrows"></i>
                            Do you have code or an app that could run this brand? <?php echo ucfirst($domain)?> is connected with <a href="http://contrib.com/signup/firststep?domain=<?php echo $domain?>" target="_blank">Contrib</a>. 
                        </p>
                        <p class="devdesc">
                            <i class="fa fa-arrows"></i>
                            <a href="http://contrib.com/signup/firststep?domain=<?php echo $domain?>" target="_blank">Contrib</a> is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?php echo $domain?>?
                        </p>
                        <div class="form-group text-center">
                            <a href="/contact" class="btn btn-primary">Inquire Here</a>
                        </div>
                    </div>
                </div>
			</div>
		</div>
	</div>
</div>
<!-- end page container-->
<?php include 'footer.php';?>