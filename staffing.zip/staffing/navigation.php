<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"> 
	<div class="container">
		<a class="navbar-brand" href="/"><?=ucfirst($domain)?></a>		
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarStaffing" aria-controls="navbarStaffing" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
		<div class="collapse navbar-collapse" id="navbarStaffing">
			<div class="mr-auto"></div>
			<ul class="navbar-nav">
				<li class="nav-item active"><a class="nav-link" href="/">Home</a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo $base_url?>about">About Us</a></li>
				<li class="nav-item"><a id="_contactus" href="javascript:;" data-toggle="modal" data-target="#form-container" class="nav-link">Contact Us</a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo $base_url?>partner">Partners</a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo $base_url?>referral">Referrals</a></li>
			</ul>				
		</div>
	</div>
</nav>