<style>
.navbar-default {
	height: 70px;
}
.navbar-right {
    margin-top: 8px;
}
</style>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="<?php echo $keywords; ?>"/>
	<title><?=$title?></title>

<nav class="navbar navbar-default navbar-static-top">
  <div class="container">
	<div class="navbar-header">
	  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	  </button>
	  <?php if (empty($logo)) { ?>
		<a href="/"><h3> <?php echo ucfirst($domain) ?> </h3></a>
	<? }else{?>
		<img class="ed-head" src="<?=$logo?>" alt="<?=$domain?>" title="<?=$domain?>" style=" float: left;height: 68px;">
		
	<?php }?>
	</div>
	<div id="navbar" class="navbar-collapse collapse">          
	  <ul class="nav navbar-nav navbar-right">
		<li><a href="/">Home</a></li>
		<li><a href="/about">About</a></li>
		<li><a href="/apps">Apps</a></li>
		<li><a href="/contact">Contact Us</a></li>
		<li><a href="/referral">Referrals</a></li>
		<li><a href="/partner">Partners</a></li>

	  </ul>
	</div><!--/.nav-collapse -->
  </div>
</nav>