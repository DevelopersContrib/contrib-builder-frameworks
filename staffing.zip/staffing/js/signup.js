
/* LyogcmV2aXNpb24gYnk6IExQIGFkZGVkIGlwIGFkZCBmaWVsZCAxMC8xMC8xNiAqLw== */

$('#fname_btn').click(function(e){
	var fname = $("input[name='first_name']").val();
	$('#span_lname').html(fname);
	e.preventDefault();
});

$(document).ready(function(){

	$("#boom").click(function(e){	
		if(validateForm()){

		 $.LoadingOverlay("show", {
				image: 'js/loading.gif'
		});

		var email = $.session.get('email');
		var firstname = $("input[name='first_name']").val();
		var lastname = $("input[name='last_name']").val();
		var password = $("input[name='password']").val();
		var country_id = $('#country').children('option').filter(':selected').val();
		var country = $('#country').children('option').filter(':selected').text();
		var city  = $("input[name='city']").val();
		var linkedIn = $("input[name='linkedIn']").val();
		var twitter = $("input[name='twitter']").val();
		var fb = $("input[name='fb']").val();
		var industry_id = $("input[name='industry']:checked").prev().val();
		var industry_name = $("input[name='industry']:checked").val();
		var role_id = $("input[name='role_name']:checked").prev().val();
		var role_name = $("input[name='role_name']:checked").val();
		var intention = $("input[name='intention']").val();		
		var socials = [linkedIn, twitter, fb];
		var domain = $('#domain').val();
		var resumeurl = 'http://linkedin.com/'+firstname;
		var message = intention;
		
		var formdata = {
			email:email,
			firstname:firstname,
			lastname:lastname,
			password:password,
			country_id:country_id,
			country:country,
			city:city,
			industry_id:industry_id,
			industry_name:industry_name,
			role_id:role_id,
			role_name:role_name,
			intention:intention,
			socials:socials
		}

		// console.log(formdata);

		$.post('http://www.api.contrib.com/forms/save_staffing_stf',		
			{
				email:email,
				firstname:firstname,
				lastname:lastname,
				password:password,
				country:country,
				city:city,
				industry_id:industry_id,
				industry_name:industry_name,
				role_id:role_id,
				role_name:role_name,
				role:role_id,
				intention:intention,
				domain:domain,
				resumeurl:resumeurl,
				message:message,
				country_id:country_id

			},
			function(data)
			{
				if (data.success == true) {
					$.post('http://www.manage.vnoc.com/salesforce/addlead',
					{
						'firstname':firstname,
						'lastname':lastname,
						'title':'',
						'email':email,
						'phone':'',
						'street':'',
						'city':city,
						'country':country,
						'state':'',
						'zip':'',
						'role':role_name,
						'form_type':'Contrib User'
					},
					function(data2)
					{
						$.LoadingOverlay("hide");
						var name = firstname+" "+lastname;
						$.session.set('name', name);
						window.location.href = 'success';

					}
					)
				} else {
					$.LoadingOverlay("hide");
					$('.alert-inner').html(data.result);
					$('.alert-general-container').show();
				}
			}
		)
			
	}
	
	e.preventDefault();
});



});

function validateForm(){
	var counter = 0;
	if($("input[name='first_name']").val()==''){
		$('#alert_fname').show();
		counter++;
	} else {
		$('#alert_fname').hide();
	}
	
	if($("input[name='last_name']").val()==''){
		$('#alert_lname').show();
		counter++;
	} else {
		$('#alert_lname').hide();
	}
	
	if($("input[name='password']").val()==''){
		$('#alert_pwd').show();
		counter++;
	} else if($("input[name='password']").val().length < 8){
		$('#alert_pwd').html('Password must be atleast 8 characters.');
		$('#alert_pwd').show();
		counter++;
	} else {
		$('#alert_pwd').hide();
	}
	
	if($('#country').children('option').filter(':selected').val()==''){
		$('#alert_country').show();
		counter++;
	} else {
		$('#alert_country').hide();
	}
	
	if($("input[name='city']").val()==''){
		$('#alert_city').show();
		counter++;
	} else {
		$('#alert_city').hide();
	}
	
	if($("input[name='linkedIn']").val()!=''){
		var url = $("input[name='linkedIn']").val();
		if(!isUrlValid(url)){
			$('#alert_linkedIn').show();
			counter++;
		}
	} else {
		$('#alert_linkedIn').hide();
	}
	
	if($("input[name='twitter']").val()!=''){
		var url = $("input[name='twitter']").val();
		if(!isUrlValid(url)){
			$('#alert_twitter').show();
			counter++;
		}
	} else {
		$('#alert_twitter').hide();
	}
	
	if($("input[name='fb']").val()!=''){
		var url = $("input[name='fb']").val();
		if(!isUrlValid(url)){
			$('#alert_fb').show();
			counter++;
		}
	} else {
		$('#alert_fb').hide();
	}
	
	if(!$("input[name='industry']:checked").val()){
		$('#alert_workType').show();
		counter++;	
	} else {
		$('#alert_workType').hide();
	}
	
	if(!$("input[name='role_name']:checked").val()){
		$('#alert_role').show();
		counter++;	
	} else {
		$('#alert_role').hide();
	}
	
	if(!$("input[name='intention']:checked").val()){
		$('#alert_intention').show();
		counter++;	
	} else {
		$('#alert_intention').hide();
	}
	
	if(counter > 0){
		$('html, body').animate({ scrollTop: 0 }, 'fast');
	} else {
		return true;
	}
}

function isUrlValid(url) {
    return /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
}

	
	















