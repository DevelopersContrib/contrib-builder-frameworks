<!-- Start:: Staffing Form Text Content -->
<div class="col-lg-6 bg-left-form">
	<div class="bg-left-overlay"></div>
	<div class="left-content-main">
		<h1 class="title-left mb-3">
			Submit Team Application
		</h1>
		<p class="desc-left mb-4">
			When you submit your registration, you can quickly join the <?=ucfirst($domain)?>. team and take part in micro tasks and be paid in services fees, equity or performance equities.
		</p>
		<div class="box-steps p-3 mb-3">
			<div class="media">
				<img class="mr-3 align-self-center" src="https://cdn.vnoc.com/icons/submit-application.png" width="40" alt="">
				<div class="media-body">
					<div class="steps-header-title d-block fnt-500 mb-2">
						Submit an Application
					</div>
					<div class="d-block">
						<small>
							You will receive an email when we approve your application.
						</small>
					</div>
				</div>
			</div>
		</div>
		<div class="box-steps p-3">
			<div class="media">
				<img class="mr-3 align-self-center" src="https://cdn.vnoc.com/icons/handshake.png" width="40" alt="">
				<div class="media-body">
					<div class="steps-header-title d-block fnt-500 mb-2">
						Start working on Tasks and Requests 
					</div>
					<div class="d-block">
						<small>
							Make money by getting equity or pay per performance for tasks rendered and service requests fulfilled.
						</small>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: Loading -->
<div class="col-lg-6 align-self-center d-none" id="staffing_solo_loading">
	<div class="text-center">
		<img src="https://cdn.vnoc.com/icons/loader-circle-outline.gif">
		<div class="d-block small">
			Please wait . . .
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: First Step -->
<div class="col-lg-6 align-self-center" id="staffing_step1">
	<div class="bg-form-content">
		<div class="note note-danger d-none" id="staffing_warning1">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<h3 class="fnt-300 mb-3 text-primary">
			Apply Today for <span class="text-capitalize"><?=ucfirst($domain)?></span>
		</h3>
		<div class="form-group">
			<label for="">Email Address <span class="text-danger">*</span></label>
			<input type="text" class="form-control" id="staffing_initialemail">
		</div>
		<a href="javascript:;" class="btn btn-primary btn-block pulse-btn" id="staffing_btn_1">
			Apply Today
			<i class="fas fa-arrow-right ml-2"></i>
		</a>
		
	</div>
</div>
<!-- End -->

<!-- Start:: Second Step -->
<div class="col-lg-6 align-self-center d-none" id="staffing_step2">
	<div class="bg-form-content">
		<h3 class="fnt-300 mb-3 text-primary">
			Apply Today for <span class="text-capitalize"><?=ucfirst($domain)?></span>
		</h3>
		<div class="note note-danger d-none" id="staffing_warning2">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							First Name
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="staffing_firstname">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Last Name
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="staffing_lastname">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Email
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="staffing_email">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Website
						</small>
					</label>
					<input type="text" class="form-control form-control-sm" id="staffing_website">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Country
						</small>
						<span class="text-danger">*</span>
					</label>
					<select class="form-control form-control-sm" id="staffing_country">
						<option value=""></option>									
						<?php for($ci=0;$ci<sizeof($countriesarray);$ci++){ ?>											
						<option value="<?=$countriesarray[$ci]['country_id']?>"><?=$countriesarray[$ci]['name']?></option>
						<?php } ?>
					</select>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							City
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="staffing_city">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Password
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="password" class="form-control form-control-sm" id="staffing_password">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Confirm Password
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="password" class="form-control form-control-sm" id="staffing_password2">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<!--<a href="" class="btn btn-danger btn-block">
					<i class="fas fa-arrow-left mr-2"></i>
					Back
				</a>-->
			</div>
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-primary btn-block" id="staffing_btn_2">
					Next
					<i class="fas fa-arrow-right ml-2"></i>
				</a>
			</div>
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: Third Step -->
<div class="col-lg-6 align-self-center d-none" id="staffing_step3">
	<div class="bg-form-content">
		<h3 class="fnt-300 mb-3 text-primary">
			Apply Today for <span class="text-capitalize"><?=ucfirst($domain)?></span>
		</h3>
		<div class="note note-danger d-none" id="staffing_warning3">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Team Role
						</small>
						<span class="text-danger">*</span>
					</label>
					<select class="form-control form-control-sm" id="staffing_role">
						<option value=""></option>
						<?php for($ci=0;$ci<sizeof($rolesarray);$ci++){ ?>	
						<?if(!($rolesarray[$ci]['role_id'] == 29 || $rolesarray[$ci]['role_id'] == 11)){?>
						<option value="<?=$rolesarray[$ci]['role_id']?>"><?=$rolesarray[$ci]['role_name']?></option>
						<?php } ?>
						<?php } ?>
					</select>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Resume Link
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="staffing_resumeurl">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Why you should join in our team?
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="staffing_message">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-danger btn-block" id="staffing_back_3">
					<i class="fas fa-arrow-left mr-2"></i>
					Back
				</a>
			</div>
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-primary btn-block" id="staffing_btn_3">
					Next
					<i class="fas fa-arrow-right ml-2"></i>
				</a>
			</div>
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: Fourth Step -->
<div class="col-lg-6 align-self-center d-none" id="staffing_step4">
	<div class="bg-form-content">
		<h3 class="fnt-300 mb-3 text-primary">
			Apply Today for <span class="text-capitalize"><?=ucfirst($domain)?></span>
		</h3>
		<div class="note note-danger d-none" id="staffing_warning4">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/facebook.png" alt="">
					<div class="media-body">
						<input placeholder="link to your facebook profile" type="text" class="form-control form-control-sm" id="staffing_facebook">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/linkedin.png" alt="">
					<div class="media-body">
						<input placeholder="link to your linkedin profile" type="text" class="form-control form-control-sm" id="staffing_linkedin">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/github.png" alt="">
					<div class="media-body">
						<input placeholder="link to your github profile" type="text" class="form-control form-control-sm" id="staffing_github">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/skype.png" alt="">
					<div class="media-body">
						<input placeholder="your skype id" type="text" class="form-control form-control-sm" id="staffing_skype">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/yahoo.png" alt="">
					<div class="media-body">
						<input placeholder="your yahoo id" type="text" class="form-control form-control-sm" id="staffing_yahoo">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/gtalk.png" alt="">
					<div class="media-body">
						<input placeholder="your gtalk id" type="text" class="form-control form-control-sm" id="staffing_talk">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/aol.png" alt="">
					<div class="media-body">
						<input placeholder="your AOL id" type="text" class="form-control form-control-sm" id="staffing_aol">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
			<div class="col-lg-12 mb-2">
				<div class="media">
					<img class="mr-3" src="https://d2qcctj8epnr7y.cloudfront.net/images/icons/windows.png" alt="">
					<div class="media-body">
						<input placeholder="your windows live id" type="text" class="form-control form-control-sm" id="staffing_wlive">
					</div>
					<span class="small ml-3 align-self-center text-secondary">
						(optional)
					</span>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-danger btn-block" id="staffing_back_4">
					<i class="fas fa-arrow-left mr-2"></i>
					Back
				</a>
			</div>
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-primary btn-block" id="staffing_btn_4">
					Next
					<i class="fas fa-arrow-right ml-2"></i>
				</a>
			</div>
			<input type="hidden" id="staffing_domain" value="<?=$domain?>">
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: Fifth Step -->
<div class="col-lg-6 align-self-center d-none" id="staffing_final">
	<div class="bg-form-content">
		<div class="d-block pb-3 text-center">
			<img src="https://cdn.vnoc.com/icons/email.svg" width="100" alt="">
		</div>
		<h2 class="text-center mb-3">
			Thank you for your application.
		</h2>
		<p class="text-center text-secondary mb-5">
			You are now minutes away to joining <span class="text-capitalize"><?=ucfirst($domain)?></span> team.
		</p>
		<ul class="list-unstyled text-secondary">
			<li class="mb-3 small">
				1. Click the link in the <span class="text-success">Verification email</span> that we have just sent you. If you still haven't received it, please check your spam inbox.
			</li>
			<li class="mb-3 small">
				2. Your verification link will redirect you to our <a href="">Marketpalce hub</a> where you can login and check out your application status.
			</li>
			<li class="small">
				3. You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.
			</li>
		</ul>
		<div id="viewcontriblink">Thank You!</div>
	</div>
</div>

<script src="/js/serviceforms/bs4/staffing.js"></script>
				<!-- End -->