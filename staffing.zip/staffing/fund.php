<?php include('header.php'); ?>
<style>

</style>
<body>
	<div class="navigation-container">
		<?php include('navigation.php'); ?>
	</div>
	<div class="main page-container">		
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10 text-center mb-5">			
					<div class="page-container-inner">
						<h2 class="mb-4"><b>Fund <?=$domain?></b></h2>
						<div class="row">
						<?foreach($fund_campaigns as $funds):?>
							<?if($funds['post_title'] != 'Micro Markets'):?>
							<div class="col-sm-4 col-xs-12">
							    <div class="fund-container">
								 <div class="ribbon-wrapper-green">
								     <div class="ribbon-green">Staff Pick</div>
								 </div>
												<?php if($funds['logo'] != ""):?>
							     <?php $logo = "https://cdn.vnoc.com/background".substr($funds['logo'],strrpos($funds['logo'],'/')) ?>
								 <img src="<?php echo $logo?>" class="img-fluid" alt="fund campaign" title="fund campaign" />
												<?php endif;?>
								 <a target="_blank" class="alink" href="<?php echo $funds['permalink']?>">
								     <h3><?php echo $funds['post_title']?></h3>
								 </a>
								 <p class="fund-desc"><?php echo strip_tags($funds['post_content'])?></p>
								 <div class="funded-l">
								     <div class="fund-icon"><i class="fa fa-usd"></i></div>
								     <div class="fund-details">
									  <p>Funded</p>
									  <p><b><?php echo number_format($funds['campaign_goal'],2)?></b></p>
								     </div>
								     <div style="clear:both"></div>
								 </div>
								 <div class="funded-r">
								     <div class="fund-icon"><i class="fa fa-bar-chart"></i></div>
								     <div class="fund-details">
									  <p>Funded</p>
									  <p><b>10%</b></p>
								     </div>
								     <div style="clear:both"></div>
								 </div>
								 <div style="clear:both"></div>
							    </div>
							</div>
						<?endif;?>
						<?endforeach?>
						</div>						
					</div>
				</div>
			</div>
		</div>
	</div>

<?php include('footer.php'); ?>