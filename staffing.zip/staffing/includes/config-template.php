<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $affiliate_id = "{{AFF_ID}}";
    $additional_html = "{{ADDITIONAL_HTML}}";
    $piwik_id = '{{PIWIK_ID}}';
    $keywords = '{{KEYWORDS}}';
    $footer_html = '{{FOOTER_HTML}}';
    $social_fb = '{{SOCIAL_FB}}';
    $social_gplus = '{{SOCIAL_GPLUS}}';
    $social_twitter = '{{SOCIAL_TWITTER}}';
    $social_linkedin = '{{SOCIAL_LINKEDIN}}';
    $social_gtube = '{{SOCIAL_GTUBE}}';

    $rolesarray = {{ROLES}};
    $countriesarray = {{COUNTRIES}};
    $industriesarray = {{INDUSTRIES}};
    $intentions = array('Looking to build a startup from an idea','Open to joining a team');
    
    $related_domains = {{RELATED_DOMAINS}};
    $fund_campaigns = {{FUND_CAMPAIGNS}};
    $partners = {{PARTNERS}};
    $programs = {{PROGRAMS}};

?>