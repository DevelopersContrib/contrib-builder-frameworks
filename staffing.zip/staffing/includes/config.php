<?php

function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}

    $api_url = "http://api3.contrib.co/request/";
    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $key = md5('vnoc.com');

if (!file_exists('./includes/config-framework.php')) {
    $file = file_get_contents('./includes/config-template.php');
    $api_url = "http://api2.contrib.co/request/";
    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $error = 0;
    
    if(stristr($domain,'~') ===FALSE) {
    	$domain = $_SERVER["HTTP_HOST"];
      $domain = str_replace("http://","",$domain);
    	$domain = str_replace("www.","",$domain);
    	$key = md5($domain);
    }else {
       $key = md5('vnoc.com');
       $d = explode('~',$domain);
       $user = str_replace('/','',$d[1]);
       
       $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
       $result =  createApiCall($url, 'GET', $headers, array());
       $data_domain = json_decode($result,true);
       $domain =   $data_domain['data']['domain'];
       
    }
    
    $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $data_domain = json_decode($result,true);
    
    if ($data_domain['success']){
    	$domainid = $data_domain['data']['DomainId'];
    	$domainname = $data_domain['data']['DomainName'];
    	$memberid = $data_domain['data']['MemberId'];
    	$title = $data_domain['data']['Title'];
    	$logo = $data_domain['data']['Logo'];
    	$description = $data_domain['data']['Description'];
    	$account_ga = $data_domain['data']['AccountGA'];
    	$description = stripslashes(str_replace('\n','<br>',$description));
      $keywords = $data_domain['data']['Keywords'];
    	
      $url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
      $result2 = createApiCall($url2, 'GET', $headers, array());
    	$data_domain2 = json_decode($result2,true);
    	
      if($data_domain2['success']){
    		$background_image = $data_domain2['data']['background_image_url'];
    		$additional_html = $data_domain2['data']['additional_html'];
        $footer_html = $data_domain2['data']['footer_html'];
    		
      $url3 = $api_url.'GetPiwikId?domain='.$domain.'&key='.$key;
      $result3 = createApiCall($url3, 'GET', $headers, array());
    	$data_domain3 = json_decode($result3,true);
      $piwik_id = $data_domain3['data']['idsite'];
        
       //get related domains
    	$url = $api_url.'getrelateddomains?domain='.$domain.'&limit=10';
      $result = createApiCall($url, 'GET', $headers, array());
      $data_domains = json_decode($result,true);
    	if ($data_domains['success']){
    		$related_domains = $data_domains['data'];
    	}
	 
   
      /*$campaigns = array();
		
    	$post_name = '';
    	$post_title = '';
    	$permalink = '';
    	$campaign_goal = '';
    	$campaign_location = '';
    	$campaign_author = '';
    	$campaign_type = '';
    	$campaign_updates = '';
    		
      if (isset($items['campaign'])){  
      	foreach($items['campaign'] as $item){
      			$meta = $item['meta'];
      			$campaign_goal = $meta['campaign_goal'];
      			$campaign_location = $meta['campaign_location'];
      			$campaign_author = $meta['campaign_author'];
      			$campaign_type = $meta['campaign_type'];
      			
      			$post_title = $item['post_title'];
      			$permalink = $item['permalink'];
      			$post_status = $item['post_status'];
      			$post_name = $item['post_name'];
      			$campaigns[] = array(
      				$post_title,				
      				$campaign_goal,
      				$campaign_location,
      				$campaign_author,
      				$campaign_type,
      				$permalink,
      				$post_name
      			);
      		}
      }*/
    		
        
    	}else{
    		$error++;
    	}
    			
    }else {
    	$error++;
    }
    
    //get fund campaigns
    $url = $api_url.'getfundcampaigns';
    $result = createApiCall($url, 'GET', $headers, array()); 
    $items = json_decode($result,true);
    if ($items['success']){
        $campaigns = $items['data'];
    }    
    
    //get monetize ads from vnoc
    $url = $api_url.'getbannercode?d='.$domain.'&p=footer';
    $result = createApiCall($url, 'GET', $headers, array());
    $data_ads = json_decode($result,true);
    $footer_banner = html_entity_decode(base64_decode($data_ads['data']['content']));
    
    //get domain affiliate id
    $url = $api_url.'getdomainaffiliateid?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $data_domain_affiliate = json_decode($result,true);
    if ($data_domain_affiliate['success']){
    	$domain_affiliate_id = $data_domain_affiliate['data']['affiliate_id'];
    }else {
    	$domain_affiliate_id = '391'; //contrib.com affiliate id
    }
    $domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$domain;
    
    
    //partners 
	$url = $api_url.'getpartners?domain='.$domain.'&key='.$key.'&final=1';
	$result = createApiCall($url, 'GET', $headers, array());
	$partners_result = json_decode($result,true);
	$partners = array();  
	if ($partners_result['success']){
			$approved_partner = $partners_result['data'];
	}else {
		$approved_partner = array();
	}		
    
	  //get form option selects
    $url = $api_url.'getsignupformdata';
    $result = createApiCall($url, 'GET', $headers, array());
    $data_signup = json_decode($result,true);
    
    if ($data_signup['success']){
     $rolesarray = $data_signup['data']['roles'];
     $countriesarray = $data_signup['data']['countries'];
     $industriesarray = $data_signup['data']['industries'];
     $parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
     $intentions = array('Looking to build a startup from an idea','Open to joining a team');
     
    }

	//referral programs 
	$url = $api_url.'getReferralBanners?domain='.$domain.'&key='.$key.'&affiliate_id='.$domain_affiliate_id;
	$result = createApiCall($url, 'GET', $headers, array());
	$program_result = json_decode($result,true);
	$programs = array();  
	if ($program_result['success']){
			$programs = $program_result['data'];
	}else {
		$programs = array();
	}	
    
    //get social urls
    
  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=staffing.com&social=fb';
	$result = createApiCall($url, 'GET', $headers, array());
	$social_result = json_decode($result,true);
	if ($social_result['success']){
			$social_fb = $social_result['data']['profile_url'];
	}else {
		$social_fb = "";
	}	
    
    
  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=staffing.com&social=gplus';
	$result = createApiCall($url, 'GET', $headers, array());
	$social_result = json_decode($result,true);
	if ($social_result['success']){
			$social_gplus  = $social_result['data']['profile_url'];
	}else {
		$social_gplus = "";
	}	
  
  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=staffing.com&social=twitter';
	$result = createApiCall($url, 'GET', $headers, array());
	$social_result = json_decode($result,true);
	if ($social_result['success']){
			$social_twitter  = $social_result['data']['profile_url'];
	}else {
		$social_twitter = "";
	}	
  
  
  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=staffing.com&social=linkedin';
	$result = createApiCall($url, 'GET', $headers, array());
	$social_result = json_decode($result,true);
	if ($social_result['success']){
			$social_linkedin  = $social_result['data']['profile_url'];
	}else {
		  $social_linkedin = "";
	}	
      
      
   $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=staffing.com&social=gtube';
	$result = createApiCall($url, 'GET', $headers, array());
	$social_result = json_decode($result,true);
	if ($social_result['success']){
			$social_gtube  = $social_result['data']['profile_url'];
	}else {
		  $social_gtube = "";
	}	   
  
  //if no background
  
    if ($background_image == "") {
      $url = $api_url.'Getdomainbackground?key='.$key.'&domain='.$domain;
      $result = createApiCall($url, 'GET', $headers, array());
      $random_background_result = json_decode($result,true);
      $background_image = $random_background_result['data']['background_image_url'];
  }

  //if no domain keywords
    if($keywords == ""){
      $url = 'http://api2.contrib.co/request/DomainKeywords?key='.$key.'&domain='.$domain;
      $result = createApiCall($url, 'GET', $headers, array());
      $domain_keywords_result = json_decode($result,true);
      $keywords = $domain_keywords_result['data']['keywords'];
    }
  
   //temporarily static fund campaigns
   $campaigns = array (
  0 => 
  array (
    'post_title' => 'Acting.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/acting-com/',
    'post_name' => 'acting-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/acting.com_.png',
    'post_content' => 'Acting.com allows actors and people in the entertainment industry to put up their profile to get casting audition jobs and opportunities. It also allows companies in the Production industry to...',
  ),
  1 => 
  array (
    'post_title' => 'CodeChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/codechallenge-com/',
    'post_name' => 'codechallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/codechallenge.png',
    'post_content' => '<h4>Join CodeChallenge.com</h4>
<h4><strong>Are you an entrepreneur or want to work for a great online business?</strong></h4>
*Select your niche.
*Get mentorship and access to premium online...',
  ),
  2 => 
  array (
    'post_title' => 'Cookboard.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Florida',
    'campaign_author' => 'Maai Florendo',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cookboard-com/',
    'post_name' => 'cookboard-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/11/logo-CookBoard-2.png',
    'post_content' => 'Your #1 Local Food Marketplace community! Join us as we launch it Dec 2014!

Where local chefs create cook boards for availability to the local foodie community\\n\\n

In depth...',
  ),
  3 =>
  array (
    'post_title' => 'CoWork.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cowork-com-virtual-opportunities-to-do-amazing-things/',
    'post_name' => 'cowork-com-virtual-opportunities-to-do-amazing-things',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/02/4743596194.jpg',
    'post_content' => '<a href="http://www.cowork.com">Cowork.com</a>

CoWork.com is an online venture creation network that works with other like minded professionals building awesome companies, projects and...',
  ),
  4 => 
  array (
    'post_title' => 'iChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/ichallenge-com/',
    'post_name' => 'ichallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/3616845592.jpg',
    'post_content' => 'Ichallenge.com is a gamification challenge framework that allows you to join a challenge or sponsor a challenge without monetary involvement.

&nbsp;',
  ),
  5 => 
  array (
    'post_title' => 'iContent.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/icontent-com/',
    'post_name' => 'icontent-com',
    'logo' => 'http://ifund.com/wp-content/uploads/2014/03/icontent-logo.png',
    'post_content' => '<p>iContent is a xml application that connects all your content into an integrated and intelligent system that learns and earns while you focus on creating amazing audio, visual and contextual...',
  ),
  6 => 
  array (
    'post_title' => 'Linked.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/linked-com/',
    'post_name' => 'linked-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/03/Linked_com-linked_com.png',
    'post_content' => 'Linking people, skills and opportunities to create the worlds largest crowd commerce business creation system. Be a part of Linked.com and get equity shares for your donations.

<img...',
  ),
  7 => 
  array (
    'post_title' => 'MBAChallenge',
    'campaign_goal' => '10000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/mbachallenge/',
    'post_name' => 'mbachallenge',
    'logo' => 'http://ifund.com/wp-content/uploads/2015/06/IMG_1404.jpg',
    'post_content' => 'MBAChallenge is a leading skills based business game created to challenge college educated people with street smart professionals.',
  ),
  8 => 
  array (
    'post_title' => 'Micro Markets',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/micro-markets/',
    'post_name' => 'micro-markets',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/micromarkets1.png',
    'post_content' => '<a href="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets.png"><img alt="logo-micromarkets" title="logo-micromarkets" src="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets-300x44.png"...',
  ),
  9 => 
  array (
    'post_title' => 'MusicChannel.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/musicchannel-com/',
    'post_name' => 'musicchannel-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/07/51661884511.jpg',
    'post_content' => 'MusicChannel is a weekly bounty competition that allows unsigned artists to publish their songs, make them viral and if they are selected will win weekly bounties!

We are looking for backers...',
  ),
);
  
  
  //create file
  $file = str_replace('{{DOMAIN}}',$domain , $file);
  $file = str_replace('{{DOMAIN_ID}}',$domainid , $file);
  $file = str_replace('{{MEMBER_ID}}',$memberid, $file);
  $file = str_replace('{{TITLE}}',$title, $file);
  $file = str_replace('{{KEYWORDS}}',$keywords, $file);
  $file = str_replace('{{LOGO}}',$logo, $file);
  $file = str_replace('{{DESCRIPTION}}',$description, $file);
  $file = str_replace('{{ACCOUNT_GA}}',$account_ga, $file);
  $file = str_replace('{{BACKGROUND_IMAGE}}',$background_image, $file);
  $file = str_replace('{{ADDITIONAL_HTML}}',$additional_html, $file);
  $file = str_replace('{{FOOTER_HTML}}',$footer_html, $file);
  $file = str_replace('{{AFF_LINK}}',$domain_affiliate_link, $file);
  $file = str_replace('{{AFF_ID}}',$domain_affiliate_id, $file);
  $file = str_replace('{{PIWIK_ID}}',$piwik_id, $file);
  $file = str_replace('{{RELATED_DOMAINS}}',var_export($related_domains, true), $file);
  $file = str_replace('{{FUND_CAMPAIGNS}}',var_export($campaigns, true), $file);
  $file = str_replace('{{PARTNERS}}',var_export($approved_partner, true), $file);
  $file = str_replace('{{PROGRAMS}}',var_export($programs, true), $file);
  $file = str_replace('{{ROLES}}',var_export($rolesarray, true), $file);
  $file = str_replace('{{COUNTRIES}}',var_export($countriesarray, true) , $file);
  $file = str_replace('{{INDUSTRIES}}',var_export($industriesarray, true), $file);
  $file = str_replace('{{SOCIAL_FB}}',$social_fb, $file);
  $file = str_replace('{{SOCIAL_GPLUS}}',$social_gplus, $file);
  $file = str_replace('{{SOCIAL_TWITTER}}',$social_twitter, $file);
  $file = str_replace('{{SOCIAL_LINKEDIN}}',$social_linkedin, $file);
  $file = str_replace('{{SOCIAL_GTUBE}}',$social_gtube, $file);
  file_put_contents('./includes/config-framework.php', $file);
}

	include "./includes/config-framework.php";
  
	//get number of leads for counter
    $url = $api_url.'getdomainleadscount?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $data_follow_count = json_decode($result,true);
    if ($data_follow_count['success']){
    	$follow_count = ($data_follow_count['data']['leads'] + 1 ) * 25;
    }else {
    	$follow_count = 1 * 25;
    }
	

/**
	generate robots.txt if not exist
**/
$filename = '/robots.txt';
if(!(file_exists($filename))) {
    $my_file = 'robots.txt';
	$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
	$data = '---BEGIN ROBOTS.TXT ---
User-Agent: *
Disallow:

Sitemap: http://'.$domain.'/sitemap.html
--- END ROBOTS.TXT ----';
	fwrite($handle, $data);
}
$__page = $_SERVER['PHP_SELF'];

if($__page =='/about.php')
	$title = 'About '.ucwords($domain);
else if($__page =='/terms.php')
	$title = ucwords($domain).' - Terms of Use';
else if($__page =='/privacy.php')
	$title = ucwords($domain).' - Privacy & Policy';
else if($__page =='/contact.php')
	$title = ucwords($domain).' - Contact Us';
else if($__page =='/staffing.php')
	$title = ucwords($domain).' - We are Hiring!';
else if($__page =='/referral.php')
	$title = ucwords($domain).' - Get Banners And Make Money';

?>