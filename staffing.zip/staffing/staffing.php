<?php include('includes/config.php');?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="custom.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<style>
.page-container {
	margin-top:50px;
	margin-bottom:50px;
}
.page-container .btn-pg {
	margin-bottom:30px;
}
</style>
<!-- navigation -->
<?php include('navigation.php');?>
<!-- page container-->
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 text-center">			
			<div class="page-container">
				<h2 class="ttle text-capitalize">
					Our Staffing Needs at <?php echo $domain; ?>
				</h2>
				<p>
					We are looking for the best of the best, Full-Time, Part-Time, Moonlighting, Contractual and Freelance.
				</p>
				<p>
					We consult and manage over 100,000 domain name ventures and are always seeking Strategic Partnerships, Applications, Domains, Engineers, Developers, Specialist and just cool smart people around the Globe. Learn more about openings and opportunities with our partner companies and send us your resume or examples to accelerate the process.
				</p>
				<p>Learn more about <a href="/contact.php">openings and opportunities</a> with our partner companies.</p>
				<br>
				<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?echo $domain; ?>&f=staffing"></script>
			</div>
		</div>
	</div>
</div>
<!-- end page container-->
<!-- footer -->
	   <?php include('footer.php');?>
		<!-- end footer -->

