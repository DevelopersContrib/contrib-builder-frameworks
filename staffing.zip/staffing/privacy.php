<?php include('includes/config.php');?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="custom.css">
<style>
.page-container {
	margin-top:50px;
}
.page-container .btn-pg {
	margin-bottom:30px;
}
.box-blck {
    background: #333;
    border-radius: 12px;
    box-shadow: 0 0 14px rgba(255, 255, 255, 0.2);
    margin: 30px 0 100px;
    padding: 30px 15px;
        color: #ddd;

}
.box-blck .ttle {
    color: #ddd;
    font-weight: bold;
    margin-top: 0;
}
</style>
<!-- navigation -->
<?php include('navigation.php');?>
<!-- page container-->
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 text-center">			
			<div class="page-container">
				
				<h2>Privacy <?=$domain?></h2>
				<hr>
				 <div class="arrw-rela"><div class="arrw-point-white"></div></div>
                    <div class="box-blck">
                        <?php 
                            $api_content_url = "http://api3.contrib.co/announcement/"; //get privacy
                            $url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=privacy';
                            $result = createApiCall($url, 'GET', $headers, array());
                            $data_domain = json_decode($result,true);
                            
                            if (isset($data_domain['data']['content'])){
                                $privacy = $data_domain['data']['content'];
                            }else {
                                $privacy = "";
                            }
                            
                            echo $privacy;
                        ?>
                    </div>
                </div>
			</div>
		</div>
	</div>
</div>
<!-- end page container-->
<?php include 'footer.php';?>