<?php include('includes/config.php');?>



<!doctype html>

<html lang="en">



<head>

	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<meta name="description" content="<?=$domain?> <?=$description?>" />

	<meta name="keyword" content="<?=$keywords?>" />

	<meta name="author" content="<?=$domain?>">

	<script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>

	<link rel="canonical" href="https://<?=$domain?>" />

	<title><?=ucfirst($domain)?></title>	

	<link rel="icon" href="/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

	<link href="css/custom.css" rel="stylesheet"> 	

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

	<script type="text/javascript" src="js/pulsate.js"></script>

	<script src="https://kit.fontawesome.com/7b888bceb1.js"></script>

	<!-- piwik/ga -->

	<script>

		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){

		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),

		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)

		})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		ga('create', '<?=$account_ga?>', 'auto');

		ga('send', 'pageview');

	</script>

	<!-- Piwik -->

	<script type="text/javascript">

		var _paq = _paq || [];

		_paq.push(['trackPageView']);

		_paq.push(['enableLinkTracking']);

		(function() {

			var u="//www.stats.numberchallenge.com/";

			_paq.push(['setTrackerUrl', u+'piwik.php']);

			_paq.push(['setSiteId', <?=$piwik_id; ?>]);

			var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];

			g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);

		})();

	</script>

	<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
	
	<script type="text/javascript" src="https://tools.contrib.com/cwidget/roundbadge?d=<?echo $domain?>"></script> 

	<style>

	html, body {

		height: 100%;

	}	

	a:hover {

		text-decoration: none;

	}

	.fw-600 {

		font-weight: 600;

	}

	.fw-800 {

		font-weight: 800;

	}

	.page-container {

		margin-top: 100px;

	}

	<?php if(!empty($background_image)):?>

	<?php if(strpos($background_image,'cdn.vnoc') === FALSE) {

		$img = 'https://cdn.vnoc.com/background'.substr($background_image,strrpos($background_image,'/'));

	} else {

		$img = $background_image;	

	}?>

	.outer-container {

		background-image: linear-gradient( rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7) ), url(https://cdn.vnoc.com/background/jobs4.jpg);

		background-position: 50% 50%;

		background-repeat: no-repeat;

		-webkit-background-size: cover;

		-moz-background-size: cover;

		-o-background-size: cover;

		background-size: cover;

		background-attachment: fixed;

	}

	<?php endif;?>	

	</style>	

</head>