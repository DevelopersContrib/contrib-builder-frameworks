<?php include('includes/config.php');?>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$title?></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="custom.css">

<style>
.page-container {
	margin-top:50px;
	margin-bottom:100px;
}
.page-container .btn-pg {
	margin-bottom:40px;
}
</style>
<!-- navigation -->
<!-- -->
<!-- page container-->
<?php include('navigation.php');?>

<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 text-center">			
			<div class="page-container">
				<h2>Contact <?=$domain?></h2>
					<hr>
						<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?echo $domain?>"></script>
                 <br><br>
                </div>
			</div>
		</div>
	</div>
 <script type="text/javascript" charset="utf-8">
		$(document).ready(function(){
			
			$('#email').click(function(){
				$(this).attr("placeholder","");
			});
			
			$('#pagesubmit').hide();
			$('#pagesubmit').removeClass('hidden');
			
			$('#btnsubmit').click(function(){
				$('#signupform').submit();
			});
			
			$('#signupform').submit(function(){
				
				var email = $('#email').val();
				var user_ip = $('#user_ip').val();
				var indexof = email.indexOf("@");
				var name = email.slice(0,indexof);
				var domain = $('#domain').val(); 
				
				
				if(email==''){
					alert('Email is Required.');
					$('#email').focus();
					return false;
				}else if(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test(email)==false){
					alert('Please enter a valid email address.');
					$('#email').focus();
					return false;
				}else{
					
					$("#signupform").hide();	
					$('#response_wait').show();
					$("#pagesubmit").slideDown('normal');
					
					//DOMAINDI LEADS		
					jQuery.ajax({
						type: "post",url: "http://www.api.contrib.com/forms/saveleads",
						data: {'email':email, 'domain':domain,'user_ip':user_ip},
						success: function(res){
							$('#response_wait').hide();
							console.log(res);
							
							$("#loading").hide();
							
							if(res.success=='false'){
								$('#response').append('<div class="span12 text-center" id="response">Something went wrong. Sorry for the inconvenience.</div>');
							}else if(res.success=='success'){															
								$('#pemail').val(email);
								$('#response').css('display','block');
								
							}else{
								$('#response').append('<div class="span12 text-center" id="response">'+res.success+'<br><br>Visit our <a href="http://www.contrib.com/brand/details/'+domain+'" target="_blank">'+domain.toUpperCase()+' brand page</a> for further details. <br><br>Thank you! <br><br></div>');
							}							
						}
					});	
					
					// SALESFORCE LEAD
					$.post("http://www.manage.vnoc.com/salesforce/addlead",
					{
						'firstName':name,
						'lastName':name,
						'title':'',
						'email':email,
						'phone':'',
						'street':'',
						'city':'',
						'country':'',
						'state':'',
						'zip':'',
						'domain':domain,
						'form_type':'Contrib Lead Template'						
					},
					function(data2){
						console.log(data2);
					}
					);									
					return false;				
				}				
				return false;
			});
        });
	</script>
<!-- end page container-->
<?php include 'footer.php';?>