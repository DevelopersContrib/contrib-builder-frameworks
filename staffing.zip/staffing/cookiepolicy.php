<?php include('header.php'); ?>
<style>
.box-blck h1 {
	font-size: 1.6rem;
}
</style>
<body>
	<div class="navigation-container">
		<?php include('navigation.php'); ?>
	</div>
	<div class="main page-container mb-5">		
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10 text-center">			
					<div class="page-container-inner mb-5">
						<h2><b>Cookie Policy <?=$domain?></b></h2>
						<hr>
						<div class="arrw-rela"><div class="arrw-point-white"></div></div>
					      <div class="box-blck">
						   <?php 
							$api_content_url = "https://api3.contrib.co/announcement/"; //get cookie policy
							$url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=cookie';
							$result = createApiCall($url, 'GET', $headers, array());
							$data_domain = json_decode($result,true);
							
							if (isset($data_domain['data']['content'])){
							    $cookie = $data_domain['data']['content'];
							}else {
							    $cookie = "";
							}
							
							echo $cookie;
						   ?>
					      </div>
					 </div>
				</div>
			</div>
		</div>
	</div>

<?php include('footer.php'); ?>