<?php include('header.php'); ?>
<style>
.blur-box {
	background: rgb(245, 245, 245) none repeat scroll 0% 0%;
	border-radius: 3px;
	margin-bottom: 20px;
	padding: 10px;
}
</style>
<body>
	<div class="navigation-container">
		<?php include('navigation.php'); ?>
	</div>
	<div class="main page-container">		
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10 text-center">			
					<div class="page-container-inner mb-5">
						<h2 class="mb-4"><b>Join Our Partner Network</b></h2>
							<div class="row">
								<!-- dynamic partners-->
								<div class="arrw-rela">
									<div class="arrw-point-white"></div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://contrib.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-new-contrib-06.png" alt="contrib.com" title="contrib.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://contrib.com">Contrib.com</a>
											    </h3>
											<p> Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://globalventures.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/image_logo-gventures10-420x60.png" alt="globalventures.com" title="globalventures.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://globalventures.com">GlobalVentures.com</a>
											    </h3>
											<p> Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart. </p>
											<p> With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://ifund.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/ifund.png" alt="ifund.com" title="ifund.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://ifund.com">iFund.com</a>
											    </h3>
											<p> iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform. iFund receives no compensation in connection with the purchase or sale of securities. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://ichallenge.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-ichallenge1.png" alt="ichallenge.com" title="ichallenge.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://ichallenge.com">iChallenge.com</a>
											    </h3>
											<p> The best internet challenges. Solve and win online prizes. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://socialid.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-socialid1.png" alt="socialid.com" title="socialid.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://socialid.com">SocialId.com</a>
											    </h3>
											<p> SocialId helps you get the social name for all major social networking websites. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://virtualinterns.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-virtualinterns3.png" alt="virtualinterns.com" title="virtualinterns.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://virtualinterns.com">Virtualinterns.com</a>
											    </h3>
											<p> Join our exclusive community of like minded people on virtualinterns.com </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://referrals.com"> <img style="width:290px;" class="img-fluid" src="https://cdn.vnoc.com/logos/logo-referrals-header.png" alt="referrals.com" title="referrals.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://referrals.com">Referrals.com</a>
											    </h3>
											<p> Most effective Business Referral Program and Tools Available. Find and share referrals locally. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://adrate.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-adrate-3.png" alt="adrate.com" title="adrate.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://adrate.com">Adrate.com</a>
											    </h3>
											<p> Insightful Ad Content Direct To Your Target Market Advertising That Will Reach. Attract. Target. & Engage Your Future Customers </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://consultants.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-consultants1.png" alt="consultants.com" title="consultants.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://consultants.com">Consultants.com</a>
											    </h3>
											<p> Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://domaindirectory.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-domaindirectory300x82.png" alt="domaindirectory.com" title="domaindirectory.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://domaindirectory.com">Domaindirectory.com</a>
											    </h3>
											<p> Domain Directory - Buy, Sell, Trade, Develop, Partner with premium domains on the Domain Directory platform. </p>
										</div>
									</div>
								</div>
								<div class="blur-box text-left">
									<div class="row">
										<div class="col-sm-4">
											<a href="https://handyman.com"> <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-handyman.png" alt="handyman.com" title="handyman.com"> </a>
										</div>
										<div class="col-sm-8">
											<h3>
												 <a href="https://handyman.com">Handyman.com</a>
											    </h3>
											<p> Handyman.com is the best place to find a professional contractor. </p>
										</div>
									</div>
								</div>
								<!-- dynamic partners -->
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php include('footer.php'); ?>