<?php include('includes/config.php');?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="<?php echo $description;?>">
		<meta name="author" content="<?php echo $domain; ?>">
		<meta name="keywords" content="<?php echo $keywords; ?>"/>
		<link rel="icon" href="../../favicon.ico">

		<title>Sign Up</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
		<link rel="stylesheet" href="custom.css">

		<!-- piwik/ga -->
		<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
			ga('create', '<?=$account_ga?>', 'auto');
			ga('send', 'pageview');
		</script>
		<!-- Piwik -->
		<script type="text/javascript">
			var _paq = _paq || [];
			_paq.push(['trackPageView']);
			_paq.push(['enableLinkTracking']);
			(function() {
				var u="//www.stats.numberchallenge.com/";
				_paq.push(['setTrackerUrl', u+'piwik.php']);
				_paq.push(['setSiteId', <?=$piwik_id; ?>]);
				var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
				g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
			})();
		</script>
		<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>

		<style>
		body {
			background:#F7EFEC;
			color:#ccc;
		}
		.footer {
		  position: fixed;
		  bottom: 0;
		  width: 100%;
		  background-color: #dedede;
		  padding:10px 0px 0px;
		}
		.sign-up-container ul {
			margin-left: -40px;
		}
		.sign-up-container ul li {
			list-style-type:none;
			margin-bottom: 100px;
		}
		.sign-up-container .active {
			color:#222 !important;
		}
		.sign-up-container select {
			height: 50px;
			width: 100%;
			background: #F7EFEC;
			border: 1px solid rgb(221, 221, 221);
			font-size: 21px;
			border-radius: 3px;
		}
		.bd{
			opacity:0;
		}
		.loadingoverlay {
		    z-index : 9999;  /* This value should be just higher than your other elements' z-indexes */
		}

		.working {
		    background: url("img/ajax-loader-trans.gif") no-repeat scroll right center !important;
		    padding-right: 2px;
		}

		</style>
	</head>

	<body id="body" data-spy="scroll" data-target=".navbar" data-offset="200">	
	<div class="navbar" style="display:none;">
			<ul class="nav">
				<li><a href="#section1">Section 1</a></li>
				<li><a href="#section2">Section 2</a></li>
				<li><a href="#section3">Section 3</a></li>
				<li><a href="#section4">Section 4</a></li>
				<li><a href="#section5">Section 5</a></li>
				<li><a href="#section6">Section 6</a></li>
				<li><a href="#section7">Section 7</a></li>
				<li><a href="#section8">Section 8</a></li>
				<li><a href="#section9">Section 9</a></li>
				<li><a href="#section10">Section 10</a></li>
				<li><a href="#section11">Section 11</a></li>
				<li><a href="#section12">Section 12</a></li>
			</ul>
	</div>
    <div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="sign-up-container">
					<form>
						<ul>
							<li class="active">
								<div class="form-group" id="section1">
									<label><span class="number">1</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What is your <b>first name</b>?&nbsp;<b class="suc-asterisk">*</b></label>
									<input type="text" class="form-control" name="first_name">
									<div id="alert_fname" class="alert alert-danger" role="alert" style="display:none;">Please fill this in.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general" id="fname_btn" />										
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section2">
									<label><span class="number">2</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What is your <b>last name, <span id="span_lname"></span></b>?&nbsp;<b class="suc-asterisk">*</b></label>
									<input type="text" class="form-control" name="last_name">
									<div id="alert_lname" class="alert alert-danger" role="alert" style="display:none;">Please fill this in.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section3">
									<label><span class="number">3</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;Create <b>password</b>&nbsp;<b class="suc-asterisk">*</b></label>
									<input type="password" class="form-control" name="password">
									<div id="alert_pwd" class="alert alert-danger password" role="alert" style="display:none;">Password is required.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>							
								<div class="form-group" id="section5">
									<label><span class="number">5</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;Select <b>country</b>&nbsp;<b class="suc-asterisk">*</b></label>
									<select id="country" class="form-control" id="country_id" >
										<option value="">Select Country *</option>
												<?php foreach($countriesarray as $country):?>
												<option value="<?php echo $country['country_id'];?>"><?php echo $country['name'];?></option>
										<?php endforeach;?>
									</select>
									<div id="alert_country" class="alert alert-danger password" role="alert" style="display:none;">Please select a country.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section6">
									<label><span class="number">6</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;Enter <b>city</b>&nbsp;<b class="suc-asterisk">*</b></label>
									<input type="text" class="form-control" id="city" name="city" >
									<div id="alert_city" class="alert alert-danger password" role="alert" style="display:none;">Please fill this in.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section7">
									<label><span class="number">7</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What is your LinkedIn Profile?&nbsp;</label>
									<p>*This must be a direct link to your profile. Applications with a bad link are deleted automatically. </p>
									<input type="text" class="form-control" placeholder="http://" name="linkedIn">
									<div id="alert_linkedIn" class="alert alert-danger password" role="alert" style="display:none;">Invalid Url.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section8">
									<label><span class="number">8</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What is your Twitter Profile?&nbsp;</label>
									<input type="text" class="form-control" placeholder="http://" name="twitter">
									<div id="alert_twitter" class="alert alert-danger password" role="alert" style="display:none;">Invalid Url.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section9">
									<label><span class="number">9</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What is your Facebook Profile?&nbsp;</label>
									<input type="text" class="form-control" placeholder="http://" name="fb">
									<div id="alert_fb" class="alert alert-danger password" role="alert" style="display:none;">Invalid Url.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section10">
									<label><span class="number">10</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What type of work are you looking to exchange for equity?&nbsp;<b class="suc-asterisk">*</b></label>
									<div class="clearfix"></div>
									<div class="work_type">
										<?php foreach($industriesarray as $industries):?>
										<div class="bd2">
											<input type="hidden" name="industry_id" value="<?php echo $industries['IndustryId'];?>" />
											<input id="<?php echo $industries['Name'];?>" name="industry" type="radio" class="with-font work_type" value="<?php echo $industries['Name'];?>" />
											<label for="<?php echo $industries['Name'];?>"><?php echo $industries['Name'];?></label>
										</div>
										<?php endforeach;?>
									</div>
									<div id="alert_workType" class="alert alert-danger password" role="alert" style="display:none;">Please select a work type.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section11">
									<label><span class="number">11</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What is your preferred role?&nbsp;<b class="suc-asterisk">*</b></label>
									<div class="clearfix"></div>
									<div class="role">
										<?php foreach($rolesarray as $roles):?>
										<div class="bd2">
											<input type="hidden" name="role_id" value="<?php echo $roles['role_id'];?>" />
											<input id="<?php echo $roles['role_name'];?>" name="role_name" type="radio" class="with-font role_name" value="<?php echo $roles['role_name'];?>" />
											<label for="<?php echo $roles['role_name'];?>"><?php echo $roles['role_name'];?></label>
										</div>
										<?php endforeach;?>
									</div>
									<div id="alert_role" class="alert alert-danger password" role="alert" style="display:none;">Please select your role.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="form-group" id="section12">
									<label><span class="number">12</span>&nbsp;<i class="fa fa-arrow-right"></i>&nbsp;What kind of arrangement are you looking for?&nbsp;<b class="suc-asterisk">*</b></label>
									<div class="clearfix"></div>
									<div class="role">
										<?php foreach($intentions as $intention):?>
										<div class="bd2" style="width:100%;">
											<input id="<?php echo $intention;?>" name="intention" type="radio" class="with-font intention" value="<?php echo $intention;?>" />
											<label for="<?php echo $intention;?>"><?php echo $intention;?></label>
										</div>
										<?php endforeach;?>
									</div>
									<div id="alert_intention" class="alert alert-danger password" role="alert" style="display:none;">Please select your intention.</div>
									<div class="bd">
										<input type="button"  value="ok" class="btn btn-primary input-lg general"  />
										<div class="button-text">
											press <b>ENTER</b>
										</div>
									</div>
								</div>
							</li>							
						</ul>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="submit-button-container">
	<hr style="border-bottom:1px solid #ccc;">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<input id="boom" type="submit" name="submit_btn" value="Submit!" class="btn btn-primary input-lg" />
					<input type="hidden" id="ip" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
					<input type="hidden" id="domain" name="domain" value="<?php echo $domain; ?>"/>
					<input type="text" id="secret" name="secret" value="" style="display:none;">
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	
    <footer class="footer">
      <div class="container">
		<div id="progress" class="col-md-8 col-md-offset-2">
			<label>0% Completed</label>
			<div class="progress">			
			  <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 0%;">
				<span class="sr-only">0% Complete</span>
			  </div>
			</div>
		</div>
      </div>
    </footer>
   <script src="https://code.jquery.com/jquery-2.2.1.min.js" integrity="sha256-gvQgAFzTH6trSrAWoH1iPo9Xc96QxSZ3feW6kem+O00=" crossorigin="anonymous"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
   <script src="js/jquerysession.js"></script>
   <script src="js/loadingoverlay.js"></script>
   <script src="js/signup.js"></script>
   
   <script>
	function progress()
	{
		var items = 0;
		$('.form-control').each(function(){
			if($(this).val()!=''){
				items++;
			}
		});
		
		if($('.work_type:checked').length>0){
			items++;
		}
		if($('.intention:checked').length>0){
			items++;
		}
		if($('.role_name:checked').length>0){
			items++;
		}
		
		if(items==0){
			$('#progress label').html('0% Completed');
			$('#progress span').html('0% Completed');
			$('#progress .progress-bar').css('width','0%');
			return;
		}
		if(items<10){
			$('#progress label').html(items+'0% Completed');
			$('#progress span').html(items+'0% Completed');
			$('#progress .progress-bar').css('width',items+'0%');			
		}else if(items==11){
			$('#progress label').html('95% Completed');
			$('#progress span').html('95% Completed');
			$('#progress .progress-bar').css('width','95%');
		}else if(items==12){
			$('#progress label').html('100% Completed');
			$('#progress span').html('100% Completed');
			$('#progress .progress-bar').css('width','100%');
		}
	}
	
	$( document ).ready(function() {
		$('.form-control').val('');
		
		$('.intention, .role_name, .work_type').click(function(){
			progress();
		});
		
		$('.role_name, .intention, .work_type').change(function(){
			progress();
		});
				
		$('input.general').click(function(){
			var i =$('input.general').index(this);
			var target = $('input.general').eq(i+1);
			$('html,body').animate({
			   scrollTop: target.parents('.form-group').offset().top
			}, 1000, 'swing', function(){
				setTimeout(function(){
					target.parents('li').find('.form-control').focus();
				},100);
			});
		});
		
		$('.form-control').keyup(function( event ) {
			$('.bd').css('opacity',0);
			if($(this).val()!=''){
				$(this).parents('li').find('.bd').css('opacity',1);
			}
			progress();
		}).keydown(function( event ) {
		  if ( event.which == 13 ) {
			if($(this).val()!=''){
				$(this).parents('li').find('input.general').trigger('click');
			}
		  }
		});
		
		$('.navbar').on('activate.bs.scrollspy', function () {
			$('.sign-up-container li').removeClass('active');
			$('.bd').css('opacity',0);
			var id = $('.nav li.active a').attr('href');
			$(id).parents('li').addClass('active');
			if($(id).find('.form-control').length>0){
				if($(id).find('.form-control').val()!=''){
					$(id).find('.bd').css('opacity',1);
				}
			}
			progress();
		});
	});

			$(document).ready(function(){
				$('#city').keyup(function(){
					var country_name = $('#country').children('option').filter(':selected').text();
					$('#city').autocomplete({
						search  : function(){$(this).addClass('working');},
						open    : function(){	
									$(this).removeClass('working');
									$('ul.ui-menu').css({'z-index':'1000','border-radius':'0','border-color':'#fff','class':'form-control'});
								},
						source: 'http://www.contrib.com/network/autocompleteCity/'+country_name,
						minLength: 2,
						select: function (event, ui) {   
							var selectedObj = ui.item;
							var cityname = selectedObj.value;
							$('#city').text(cityname);	
							$(this).removeClass('working');
						}
					});
				});
		});						

</script>
  </body>
</html>
