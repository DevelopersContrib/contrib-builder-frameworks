<script type="text/javascript" src="/js/plugins/jquery.number.js"></script>		
<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.1/themes/smoothness/jquery-ui.css">
<style type="text/css">
@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800);
body{
	font-family: 'Open Sans', sans-serif;
	font-weight: 300;
	background:#eee;
}
.wrap-header-container{
	border-bottom: 1px solid #ddd;
	padding: 20px 0;
	background-color: #fff;
}		
.form-group.has-error small.help-block{
	color: #fff;
	padding: 0 10px 5px;
	font-weight: 700;
}
.form-group.success:after {
	font-family: "Glyphicons Halflings";
	content: "\e013";
	color: #44b27b;
	position: absolute;
	right: 20px;
	top: 12px;
	font-size: 1.5em;
}
.form-group.has-error small.help-block {
	color: #fff;
	font-weight: 700;
	padding: 0 10px 5px;
}
.step2, .step3, .step4, .step5{
	display: none;
}
.ep-calculator {
background:#fff;
padding:40px 50px;
border-radius:12px;
margin-top:30px;
margin-bottom:20px;		
border:1px solid #dedede;
box-shadow: 0px 4px #dedede, 0px 10px 15px rgba(0, 0, 0, 0.2);
}
.ep-calculator .form-control {
height:40px;
font-size:16px;
}
.ep-calculator .equal-sign {
font-size:40px;
}
.ep-calculator .ep-tresult {
	font-size: 48px;
	font-weight: bold;
	vertical-align: -6px;
}
.calculator-box {
}
.ep-calculator .numbr {
	font-size: 24px;
	font-weight: bold;
}
.ep-calculator .indesign {
	box-shadow: 0px 4px rgba(0, 0, 0, 0.2) inset;
	background: #f3f3f3;
	border-radius: 3px;
	border: medium none;
	margin-top: 8px;
	color:#121212;
}
.ep-calculator .btn-primary {
	border-bottom: 5px solid #2e6da4;
}
.errmsg {
	position: absolute;
}
.ui-autocomplete{
	max-width:300px !important;
}

.working {
	background: url("/images/ajax-loader-trans.gif") no-repeat scroll right center #fff !important;
}
.errmsg{
	color:red;
}
.chart-container .chart-heading {	
	background: #fafafa;
	padding: 1px 10px;
	margin-bottom: 10px;
	border-bottom: 1px solid #dedede;
}
.rowie {
	padding-bottom: 30px;
}
.computeEP {
	margin-top: 15px;
}
.spinner {
  display: inline-block;
  opacity: 0;
  width: 0;

  -webkit-transition: opacity 0.25s, width 0.25s;
  -moz-transition: opacity 0.25s, width 0.25s;
  -o-transition: opacity 0.25s, width 0.25s;
  transition: opacity 0.25s, width 0.25s;
}

.has-spinner.active {
  cursor:progress;
}

.has-spinner.active .spinner {
  opacity: 1;
  width: auto; /* This doesn't work, just fix for unkown width elements */
}

.has-spinner.btn-mini.active .spinner {
    width: 10px;
}

.has-spinner.btn-small.active .spinner {
    width: 13px;
}

.has-spinner.btn.active .spinner {
    width: 16px;
}

.has-spinner.btn-large.active .spinner {
    width: 19px;
}
.control-label {
	font-weight: 400;
}
</style>	

<div class="calculator-box">
	<div class="ep-calculator">
		<div class="row">
			<div class="rowie">
				<!-- calc -->
				<div class="form-horizontal form-pricing" >	
						<div class="price-form">
							  <div class="form-group">
								  <div class="row">
										<div class="col-sm-5">
										  <label class="control-label pull-right">Choose from any of our brands</label>
										</div>
										<div class="col-sm-7">
											<input id="domain_name" type="text" class="txt form-control indesign" placeholder="e.g contrib.com"><span class="errmsg"></span>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-5">
										  <label class="control-label pull-right">Your Rate/Hr ($): </label>
										</div>
										<div class="col-sm-7">
											<input id="rate" type="text" class="txt form-control numbr indesign" name="myrate" id="myrate"><span class="errmsg"></span>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-5">
										  <label class="control-label pull-right">How many hours in total can you contribute? </label>
										</div>
										<div class="col-sm-7">
											<input id="hrs" type="text" class="txt form-control numbr indesign" name="myhour" id="myhour"><span class="errmsg"></span>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-5">
										  <label class="control-label pull-right">What do you want to contribute?  </label>
										  <small class="pull-right">Choose from suggested contributions or make your own</small>
										</div>
										<div class="col-sm-7">
											<input type="text" id="contribution_title" class="txt form-control indesign" placeholder="e.g Write content" /><span class="errmsg"></span>
											<input type="hidden" id="contribution_ep" />
										</div>
									</div>
								</div>													
							  <div class="form-group">
								  <div class="computeEP">
									<button id="calculate" data-loading-text="Calculating equity points..."  type="submit" class="btn btn-primary btn-lg btn-block has-spinner"><span class="spinner"><i class="icon-spin icon-refresh"></i></span>&nbsp;Calculate Your Equity Points <span class="glyphicon glyphicon-chevron-right"></span></button>
								  </div>
							  </div>
								<div class="form-group">
								  <div style="display:none;" class="resultEP text-center">
									<span class="equal-sign"><img src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/coin-equity-points-50x50.png" alt="equity points" title="equity points"></span>&nbsp;
									<span class="ep-tresult">209,013</span>
									<h4>Equity Points <i class="fa fa-at"></i> $ <span id="valuation"></span> Valuation</h4>
									<h4>Pie Share  <span id="pieshare"></span>%</h4>
									<small>(Total of user contribution per domain/Total of all domain contribution of all users under equity type(crowd,investor,partnership) per domain) X equity percent based on venture settings</small>
									<h5>Domain Revenue : $<span id="monetization_result"></span> X <span id="percent_result"></span></h4>

								<h4>Revenue Share : $<span id="revenue_content"></span></h4>
								  <small>(Domain total monetization value from referral programs revenue  - Domain expenses ) X (equity percent / 100)</small>
									<p><small>1 Equity Point is = $1. Our $ Valuation is calculated by our eShares app. It is volatile and dynamic and tends to go up. If there are 
									many contributions to this brand, the computed valuation number will go up. </small></p>
								  </div>
							  </div>												  
						</div>
				</div>												
				<!-- end calc -->
				<div class="summary" style="display:none;">
					<div class="chart-container">
						<div class="chart-heading">
							<h4 class="text-center">Current Equity Pie for Brand</h4>
						</div>
						<div class="chart-body">
							<div class="flot-chart">
								<center id="loading" style="display:none;">Loading...</center>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
			</div>											
		</div> 
		<div class="clearfix"></div>
	</div>
		<div class="clearfix"></div>
</div>
	<div class="clearfix"><br></div>
</div>
<script src="/js/flot/excanvas.min.js"></script>
<script src="/js/flot/jquery.flot.js"></script>
<script src="/js/flot/jquery.flot.pie.js"></script>
<script src="/js/flot/jquery.flot.resize.js"></script>
<script src="/js/flot/jquery.flot.tooltip.min.js"></script>
<script>
jQuery(document).ready(function () {
	var x = 0;
  //called when key is pressed in textbox
  jQuery("#myrate").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
        jQuery("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   });
   jQuery("#myhour").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
        jQuery("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   });
   
   jQuery('#domain_name').val('');
   jQuery('#rate').val('');
   jQuery('#hrs').val('');
   jQuery('#contribution_title').val('');
   
   jQuery('.txt').keypress(function(){
		jQuery(this).next().html('').hide();
   });
   
   jQuery('#contribution_title').keyup(function(){
		if(jQuery(this).val()=="") jQuery('#contribution_ep').val('');
   });
   
   jQuery('#calculate').click(function()
   {
	   var error = false;
		jQuery('.errmsg').html('').hide();
		if(jQuery('#domain_name').val()==""){
			jQuery('#domain_name').next().html('Please enter domain').show();
			error = true;
		}
		
		if(isNaNex(jQuery("#rate").val()) && isNaNex(jQuery("#hrs").val()) && isNaNex(jQuery("#contribution_ep").val())){
			jQuery("#rate").val('');
			jQuery("#hrs").val('');
			jQuery("#rate").next().html('Please enter rate').show();
			jQuery("#hrs").next().html('Please enter hrs').show();
			error = true;
		}else if(isNaNex(jQuery("#rate").val()) && isNaNex(jQuery("#contribution_ep").val())){
			jQuery("#rate").val('');
			jQuery("#rate").next().html('Please enter rate').show();
			error = true;
		}else if(isNaNex(jQuery("#hrs").val()) && isNaNex(jQuery("#contribution_ep").val())){
			jQuery("#hrs").val('');
			jQuery("#hrs").next().html('Please enter hrs').show();
			error = true;
		}
		
		if(error) return false;
		
		var ep = getEP();
		
		jQuery('.resultEP').hide();
		jQuery(this).button('loading');
		showeshares(jQuery('#domain_name').val(),ep);
		
		return false;
   });
   
   function getPie(domain)
   {
	   jQuery('.summary').show();
	   jQuery('#loading').show();
	   jQuery('.chart').remove();
	   jQuery.post('/post',
			{
				domain:domain,
			},
		    function(data){
				jQuery('#loading').hide();				
				//var data = data.data;
				var obj = jQuery.parseJSON( data );
				console.log(obj.data);
				var data = obj.data;
				//console.log(obj['data']);
				x++;
				jQuery('.flot-chart').append('<div id="flot-pie-chart'+x+'" class="chart" style="width:100%;height:250px;"></div>');				
				var plotObj = $.plot($("#flot-pie-chart"+x), data, {
					series: {
						pie: {
							show: true
						}
					},
					grid: {
						hoverable: true
					},
					tooltip: true,
					tooltipOpts: {
						content: "%p.0%, %s", // show percentages, rounding to 2 decimal places
						shifts: {
							x: 20,
							y: 0
						},
						defaultTheme: false
					}
				});
		});
   }
   
   function isNaNex(a)
   {
		if(a=="") return true;
		return isNaN(a);
   }
   
   jQuery('#domain_name').autocomplete({
		search  : function(){jQuery(this).addClass('working');},
		open    : function(){jQuery(this).removeClass('working');},
		source: 'https://manage.vnoc.com/company/autoDomain/0',
		minLength: 2,
		select: function (event, ui) {   
			var selectedObj = ui.item;   
			var domain_name = selectedObj.value;
			$('#domain_name').val(domain_name);
			$('#contributedomain').html(domain_name);
			
			getPie(jQuery('#domain_name').val());
			
			jQuery('#rate').val('');
			jQuery('#hrs').val('');
			jQuery('#contribution_title').val('');
			
			jQuery(this).removeClass('working');
			initialize_autocomplete(domain_name);
			jQuery('#rate').focus();
		}
	});
	
   function showeshares(domain,ep){
   		$('#calculate').html('Calculating...');
		jQuery.post('/getshare',
			{
			   domain:domain,
			   ep:ep

			},
		    function(data){
		    	var obj = jQuery.parseJSON( data );
				//console.log(obj.data);
				var data = obj.data;
				console.log(data.theo);	
				jQuery('.ep-tresult').html(getEP());
				jQuery('#valuation').html($.number(data.theo));
				jQuery('#calculate').button('reset');
        
        
        jQuery.post('/getpierevenue',
			{
			   domain:domain,
			   ep:ep

			},
		    function(data){				
			var obj2 = jQuery.parseJSON( data );
			//console.log(data);
			var data2 = obj2.data;
			console.log(data2);	
			jQuery('.resultEP').show();
          	jQuery('#pieshare').html(data2.share);
          	jQuery('#revenue_content').html($.number(data2.revenue));
          	jQuery('#monetization_result').html($.number(data2.main_revenue));
          	jQuery('#percent_result').html(data2.main_percent);
          	$('#calculate').html(' Calculate Your Equity Points ');
				
		});
        

		});
	}
   
	function getEP()
	{
		var rate = jQuery('#rate').val();
		var hrs = jQuery('#hrs').val();
		if( isNaNex(rate)){
			jQuery('#rate').val(0);
		}
		
		if( isNaNex(hrs)){
			jQuery('#hrs').val(0);
		}
		
		var ep = 0;
		if(jQuery('#rate').val()<1 && jQuery('#hrs').val()<1){
			var contribution_ep = jQuery('#contribution_ep').val();
			
			if(isNaNex(contribution_ep)){
				ep = 0;
			}else{
				ep = contribution_ep;
			}
		}else{
			ep = rate * hrs;
		}
		
		return ep;
	}
   
		
		function initialize_autocomplete(domain){	 
			
			var titles = [
			  {
				value: "10",
				label: "Brand Discussion",
				desc: "Post discussion to "+domain.toUpperCase()+"."
			  },
			  {
				value: "10",
				label: "Create Meta Title and Description",
				desc: "Create meta title and description for "+domain.toUpperCase()+"."
			  },
			  {
				value: "10",
				label: "Content Writing",
				desc: "Create and write content description for "+domain.toUpperCase()+"."
			  },
			  {
				value: "10",
				label: "Create Logo",
				desc: "Create logo for "+domain.toUpperCase()+"."
			  },
			  {
				value: "10",
				label: "Create Marketing Strategies",
				desc: "Create marketing strategies for the development of "+domain.toUpperCase()+"."
			  },
			  {
				value: "10",
				label: "Blog Contributor",
				desc: "Will refer a blog contributor, with or without experience. Sample written stuff will be sent to you."
			  },
			  {
				value: "10",
				label: "Research for Top Accelerators",
				desc: "Research atleast 15 top startup accelerators."
			  },
			  {
				value: "10",
				label: "Research for Startup Tools",
				desc: "Research for Top Startup Tools in 2014. An excel file will be added and will be shared via the update chat box."
			  },
			  {
				value: "10",
				label: "Tweet about "+domain.toUpperCase()+" in my twitter page",
				desc: "Tweet about "+domain.toUpperCase()+" in my twitter page. I will give you a link to my twitter page to confirm it."
			  },
			  {
				value: "10",
				label: domain.toUpperCase()+" Social Post",
				desc: "Post about "+domain.toUpperCase()+" linking to Facebook, Twitter, Google+ and/or Linkedin Pages. Screenshot or a link to my specific post regarding "+domain.toUpperCase()+" will be given to confirm it."
			  },
			  {
				value: "20",
				label: "Forum Topic Contributors",
				desc: "Specific topic and post about specific topic chosen will be posted here -> https://contrib.com/discussions"
			  },
			  {
				value: "10",
				label: "Do a write up about "+domain.toUpperCase()+" in my website or blog",
				desc: "Screenshot or a link to my specific post will be given to confirm it."
			  },
			  {
				value: "10",
				label: "Add a link or badge about "+domain.toUpperCase()+" to your blog",
				desc: "Link to my blog, with a decent traffic, will be given to confirm it."
			  }
			];
		 
			$( "#contribution_title" ).autocomplete({
			  minLength: 0,
			  source: titles,
			  focus: function( event, ui ) {
				$( "#contribution_title" ).val( ui.item.label );
				return false;
			  },
			  select: function( event, ui ) {
				$( "#contribution_title" ).val( ui.item.label );
				$( "#contribution_desc" ).val( ui.item.desc );
				$( "#contribution_worth" ).val( ui.item.value );
				//showeshares(domain,ui.item.value);
				$('#contribution_ep').val(ui.item.value);
				return false;
			  }
			})
			.autocomplete( "instance" )._renderItem = function( ul, item ) {
			  return $( "<li>" )
				.append( "<a>" + item.label + "<br><small style='color:gray'>" + item.desc + "</small></a>" )
				.appendTo( ul );
			};
		}	  
});

$(function(){
    $('a, button').click(function() {
        $(this).toggleClass('active');
    });
});
</script>	