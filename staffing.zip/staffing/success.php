<?php include('includes/config.php');?>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=$title?></title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="custom.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="js/jquerysession.js"></script>
<style>
.page-container {
	margin-top:50px;
}
.page-container .btn-pg {
	margin-bottom:30px;
}
.success-box .name {
	color:green;
}
.tyg {
    margin-top: 100px;
    margin-bottom: 0px;
    border-bottom: 1px solid #1D772A;
}  
	.tyg img {
		height: 250px;
	}
hr {
	border-bottom: 1px solid #1D772A;
}
.success-box .email {
	color:green;
}
.success-box .domain {
	color:green;
}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		var name = $.session.get('name');
		$('.name').html(name);
	});
</script>
<!-- page container-->
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 text-center">			
			<div class="page-container success-box">
				<div class="tyg">
				<img src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" alt="Thank you" title="Thank you">
				<h2 style="margin-top: -50px;"><span class="name"></span> for signing up!</h2>				
				</div>
				<div class="check-email">
				<h3>You are only seconds to joining <span class="domain"><?=$domain?></span></h3>
				<h3>Check your <span class="email">email</span> for more updates.</h3>
				</div>
				<div class="addhtml">
						<?if($additional_html != ""):?>
						<?echo base64_decode($additional_html)?>
						<?endif;?>
				</div>
				<hr>
				<a href="/" class="btn btn-primary btn-lg">Return Homepage</a>
			</div>
		</div>
	</div>
</div>
<!-- end page container-->