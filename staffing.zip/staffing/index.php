<?php include('includes/config.php');?>

<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="<?php echo $description;?>">
	<meta name="author" content="<?php echo $domain; ?>">
	<meta name="keywords" content="<?php echo $keywords; ?>"/>

	<title><?=$title?></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="custom.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		
		<!-- piwik/ga -->
		<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
			ga('create', '<?=$account_ga?>', 'auto');
			ga('send', 'pageview');
		</script>
		<!-- Piwik -->
		<script type="text/javascript">
			var _paq = _paq || [];
			_paq.push(['trackPageView']);
			_paq.push(['enableLinkTracking']);
			(function() {
				var u="//www.stats.numberchallenge.com/";
				_paq.push(['setTrackerUrl', u+'piwik.php']);
				_paq.push(['setSiteId', <?=$piwik_id; ?>]);
				var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
				g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
			})();
		</script>
		<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>

	<style>
	body {
		font-family: Arial !important;
	}
	.feature-text h2 {
		font-size: 34px;
	}
	.feature-text .fa {
		font-size:100px;
	}
	.sec-jw {
		padding:80px 0px;
	}
	.for-equity {
		display: inline-block;
		background-color: #fff;
		color:#666;
		border: 1px solid #ccc;
		box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
		font-size: 21px;
		padding: 7px 15px 0px;
		vertical-align: -3px;
		height: 46px;
	}

	<?php
		if ($background_image != "" ) { ?>
			.banner
			 {				
			 background-image: linear-gradient( rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5) ),url(<?php echo $background_image ?>);
			background-position: 50% 50%;
			background-repeat: no-repeat;
			-webkit-background-size: cover;
			-moz-background-size: cover;
			-o-background-size: cover;
			background-size: cover;
			background-attachment: fixed;
			 }

	<?php } ?>

	</style>
	</head>
	<body>
		<div class="banner header-banner">
			<div class="container">
				<div class="col-md-12">
					<div class="description">
						<p>
							
							<?php if (empty($logo)) { ?>
									<h1 class="text-center logo-desc"> <?php echo ucfirst($domain) ?> </h1>
							<? }else{?>
									<img class="ed-head" src="<?=$logo?>">
							<?php }?>

						</p>
						<h1 class="text-center main-desc"><?=$description?></h1>
					</div>
					<div class='form-inline' role='form'>
						<form novalidate="novalidate" class="simple_form new_user" id="new_user" action="#" accept-charset="UTF-8" method="post">
						<input name="utf8" type="hidden" value="&#x2713;" />
						<input type="hidden" name="authenticity_token" value="ovIvn99xTl7TBd620AMATHZ6lsxbDqJHIhvzca9dLU8wVttqCxmddocPHYlJT3UY/dZE78xlmCYG3detRxVjPA==" />
						<input label="false" class="string email required form-control input-lg" id="email" placeholder="Email" type="email" value="" name="user[email]" />
						<div class="for-equity">I am looking to work for equity</div>
						<!-- <input type="submit" name="submit" value="REQUEST EARLY ACCESS" class="btn btn-primary input-lg" /> -->
						<a href="#" id="validation" class="btn btn-primary btn-lg btn-rea">REQUEST EARLY ACCESS</a>
						<input type="hidden" id="user_ip" name="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
						<input type="hidden" id="domain" name="domain" value="<?php echo $domain; ?>"/>
						<div class="alert alert-danger email-alert" role="alert" id="emailexist" style="display:none;">*Email Already Exist.</div>
						<div class="alert alert-danger email-alert" role="alert" id="emptyemail" style="display:none;">*Please Enter a Valid Email Address.</div>
						<div class="alert alert-danger email-alert" role="alert" id="invalidemail" style="display:none;">*Invalid Email Address.</div>

						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="section sec-jw" style="background:#fff;">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-6 text-center">
						<div class="feature-text">
						<i class="fa fa-sign-in" aria-hidden="true"></i>
						<h2>Join any of our brands and companies.</h2>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6">
						<div class="feature-text text-center">
						<i class="fa fa-cog" aria-hidden="true"></i>
						<h2>Work for equity in a transparent network.</h2>
						</div>
					</div>
				</div>
			</div>
		</div>	
		
		<div class="section" style="background:#f5f5f5;">
			<div class="container">
				<div class="row"> 
					<h2 class="text-center">Check out our Contrib Calculator below:</h2>
					<div class="col-md-6 col-md-offset-3">
						<?php include 'calculator.php';?>
					</div>
				</div>
			</div>
		</div>
		<?php if (count($related_domains) >0):?>
		<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
		<div class="section-brands" style="padding: 50px 0px; background:#fff;">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center lead-ttle-top" style="padding-bottom: 10px;">
							<h2 class="brdr-lead">
								<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
								Our Partner Sites
							</h2>
						</div>
						<div class="col-md-6 col-md-offset-3 ops-box">
							<div class="verlist">
								<div class="row">
								   <?php $count = count($related_domains)?>
									<div class="col-sm-6 col-xs-12">
										<ul class="list-unstyled ul-verticals">
										   <?php for ($i=0;$i<$count;$i++):?>
											<li>
												<a href="http://<?php echo $related_domains[$i]['domain_name']?>" class="text-capitalize" target="_blank">
													<i class="fa fa-angle-right"></i>
													<?php echo $related_domains[$i]['domain_name']?>
												</a>
											</li>
										   
										   <?php if ($count > 5 && $i==4):?>
										   
										</ul>
									</div>
									<div class="col-sm-6 col-xs-12">
										<ul class="list-unstyled ul-verticals">
									<?php endif?>
								   <?php endfor;?>     
											
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-12 text-center">
							<br />
							<div class="form-group">
								<a href="http://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" class="btn btn-success" target="_blank">
									<i class="fa fa-search"></i>
									View More
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		 <?php endif?> 
		
		<!-- footer -->
	   <?php include('footer.php');?>
		<!-- end footer -->


	<script src="js/main.js"></script>
	<script src="js/jquerysession.js"></script>


		<script type="text/javascript">
		function validateEmail(email) {
			  var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
				   
				    if (filter.test(email)) {
				        return true;
				    }
				    else {
				        return false;
			}
		}

		function Saveleads () {
			var email = jQuery('#email').val();
			var user_ip = jQuery('#user_ip').val();
			var domain = jQuery('#domain').val();

			jQuery.post('http://www.api.contrib.com/forms/saveleads',
			{
				domain:domain,
				user_ip:user_ip,
				email:email

			},function(data){
				console.log('Success Leads');
				$('#emailexist').hide();
						$('#emptyemail').hide();
						$('#invalidemail').hide();
						var equity = $('#equity option:selected').text();
						var email = $('#email').val();
						$.session.set('email', email);
						$.session.set('equity', equity);
						window.location.href = 'sign-up';
			}
			)

		}

		$("#validation").click(function(){
			var button = $(this);
			
			flagEmail = false;
			var email = $('#email').val();
			if ($.trim(email).length == 0) 
			{
				$('#emptyemail').show(500);

				setTimeout(function() {
				    $('#emptyemail').fadeOut('fast');
				}, 2000); 


			}
			else if(validateEmail(email)) 
			{
				flagEmail = true;
				$('#emptyemail').hide();
				$('#invalidemail').hide();
			}
			else{
				
				$('#invalidemail').show(500);

				setTimeout(function() {
				    $('#invalidemail').fadeOut('fast');
				}, 2000); 
			}

			if (flagEmail==true) {
				button.attr('disabled','disabled').html('Please Wait .. ');
				$.post('http://www.contrib.com/signup2/checkemailexists',

				{
					email:email
				}
				,
					function(data){
					
					if (data.exists===true) 
					{
						$('#emailexist').show();
							setTimeout(function() {
							    $('#emailexist').fadeOut('fast');
							}, 2000); 
					}
					else
					{	
						Saveleads();
					}
				})
			}
			
		});
			
	</script>
	</body>
</html>