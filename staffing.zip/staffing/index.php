<?php include('header.php'); ?>



<body>

	<div class="navigation-container d-none">

		<?php include('navigation.php'); ?>

	</div>

	<div class="main">

		<!-- main inner -->

		<div class="outer-container vh-100">

			<div class="container h-100 d-flex justify-content-center">

				<div class="jumbotron-middle my-auto text-center">

					<h1 class="display-3 fw-600">

						<?php 
						//var_dump($logo);
						if(!empty($logo)) {

								if(strpos($logo,'https') === FALSE){
									$logo_url = str_replace('http','https',$logo);
								}else{
									$logo_url = $logo;
								}

								echo '<img class="ed-head" src="'.$logo_url.'">';

							} else {

								echo '<h1 class="display-3 fw-600">'.ucfirst($domain).'</h1>';

							}?>

					</h1>

					<h5><?=$description?></h5>

					<div class="form-row form-box" role='form'>

					    <div class="col-md-4">

						      <form novalidate="novalidate" class="simple_form new_user" id="new_user" action="#" accept-charset="UTF-8" method="post">

							<input name="utf8" type="hidden" value="&#x2713;" />

							<input type="hidden" name="authenticity_token" value="ovIvn99xTl7TBd620AMATHZ6lsxbDqJHIhvzca9dLU8wVttqCxmddocPHYlJT3UY/dZE78xlmCYG3detRxVjPA==" />

							<input label="false" class="string email required form-control form-control-lg" id="email" placeholder="Email" type="email" value="" name="user[email]" />					      

					    </div>

					    <div class="col-md-5">

						<input type="text" class="form-control form-control-lg" id="" value="I am looking to work for token" disabled>					      

					    </div>

					    <div class="col-md-3">

						      <a href="#" id="validation" class="btn btn-primary btn-lg btn-block">Request Access</a>

							<input type="hidden" id="user_ip" name="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">

							<input type="hidden" id="domain" name="domain" value="<?php echo $domain; ?>"/>							

					    </div>

					    <div class="col-md-12">

						<div class="alert alert-danger email-alert" role="alert" id="emailexist" style="display:none;">*Email Already Exist.</div>

						<div class="alert alert-danger email-alert" role="alert" id="emptyemail" style="display:none;">*Please Enter a Valid Email Address.</div>

						<div class="alert alert-danger email-alert" role="alert" id="invalidemail" style="display:none;">*Invalid Email Address.</div>

					    </div>

					 </div>

				</div>

			</div>

		</div>

		<div class="section sec-jw section-white">

			<div class="container">

				<div class="row">

					<div class="col-md-6 col-sm-6 text-center">

						<div class="feature-text">

						<i class="fa fa-sign-in" aria-hidden="true"></i>

						<h2>Join any of our brands and companies.</h2>

						</div>

					</div>

					<div class="col-lg-6 col-md-6 col-sm-6">

						<div class="feature-text text-center">

						<i class="fa fa-cog" aria-hidden="true"></i>

						<a href="https://crypto.contrib.com/" target="_blank" class="work-for-token-link">

							<h2>Work for Contrib Tokens in our blockchain powered Contribution platform.</h2>

						</a>

						</div>

					</div>

				</div>

			</div>

		</div>

		<div class="section section-light">

			<div class="container">

				<div class="row justify-content-center"> 

					<h2 class="text-center fw-600">Check out our Contrib Calculator below</h2>

					<div class="col-md-6">

						<?php include 'calculator.php';?>

					</div>

				</div>

			</div>

		</div>

		<div class="section">

			<div class="cont-box text-center">

				<script type="text/javascript" src="https://tools.contrib.com/eservice?d=<?php echo $domain?>&ver=2"></script>

			</div>

		</div>

		<?php if (count($related_domains) >0):?>

		<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>

		<div class="section-brands" style="padding: 50px 0px; background:#fff;">

			<div class="container">

				<div class="row justify-content-center">

					<div class="col-md-12 text-center lead-ttle-top" style="padding-bottom: 10px;">

						<h2 class="brdr-lead fw-600">							

							Our Partner Sites

						</h2>

					</div>

					<div class="col-md-7 ops-box">

						<div class="verlist">

							<div class="row">

							   <?php $count = count($related_domains)?>

								<div class="col-sm-6 col-xs-12">

									<ul class="list-unstyled ul-verticals">

									   <?php for ($i=0;$i<$count;$i++):?>

										<li>

											<a href="https://<?php echo $related_domains[$i]['domain_name']?>" class="text-capitalize" target="_blank">

												<i class="fa fa-angle-right"></i>

												<?php echo $related_domains[$i]['domain_name']?>

											</a>

										</li>

									   <?php if ($count > 5 && $i==4):?>

									</ul>

								</div>

								<div class="col-sm-6 col-xs-12">

									<ul class="list-unstyled ul-verticals">

									<?php endif?>

									<?php endfor;?>  

									</ul>

								</div>

							</div>

						</div>

					</div>

					<div class="col-sm-12 text-center">

						<br />

						<div class="form-group">

							<a href="https://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" class="btn btn-success" target="_blank">

								<i class="fa fa-search"></i>

								View More

							</a>

						</div>

					</div>

				</div>

			</div>

		</div>

		 <?php endif?>		

		<!-- end main inner -->

	</div>



<?php include('footer.php'); ?>



<script src="/js/main.js"></script>

<script src="/js/jquerysession.js"></script>

<script type="text/javascript">

	function validateEmail(email) {

		  var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

			   

			    if (filter.test(email)) {

				 return true;

			    }

			    else {

				 return false;

		}

	}



	function Saveleads () {

		var email = jQuery('#email').val();

		var user_ip = jQuery('#user_ip').val();

		var domain = jQuery('#domain').val();



		jQuery.post('https://www.contrib.com/forms/saveleads',

		{

			domain:domain,

			user_ip:user_ip,

			email:email



		},function(data){

			console.log('Success Leads');

			$('#emailexist').hide();

					$('#emptyemail').hide();

					$('#invalidemail').hide();

					var equity = $('#equity option:selected').text();

					var email = $('#email').val();

					$.session.set('email', email);

					$.session.set('equity', equity);

					window.location.href = 'sign-up';

		}

		)



	}



	$('#email').on('keyup',function(e){

		let key = e.keyCode;

		if(key === 13) {

			$("#validation").trigger('click');

		}

	});



	$("#validation").click(function(){

		var button = $(this);

		

		flagEmail = false;

		var email = $('#email').val();

		if ($.trim(email).length == 0) 

		{

			$('#emptyemail').show(500);



			setTimeout(function() {

			    $('#emptyemail').fadeOut('fast');

			}, 2000); 





		}

		else if(validateEmail(email)) 

		{

			flagEmail = true;

			$('#emptyemail').hide();

			$('#invalidemail').hide();

		}

		else{

			

			$('#invalidemail').show(500);



			setTimeout(function() {

			    $('#invalidemail').fadeOut('fast');

			}, 2000); 

		}



		if (flagEmail==true) {

			button.attr('disabled','disabled').html('Please Wait .. ');

			$.post('https://www.contrib.com/signup2/checkemailexists',



			{

				email:email

			}

			,

				function(data){

				

				if (data.exists===true) 

				{

					$('#emailexist').show();

						setTimeout(function() {

						    $('#emailexist').fadeOut('fast');

						}, 2000); 

				}

				else

				{	

					Saveleads();

				}

			})

		}

		

	});			

</script>