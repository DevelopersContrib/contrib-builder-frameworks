<style>
/* For Social Media Style Brand Details */
.icon-button {
	border-radius: 0.6rem;
	cursor: pointer;
	display: inline-block;
	font-size: 1rem;
	height: 2rem;
	line-height: 2rem;
	position: relative;
	text-align: center;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
	width: 2rem;
}

/* Circle */
.icon-button span {
	border-radius: 0;
	display: block;
	height: 0;
	left: 50%;
	margin: 0;
	position: absolute;
	top: 50%;
	-webkit-transition: all 0.3s;
	-moz-transition: all 0.3s;
	-o-transition: all 0.3s;
	transition: all 0.3s;
	width: 0;
}
.icon-button span {
	width: 2rem;
	height: 2rem;
	border-radius: 0.6rem;
	margin: -1.5rem;
}
.twitter span {
	background-color: #4099ff;
}
.facebook span {
	background-color: #3B5998;
}
.google-plus span {
	background-color: #dd4b39;
}
.youtube span {
	background-color: #bb0000;
}
.pinterest span {
	background-color: #cb2027;
}
.angellist span {
	background-color: #000;
}
.github span {
	background-color: #000;
}
.linkedin span {
	background-color: #007bb6 ;
}
.tumblr span {
	background-color: #36465d ;
}
.foursquare span {
	background-color: #0072b1 ;
}

/* Icons */
.icon-button i {
	background: none;
	color: white;
	height: 1rem;
	left: 0;
	line-height: 1rem;
	position: absolute;
	top: 0;
	width: 1rem;
	z-index: 10;
}
/* For Image iCons */
.social-img-icon-a{
	border-radius: 0.6rem;
	display: block;
	height: 30px;
	overflow: hidden;
	width: 30px;
}
.social-img-icon-a img{
	height: 30px;
}
/* Footer */
.footer-dark-1 {
	background: #333;
	color: #fff;
	padding:	40px 0px 20px;
}
.footer-dark-1 h3 {
	font-size: 19px;
}
.footer-dark-1 a {
	color:#999;
}
.footer-dark-2 {
	background: #222;
	color: #fff;
	padding: 12px 0px 5px;
	font-size: 11px;
}
.footer-dark-2 a {
	font-size: 11px;
	color: #999;
}
.footer-dark-1 .socials-ul .fa {
	font-size: 35px;
	color: #fff;
}
.list-inline {
    padding-left: 0;
    list-style: none;
}
.list-inline li {
    display: inline-block;
}
</style>
<script src="https://kit.fontawesome.com/7b888bceb1.js"></script>

<link rel="stylesheet" href="<?php echo $base_url?>css/serviceforms/bs4/form-modal-v2.css">

<div class="modal fade" id="form-container" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
		<div class="modal-content form-modal bg-color-content">
			<div class="custom-modal-close-form">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>

			<!-- Start:: Introduction Choices and Radio Button -->
			<div id="form-container-inquire" class="row mx-0 d-none">
				<?include('serviceform/contact_us.php'); ?>
			</div>

			<!-- Partner Forms -->
			<div id="form-container-partner" class="row mx-0 d-none">
				<?include('serviceform/partner.php'); ?>
			</div>
			<!-- End -->

			<!-- Staffing Forms -->
			<div id="form-container-staffing" class="row mx-0 d-none">
				<?include('serviceform/staffing.php'); ?>
			</div>
			<!-- End -->

			
		</div>
	</div>
</div>

<script type="text/javascript">
	
	$(function(){
		$('a#show_partner_dialog, a#_partner').click(function(){
			hideOtherForms();
			$('#form-container-partner').removeClass('d-none');
		});
		
		$('a#_contactus').click(function(){
			hideOtherForms();
			$('#form-container-inquire').removeClass('d-none');
		});
		
		$('a#_apply').click(function(){
			hideOtherForms();
			$('#form-container-staffing').removeClass('d-none');
		});

	});
	
	function hideOtherForms(){
		$('#form-container-partner').addClass('d-none');
		$('#form-container-inquire').addClass('d-none');
		$('#form-container-staffing').addClass('d-none');
	}

</script>	
<div class="footer-dark-1">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							<?=$domain?>							
						</h3>
						<p>
							<?=$description?>							
						</p>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							get started
						</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a href="<?php echo $base_url?>partner" class="text-capitalize">
									Partner with us
								</a>
							</li>
							<li><a href="javascript:;" id="_apply" data-toggle="modal" data-target="#form-container" >Apply Now</a></li>
							<li>
								<a href="<?php echo $base_url?>referral" class="text-capitalize">
									referral
								</a>
							</li>
							<li style="display:none;">
								<a href="<?php echo $base_url?>fund" class="text-capitalize">
									fund
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>apps" class="text-capitalize">
									Apps
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>developers" class="text-capitalize">
									developers
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							company
						</h3>
						<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
							<li>
								<a href="<?php echo $base_url?>about" class="text-capitalize">
									About us
								</a>
							</li>							
							<li>
								<a href="<?php echo $base_url?>terms" class="text-capitalize">
									Terms
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>privacy" class="text-capitalize">
									Privacy
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>cookiepolicy" class="text-capitalize">
									cookie policy
								</a>
							</li>
							<li><a id="_contactus" href="javascript:;" data-toggle="modal" data-target="#form-container" class="text-capitalize">Contact Us</a></li>
							<li>
								<a href="https://www.domaindirectory.com/policypage/unsubscribe?domain=<?=$domain?>" class="text-capitalize" target="_blank">
									unsubscribe
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">						
						<h3 class="fnt-bold text-uppercase">
							partners
						</h3>
						<p>
						     <a href="https://goo.gl/R4U8sH" target="_blank"><img style="border:0px;height: 65px !important;width: ;width: 225px !important;" src="https://cdn.vnoc.com/banner/banner-ctb-earn-ctb-tokens.png" alt="Crypto Contrib" title="Crypto Contrib"></a>
						   </p>
						<h3 class="fnt-bold text-uppercase">
							Socials
						</h3>
						<ul class="list-inline socials-ul mt-3 pl-2">
							<li class="list-inline-item">
								<a title="twitter" class="icon-button twitter" href="https://twitter.com/contrib">
									<i class="fab fa-twitter" aria-hidden="true"></i>
									<span></span>
								</a>
							</li>
							<li class="list-inline-item">
								<a title="facebook" class="icon-button facebook" href="https://www.facebook.com/Contrib.Official">
									<i class="fab fa-facebook-f" aria-hidden="true"></i>
									<span></span>
								</a>
							</li>
							<li class="list-inline-item">
								<a title="linkedin" class="icon-button linkedin" href="https://www.linkedin.com/company/contrib-com">
									<i class="fab fa-linkedin-in" aria-hidden="true"></i>
									<span></span>
								</a>
							</li>
						</ul>						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer-dark-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6 f-a-links">
						© <?=date("Y")?> <a href="" class="text-capitalize "><?=$domain?></a>. All Rights Reserved. 
					</div>
					<div class="col-md-6" style="display:none;">
						<ul class="list-inline text-right f-a-links">
							<li>
								<a href="/about" class="text-capitalize">
									<i class="fa fa-bookmark-o"></i>
									About us&nbsp;
								</a>
							</li>
							<li>
								<a href="/terms" class="text-capitalize">
									<i class="fa fa-book"></i>
									Terms&nbsp;
								</a>
							</li>
							<li>
								<a href="/privacy" class="text-capitalize">
									<i class="fa fa-cube"></i>
									privacy&nbsp;
								</a>
							</li>
							<li>
								<a href="/contact" class="text-capitalize">
									<i class="fa fa-phone-square"></i>
									contact us
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

</body>
</html>