<style>
	.animated {
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
}
@-webkit-keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}

@keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        -ms-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        -ms-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}
.rotateIn {
    -webkit-animation-name: rotateIn;
    animation-name: rotateIn;
}
.r-d{
    -webkit-animation-delay: 2.5s;
    -moz-animation-delay: 2.5s;
    -ms-animation-delay: 2.5s;
    -o-animation-delay: 2.5s;
    animation-delay: 2.5s;
}
.r-d.rotateIn{
    position: absolute; 
    z-index: 10; 
    top: -20px; 
    left: 190px;
}
.arrw-rela {
    position: relative;
}	
</style>
<!-- footer -->
	   <div class="footer-dark-1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase">
									<?=$domain?>
								</h3>
								<p>
									<?=$description?>
								</p>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase">
									get started
								</h3>
								<ul class="list-unstyled f-a-links">
									<li>
										<a href="/partner" class="text-capitalize">
											Partner with us
										</a>
									</li>
									<li>
										<a href="/referral" class="text-capitalize">
											referral
										</a>
									</li>
									<li>
										<a href="/fund" class="text-capitalize">
											fund
										</a>
									</li>
									<li>
										<a href="/developers" class="text-capitalize">
											developers
										</a>
									</li>
								</ul>
							</div>
							<div class="col-md-3">
								<h3 class="fnt-bold text-uppercase">
									company
								</h3>
								<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
									<li>
										<a href="/about" class="text-capitalize">
											About us
										</a>
									</li>
									<li>
										<a href="/apps" class="text-capitalize">
											Apps
										</a>
									</li>
									<li>
										<a href="/terms" class="text-capitalize">
											Terms
										</a>
									</li>
									<li>
										<a href="/privacy" class="text-capitalize">
											Privacy
										</a>
									</li>
									<li>
										<a href="/contact" class="text-capitalize">
											Contact us
										</a>
									</li>
								</ul>
							</div>
							<div class="col-md-3">
								<!-- <h3 class="fnt-bold text-uppercase">
									partners
								</h3>
								<p>
									<a href="http://www.rackspace.com">
										<img style="height:45px;" title="Rackspace" alt="Rackspace" src="">
									</a>
								</p> -->
								<h3 class="fnt-bold text-uppercase">
									partners
								</h3>
								<p>
								  <?if($footer_html != ""):?>
        					<?echo base64_decode($footer_html)?>
        					<?php else:?>
        					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
        				<?endif;?>
								</p>
								<h3 class="fnt-bold text-uppercase">
									Socials
								</h3>
								<ul class="list-inline socials-ul">
									<li>
										<a title="twitter" class="icon-button twitter" href="<?echo $social_twitter?>">
											<i class="fa fa-twitter-square"></i>
											<span></span>
										</a>
									</li>
									<li>
										<a title="facebook" class="icon-button facebook" href="<?echo $social_fb?>">
											<i class="fa fa-facebook-square"></i>
											<span></span>
										</a>
									</li>										
									<li>
										<a title="linkedin" class="icon-button linkedin" href="<?echo $social_linkedin?>">
											<i class="fa fa-linkedin-square"></i>
											<span></span>
										</a>
									</li>
								</ul>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-dark-2">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6 f-a-links">
								© <?=date("Y")?> <a href="" class="text-capitalize "><?=$domain?></a>. All Rights Reserved. 
							</div>
							<div class="col-md-6">
								<ul class="list-inline text-right f-a-links">
									<li>
										<a href="/about" class="text-capitalize">
											<i class="fa fa-bookmark-o"></i>
											About us
										</a>
									</li>
									<li>
										<a href="/terms" class="text-capitalize">
											<i class="fa fa-book"></i>
											Terms
										</a>
									</li>
									<li>
										<a href="/privacy" class="text-capitalize">
											<i class="fa fa-cube"></i>
											privacy
										</a>
									</li>
									<li>
										<a href="/contact" class="text-capitalize">
											<i class="fa fa-phone-square"></i>
											contact us
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- end footer -->