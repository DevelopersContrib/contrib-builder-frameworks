<?php
    $domain =   "staffing.com";
    $domainid = "7669";
    $memberid = "38";
    $title = "Staffing.com - Learn more about Joining our Partner Network";
    $logo =  "https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-staffing1.png";
    $description = "Get your Part Time Job at Staffing.com! Contribute to Premium Brands Today! Join our staffing opportunities today.";
    $account_ga = "UA-29828968-50";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "http://d2qcctj8epnr7y.cloudfront.net/uploads/bg/apple_desktop-wallpaper.jpg";
    $fb_page =  "";
    $twitter = "";
    $bottom_text  = "Get your Part Time Job at Staffing.com! Contribute to Premium Brands Today! Join our staffing opportunities today.";
    $forsale = "";
    $forsaledefault = "";
	$forsaletext = "This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.";
    $footer_banner = "";
    $domain_affiliate_link = "http://referrals.contrib.com/idevaffiliate.php?id=109&url=http://www.contrib.com/signup/firststep?domain=staffing.com";
    $affiliate_id = "109";
    $additional_html = "PGJyIC8+PGg0PkNvbnRyaWIgdG8gU3RhZmZpbmcuY29tIGFuZCBTaGFyZSBlcXVpdHkgd2l0aCBvdGhlciB2aXJ0dWFsIGxlYWRlcnMgYW5kIHN0YWZmPC9oND4KPHNjcmlwdCBhc3luYyBzcmM9Ii8vcGFnZWFkMi5nb29nbGVzeW5kaWNhdGlvbi5jb20vcGFnZWFkL2pzL2Fkc2J5Z29vZ2xlLmpzIj48L3NjcmlwdD4KPCEtLSBNdXNpYyBGcmFtZXdvcmsgMjUwIC0tPgo8aW5zIGNsYXNzPSJhZHNieWdvb2dsZSIKICAgICBzdHlsZT0iZGlzcGxheTppbmxpbmUtYmxvY2s7d2lkdGg6MzAwcHg7aGVpZ2h0OjI1MHB4IgogICAgIGRhdGEtYWQtY2xpZW50PSJjYS1wdWItMDM5MDgyMTI2MTQ2NTQxNyIKICAgICBkYXRhLWFkLXNsb3Q9IjE1NzQxMzcxMDAiPjwvaW5zPgo8c2NyaXB0PgooYWRzYnlnb29nbGUgPSB3aW5kb3cuYWRzYnlnb29nbGUgfHwgW10pLnB1c2goe30pOwo8L3NjcmlwdD4KPHNjcmlwdCBhc3luYyBzcmM9Ii8vcGFnZWFkMi5nb29nbGVzeW5kaWNhdGlvbi5jb20vcGFnZWFkL2pzL2Fkc2J5Z29vZ2xlLmpzIj48L3NjcmlwdD4KPCEtLSBNdXNpYyBGcmFtZXdvcmsgMjUwIC0tPgo8aW5zIGNsYXNzPSJhZHNieWdvb2dsZSIKICAgICBzdHlsZT0iZGlzcGxheTppbmxpbmUtYmxvY2s7d2lkdGg6MzAwcHg7aGVpZ2h0OjI1MHB4IgogICAgIGRhdGEtYWQtY2xpZW50PSJjYS1wdWItMDM5MDgyMTI2MTQ2NTQxNyIKICAgICBkYXRhLWFkLXNsb3Q9IjE1NzQxMzcxMDAiPjwvaW5zPgo8c2NyaXB0PgooYWRzYnlnb29nbGUgPSB3aW5kb3cuYWRzYnlnb29nbGUgfHwgW10pLnB1c2goe30pOwo8L3NjcmlwdD4=";
    $piwik_id = '19';
    $related_domains = array (
  0 => 
  array (
    'domain_name' => 'staffingresolutions.com',
    'domain_id' => '16039',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-staffingresolutions.png',
    'title' => 'Staffingresolutions.com',
    'slug' => 'jobs-services',
  ),
  1 => 
  array (
    'domain_name' => 'staffingondemand.com',
    'domain_id' => '1137',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-staffingondemand.png',
    'title' => 'Staffingondemand.com',
    'slug' => 'jobs-services',
  ),
  2 => 
  array (
    'domain_name' => 'staffing.com',
    'domain_id' => '121',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-staffing1.png',
    'title' => 'Staffing.com - Learn more about Joining our Partner Network',
    'slug' => 'jobs-services',
  ),
  3 => 
  array (
    'domain_name' => 'jobschallenge.com',
    'domain_id' => '565',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-jobschallenge-com.png',
    'title' => 'Welcome to jobschallenge.com',
    'slug' => 'jobs-services',
  ),
  4 => 
  array (
    'domain_name' => 'jobschallenge.org',
    'domain_id' => '559',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-jobschallenge-org.png',
    'title' => NULL,
    'slug' => 'jobs-services',
  ),
  5 => 
  array (
    'domain_name' => 'laborindustry.com',
    'domain_id' => '2277',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-laborindustry1.png',
    'title' => 'Welcome to laborindustry.com',
    'slug' => 'jobs-services',
  ),
  6 => 
  array (
    'domain_name' => 'talent.holdings',
    'domain_id' => '21952',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Talent-Holdings1.png',
    'title' => 'Talent.holdings',
    'slug' => 'jobs-services',
  ),
  7 => 
  array (
    'domain_name' => 'gatorjobs.com',
    'domain_id' => '363',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Gatorjobs1.png',
    'title' => 'Welcome to gatorjobs.com',
    'slug' => 'jobs-services',
  ),
  8 => 
  array (
    'domain_name' => 'emergingartist.com',
    'domain_id' => '29259',
    'logo' => 'https://s3.amazonaws.com/assets.zipsite.net/images/2013/logo-EmergingArtist-1.png',
    'title' => 'Welcome to emergingartist.com',
    'slug' => 'jobs-services',
  ),
  9 => 
  array (
    'domain_name' => 'jobschallenge.net',
    'domain_id' => '562',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-jobschallengenet.png',
    'title' => 'Welcome to jobschallenge.net',
    'slug' => 'jobs-services',
  ),
);
    $fund_campaigns = array (
  0 => 
  array (
    'post_title' => 'Acting.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/acting-com/',
    'post_name' => 'acting-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/acting.com_.png',
    'post_content' => 'Acting.com allows actors and people in the entertainment industry to put up their profile to get casting audition jobs and opportunities. It also allows companies in the Production industry to...',
  ),
  1 => 
  array (
    'post_title' => 'CodeChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/codechallenge-com/',
    'post_name' => 'codechallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/codechallenge.png',
    'post_content' => '<h4>Join CodeChallenge.com</h4>
<h4><strong>Are you an entrepreneur or want to work for a great online business?</strong></h4>
*Select your niche.
*Get mentorship and access to premium online...',
  ),
  2 => 
  array (
    'post_title' => 'Cookboard.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Florida',
    'campaign_author' => 'Maai Florendo',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cookboard-com/',
    'post_name' => 'cookboard-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/11/logo-CookBoard-2.png',
    'post_content' => 'Your #1 Local Food Marketplace community! Join us as we launch it Dec 2014!

Where local chefs create cook boards for availability to the local foodie community\\n\\n

In depth...',
  ),
  3 => 
  array (
    'post_title' => 'CoWork.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cowork-com-virtual-opportunities-to-do-amazing-things/',
    'post_name' => 'cowork-com-virtual-opportunities-to-do-amazing-things',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/02/4743596194.jpg',
    'post_content' => '<a href="http://www.cowork.com">Cowork.com</a>

CoWork.com is an online venture creation network that works with other like minded professionals building awesome companies, projects and...',
  ),
  4 => 
  array (
    'post_title' => 'iChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/ichallenge-com/',
    'post_name' => 'ichallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/3616845592.jpg',
    'post_content' => 'Ichallenge.com is a gamification challenge framework that allows you to join a challenge or sponsor a challenge without monetary involvement.

&nbsp;',
  ),
  5 => 
  array (
    'post_title' => 'iContent.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/icontent-com/',
    'post_name' => 'icontent-com',
    'logo' => 'http://ifund.com/wp-content/uploads/2014/03/icontent-logo.png',
    'post_content' => '<p>iContent is a xml application that connects all your content into an integrated and intelligent system that learns and earns while you focus on creating amazing audio, visual and contextual...',
  ),
  6 => 
  array (
    'post_title' => 'Linked.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/linked-com/',
    'post_name' => 'linked-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/03/Linked_com-linked_com.png',
    'post_content' => 'Linking people, skills and opportunities to create the worlds largest crowd commerce business creation system. Be a part of Linked.com and get equity shares for your donations.

<img...',
  ),
  7 => 
  array (
    'post_title' => 'MBAChallenge',
    'campaign_goal' => '10000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/mbachallenge/',
    'post_name' => 'mbachallenge',
    'logo' => 'http://ifund.com/wp-content/uploads/2015/06/IMG_1404.jpg',
    'post_content' => 'MBAChallenge is a leading skills based business game created to challenge college educated people with street smart professionals.',
  ),
  8 => 
  array (
    'post_title' => 'Micro Markets',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/micro-markets/',
    'post_name' => 'micro-markets',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/micromarkets1.png',
    'post_content' => '<a href="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets.png"><img alt="logo-micromarkets" title="logo-micromarkets" src="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets-300x44.png"...',
  ),
  9 => 
  array (
    'post_title' => 'MusicChannel.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/musicchannel-com/',
    'post_name' => 'musicchannel-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/07/51661884511.jpg',
    'post_content' => 'MusicChannel is a weekly bounty competition that allows unsigned artists to publish their songs, make them viral and if they are selected will win weekly bounties!

We are looking for backers...',
  ),
);
    $partners = array (
  0 => 
  array (
    'partner_id' => '43412',
    'summary' => 'Contribute your Skills, Services, Apps, Contacts or Capital, part-time. Help a team of other passionate people doing amazing things. Come learn and earn! Amazing things happen with the right people, technology, business model, resources and passion. Earn equity ownership, Learn from other great people, Lead a venture and distribute up to 2% of the shares to your charity.',
    'company_name' => 'Contrib.com',
    'domain' => 'staffing.com',
    'url' => 'http://www.contrib.com',
    'approved_by' => '10',
    'date_applied' => '2014-11-04 06:44:49',
    'approved' => '1',
    'image' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-174x35.png',
    'member_id' => '7',
    'approved_status' => 'approved',
    'slug' => 'contrib-staffing-com',
    'type' => 'Added Value Marketing Partnerships',
    'partner_views' => '0',
    'link_type' => 'link',
    'code' => NULL,
    'is_custom' => '0',
    'description' => 'We are a community of Entrepreneurs, Developers, Designers, Marketers and Specialists from around the world building, managing and monetizing virtual businesses on premium domains for equity and cash grants.',
    'exchange_url' => NULL,
    'ld_id' => '0',
    'ld_url' => NULL,
    'in_equity' => '0',
  ),
  1 => 
  array (
    'partner_id' => '19451',
    'summary' => 'Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.',
    'company_name' => 'GlobalVentures.com',
    'domain' => 'staffing.com',
    'url' => 'http://globalventures.com',
    'approved_by' => '10',
    'date_applied' => '2014-11-04 01:34:48',
    'approved' => '1',
    'image' => 'https://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png',
    'member_id' => '7',
    'approved_status' => 'approved',
    'slug' => 'globalventures-staffing-com',
    'type' => 'Added Value Marketing Partnerships',
    'partner_views' => '0',
    'link_type' => 'link',
    'code' => NULL,
    'is_custom' => '0',
    'description' => 'With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.',
    'exchange_url' => NULL,
    'ld_id' => '0',
    'ld_url' => NULL,
    'in_equity' => '1',
  ),
);
    $programs = array (
  0 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=109_4_1_26" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/handyman-badge-5.png" width="170" height="200" alt="handyman badge 5" title="handyman badge 5"></a>',
    'title' => 'Handyman',
  ),
  1 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=109_17_1_52" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/handyman-needed-2.jpg" width="231" height="110" alt="Refer Homeowners" title="Refer Homeowners"></a>',
    'title' => 'Handyman Homeowners',
  ),
  4 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=109_5_1_34" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-socialId-180x150-1.png" width="180" height="150" alt="Social Id Banners" title="Social Id Banners"></a>',
    'title' => 'SocialId',
  ),
  5 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=109_1_1_4" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-heart5.png" width="150" height="150" alt="I love Contrib" title="I love Contrib"></a>',
    'title' => 'Contrib',
  ),
  6 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=109_15_1_50" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/talentdirect-logo.jpg" width="243" height="131" alt="Become a Talent" title="Become a Talent"></a>',
    'title' => 'Talentdirect',
  ),
  7 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=109_6_1_37" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-virtualinterns-728x90-1.png" width="728" height="90" alt="VirtualInterns" title="VirtualInterns"></a>',
    'title' => 'VirtualInterns',
  ),
);
$rolesarray = array (
  0 => 
  array (
    'role_id' => '24',
    'role_name' => 'Advisor',
  ),
  1 => 
  array (
    'role_id' => '34',
    'role_name' => 'Chief Technology Officer',
  ),
  2 => 
  array (
    'role_id' => '30',
    'role_name' => 'Co-founder',
  ),
  3 => 
  array (
    'role_id' => '35',
    'role_name' => 'Community Manager',
  ),
  4 => 
  array (
    'role_id' => '7',
    'role_name' => 'Content Manager',
  ),
  5 => 
  array (
    'role_id' => '29',
    'role_name' => 'Domain Owner',
  ),
  6 => 
  array (
    'role_id' => '25',
    'role_name' => 'Engineer',
  ),
  7 => 
  array (
    'role_id' => '21',
    'role_name' => 'Execution Officer',
  ),
  8 => 
  array (
    'role_id' => '14',
    'role_name' => 'Graphics UI',
  ),
  9 => 
  array (
    'role_id' => '42',
    'role_name' => 'Human Resource Manager',
  ),
  10 => 
  array (
    'role_id' => '32',
    'role_name' => 'Investor',
  ),
  11 => 
  array (
    'role_id' => '17',
    'role_name' => 'Lead Developer',
  ),
  12 => 
  array (
    'role_id' => '15',
    'role_name' => 'Marketer',
  ),
  13 => 
  array (
    'role_id' => '23',
    'role_name' => 'Mentor',
  ),
  14 => 
  array (
    'role_id' => '11',
    'role_name' => 'Owner',
  ),
  15 => 
  array (
    'role_id' => '12',
    'role_name' => 'Partner',
  ),
  16 => 
  array (
    'role_id' => '27',
    'role_name' => 'Partner Manager',
  ),
  17 => 
  array (
    'role_id' => '31',
    'role_name' => 'Press/Marketing Relations',
  ),
  18 => 
  array (
    'role_id' => '1',
    'role_name' => 'Project Manager',
  ),
  19 => 
  array (
    'role_id' => '33',
    'role_name' => 'Research Specialist',
  ),
  20 => 
  array (
    'role_id' => '26',
    'role_name' => 'Revenue Officer',
  ),
  21 => 
  array (
    'role_id' => '16',
    'role_name' => 'Social and Media ',
  ),
  22 => 
  array (
    'role_id' => '9',
    'role_name' => 'Tester',
  ),
  23 => 
  array (
    'role_id' => '28',
    'role_name' => 'Venture Leader',
  ),
  24 => 
  array (
    'role_id' => '8',
    'role_name' => 'Web Developer',
  ),
);
	$countriesarray = array (
  0 => 
  array (
    'country_id' => '11',
    'name' => 'Argentina',
  ),
  1 => 
  array (
    'country_id' => '12',
    'name' => 'Armenia',
  ),
  2 => 
  array (
    'country_id' => '14',
    'name' => 'Australia',
  ),
  3 => 
  array (
    'country_id' => '15',
    'name' => 'Austria',
  ),
  4 => 
  array (
    'country_id' => '17',
    'name' => 'Bahamas',
  ),
  5 => 
  array (
    'country_id' => '18',
    'name' => 'Bahrain',
  ),
  6 => 
  array (
    'country_id' => '200',
    'name' => 'Belarus',
  ),
  7 => 
  array (
    'country_id' => '21',
    'name' => 'Belgium',
  ),
  8 => 
  array (
    'country_id' => '29',
    'name' => 'Brazil',
  ),
  9 => 
  array (
    'country_id' => '35',
    'name' => 'Cambodia',
  ),
  10 => 
  array (
    'country_id' => '37',
    'name' => 'Canada',
  ),
  11 => 
  array (
    'country_id' => '42',
    'name' => 'Chile',
  ),
  12 => 
  array (
    'country_id' => '43',
    'name' => 'China',
  ),
  13 => 
  array (
    'country_id' => '46',
    'name' => 'Colombia',
  ),
  14 => 
  array (
    'country_id' => '207',
    'name' => 'Cuba',
  ),
  15 => 
  array (
    'country_id' => '51',
    'name' => 'Denmark',
  ),
  16 => 
  array (
    'country_id' => '56',
    'name' => 'Ecuador',
  ),
  17 => 
  array (
    'country_id' => '57',
    'name' => 'Egypt',
  ),
  18 => 
  array (
    'country_id' => '58',
    'name' => 'El Salvador',
  ),
  19 => 
  array (
    'country_id' => '64',
    'name' => 'Fiji',
  ),
  20 => 
  array (
    'country_id' => '65',
    'name' => 'Finland',
  ),
  21 => 
  array (
    'country_id' => '66',
    'name' => 'France',
  ),
  22 => 
  array (
    'country_id' => '71',
    'name' => 'Georgia',
  ),
  23 => 
  array (
    'country_id' => '72',
    'name' => 'Germany',
  ),
  24 => 
  array (
    'country_id' => '80',
    'name' => 'Guatemala',
  ),
  25 => 
  array (
    'country_id' => '83',
    'name' => 'Haiti',
  ),
  26 => 
  array (
    'country_id' => '85',
    'name' => 'Honduras',
  ),
  27 => 
  array (
    'country_id' => '87',
    'name' => 'Hungary',
  ),
  28 => 
  array (
    'country_id' => '88',
    'name' => 'Iceland',
  ),
  29 => 
  array (
    'country_id' => '89',
    'name' => 'India',
  ),
  30 => 
  array (
    'country_id' => '90',
    'name' => 'Indonesia',
  ),
  31 => 
  array (
    'country_id' => '91',
    'name' => 'Ireland',
  ),
  32 => 
  array (
    'country_id' => '92',
    'name' => 'Israel',
  ),
  33 => 
  array (
    'country_id' => '93',
    'name' => 'Italy',
  ),
  34 => 
  array (
    'country_id' => '94',
    'name' => 'Jamaica',
  ),
  35 => 
  array (
    'country_id' => '95',
    'name' => 'Japan',
  ),
  36 => 
  array (
    'country_id' => '111',
    'name' => 'Macedonia',
  ),
  37 => 
  array (
    'country_id' => '112',
    'name' => 'Madagascar',
  ),
  38 => 
  array (
    'country_id' => '113',
    'name' => 'Malawi',
  ),
  39 => 
  array (
    'country_id' => '114',
    'name' => 'Malaysia',
  ),
  40 => 
  array (
    'country_id' => '115',
    'name' => 'Maldives',
  ),
  41 => 
  array (
    'country_id' => '116',
    'name' => 'Mali',
  ),
  42 => 
  array (
    'country_id' => '117',
    'name' => 'Malta',
  ),
  43 => 
  array (
    'country_id' => '132',
    'name' => 'Netherlands',
  ),
  44 => 
  array (
    'country_id' => '135',
    'name' => 'New Zealand',
  ),
  45 => 
  array (
    'country_id' => '140',
    'name' => 'Norway',
  ),
  46 => 
  array (
    'country_id' => '145',
    'name' => 'Paraguay',
  ),
  47 => 
  array (
    'country_id' => '146',
    'name' => 'Peru',
  ),
  48 => 
  array (
    'country_id' => '147',
    'name' => 'Philippines',
  ),
  49 => 
  array (
    'country_id' => '148',
    'name' => 'Poland',
  ),
  50 => 
  array (
    'country_id' => '149',
    'name' => 'Portugal',
  ),
  51 => 
  array (
    'country_id' => '153',
    'name' => 'Romania',
  ),
  52 => 
  array (
    'country_id' => '154',
    'name' => 'Russia',
  ),
  53 => 
  array (
    'country_id' => '166',
    'name' => 'Singapore',
  ),
  54 => 
  array (
    'country_id' => '170',
    'name' => 'Spain',
  ),
  55 => 
  array (
    'country_id' => '175',
    'name' => 'Sweden',
  ),
  56 => 
  array (
    'country_id' => '176',
    'name' => 'Switzerland',
  ),
  57 => 
  array (
    'country_id' => '177',
    'name' => 'Taiwan',
  ),
  58 => 
  array (
    'country_id' => '180',
    'name' => 'Thailand',
  ),
  59 => 
  array (
    'country_id' => '189',
    'name' => 'Ukraine',
  ),
  60 => 
  array (
    'country_id' => '190',
    'name' => 'United Arab Emirates',
  ),
  61 => 
  array (
    'country_id' => '191',
    'name' => 'United Kingdom',
  ),
  62 => 
  array (
    'country_id' => '1',
    'name' => 'United States',
  ),
  63 => 
  array (
    'country_id' => '194',
    'name' => 'Venezuela',
  ),
  64 => 
  array (
    'country_id' => '195',
    'name' => 'Vietnam',
  ),
);
	$industriesarray = array (
  0 => 
  array (
    'IndustryId' => '6',
    'Name' => 'Admin Support',
  ),
  1 => 
  array (
    'IndustryId' => '12',
    'Name' => 'Autos',
  ),
  2 => 
  array (
    'IndustryId' => '14',
    'Name' => 'Business Services',
  ),
  3 => 
  array (
    'IndustryId' => '19',
    'Name' => 'Computer and Technology',
  ),
  4 => 
  array (
    'IndustryId' => '5',
    'Name' => 'Design & Multimedia',
  ),
  5 => 
  array (
    'IndustryId' => '17',
    'Name' => 'Education',
  ),
  6 => 
  array (
    'IndustryId' => '4',
    'Name' => 'Engineering & Manufacturing',
  ),
  7 => 
  array (
    'IndustryId' => '10',
    'Name' => 'Events and Parties',
  ),
  8 => 
  array (
    'IndustryId' => '7',
    'Name' => 'Finance & Management',
  ),
  9 => 
  array (
    'IndustryId' => '13',
    'Name' => 'Fitness and Recreation',
  ),
  10 => 
  array (
    'IndustryId' => '11',
    'Name' => 'Healthcare and Beauty',
  ),
  11 => 
  array (
    'IndustryId' => '18',
    'Name' => 'Home Care and Services',
  ),
  12 => 
  array (
    'IndustryId' => '8',
    'Name' => 'Legal',
  ),
  13 => 
  array (
    'IndustryId' => '9',
    'Name' => 'Real Estate',
  ),
  14 => 
  array (
    'IndustryId' => '2',
    'Name' => 'Sales & Marketing',
  ),
  15 => 
  array (
    'IndustryId' => '15',
    'Name' => 'Staffing and Jobs',
  ),
  16 => 
  array (
    'IndustryId' => '16',
    'Name' => 'Travel',
  ),
  17 => 
  array (
    'IndustryId' => '1',
    'Name' => 'Web & Programming',
  ),
  18 => 
  array (
    'IndustryId' => '3',
    'Name' => 'Writing & Translation',
  ),
);
$intentions = array (
  0 => 'Looking to build a startup from an idea',
  1 => 'Open to joining a team',
);
?>