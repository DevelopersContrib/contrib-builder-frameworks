<?php include('includes/config.php');?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="custom.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
    .nav-pills.nav-pills-cust {
        background-color: #fff;
        border: 1px solid #e7e7e7;
        border-radius: 5px;
        margin-bottom: 5px;
        padding: 5px 10px;
    }
    .blck2-box{
        margin-top: auto
    }
	.page-container {
		margin-top: 50px;
margin-bottom: 50px;
background: #f5f5f5;
padding: 20px;
	}
	.page-container .btn-pg {
		margin-bottom:30px;
	}
	.blur-box {
    background-color: #f5f5f5;
    margin-bottom: 25px;
    padding: 15px;
    color:#fff;
    
}
/* Referral Page */
.blck2-box{
    background-color: #f5f5f5;
    padding: 25px 15px;
    margin-bottom: 25px;
    text-align: left;
    margin-top: -5px;
}
.wrap-allbanner {
    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-728x90-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 90px;
    position: relative;
    width: 728px;
}
.wrap-bannerLeft, .wrap-bannerRight {
    display: inline-block;
    float: left;
}
.wrap-bannerLeft {
    box-sizing: border-box;
    height: 90px;
    overflow: hidden;
    padding: 15px 5px 20px 10px;
    vertical-align: top;
    width: 245px;
}
.ellipsis {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.aBnnrP {
    box-sizing: border-box;
    color: #0088cc;
    display: block;
    font-size: 22px;
    font-weight: bold;
    line-height: normal;
    margin: 0;
    text-align: center;
    text-decoration: none;
    text-transform: capitalize;
}
.logo-banners1 {
    box-sizing: border-box;
    max-height: 58px;
    max-width: 100%;
}
.wrap-bannerRight {
    color: #ffffff;
    height: 90px;
    margin-left: 84px;
    width: 397px;
}
.content-rightText {
    box-sizing: border-box;
    margin: auto;
    padding-top: 16px;
    width: 350px;
}
.content-rightText span {
    box-sizing: border-box;
    display: block;
}
.content-rightText span, .content-rightText p {
    font-size: 25px;
    text-align: center;
    text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
}
.block-group{
    border-bottom: 1px solid #fff;
    margin-bottom: 25px;
    padding-bottom: 30px;
}
.block-group:last-child{
    margin-bottom: 0;
    border-bottom: none;
}
.wrapBanner-2 {
    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/jayson/180x150-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 150px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 180px;
}
.wrap-topBanner {
    box-sizing: border-box;
    display: block;
    margin: 37px auto 0;
    position: relative;
    width: 118px;
}
.wrap-contentTop {
    box-sizing: border-box;
    color: #fff;
    font-size: 20px;
    letter-spacing: 0.01em;
    line-height: 1.1em;
    text-align: center;
    text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
}

.wrap-contentTop span {
    display: block;
}
.wrap-downBanner {
    box-sizing: border-box;
    display: block;
    height: 37px;
    margin: 5px 0 0;
    overflow: hidden;
}
.wrap-contentDown {
    box-sizing: border-box;
    height: 35px;
    margin: auto;
    padding: 1px 0;
    width: 125px;
}
.wrap-contentDown img {
    max-height: 32px;
    max-width: 100%;
    text-align: center;
}
.wrap-contentDown p {
    box-sizing: border-box;
    color: #0088cc;
    display: block;
    margin: 0;
}
.wrapBanner-3 {
    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-160x600-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 600px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 180px;
}
.wrap-topBanner3 {
    box-sizing: border-box;
    display: block;
    margin: 130px 18px 0;
    position: relative;
    width: 120px;
}


.wrapBanner-4 {
    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-250x250-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 250px;
    margin: auto;
    overflow: hidden;
    position: relative;
    width: 250px
}
.wrap-topBanner4 {
    box-sizing: border-box;
    display: block;
    margin: 76px 18px 0;
    position: relative;
    
}
</style>
<!-- navigation -->
<?php include('navigation.php');?>
<!-- page container-->
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 text-center">			
			<div class="page-container">
				<div class="arrw-rela"><div class="arrw-point-white"></div></div>
				<br>
				<iframe width="748px" height="800px" frameborder="0" seamless="" scrolling="auto" src="http://referrals.contrib.com/aff_index.php?affiliate=<?php echo $domain?>"></iframe>
				<br><br>
				<ul role="tablist" class="nav nav-pills nav-pills-cust">
					<li class="active" role="presentation"><a data-toggle="tab" role="tab" aria-controls="home" href="#home">Referral Programs</a></li>
					<li role="presentation"><a data-toggle="tab" role="tab" aria-controls="bannerCode" href="#bannerCode">Banners</a></li>
				</ul>
				<div class="tab-content tab-content-cust">
					<div id="home" class="tab-pane active" role="tabpanel">
                         <div class="blck2-box">
                         	   <?php if (count($programs)>0):?>
                         	   	 <?php foreach ($programs as $key=>$val):?>
                         	   	 		 <div class="block-group">
                                                <dl class="dl-horizontal banner-info">
					                                            <dt>Referral Program</dt><dd><?php echo $val['title']?></dd>
					                             </dl>
                                    <div class="floating text-center banner-img-cont">
                                        <?php echo $val['code']?>
                                    </div>
                                    <br />
                                    <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                                    <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control"> <?php echo $val['code']?></textarea>
                                    <div class="clearfix"></div>
                                </div>
                         	   	 <?php endforeach;?>
                         	   <?php endif?>
                         </div>
                            
                    </div>
					<div id="bannerCode" class="tab-pane" role="tabpanel">
						<div class="blck2-box">
							<div class="block-group">
								<dl class="dl-horizontal">
									<dt>Marketing Group</dt><dd>Contrib</dd>
									<dt>Banner Size</dt><dd>728 x 90</dd>
									<dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
									<dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
								</dl>
								<div class="floating text-center banner-img-cont">
									<div class="wrap-allbanner">
										<div class="wrap-bannerLeft">
											<p class="aBnnrP ellipsis" href="">
												<img alt="<?php echo $domain?>" title="<?php echo $domain?>" src="<?echo $logo?>" class="logo-banners1">
											</p>
										</div>
										<div class="wrap-bannerRight ">
											<div class="content-rightText ">
												<span class="">Follow , Join and</span>
												<p class="ellipsis">Partner with Contrib.com</p>
											</div>
										</div>
									</div>
								</div>
								<br />
								<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
								<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
								<div class="clearfix"></div>
							</div>
							<div class="block-group">
								<dl class="dl-horizontal">
									<dt>Marketing Group</dt><dd>Contrib</dd>
									<dt>Banner Size</dt><dd>180 x 150</dd>
									<dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
									<dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
								</dl>
								<div class="floating text-center banner-img-cont">
									<div class="wrapBanner-2">
										<div class="wrap-topBanner ">
											<div class="wrap-contentTop">
												<span>Follow, Join</span>
												<span>and Partner with</span>
											</div>
										</div>
										<div class="wrap-downBanner">
											<div class="wrap-contentDown">
												<p class="ellipsis" href="">
													<img alt="<?php echo $domain?>" title="<?php echo $domain?>" src="<?echo $logo?>">
												</p>
											</div>
										</div>
									</div>
								</div>
								<br />
								<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
								<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
								<div class="clearfix"></div>
							</div>
							<div class="block-group">
								<dl class="dl-horizontal">
									<dt>Marketing Group</dt><dd>Contrib</dd>
									<dt>Banner Size</dt><dd>728 x 90</dd>
									<dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
									<dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
								</dl>
								<div class="floating text-center banner-img-cont">
									<div class="wrapBanner-3">
										<div class="wrap-topBanner3 ">
											<div class="wrap-contentTop">
												<span>Follow, Join</span>
												<span>and Partner with</span>
											</div>
										</div>
										<div class="wrap-downBanner">
											<div class="wrap-contentDown">
												<p class="ellipsis" href="">
													<img alt="<?php echo $domain?>" title="<?php echo $domain?>" src="<?echo $logo?>">
											</div>
										</div>
									</div>
								</div>
								<br />
								<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
								<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/verticalbanner<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
							</div>
							
							<div class="block-group">
								<dl class="dl-horizontal">
									<dt>Marketing Group</dt><dd>Contrib</dd>
									<dt>Banner Size</dt><dd>250 x 250</dd>
									<dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
									<dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
								</dl>
								<div class="floating text-center banner-img-cont">
									<div class="wrapBanner-4">
										<div class="wrap-topBanner4 ">
											<div class="wrap-contentTop">
												<span>Follow, Join</span>
												<span>and Partner with</span>
											</div>
										</div>
										<div class="wrap-downBanner">
											<div class="wrap-contentDown">
												<p class="ellipsis" href="">
													<img src="<?echo $logo?>" alt="<?php echo $domain?>" title="<?php echo $domain?>">
											</div>
										</div>
									</div>
								</div>
								<br />
								<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
								<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/squarebanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end page container-->
<!-- footer -->
	   <?php include('footer.php');?>
		<!-- end footer -->