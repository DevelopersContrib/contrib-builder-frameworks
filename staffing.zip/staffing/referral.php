<?php include('header.php'); ?>
<style>

</style>
<body>
	<div class="navigation-container">
		<?php include('navigation.php'); ?>
	</div>
	<div class="main page-container">		
		<div class="container mb-5 mt-5">
			<div class="row"> 
			     <div class="col-sm-12 text-center"> 
				  <div class="col-lg-12 text-center mb-5">
				      <? if($info['logo']!=''){ ?>
					   <?php 

						if(strpos($logo,'https') === FALSE){
						    $logo = str_replace('http','https',$logo);
						}else{
						    $logo_site = $logo;
						}
					   ?>
					  <a href="https://<?=$domain?>" class="d-inline-block logo-partner-page">
						<img class="img-fluid" src="<?=$logo?>" alt="">
					   </a>
				      <? }else{ ?>
				      <h1><b><?=ucwords($domain)?></b></h1>
				      <? } ?>
				      <p class="mt-2">
					   <b>
						Learn more about Joining our Partner Network
					   </b>
				      </p>

				  </div>
				  <div class="col-lg-12 mb-5">
					<!--<script class="ctb-box" id='referral-script' src='https://www.referrals.com/extension/widget.js?key=356' type='text/javascript'></script>-->

				      <!-- <script class="ctb-box" id="referral-script" src="https://www.referrals.com/extension/widget.js?key=<?=$widget_id?>" type="text/javascript"></script> -->
				      <div id="script-container"></div>
				  </div>
			     </div>
			 </div>
		</div>
	</div>
<script type="text/javascript">
    $(document).ready(function(){
        var domain = '<?php echo $domain; ?>';

        $.ajax({
            url: 'https://api1.contrib.co/request/Getdomainwidget?key=5c1bde69a9e783c7edc2e603d8b25023&domain='+domain,
            method: 'POST',
            beforeSend: function() {

            },
            success: function(res) {
                if (res.success === true) {
                    $('#script-container').html(`<script class="ctb-box" id="referral-script" src="https://www.referrals.com/extension/widget.js?key=${res.data['widget_id']}" type="text/javascript"><\/script>`);                
                    console.log(res.data['widget_id']);                                                     
                }
            },
            complete: function() {

            },
        });
    });
</script>
<?php include('footer.php'); ?>