<?php include('includes/config.php');?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="custom.css">
<style>
.page-container {
	margin-top:50px;
}
.page-container .btn-pg {
	margin-bottom:30px;
}
.pcontent {
	background: #000;
padding: 60px 50px;
margin-bottom: 200px;
color:#fff;
}
.pcontent h3 {
	text-transform:uppercase;
}
</style>
<!-- navigation -->
<?php include('navigation.php');?>
<!-- -->
<!-- page container-->
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 text-center">			
			<div class="page-container">
				<h2>About <?=$domain?></h2>
				<hr>
				<div class="pcontent">
					<div class="about-year text-uppercase white-text"><span class="clearfix">20</span> Years</div>
					<h3>We have been in the forefront of domain development and technologies since 1996</h3>
					<p style="clear:both"></p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end page container-->
<?php include 'footer.php';?>