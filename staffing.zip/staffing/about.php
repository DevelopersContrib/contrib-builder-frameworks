<?php include('header.php'); ?>
<style>

</style>
<body>
	<div class="navigation-container">
		<?php include('navigation.php'); ?>
	</div>
	<div class="main page-container">		
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10 text-center">			
					<div class="page-container">
						<h2><b>About <?=$domain?></b></h2>
						<div class="pcontent">
							<div class="about-year text-uppercase white-text"><span class="clearfix">20</span> 
								<span class="years">Years</span>
							</div>
							<h3>We have been in the forefront of domain development and technologies since 1996</h3>
							<p style="clear:both"></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php include('footer.php'); ?>