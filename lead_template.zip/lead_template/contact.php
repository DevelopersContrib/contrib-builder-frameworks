<?php include 'header.php'; ?>
                    <div class="arrw-rela"><div class="arrw-point-white"></div></div>
                    
                        <script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?echo $domain?>"></script>
                    <br><br>
                </div>
<?php include_once 'footer.php';?>          
