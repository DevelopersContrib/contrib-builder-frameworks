<?php
$domain = 'streamboard.com';
$domainid = '2663';
$domainname = 'streamboard.com';
$title = 'Streamboard.com';
$logo = 'http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-streamboard1.png';
$description = 'Join our exclusive community of like minded people on streamboard.com';
$account_ga = '';
?>
<?
$background_image_url="";
$fb_page="";
$twitter_page="";
$bottom_text="";
?>