<?php

    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $keywords = "{{KEYWORDS}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
    $fb_page =  "{{FB_PAGE}}";
    $twitter = "{{TWITTER}}";
    $bottom_text  = "{{BOTTOM_TEXT}}";
    $forsale = "{{SHOW_FOR_SALE}}";
    $forsaledefault = "{{SHOW_FOR_SALE_DEFAULT}}";
	$forsaletext = "{{FOR_SALE_TEXT}}";
    $footer_banner = "{{FOOTER_BANNER}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $affiliate_id = "{{AFF_ID}}";
    $additional_html = "{{ADDITIONAL_HTML}}";
    $footer_html = "{{FOOTER_HTML}}";
    $piwik_id = '{{PIWIK_ID}}';
    $related_domains = {{RELATED_DOMAINS}};
    $fund_campaigns = {{FUND_CAMPAIGNS}};
    $partners = {{PARTNERS}};
    $programs = {{PROGRAMS}};
    $social_fb = '{{SOCIAL_FB}}';
    $social_gplus = '{{SOCIAL_GPLUS}}';
    $social_twitter = '{{SOCIAL_TWITTER}}';
    $social_linkedin = '{{SOCIAL_LINKEDIN}}';
    $social_gtube = '{{SOCIAL_GTUBE}}';
    $topsites = {{TOPSITES}};
    $rolesarray = {{ROLES}};
    $countriesarray = {{COUNTRIES}};
    $industriesarray = {{INDUSTRIES}};
    $parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
    

?>