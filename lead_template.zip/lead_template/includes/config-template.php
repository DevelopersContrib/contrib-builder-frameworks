<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
    $fb_page =  "{{FB_PAGE}}";
    $twitter = "{{TWITTER}}";
    $bottom_text  = "{{BOTTOM_TEXT}}";
    $forsale = "{{SHOW_FOR_SALE}}";
    $forsaledefault = "{{SHOW_FOR_SALE_DEFAULT}}";
	$forsaletext = "{{FOR_SALE_TEXT}}";
    $footer_banner = "{{FOOTER_BANNER}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
    $additional_html = "{{ADDITIONAL_HTML}}";
    $piwik_id = '{{PIWIK_ID}}';
    $related_domains = {{RELATED_DOMAINS}};
    $fund_campaigns = {{FUND_CAMPAIGNS}};
?>