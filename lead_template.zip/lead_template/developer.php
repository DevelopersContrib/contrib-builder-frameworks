<style>
.boxcon {
    background: rgba(0,0,0,0.6);
    padding: 30px 40px 40px;
    margin-top: 20px;
    margin-bottom: 20px;
}
.section-1 {
    min-height: 0px !important;
}
</style>
<?php include 'header.php'; ?>                      
<div class="section-1">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="row"> 
            <div class="col-sm-12 text-center"> 
                <div class="boxcon">
                    <h2 class="ttle text-capitalize text-center">
                        <?php echo $domain?> Terms of Use
                    </h2>
                    <br /> 
                    <p class="devdesc">
                        <i class="fa fa-arrows"></i>
                        Do you have code or an app that could run this brand? <?php echo ucfirst($domain)?> is connected with <a href="http://contrib.com/signup/firststep?domain=<?php echo $domain?>" target="_blank">Contrib</a>. 
                    </p>
                    <p class="devdesc">
                        <i class="fa fa-arrows"></i>
                        <a href="http://contrib.com/signup/firststep?domain=<?php echo $domain?>" target="_blank">Contrib</a> is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?php echo $domain?>?
                    </p>
                    
                </div> 
            </div>
        </div>
    </div>
</div>
<?php include_once 'footer.php';?>       

