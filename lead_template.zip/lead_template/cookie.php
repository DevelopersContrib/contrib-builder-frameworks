<style>
.boxcon {
	background: rgba(0,0,0,0.6);
	padding: 30px 40px 40px;
	margin-top: 20px;
	margin-bottom: 20px;
}
.section-1 {
	min-height: 0px !important;
}
</style>
<?php include 'header.php'; ?>
<div class="section-1">
	<div class="bg-overlay"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-sm-12 text-center"> 
				<div class="boxcon">
					<?php 
				   $api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
				   $url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=cookie';
				   $result =  createApiCall($url, 'GET', $headers, array());
				   $data_domain = json_decode($result,true);
				   if (isset($data_domain['data']['content'])){
				   	$cookie =   $data_domain['data']['content'];
				   }else {
				   	$cookie = "";
				   }

				   echo $cookie;
				   ?>
				</div>   
			</div>
		</div>
	</div>
</div>
<?php include_once 'footer.php';?>       
