<?php include 'header.php'; ?>
<style>
    .nav-pills.nav-pills-cust {
        background-color: #f8f8f8;
        border: 1px solid #e7e7e7;
        border-radius: 5px;
        margin-bottom: 5px;
        padding: 5px 10px;
    }
    .blck2-box{
        margin-top: auto
    }
</style>
                    <div class="arrw-rela"><div class="arrw-point-white"></div></div>
                    <br />
                    <iframe width="748px" height="800px" frameborder="0" seamless="" scrolling="auto" src="http://referrals.contrib.com/aff_index.php?affiliate=<?php echo $domain?>"></iframe>
                    <br>
                    <ul role="tablist" class="nav nav-pills nav-pills-cust">
                        <li class="active" role="presentation"><a data-toggle="tab" role="tab" aria-controls="home" href="#home">Referral Programs</a></li>
                        <li role="presentation"><a data-toggle="tab" role="tab" aria-controls="bannerCode" href="#bannerCode">Banners</a></li>
                    </ul>
                    <div class="tab-content tab-content-cust">
                        <div id="home" class="tab-pane active" role="tabpanel">
                         <div class="blck2-box">
                         	   <?php if (count($programs)>0):?>
                         	   	 <?php foreach ($programs as $key=>$val):?>
                         	   	 		 <div class="block-group">
                                                <dl class="dl-horizontal banner-info">
					                                            <dt>Referral Program</dt><dd><?php echo $val['title']?></dd>
					                             </dl>
                                    <div class="floating text-center banner-img-cont">
                                        <?php echo $val['code']?>
                                    </div>
                                    <br />
                                    <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                                    <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control"> <?php echo $val['code']?></textarea>
                                    <div class="clearfix"></div>
                                </div>
                         	   	 <?php endforeach;?>
                         	   <?php endif?>
                         </div>
                            
                        </div>
                        <div id="bannerCode" class="tab-pane" role="tabpanel">
                         <div class="blck2-box">
                                <div class="block-group">
                                    <dl class="dl-horizontal">
                                        <dt>Marketing Group</dt><dd>Contrib</dd>
                                        <dt>Banner Size</dt><dd>728 x 90</dd>
                                        <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                        <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                                    </dl>
                                    <div class="floating text-center banner-img-cont">
                                        <div class="wrap-allbanner">
                                            <div class="wrap-bannerLeft">
                                                <p class="aBnnrP ellipsis" href="">
                                                    <img alt="<?php echo $domain?>" title="<?php echo $domain ?>" src="<?echo $logo?>" class="logo-banners1">
                                                </p>
                                            </div>
                                            <div class="wrap-bannerRight ">
                                                <div class="content-rightText ">
                                                    <span class="">Follow , Join and</span>
                                                    <p class="ellipsis">Partner with Contrib.com</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br />
                                    <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                                    <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="block-group">
                                    <dl class="dl-horizontal">
                                        <dt>Marketing Group</dt><dd>Contrib</dd>
                                        <dt>Banner Size</dt><dd>180 x 150</dd>
                                        <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                        <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                                    </dl>
                                    <div class="floating text-center banner-img-cont">
                                        <div class="wrapBanner-2">
                                            <div class="wrap-topBanner ">
                                                <div class="wrap-contentTop">
                                                    <span>Follow, Join</span>
                                                    <span>and Partner with</span>
                                                </div>
                                            </div>
                                            <div class="wrap-downBanner">
                                                <div class="wrap-contentDown">
                                                    <p class="ellipsis" href="">
                                                        <img alt="<?php echo $domain?>" title="<?php echo $domain; ?>" src="<?echo $logo?>">
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br />
                                    <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                                    <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="block-group">
                                    <dl class="dl-horizontal">
                                        <dt>Marketing Group</dt><dd>Contrib</dd>
                                        <dt>Banner Size</dt><dd>728 x 90</dd>
                                        <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                        <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                                    </dl>
                                    <div class="floating text-center banner-img-cont">
                                        <div class="wrapBanner-3">
                                            <div class="wrap-topBanner3 ">
                                                <div class="wrap-contentTop">
                                                    <span>Follow, Join</span>
                                                    <span>and Partner with</span>
                                                </div>
                                            </div>
                                            <div class="wrap-downBanner">
                                                <div class="wrap-contentDown">
                                                    <p class="ellipsis" href="">
                                                        <img alt="<?php echo $domain?>" title="<?php echo $domain; ?>" src="<?echo $logo?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br />
                                    <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                                    <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/verticalbanner<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                                </div>
                                
                                <div class="block-group">
                                    <dl class="dl-horizontal">
                                        <dt>Marketing Group</dt><dd>Contrib</dd>
                                        <dt>Banner Size</dt><dd>250 x 250</dd>
                                        <dt>Banner Description</dt><dd><?php echo $domain?> Banner</dd>
                                        <dt>Target URL</dt><dd>http://<?php echo $domain?></dd>
                                    </dl>
                                    <div class="floating text-center banner-img-cont">
                                        <div class="wrapBanner-4">
                                            <div class="wrap-topBanner4 ">
                                                <div class="wrap-contentTop">
                                                    <span>Follow, Join</span>
                                                    <span>and Partner with</span>
                                                </div>
                                            </div>
                                            <div class="wrap-downBanner">
                                                <div class="wrap-contentDown">
                                                    <p class="ellipsis" href="">
                                                        <img src="<?echo $logo?>" title="<?php echo $domain; ?>" alt="<?php echo $domain?>" src="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br />
                                    <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
                                    <textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/squarebanner/<?php echo $domain?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php include_once 'footer.php';?>       
