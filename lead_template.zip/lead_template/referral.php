<? include_once 'header.php'; ?>


<style>
    #container2 p{text-align:justify !important}

    .input-block-level {
        display: block;
        width: 100%;
        min-height: 30px;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    h3{
        margin: 10px 0;
        font-family: inherit;
        font-weight: bold;
        line-height: 20px;
        color: inherit;
        text-rendering: optimizelegibility;
    }
    dl {
        margin-bottom: 20px;
    }
    
    dt,
    dd {
        line-height: 20px;
    }
    
    dt {
        font-weight: bold;
    }
    
    dd {
        margin-left: 10px;
    }
    
    .dl-horizontal {
        *zoom: 1;
    }
    
    .dl-horizontal:before,
    .dl-horizontal:after {
        display: table;
        line-height: 0;
        content: "";
    }
    
    .dl-horizontal:after {
        clear: both;
    }
    
    .dl-horizontal dt {
        float: left;
        width: 160px;
        overflow: hidden;
        clear: left;
        text-align: right;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .dl-horizontal dd {
        margin-left: 180px;
    }
    .padd-banner{
        padding: 10px 20px;
    }
    .banner-main{
        margin-bottom: 30px;
        padding-bottom:10px;
        border-bottom: 1px solid #fff;
    }
    .banner-main textarea{
        resize:none;
        border-radius: 4px;
        border: 1px solid #000000;
    }
    .banner-main:last-child{
        border-bottom: none;
    }
    .banner-header{
        font-weight: 300;
        color: #fff;
        border-bottom: 1px solid #fff;
        line-height: 65px;
        margin:0 0 30px;
    }
    .banner-img-cont{
        margin-bottom: 25px;
    }
    .banner-source{
        color: #fff;
        font-size:18px;
    }
    .banner-info{
        color: #fff;
    }
    /*
    ==============================================
    tossing
    ==============================================
    */
    
    .tossing{
        animation-name: tossing;
        -webkit-animation-name: tossing;	
        
        animation-duration: 2.5s;	
        -webkit-animation-duration: 2.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes tossing {
        0% {
            transform: rotate(-4deg);	
        }
        50% {
            transform: rotate(4deg);
        }
        100% {
            transform: rotate(-4deg);	
        }						
    }
    
    @-webkit-keyframes tossing {
        0% {
            -webkit-transform: rotate(-4deg);	
        }
        50% {
            -webkit-transform: rotate(4deg);
        }
        100% {
            -webkit-transform: rotate(-4deg);	
        }				
    }
    /*
    ==============================================
    floating
    ==============================================
    */
    
    .floating{
        animation-name: floating;
        -webkit-animation-name: floating;
        
        animation-duration: 1.5s;	
        -webkit-animation-duration: 1.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes floating {
        0% {
            transform: translateY(0%);	
        }
        50% {
            transform: translateY(8%);	
        }	
        100% {
            transform: translateY(0%);
        }			
    }
    
    @-webkit-keyframes floating {
        0% {
            -webkit-transform: translateY(0%);	
        }
        50% {
            -webkit-transform: translateY(8%);	
        }	
        100% {
            -webkit-transform: translateY(0%);
        }			
    }
    .text-center{
        text-align:center;
    }
    #container2 p{
        text-align: center !important;
    }
</style>
<div id="container2" style="text-align:justify;width: 800px;">
    <div class="padd-banner">
        <div class="banner-main">
            <h3 class="banner-header">Get <?=$domain?> Banners and Make Money</h3>
            <dl class="dl-horizontal banner-info">
                <dt>Marketing Group</dt><dd>Contrib</dd>
                <dt>Banner Size</dt><dd>150 x 150</dd>
                <dt>Banner Description</dt><dd>Proud member of Contrib Sticker</dd>
                <dt>Target URL</dt><dd>http://www.contrib.com</dd>
            </dl>
            <div class="tossing text-center banner-img-cont">
                <img src="http://referrals.contrib.com/banners/badge-contrib-2.png" />
            </div>
            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
            <textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
                <a href="http://referrals.contrib.com/idevaffiliate.php?id=<?=$domain_affiliate_id?>" target="_blank">
                    <img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-2.png" width="150" height="150" alt="Proud Member of Contrib"></a>
            </textarea>
            
        </div>
        <div class="banner-main">
            <dl class="dl-horizontal banner-info">
                <dt>Marketing Group</dt><dd>Contrib</dd>
                <dt>Banner Size</dt><dd>150 x 150</dd>
                <dt>Banner Description</dt><dd>Contrib Sticker 1</dd>
                <dt>Target URL</dt><dd>http://www.contrib.com</dd>
            </dl>
            
            <div class="tossing text-center banner-img-cont">
                <img src="http://referrals.contrib.com/banners/badge-contrib-3.png" />
            </div>
            
            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
            <textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
                <a href="http://referrals.contrib.com/idevaffiliate.php?id=<?=$domain_affiliate_id?>" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-3.png" width="150" height="150" alt="Contrib"></a>
            </textarea>
        </div>
        <div class="banner-main">
            <dl class="dl-horizontal banner-info">
                <dt>Marketing Group</dt><dd>Contrib</dd>
                <dt>Banner Size</dt><dd>150 x 150</dd>
                <dt>Banner Description</dt><dd>I love Contrib Sticker</dd>
                <dt>Target URL</dt><dd>http://www.contrib.com</dd>
            </dl>
            
            <div class="tossing text-center banner-img-cont">
                <img src="http://referrals.contrib.com/banners/badge-contrib-heart5.png" />
            </div>
            
            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
            <textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
                <a href="http://referrals.contrib.com/idevaffiliate.php?id=<?=$domain_affiliate_id?>" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-heart5.png" width="150" height="150" alt="I love Contrib"></a>
            </textarea>
        </div>
        <div class="banner-main">
            <dl class="dl-horizontal banner-info">
                <dt>Marketing Group</dt><dd>Contrib</dd>
                <dt>Banner Size</dt><dd>200 x 200</dd>
                <dt>Banner Description</dt><dd>Contrib Banner</dd>
                <dt>Target URL</dt><dd>http://www.contrib.com</dd>
            </dl>
            
            <div class="floating text-center banner-img-cont">
                <img src="http://referrals.contrib.com/banners/ban-contrib-200x200-4.png" />
            </div>
            
            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
            <textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
                <a href="http://referrals.contrib.com/idevaffiliate.php?id=<?=$domain_affiliate_id?>" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-contrib-200x200-4.png" width="200" height="200" alt="Proud Member of Contrib"></a>
            </textarea>
        </div>
        <div class="banner-main">
            <dl class="dl-horizontal banner-info">
                <dt>Marketing Group</dt><dd>Contrib</dd>
                <dt>Banner Size</dt><dd>228 x 90</dd>
                <dt>Banner Description</dt><dd>Contrib Banner</dd>
                <dt>Target URL</dt><dd>http://www.contrib.com</dd>
            </dl>
            
            <div class="floating text-center banner-img-cont">
                <img src="http://referrals.contrib.com/banners/ban-contrib-228x90-4.png" />
            </div>
            
            <p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
            <textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
                <a href="http://referrals.contrib.com/idevaffiliate.php?id=1874_0_1_12" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-contrib-228x90-4.png" width="228" height="90" alt="Proud Member of Contrib"></a>
            </textarea>
        </div>
    </div>
</div>


<? include_once 'footer.php';?>