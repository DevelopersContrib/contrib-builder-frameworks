<?php include 'header.php'; ?>
                    <div class="arrw-rela"><div class="arrw-point-white"></div></div>
                     <div class="box-blck">
                        <h2 class="ttle text-capitalize">
                            Our Staffing Needs at <?php echo $domain?>
                        </h2>
                        <p>
                            We are looking for the best of the best, Full-Time, Part-Time, Moonlighting, Contractual and Freelance.
                        </p>
                        <p>
                            We consult and manage over 100,000 domain name ventures and are always seeking Strategic Partnerships, Applications, Domains, Engineers, Developers, Specialist and just cool smart people around the Globe. Learn more about openings and opportunities with our partner companies and send us your resume or examples to accelerate the process.
                        </p>
                        <p>Learn more about <a href="/contact.php">openings and opportunities</a> with our partner companies.</p>
                        <br>
                        <script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?echo $domain?>&f=staffing"></script>
                    </div>
                </div>
<?php include_once 'footer.php';?>          

