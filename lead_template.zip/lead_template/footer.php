<!-- new footer-->
<link rel="stylesheet" href="<?php echo $base_url?>css/serviceforms/bs4/form-modal-v2.css">


<div class="modal fade" id="form-container" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
		<div class="modal-content form-modal bg-color-content">
			<div class="custom-modal-close-form">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>

			<!-- Start:: Introduction Choices and Radio Button -->
			<div id="form-container-inquire" class="row mx-0 d-none">
				<?include('serviceform/contact_us.php'); ?>
			</div>

			<!-- Partner Forms -->
			<div id="form-container-partner" class="row mx-0 d-none">
				<?include('serviceform/partner.php'); ?>
			</div>
			<!-- End -->

			<!-- Staffing Forms -->
			<div id="form-container-staffing" class="row mx-0 d-none">
				<?include('serviceform/staffing.php'); ?>
			</div>
			<!-- End -->

			
		</div>
	</div>
</div>

<script type="text/javascript">
	
	$(function(){
		$('a#show_partner_dialog, a#_partner').click(function(){
			hideOtherForms();
			$('#form-container-partner').removeClass('d-none');
		});
		
		$('a#_contactus').click(function(){
			hideOtherForms();
			$('#form-container-inquire').removeClass('d-none');
		});
		
		$('a#_apply').click(function(){
			hideOtherForms();
			$('#form-container-staffing').removeClass('d-none');
		});

	});
	
	function hideOtherForms(){
		$('#form-container-partner').addClass('d-none');
		$('#form-container-inquire').addClass('d-none');
		$('#form-container-staffing').addClass('d-none');
	}

</script>	

<div class="footer-top">
	<div class="container">
		<div class=" row">
		  <div class=" col-md-3">
			<h3><?php echo $domain?></h3>
			<p>is a proud venture of Global Ventures, LLC. Join our network of performance based companies using <?php echo $domain?>.</p>
		  </div>
		  <div class=" col-md-3">
			<h3>Get Started</h3>
			<ul class="list-unstyled">
				<li><a href="/partners">Partner With Us</a></li>
				<li><a href="javascript:;" id="_apply" data-toggle="modal" data-target="#form-container" >Apply Now</a></li>
				<li><a href="/referral">Referral</a></li>
        		<li><a href="/apps">Apps</a></li>
				<li><a href="/developers">Developers</a></li>
			</ul>
		  </div>
		  <div class=" col-md-3">
			<h3>Company</h3>
			<ul class="list-unstyled">
				<li><a href="/about">About Us</a></li>
				<li><a href="/terms">Terms</a></li>
				<li><a href="/privacy">Privacy</a></li>
				<li><a href="/cookie">Cookie Policy</a></li>
				<li><a href="https://www.domaindirectory.com/policypage/unsubscribe?domain=<?php echo $domain?>" target="_blank">Unsubscribe</a></li>
				<li><a id="_contactus" href="javascript:;" data-toggle="modal" data-target="#form-container" >Contact Us</a></li>
				
			</ul>
		  </div>
		  <div class=" col-md-3">
			<h3>Partners</h3>
			   <?if($footer_html != ""):?>
					<?echo str_replace('http://','https://',base64_decode($footer_html));?>
					<?php else:?>
					<a href="https://goo.gl/WpfyJC" target="_blank"><img style=":0px" src="https://cdn.vnoc.com/banner/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
				<?endif;?>
				<p class="mt-0"></p>
			<h3>Social</h3>
			<ul class="list-inline socials-ul mt-3 pl-2">
				<li class="list-inline-item">
					<a title="twitter" class="icon-button twitter" href="https://twitter.com/contrib">
						<i class="fab fa-twitter" aria-hidden="true"></i>
						<span></span>
					</a>
				</li>
				<li class="list-inline-item">
					<a title="facebook" class="icon-button facebook" href="https://www.facebook.com/Contrib.Official">
						<i class="fab fa-facebook-f" aria-hidden="true"></i>
						<span></span>
					</a>
				</li>
				<li class="list-inline-item">
					<a title="linkedin" class="icon-button linkedin" href="http://www.linkedin.com/company/contrib-com">
						<i class="fab fa-linkedin-in" aria-hidden="true"></i>
						<span></span>
					</a>
				</li>
			</ul>
		  </div>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class=" row">
		  <div class=" col-md-6">&copy; <?php echo date("Y")." ".$domain?>. All Rights Reserved.</div>
		  <div class=" col-md-6">
			  <ul class="list-inline">			
				<li><a href="/about"><i class="fa fa-bookmark-o"></i> About Us</a></li>
				<li><a href="/terms"><i class="fa fa-book"></i> Terms</a></li>
				<li><a href="/privacy"><i class="fa fa-cube"></i> Privacy</a></li>
			  </ul>
		  </div>
		</div>
	</div>
</div>
<!-- new footer-->
</div>
	<script>
			$(document).ready(function(){
				$('.owl-carousel').owlCarousel({
					slideSpeed: 300,
					paginationSpeed: 400,
					items: 3,
					autoHeight:true,
					nav:true,
					onInitialized: setOwlStageHeight,
					onResized: setOwlStageHeight,
					onTranslated: setOwlStageHeight
				})
				function setOwlStageHeight(event) {
				    var maxHeight = 0;
				    $('.owl-item.active').each(function () { // LOOP THROUGH ACTIVE ITEMS
				        var thisHeight = parseInt( $(this).height() );
				        maxHeight=(maxHeight>=thisHeight?maxHeight:thisHeight);
				    });
				    $('.owl-carousel').css('height', maxHeight );
				    $('.owl-stage-outer').css('height', maxHeight ); // CORRECT DRAG-AREA SO BUTTONS ARE CLICKABLE
				};



			});
		</script>  
</body>

</html>