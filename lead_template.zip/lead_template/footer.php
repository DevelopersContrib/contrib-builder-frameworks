<? 
$count = 7;
$digits = strlen($follow_count);
$splittedString = str_split($follow_count);

?>
<style>
	.section-3-carousel{
		background-color: #ffffff;
		padding: 60px 0 150px;
	}
</style>
<center style="margin: 15px 30px 20px 30px;">
	<span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999999" data-stop="<?=$follow_count?>">
		<span class="part part0">
			<?
			for($i=$count; $i>0; $i--){
				if($i==$digits){
					for($j=0;$j<$digits;$j++){						
						echo '<span class="digit digit'.$splittedString[$j].'"></span>';
					}	
					break;					
				}else{
					echo '<span class="digit digit0"></span>';
				}
			}
			?>
		</span>							  
	</span>
</center>
</div>
</div>
</div>

<?php if (count($topsites)>0):?>
<div class="section-3-carousel">
	<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 class="tb-title">Our Top Brands</h1>
					</div>
					<div class="col-md-12">
						<div class="owl-carousel">
						    <?php foreach ($topsites as $key=>$val):?>
								<div class="wrap-marketplace-box-item">
									<a href="http://<?php echo $val['domain_name']?>" target="_blank" class="wmbi-img-logo">
										<img src="<?php echo $val['logo']?>" alt="<?php echo $val['domain_name'];?>"  title="<?php echo $val['domain_name']; ?>" class="img-responsive">
									</a>
									<h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
										<?php echo $val['domain_name']?>                        
									</h3>
									<p class="p-marg-btm">
		                                <?php echo stripcslashes($val['description'])?>
		                            </p>
		                            <p>
		                                <a href="http://<?php echo $val['domain_name']?>" target="_blank"><?php echo $val['domain_name']?></a>
		                            </p>
		                            <ul class="list-inline ul-wmbi-zero">
		                                <li>
		                                    <a href="http://<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Visit</a>
		                                </li>
		                                <li>
		                                    <a href="https://contrib.com/brand/details/<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Details</a>
		                                </li>
		                            </ul>
								</div>
							<?php endforeach;?>
						</div>
					</div>
				</div>
	</div>
</div>
<?php endif?>	

<?php if (count($related_domains) >0):?>
<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
<div class="section-2">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center lead-ttle-top">
                    <h4 class="brdr-lead">
                        <i class="fa fa-globe"></i>
                        Other Brands on <?php echo $vertical?> Vertical
                    </h4>
                </div>
                
                <div class="col-md-8 col-md-offset-2">
                    <div class="verlist">
						<div class="row">
						   <?php $count = count($related_domains)?>
							<div class="col-sm-6">
								<ul class="list-unstyled ul-verticals">
								   <?php for ($i=0;$i<$count;$i++):?>
									<li>
										<a href="http://<?php echo $related_domains[$i]['domain_name']?>" class="text-capitalize" target="_blank">
											<i class="fa fa-angle-right"></i>
											<?php echo $related_domains[$i]['domain_name']?>
										</a>
									</li>
								   
								   <?php if ($count > 5 && $i==4):?>
								   
								</ul>
							</div>
							<div class="col-sm-6">
								<ul class="list-unstyled ul-verticals">
							<?php endif?>
						   <?php endfor;?>     
									
								</ul>
							</div>
						</div>
                    </div>
                </div>
                <div class="col-sm-12 text-center">
                    <br />
                    <div class="form-group">
                        <a href="http://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" class="btn btn-success btn-lg" target="_blank">
                            <i class="fa fa-search"></i>
                            View More
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php endif?> 
 
 		
<footer class="footer" style="display:none;">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <ul class="list-inline ul-list-footer">
                        <li>
                            <a href="/about" class="text-capitalize">about</a>
                        </li>
                        <li>
                            <a href="/contact" class="text-capitalize">contact us</a>
                        </li>
                        <li>
                            <a href="/partners" class="text-capitalize">partner with us</a>
                        </li>
                        <li>
                            <a href="/staffing" class="text-capitalize">apply now</a>
                        </li>
                        <li>
                            <a href="/terms" class="text-capitalize">terms</a>
                        </li>
                        <li>
                            <a href="/privacy" class="text-capitalize">privacy</a>
                        </li>
                        <li>
                            <a href="/cookie" class="text-capitalize">cookie policy</a>
                        </li>
                         <li>
                            <a href="http://www.domaindirectory.com/policypage/unsubscribe?domain=<?php echo $domain?>" class="text-capitalize">Unsubscribe</a>
                        </li>
                        <li>
                            <a href="/referral" class="text-capitalize">referral</a>
                        </li>
                        <li>
                            <a href="/fund" class="text-capitalize">fund</a>
                        </li>
                        <li>
                            <a href="/developers" class="text-capitalize">developers</a>
                        </li>
                    </ul>
                    <p>
                        &copy; <?php echo $domain?> 2017-2018<br>
                        <?php echo $footer_banner?>
                    </p>
                </div>
            </div>
        </div>
    </footer>
<!-- new footer-->
<div class="footer-top">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-3">
			<h3><?php echo $domain?></h3>
			<p>is a proud venture of Global Ventures, LLC. Join our network of performance based companies using <?php echo $domain?>.</p>
		  </div>
		  <div class="border col-md-3">
			<h3>Get Started</h3>
			<ul class="list-unstyled">
				<li><a href="/partners">Partner With Us</a></li>
				<li><a href="/staffing">Apply Now</a></li>
				<li><a href="/referral">Referral</a></li>
				<li><a href="/fund">Fund</a></li>
				<li><a href="/developers">Developers</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3>Company</h3>
			<ul class="list-unstyled">
				<li><a href="/about">About Us</a></li>
				<li><a href="/terms">Terms</a></li>
				<li><a href="/privacy">Privacy</a></li>
				<li><a href="/cookie">Cookie Policy</a></li>
				<li><a href="http://www.domaindirectory.com/policypage/unsubscribe?domain=<?php echo $domain?>" target="_blank">Unsubscribe</a></li>
				<li><a href="/contact">Contact Us</a></li>
				<li><a href="/apps">Apps</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3>Partners</h3>
			   <?if($footer_html != ""):?>
					<?echo base64_decode($footer_html)?>
					<?php else:?>
					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
				<?endif;?>
			<h3>Social</h3>
			<ul class="list-inline socials-ul">
											<li>
												<a title="facebook" class="icon-button facebook" href="<?php echo $social_fb; ?>">
													<i class="fa fa-facebook-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="google-plus" class="icon-button google-plus" href="<?php echo $social_gplus; ?>">
													<i class="fa fa-google-plus-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="youtube" class="icon-button youtube" href="<?php echo $social_gtube; ?>">
													<i class="fa fa-youtube-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="linkedin" class="icon-button linkedin" href="<?php echo $social_linkedin; ?>">
													<i class="fa fa-linkedin-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="twiiter" class="icon-button linkedin" href="<?php echo $social_twitter; ?>">
													<i class="fa fa-twitter-square"></i>
													<span></span>
												</a>
											</li>
			</ul>
		  </div>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-6">&copy; <?php echo date("Y")." ".$domain?>. All Rights Reserved.</div>
		  <div class="border col-md-6">
			  <ul class="list-inline">			
				<li><a href="/about"><i class="fa fa-bookmark-o"></i> About Us</a></li>
				<li><a href="/terms"><i class="fa fa-book"></i> Terms</a></li>
				<li><a href="/privacy"><i class="fa fa-cube"></i> Privacy</a></li>
				<li><a href="/contact"><i class="fa fa-phone-square"></i> Contact Us</a></li>
			  </ul>
		  </div>
		</div>
	</div>
</div>
<!-- new footer-->
</div>
	<script>
			$(document).ready(function(){
				$('.owl-carousel').owlCarousel({
					slideSpeed: 300,
					paginationSpeed: 400,
					items: 3,
					autoHeight:true,
					nav:true,
					onInitialized: setOwlStageHeight,
					onResized: setOwlStageHeight,
					onTranslated: setOwlStageHeight
				})
				function setOwlStageHeight(event) {
				    var maxHeight = 0;
				    $('.owl-item.active').each(function () { // LOOP THROUGH ACTIVE ITEMS
				        var thisHeight = parseInt( $(this).height() );
				        maxHeight=(maxHeight>=thisHeight?maxHeight:thisHeight);
				    });
				    $('.owl-carousel').css('height', maxHeight );
				    $('.owl-stage-outer').css('height', maxHeight ); // CORRECT DRAG-AREA SO BUTTONS ARE CLICKABLE
				};
			});
		</script>  
</body>

</html>