<style>
.boxcon {
    background: rgba(0,0,0,0.6);
    padding: 30px 40px 40px;
    margin-top: 20px;
    margin-bottom: 20px;
}
.section-1 {
    min-height: 0px !important;
}
</style>
<?php include 'header.php'; ?>
        <div class="arrw-rela"><div class="arrw-point-white"></div></div>
         <div class="box-blck">
            <h2 class="ttle text-capitalize">
                Interested in Sponsoring, Partnering or Supporting  <?=$domain?>, Join Free today
            </h2>
            <p>Learn more about <a href="/contact.php">openings and opportunities</a> with our partner companies.</p>
            <br>
            <script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?echo $domain?>&f=partner"></script>
        </div>
<?php include_once 'footer.php';?>          

