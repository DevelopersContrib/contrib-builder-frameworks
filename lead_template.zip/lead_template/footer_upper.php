<?php if (count($topsites)>0):?>
<div class="section-3-carousel">
	<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 class="tb-title">Our Top Brands</h1>
					</div>
					<div class="col-md-12">
						<div class="owl-carousel">
						    <?php foreach ($topsites as $key=>$val):?>
								<div class="wrap-marketplace-box-item">
									<?php
									if(strpos($val['logo'],'https') === FALSE){
										$logo_brand = str_replace('http','https',$val['logo']);
									}else{
										$logo_brand = $val['logo'];
									}
									?>
									<a href="https://<?php echo $val['domain_name']?>" target="_blank" class="wmbi-img-logo">
										<img src="<?php echo $logo_brand?>" alt="<?php echo $val['domain_name'];?>"  title="<?php echo $val['domain_name']; ?>" class="img-fluid">
									</a>
									<h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
										<?php echo $val['domain_name']?>                        
									</h3>
									<p class="p-marg-btm">
									    <?php echo stripcslashes($val['description'])?>
									</p>
									<p>
									    <a href="https://<?php echo $val['domain_name']?>" target="_blank"><?php echo $val['domain_name']?></a>
									</p>
									<ul class="list-inline ul-wmbi-zero">
									    <li>
										 <a href="https://<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success"><b>Visit</b></a>
									    </li>
									    <li>
										 <a href="https://contrib.com/brand/details/<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success"><b>Details</b></a>
									    </li>
									    <div class="clearfix"></div>
									</ul>									
								</div>
							<?php endforeach;?>
						</div>
					</div>
				</div>
	</div>
</div>
<?php endif?>	

<?php if (count($related_domains) >0):?>
<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
<div class="section-2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-12 text-center lead-ttle-top">
                    <h4 class="brdr-lead">
                        <i class="fa fa-globe"></i>
                        Other Brands on <?php echo $vertical?> Vertical
                    </h4>
                </div>
                
                <div class="col-md-8">
                    <div class="verlist">
						<div class="row">
						   <?php $count = count($related_domains)?>
							<div class="col-sm-6">
								<ul class="list-unstyled ul-verticals">
								   <?php for ($i=0;$i<$count;$i++):?>
									<li>
										<a href="https://<?php echo $related_domains[$i]['domain_name']?>" class="text-capitalize" target="_blank">
											<i class="fa fa-angle-right"></i>
											<?php echo $related_domains[$i]['domain_name']?>
										</a>
									</li>
								   
								   <?php if ($count > 5 && $i==4):?>
								   
								</ul>
							</div>
							<div class="col-sm-6">
								<ul class="list-unstyled ul-verticals">
							<?php endif?>
						   <?php endfor;?>     
									
								</ul>
							</div>
						</div>
                    </div>
                </div>
                <div class="col-sm-12 text-center">
                    <br />
                    <div class="form-group">
                        <a href="https://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" class="btn btn-success" target="_blank">
                            <b>
				<i class="fa fa-search"></i>
                            View More
				</b>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php endif?> 

 <div class="eservices">
 	<div class="container">
 		<div class="row">
 			
 			<div class="col-md-12">
 				<script type="text/javascript" src="https://tools.contrib.com/eservice?d=<?php echo $domain?>&ver=2"></script>
 			</div>
 		</div>
 	</div>
 </div>