<?php global $footer_html?>
<link rel="stylesheet" type="text/css" href="/css/serviceforms/contactus.css">

<div class="modal modal2 hide fade in" id="form-container">
 
  <div class="modal-header mh-2">
	<button type="button" class="close close-2" data-dismiss="modal" aria-hidden="true">&times;</button>
	<h3 class="text-center" id="form-header"><i class="icon-envelope-alt"></i> Contact Us Today !</h3>
  </div>
	
  <div class="modal-body mb-2">
    <div id="form-container-partner" style="display:none;">
		<div class="wrap-form2">
		<?include('serviceform/partner.php')?>
		</div>
	</div>
	<div id="form-container-inquire" style="display:none;">
		<?include('serviceform/contact_us.php')?>
	</div>
	<div id="form-container-staffing" style="display:none;">
		<div class="wrap-form2">
		<?include('serviceform/staffing.php')?>
		</div>
	</div>
  </div>
</div>	

<script type="text/javascript">
	
	$(function(){
		$('button#show_partner_dialog, a#_partner').click(function(){
			hideOtherForms();
			$('#form-header').html("<i class='icon-envelope-alt'></i> Submit Partnership Application");
			$('#form-container-partner').css('display','block');
		});
		
		$('a#_contactus').click(function(){
			hideOtherForms();
			$('#form-header').html("<i class='icon-envelope-alt'></i> Send Inquiry");
			$('#form-container-inquire').css('display','block');
		});
		
		$('a#_apply').click(function(){
			hideOtherForms();
			$('#form-header').html("<i class='icon-envelope-alt'></i>  Submit Team Application");
			$('#form-container-staffing').css('display','block');
		});
			
	});
	
	function hideOtherForms(){
		$('#form-container-partner').css('display','none');
		$('#form-container-inquire').css('display','none');
		$('#form-container-staffing').css('display','none');
	}

</script>	

<div class="footer-top" style="background: none repeat scroll 0 0 rgb(51,51,51); padding: 0px 0px 20px;">
	<div class="container lead-reset-padd">
		<div class="row-fluid">
			<div class="adr-footer">
				<div>
					<div class="span3">
						<h3><?=ucwords($info['domain'])?></h3>
						<p>Join our exclusive community of like minded people on <?=ucwords($info['domain'])?></p>
					</div>
					<div class="span3">
						<h3>Get Started</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a href="/partners" class="text-capitalize">
									Partner with us
								</a>
							</li>
							<li>
								<a id="_apply" data-toggle="modal" data-target="#form-container" class="text-capitalize">
									Apply now
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>referral" class="text-capitalize">
									referral
								</a>
							</li>
						</ul>
					</div>
					<div class="span3">
						<h3>Company</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a id="_contactus" data-toggle="modal" data-target="#form-container" class="text-capitalize">
									Contact us
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>terms" class="text-capitalize">
									Terms
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>apps" class="text-capitalize">
									Apps
								</a>
							</li>
						</ul>
					</div>
					<div class="span3">
						<h3>Partners</h3>
							<?if($footer_html != ""):?>
							<?echo base64_decode($footer_html)?>
								<?php else:?>
								<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
							<?endif;?>
						<h3>Socials</h3>
										<ul class="list-inline socials-ul">
											<li>
												<a title="facebook" class="icon-button facebook" href="https://www.facebook.com/pages/Javapoint/646287392104713">
													<i class="fa fa-facebook-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="google-plus" class="icon-button google-plus" href="https://plus.google.com/u/0/107137956951125091896/">
													<i class="fa fa-google-plus-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="youtube" class="icon-button youtube" href="https://www.youtube.com/user/javapointcom">
													<i class="fa fa-youtube-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="linkedin" class="icon-button linkedin" href="http://www.linkedin.com/company/javapoint">
													<i class="fa fa-linkedin-square"></i>
													<span></span>
												</a>
											</li>
										</ul>					
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
<div class="footer-bottom" style="background: none repeat scroll 0 0 rgb(34,34,34);">
	<div class="container lead-reset-padd">
		<div class="row-fluid">
			<div class="adr-footer">
				<div>
					<div class="span6">
						<span class="credits">© <?=date("Y")?> <a href="" class="text-capitalize "><?=$info['domain']?></a>. All Rights Reserved.</span>
					</div>
					<div class="span6">
						<ul class="list-inline text-left f-a-links">				
							<li>
								<a href="<?php echo $base_url?>terms" class="text-capitalize">
									<i class="fa fa-book"></i>
										Terms
								</a>
							</li>				
							<li>
								<a id="_contactus" data-toggle="modal" data-target="#form-container" class="text-capitalize">
									<i class="fa fa-phone-square"></i>
										contact us
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	 </div>
</div>
<? if($forsale=='1'){ ?>
	<div class="navbar navbar-inverse navbar-fixed-top">
	<div class="navbar-inner" style="background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x !important; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
		<?=$forsaletext?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$info['domain']?>" target="_blank" style="color:blue;">Inquire now</a>.
	</div>
	</div>
<? } ?>

<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="<?php echo $base_url?>js/lead.js" type="text/javascript"></script>


</body>
</html>