<? include('header.php'); ?>
	<div class="public-pages py-5">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 text-left">
					<?php echo $content ?>
				</div>
			</div>
		</div>
	</div>
			
<? include('footer_outer.php'); ?>