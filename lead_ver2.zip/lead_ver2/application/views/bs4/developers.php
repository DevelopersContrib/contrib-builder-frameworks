<? include('header.php'); ?>
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" />
<link href="http://fonts.googleapis.com/css?family=Lato:300,400" type="text/css" rel="stylesheet" />
<style type="text/css">
	.brdr{
		border: 1px solid;
	}
	.brdr-lead{
		color: #fff;
	}
	.text-capitalize{
		text-transform: capitalize;
	}
	.brdr-lead:before,.brdr-lead:after{
		border-color: #fff;
	}
	.lead-ttle-top{
		margin-top: 0;
		margin-bottom: 40px;
	}
	.fnt-sans{
		font-family: 'Open Sans', sans-serif;
	}
	.fnt-lato{
		font-family: 'Lato', Arial, sans-serif;
	}
	.fnt-size1-lato{
		font-size: 15px;
		letter-spacing: 1px;
		margin: 0;
	}
	.fnt-300{
		font-weight: 300 !important;
	}
	.fnt-400{
		font-weight: 400 !important;
	}
	.ttle-s2{
		text-align: left;
		margin: 20px 0;
		padding-bottom: 20px;
		position: relative;
	}

	.ttle-s2{
		position:relative;
		padding-bottom:20px;
		margin:20px 0;
		border-bottom:1px solid #dcdbd7
	}
	.ttle-s2:after{
		content:"";
		position:absolute;
		left:0;
		bottom:-1px;
		width:65px;
		height:0;
		border-bottom:2px solid #F0454D
	}
	.ttle-s2:before{
		content:"";
		position:absolute;
		left:0;
		bottom:-5px;
		height:10px;
		width:10px;
		border-radius:500px;
		background-color:#F0454D
	}

	.ttle-s2:before,.ttle-s2:after {
		border-color: #2acdc9;
	}
	.ttle-s2:before{
		background-color: #2ACDC9;
	}
	.wrap-dev-form{
		border-radius: 1px;
		padding: 10px 15px;
		color: #fff;
		background-image: url('http://d2qcctj8epnr7y.cloudfront.net/images/2013/bg-contrib-big2.png');
		background-color: #eee;
		background-repeat: no-repeat;
		background-position: center;
	}
	.wrap-scnd-form{
		background-color: #fff;
		padding: 5px 15px;
	}
	.wrap-scnd-form:before,.wrap-scnd-form:after{
		display: table;
		content: "";
	}
	.wrap-scnd-form:after{
		clear: both;
	}
	.ttle-devSub {
		display: block;
		font-size: 17px;
		font-weight: 400;
		margin-bottom: 5px;
		margin-top: 5px;
	}
	.fnt-s-14{
		font-size: 14px !important;
	}
	.dev-inner {
		background: rgba(0,0,0,.6);
		padding: 60px;
		margin: 100px 0px 160px;
		border-radius: 3px;
	}
	.dev-inner h3 {
		color: #fff;
		font-weight: 600;
	}
</style>
<div class="container-fluid"  style="background: url('<?echo $base_url?>img/bg-socialholdings.jpg') repeat;">
	<div class="container">
		<div class="row">		
			<div class="col-md-12 text-left">
				<div class="dev-inner">
					<h3 class="fnt-lato text-left mb-3">
						Do you have code or an app that could run this brand? 
						<br><?=ucwords($info['domain'])?> is connected with Contrib.
					</h3>
					<h3 class="fnt-lato text-left">
						Contrib is the new way to contribute and get equity building the world's biggest brands and startups. 
						<br>We have our own Developers platform, and we run the world’s best brands on them. 
						<br>Do you have an app, or code that could help run <?=ucwords($info['domain'])?>?
					</h3>
				</div>
			</div>
		</div>
	</div>
</div><!--3rd section-->

<? include('footer_outer.php'); ?>