<?php global $footer_html; ?>
<link rel="stylesheet" href="<?php echo $base_url?>css/serviceforms/bs4/form-modal-v2.css">


<div class="modal fade" id="form-container" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
		<div class="modal-content form-modal bg-color-content">
			<div class="custom-modal-close-form">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>

			<!-- Start:: Introduction Choices and Radio Button -->
			<div id="form-container-inquire" class="row mx-0 d-none">
				<?include('serviceform/contact_us1.php'); ?>
			</div>

			<!-- Partner Forms -->
			<div id="form-container-partner" class="row mx-0 d-none">
				<?include('serviceform/partner1.php'); ?>
			</div>
			<!-- End -->

			<!-- Staffing Forms -->
			<div id="form-container-staffing" class="row mx-0 d-none">
				<?include('serviceform/staffing1.php'); ?>
			</div>
			<!-- End -->

			
		</div>
	</div>
</div>

<script type="text/javascript">
	
	$(function(){
		$('a#show_partner_dialog, a#_partner').click(function(){
			hideOtherForms();
			$('#form-container-partner').removeClass('d-none');
		});
		
		$('a#_contactus').click(function(){
			hideOtherForms();
			$('#form-container-inquire').removeClass('d-none');
		});
		
		$('a#_apply').click(function(){
			hideOtherForms();
			$('#form-container-staffing').removeClass('d-none');
		});

	});
	
	function hideOtherForms(){
		$('#form-container-partner').addClass('d-none');
		$('#form-container-inquire').addClass('d-none');
		$('#form-container-staffing').addClass('d-none');
	}

</script>	

<div class="footer-dark-1">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3">
						<h3 class="text-uppercase footer--title">
							<?=ucwords($info['domain'])?>
						</h3>
						<p>
							Join our exclusive community of like minded people on <?=ucwords($info['domain'])?>
						</p>
					</div>
					<div class="col-md-3">
						<h3 class="text-uppercase footer--title">
							get started
						</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a href="/partners" class="text-capitalize">
									Partner with us
								</a>
							</li>
							<li>
								<a href="javascript:;" id="_apply" data-toggle="modal" data-target="#form-container" class="text-capitalize">
									Apply now
								</a>
							</li>
							<li>
								<a href="/referral" class="text-capitalize">
									referral
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>apps" class="text-capitalize">
									Apps
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>developers" class="text-capitalize">
									developers
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="text-uppercase footer--title">
							company
						</h3>
						<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
							<li>
								<a href="<?php echo $base_url?>about" class="text-capitalize">
									About
								</a>
							</li>
							<li>
								<a id="_contactus" href="javascript:;" data-toggle="modal" data-target="#form-container" class="text-capitalize">
									Contact us
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>terms" class="text-capitalize">
									Terms
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>policy" class="text-capitalize">
									policy
								</a>
							</li>
							<li>
								<a href="<?php echo $base_url?>cookiepolicy" class="text-capitalize">
									cookie policy
								</a>
							</li>							
							<li>
								<a href="https://www.domaindirectory.com/policypage/unsubscribe?domain=<?=$info['domain']; ?>" class="text-capitalize" target="_blank">
									Unsubsribe
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="text-uppercase footer--title">
							partners
						</h3>
						<?if($footer_html != ""):?>
							<?php
								$footer_html = str_replace('http:','https:',base64_decode($footer_html));
								$footer_html = str_replace('https://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png','https://cdn.vnoc.com/banner/codero-logo-HostingOnDemand.png',$footer_html);
								echo $footer_html;
							?>
						<?php else:?>
						<p>
							<a href="https://goo.gl/R4U8sH" target="_blank"><img style="border:0px;height: 65px !important;width: ;width: 225px !important;" src="https://cdn.vnoc.com/banner/banner-ctb-earn-ctb-tokens.png" alt="Crypto Contrib" title="Crypto Contrib"></a>
						</p>
						<?endif;?>
						<h3 class="text-uppercase footer--title">
							Socials
						</h3>
						<ul class="list-inline socials-ul mt-3 pl-2">
						 
							<?
								if(strpos($info['social_twitter'],'https') === FALSE){
		                            $twitter_link = str_replace('http','https',$info['social_twitter']);
		                        }else{
		                            $twitter_link = $info['social_twitter'];
		                        }
	                        ?>
							<li class="list-inline-item">
								<a title="twitter" class="icon-button twitter" href="<?php echo $twitter_link; ?>">
									<i class="fab fa-twitter"></i>
									<span></span>
								</a>
							</li>
							<?
								if(strpos($info['social_fb'],'https') === FALSE){
		                            $fb_link = str_replace('http','https',$info['social_fb']);
		                        }else{
		                            $fb_link = $info['social_fb'];
		                        }
	                        ?>
							<li class="list-inline-item">
								<a title="facebook" class="icon-button facebook" href="<?php echo $fb_link; ?>">
									<i class="fab fa-facebook-f"></i>
									<span></span>
								</a>
							</li>
							<?
								if(strpos($info['social_gtube'],'https') === FALSE){
		                            $social_gtube = str_replace('http','https',$info['social_gtube']);
		                        }else{
		                            $social_gtube = $info['social_fb'];
		                        }
	                        ?>
							<li class="list-inline-item">
								<a title="youtube" class="icon-button youtube" href="<?php echo $social_gtube; ?>">
									<i class="fab fa-youtube"></i>
									<span></span>
								</a>
							</li>
							<?
								if(strpos($info['social_linkedin'],'https') === FALSE){
		                            $social_linkedin = str_replace('http','https',$info['social_linkedin']);
		                        }else{
		                            $social_linkedin = $info['social_linkedin'];
		                        }
	                        ?>
							<li class="list-inline-item">
								<a title="linkedin" class="icon-button linkedin" href="<?php echo $social_linkedin; ?>">
									<i class="fab fa-linkedin-in"></i>
									<span></span>
								</a>
							</li>
						</ul>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer-dark-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6 f-a-links">
						© <?=date("Y")?> <a href="/" class="text-capitalize "><?=$info['domain']?> </a>. All Rights Reserved. 
					</div>
					<div class="col-md-6">
						<ul class="list-inline text-right f-a-links">
							<li class="list-inline-item">
								<a href="<?php echo $base_url?>terms" class="text-capitalize">
									<i class="fa fa-book"></i>
									Terms
								</a>
							</li>
							<li class="list-inline-item">
								<a href="javascript:;" id="_contactus" data-toggle="modal" data-target="#form-container" class="text-capitalize">
									<i class="fa fa-phone-square"></i>
									contact us
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

</body>
</html>