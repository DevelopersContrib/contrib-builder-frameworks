<? include('header.php'); ?>
<style>
.text-shad1 {
    text-shadow: none;
}
.logo-text {
    margin-top: 100px;
    font-size: 60px;
    font-weight: 600;
    color: #666;
}
.box-blck {    
    border-radius: 2px;
    margin: 30px 0 50px;
    padding: 30px 30px;
}
.box-blck .ttle {
    margin-top: 0;
    font-weight: bold;
    color: #ddd;
}
</style>
	<div class="container lander-box">
		<div class="row">
			<div class="col-lg-12 text-left">
				<div class="row">
					  <div class="col-sm-12 text-center">
					      <h1 class="text-capitalize logo-text text-shad1">
									   <?=ucwords($info['domain'])?>                           
					      </h1>
					      <h3 class="text-shad1 max-wd">
						   Join our exclusive community of like minded people on <?=ucwords($info['domain'])?> 

					      </h3>                    <!-- <div class="arrw-rela"><div class="arrw-point-white"></div></div> -->
					      <div class="box-blck">
						   <h2 class="ttle text-capitalize">
							About <?=ucwords($info['domain'])?>                        </h2>
						   <p><?=ucwords($info['domain'])?> is a proud venture of Global Ventures, LLC.</p>
						   <p>Global Ventures, LLC, established in 1996, invests in young innovators, entrepreneurs and professionals with a desire to solving big problems and help world. We combine our resources with a series of intense challenges, real-world skills development, amazing and flexible opportunities and a shared ownership and experience with the most talented young founders and professionals around the world.</p>
						   <p>Join our network of performance based companies using <?=ucwords($info['domain'])?></p>
					      </div>
					  </div>
				</div>
			</div>
		</div>
	</div>	
<? include('footer_outer.php'); ?>