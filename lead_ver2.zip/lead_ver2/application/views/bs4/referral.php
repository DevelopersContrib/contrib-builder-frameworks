<? include('header.php'); ?>

<div class="partner-section py-5">
    <div class="bg-black-overlay"></div>
    <div class="container">
            <div class="row">
                    <div class="col-lg-12 text-center mb-5">
                       <? if($info['logo']!=''){ ?>
                       <a href="https://<?=$info['domain']?>" class="d-inline-block logo-partner-page">
                        <img class="img-fluid" src="<?=$info['logo']?>" alt="">
                    </a>
                    <? }else{ ?>
                    <h1><?=ucwords($info['domain'])?></h1>
                    <? } ?>
                    <p class="mt-2">
                        <b>
                            Learn more about Joining our Partner Network
                        </b>
                    </p>

                </div>
                <div class="col-lg-12">
                     <script class="ctb-box" id='referral-script' src='https://www.referrals.com/extension/widget.js?key=356' type='text/javascript'></script>
                </div>
            </div>
    </div>
</div>


<?include('footer_outer.php');?>