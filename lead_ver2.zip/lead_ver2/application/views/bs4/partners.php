<?include('header.php'); ?>


<div class="partner-section py-5">
            <div class="bg-black-overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center mb-5">
                         <? if($info['logo']!=''){ ?>
                            <a href="https://<?=$info['domain']?>" class="d-inline-block logo-partner-page">
                                <img class="img-fluid" src="<?=$info['logo']?>" alt="">
                            </a>
                        <? }else{ ?>
                            <h1><?=ucwords($info['domain'])?></h1>
                        <? } ?>
                        <p class="mt-2">
                            <b>
                                Learn more about Joining our Partner Network
                            </b>
                        </p>
                        <a href="javascript:;" id="show_partner_dialog" class="btn btn-primary py-3 px-4" data-toggle="modal" data-target="#form-container">
                            Join Our Partner Network
                        </a>
                    </div>
                    <div class="col-lg-8 offset-lg-2">
                        <div class="bg-black-opacity mb-2 p-3">
                            <div class="row">
                                <div class="col-lg-4">
                                    <a href="https://contrib.com/" class="">
                                        <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-new-contrib-06-wyt.png" alt="">
                                    </a>
                                </div>
                                <div class="col-lg-8">
                                    <h3 class="mt-lg-3">
                                        <a href="https://contrib.com/" class="text-decoration-none text-reset text-capitalize">
                                            contrib.com
                                        </a>
                                    </h3>
                                    <p>
                                        Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-black-opacity mb-2 p-3">
                            <div class="row">
                                <div class="col-lg-4">
                                    <a href="https://globalventures.com/" class="">
                                        <img class="img-fluid" src="https://cdn.vnoc.com/logos/image_logo-gventures10-420x60.png" alt="">
                                    </a>
                                </div>
                                <div class="col-lg-8">
                                    <h3 class="">
                                        <a href="https://globalventures.com/" class="text-decoration-none text-reset">
                                            GlobalVentures.com
                                        </a>
                                    </h3>
                                    <p>
                                        Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.
                                    </p>
                                    <p>
                                        With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-black-opacity mb-2 p-3">
                            <div class="row">
                                <div class="col-lg-4">
                                    <a href="https://ifund.com/" class="">
                                        <img class="img-fluid" src="https://cdn.vnoc.com/logos/ifund.png" alt="">
                                    </a>
                                </div>
                                <div class="col-lg-8">
                                    <h3 class="mt-lg-2">
                                        <a href="https://ifund.com/" class="text-decoration-none text-reset">
                                            iFund.com
                                        </a>
                                    </h3>
                                    <p>
                                        iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform. iFund receives no compensation in connection with the purchase or sale of securities.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-black-opacity mb-2 p-3">
                            <div class="row">
                                <div class="col-lg-4">
                                    <a href="https://ichallenge.com/" class="">
                                        <img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-ichallenge1.png" alt="">
                                    </a>
                                </div>
                                <div class="col-lg-8">
                                    <h3 class="mt-lg-2">
                                        <a href="https://ichallenge.com/" class="text-decoration-none text-reset">
                                            iChallenge.com
                                        </a>
                                    </h3>
                                    <p>
                                        The best internet challenges. Solve and win online prizes. 
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- start dynmic partners -->
                        <?php if (count($partners) > 0):?>
                         <?php $partner_default = array('contrib.com','globalventures.com','ifund.com',
                             'ichallenge.com','socialid.com','virtualinterns.com','referrals.com','adrate.com',
                             'consultants.com','domaindirectory.com','handyman.com')?>
                             <?php foreach ($partners as $partner):?>
                                 <?php if (!in_array(strtolower( $partner['company_name']), $partner_default)):?>
                                   <?php $url = $partner['url']; 
                                   $url = str_replace("[affiliate_id]", $affiliate_id , $url);
                                   $url = str_replace("[brand]", $domain , $url);
                                   ?>

                                    <div class="bg-black-opacity mb-2 p-3">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <a href="<?php echo $url?>" class="">
                                                    <img class="img-fluid" src="<?php echo $partner['image']?>" alt="<?php echo $partner['company_name']?>">
                                                </a>
                                            </div>
                                            <div class="col-lg-8">
                                                <h3 class="mt-lg-2">
                                                    <a href="<?echo $url;?>" class="text-decoration-none text-reset">
                                                        <?php echo $partner['company_name']?>
                                                    </a>
                                                </h3>
                                                <p>
                                                    <?php echo stripcslashes($partner['description'])?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                               <?php endif;?>
                           <?php endforeach;?>
                       <?php endif?>
                    </div>
                </div>
            </div>
        </div>

<?include('footer_outer.php');?>