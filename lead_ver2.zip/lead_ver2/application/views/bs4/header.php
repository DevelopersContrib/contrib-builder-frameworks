<!DOCTYPE html>
<html>
<head>
	<title><?=$info['title']?> - <?=$metatitle?></title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="robots" content="index, follow" />
	<meta name="description" content="Lead Template 2">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="title" content="<?=$info['title']?> " />
	<meta name="description" content="<?=ucwords($info['domain'])?> - <?=$info['description']?>" />
	<meta name="keywords" content="<?php echo $info['keywords']?>" />
	<meta name="author" content="<?=$info['domain']; ?>">


	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://kit.fontawesome.com/8683779cf7.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="<?php echo $base_url?>css/bs4/owl.carousel.css">
	<link rel="stylesheet" href="<?php echo $base_url?>css/bs4/owl.theme.default.css">
	<link rel="stylesheet" href="<?php echo $base_url?>css/bs4/lead-template-v2.css">
	<link rel="stylesheet" media="screen" type="text/css" href="/js/jquery.counter-analog.css"  />
	<link rel="stylesheet" media="screen" type="text/css" href="/js/jquery.counter-analog2.css" />


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo $base_url?>js/bs4/owl.carousel.js"></script>
	<script src="<?php echo $base_url?>js/lead.js"></script>
	<script>
		$(document).ready(function(){
			$(".owl-carousel").owlCarousel({
				loop:true,
				autoplay:true,
				autoplayHoverPause:true
			});
		});
	</script>

	<style>
	.bg-image{
		background-size: cover;
		background-repeat: no-repeat;
		background-position: center;

		/* Dynamic image here ------- */
		<? if($attr['background_image'] != ""){ ?>
			background-image: url(<?=$attr['background_image']?>);
		<? }else{ ?>
			background-image: url('https://cdn.vnoc.com/background/misc3.jpg');
		<? } ?>
	}
</style>
<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', '<?=$info['account_ga'] ?>', '<?=$info['domain'] ?>');
	ga('send', 'pageview');

</script>
<?php if($info['piwik_id'] != ''): ?>
<!-- Piwik -->
<script type="text/javascript">
	var _paq = _paq || [];
	_paq.push(['trackPageView']);
	_paq.push(['enableLinkTracking']);
	(function() {
		var u="//www.stats.numberchallenge.com/";
		_paq.push(['setTrackerUrl', u+'piwik.php']);
		_paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
		var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
		g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
	})();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->
<?php endif; ?>
</head>
<body>
	<? if($forsale=='1' || $forsaledefault = '1'){ ?>
	<div class="domain-black-nav py-4 fnt-600 text-center">
		<!-- For Desktop CTB Claim - Do not remove this comment -->
		<div class="claim-ctb-tbn d-none d-lg-block d-sm-none">
			<a href="https://www.contrib.com/signup/firststep?domain=<?=$info['domain'] ?>" target="_blank" class="btn btn-outline-secondary fnt-500 text-white">
				<img src="https://cdn.vnoc.com/logos/badge-contrib-3.png" width="48" height="48" class="mr-1">
				Claim Your CTB Now!
			</a>
		</div>
		<!-- End -->
		<!-- For small screen -->
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="mb-lg-0">
						We have interesting opportunities for work, sponsors and partnerships. <a href="https://www.domaindirectory.com/servicepage/?domain=<?=$info['domain']; ?>" target="_blank" class="text-blue text-decoration-none">Inquire now</a>.
					</p>
					<!-- For Mobile Phones CTB Claim - Do not remove this comment -->
					<a href="referrals.contrib.com/idevaffiliate.php?id=1794&amp;url=https://www.contrib.com/signup/firststep?domain=freelance.net" target="_blank" class="ctb-cm btn btn-outline-secondary fnt-500 text-white d-none d-lg-none d-sm-inline-block">
						<img src="https://cdn.vnoc.com/logos/badge-contrib-3.png" width="48" height="48" class="mr-1">
						Claim Your CTB Now!
					</a>
					<!-- End -->
				</div>
			</div>
		</div>
		<!-- End -->
	</div>
<? } ?>

	