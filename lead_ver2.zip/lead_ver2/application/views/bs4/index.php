<? include_once('header.php'); ?>
<div class="main-header main--header-height bg-image ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center mb-3">
                <? if($info['logo']!=''){ ?>
                    <?php 
                        if(strpos($info['logo'],'https') === FALSE){
                            $logo_site = str_replace('http','https',$info['logo']);
                        }else{
                            $logo_site = $info['logo'];
                        }
                    ?>
                    <a href="https://<?=$info['domain']?>" class="d-inline-block">
                        <img class="img-fluid" src="<?=$logo_site?>" alt="<?=$info['title']?>" title="<?=$info['domain']?>" style="max-height: 100px;">
                    </a>
                <? }else{ ?>
                    <h1><?=ucwords($info['domain'])?></h1>
                <? } ?>
            </div>
            <div class="col-lg-12 text-center">
                <h2 class="title--header mb-3">
                     <? if(str_replace(' ','',$attr['top_description'])!=''){
                        echo $attr['top_description'];
                    }else if(str_replace(' ','',$info['description'])!=''){
                        echo $info['description'];
                    }else{
                        echo 'Learn more about Joining our Partner Network.';
                    } ?>
                </h2>
            </div>
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-7 offset-md-3">
                        <div class="input-leads mb-3">
                            <div class="input-group input-group-lg mb-3" id="leadcontent">
                                <input type="text" class="form-control" id="email" placeholder="Email Address. . .">
                                <input type="text" id="secret" name="secret" value="" style="display:none;">
                                <input type="hidden" id="refid" value="0">
                                <input type="hidden" id="domain" value="<?php echo $info['domain']?>">
                                <input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
                                <div class="input-group-append">
                                    <button class="btn btn-danger" id="submitLead" type="button">
                                        Join now!
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div id="error-text"></div>
                        <div class="form-group small" id="response_error"></div>
                        <div class="row" id="response_success" style="display:none">
                            <div class="col-lg-12 text-center text-warning"><h3>Thanks, your spot is reserved!</h3> Share <?php echo ucfirst($info['domain'])?> with you friends to move up in line and reserve your username.
                                <div class="addhtml p-3 mt-3">
                                    <?if($attr['additional_html'] != ""):?>
                                            <?echo base64_decode($attr['additional_html'])?>
                                    <?endif;?>
                                </div>
                            <form target="_blank" action="https://www.contrib.com/signup/follow/<?php echo ucfirst($info['domain'])?>" method="post">
                                <input type="hidden" id="pemail" name="email_follow" value=""/>
                                    <button class="btn btn-warning">Continue to Follow <?php echo ucfirst($info['domain'])?> Brand</button></form><br><br>
                            </div>


                        </div><!-- response -->
                        <div class="row" style="display: none">
                            <div id="social">
                                <table style="border:0px;width: 350px;margin: 0 auto;">
                                    <tr>
                                        <td valign='top' style='width:15%;'>
                                            <script src="https://platform.linkedin.com/in.js" type="text/javascript"></script>
                                            <script type="IN/Share" data-url="https://www.linked.com"></script>
                                        </td>
                                        <td valign='top' style='width:85%;'>

                                            <!-- AddThis Button BEGIN -->
                                            <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
                                                <a class="addthis_button_preferred_1"></a>
                                                <a class="addthis_button_preferred_2"></a>
                                                <a class="addthis_button_preferred_3"></a>
                                                <a class="addthis_button_preferred_4"></a>
                                                <a class="addthis_button_compact"></a>
                                                <a class="addthis_counter addthis_bubble_style"></a>
                                            </div>
                                            <script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
                                            <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>
                                            <!-- AddThis Button END -->
                                        </td>    
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <center style="margin: 15px 30px 20px 30px;">
                            <span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999999" data-stop="<?=$follow_count?>">
                                <span class="part part0">
                                    <?
                                    $count = 7;
                                    $digits = strlen($follow_count);
                                    $splittedString = str_split($follow_count);
                                    for($i=$count; $i>0; $i--){
                                        if($i==$digits){
                                            for($j=0;$j<$digits;$j++){                      
                                                echo '<span class="digit digit'.$splittedString[$j].'"></span>';
                                            }   
                                            break;                  
                                        }else{
                                            echo '<span class="digit digit0"></span>';
                                        }
                                    }
                                    ?>
                                </span> 
                            </span>
                        </center>
                        <div id="socials_container" style="text-align:center;margin-top:20px"><span id="follow_us"></span>&nbsp;</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="overlay-bg"></div>
</div>
<div class="section-1 py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center mb-3">
                <h2 class="fnt-500 title-color-dark">
                    <?=ucwords($info['domain'])?> Opportunity
                </h2>
            </div>
            <div class="col-lg-4">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#people" role="tab">
                            People
                        </a>
                    </li>
                   <!-- <li class="nav-item">
                        <a class="nav-link" id="jobs-tab" data-toggle="tab" href="#jobs" role="tab">
                            Jobs
                        </a>
                    </li>-->
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="people" role="tabpanel">
                        <ul class="list-unstyled my-3">
                            <?php 
                            foreach ($data_widget_users['data'] as $w) {
                                $widu_username = $w['Username'];
                                $widu_fname = $w['FirstName'];
                                $widu_country = $w['country'];

                                ?>
                                <li>
                                    <a href="https://www.contrib.com/people/me/<?=$widu_username?>" class="text-reset text-decoration-none d-block mb-1">
                                        <span class="media">
                                            <span class="circle-first-letter rounded-circle mr-2 text-uppercase">
                                               <?=$widu_fname[0]?>
                                            </span>
                                            <span class="media-body">
                                                <span class="d-block">
                                                    <span class="d-block text-capitalize small people-name fnt-500">
                                                        <?=stripslashes(ucfirst($widu_fname))?>
                                                    </span>
                                                    <span class="small d-block text-uppercase meta-from">
                                                        from <span class="fnt-700"><?=ucwords($widu_country) ?></span>
                                                    </span>
                                                </span>
                                            </span>
                                            <span class="meta-view ml-3 fnt-600 px-3 py-1 small align-self-center">
                                                <i class="fas fa-search mr-1"></i>
                                                View
                                            </span>
                                        </span>
                                    </a>
                                </li>
                             <?php } ?>
                        </ul>
                    </div>
                   <!-- <div class="tab-pane fade" id="jobs" role="tabpanel">
                        <ul class="list-unstyled my-3">
                            <?php  
                            /*foreach ($data_widget_jobs['data'] as $j){
                                $widj_domain = $j['domain_name'];
                                $widj_jobid = $j['job_id'];
                                $widj_title = $j['title'];*/
                            ?>
                            <li>
                                <a href="https://www.contrib.com/brand/jobs/<?//=$widj_domain?>/<?=$widj_jobid?>" class="text-reset text-decoration-none d-block mb-1">
                                    <span class="media">
                                        <span class="circle-first-letter rounded-circle mr-2 text-uppercase">
                                            <i class="fas fa-medal"></i>
                                        </span>
                                        <span class="media-body">
                                            <span class="d-block">
                                                <span class="px-2 d-inline-block text-white bg-warning text-capitalize small people-name mb-1 fnt-500">
                                                    <?//=ucwords($widj_domain)?>
                                                </span>
                                                <span class="small d-block text-uppercase meta-from">
                                                    needs <span class="fnt-600"><?//=$widj_title?></span>
                                                </span>
                                            </span>
                                        </span>
                                    </span>
                                </a>
                            </li>
                           <?php //} ?>
                        </ul>
                    </div>-->
                </div>
            </div>
            <div class="col-lg-7">
                <div class="row pt-5">
                    <div class="col-lg-4">
                        <div class="media">
                            <img class="mr-3" width="50" src="https://cdn.vnoc.com/icons/icon-50x50-contrib-market2.png" alt="Marketplace" title="Marketplace">
                            <div class="media-body">
                                <h5 class="section-1--media-title">
                                    Contrib Marketplace
                                </h5>
                                <p class="small">
                                    Browse Jobs, Ideas and Micro Tasks.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="media">
                            <img class="mr-3" width="50" src="https://cdn.vnoc.com/icons/icon-50x50-contrib-contribute2.png" alt="Marketplace" title="Marketplace">
                            <div class="media-body">
                                <h5 class="section-1--media-title">
                                    Contribute
                                </h5>
                                <p class="small">
                                    Contribute using your skills, services, apps and/or capital.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="media">
                            <img class="mr-3" width="50" src="https://cdn.vnoc.com/icons/icon-50x50-contrib-money2.png" alt="Marketplace" title="Marketplace">
                            <div class="media-body">
                                <h5 class="section-1--media-title">
                                    Contrib Crypto Marketplace
                                </h5>
                                <p class="small">
                                    Contribute to blockchain projects on premium urls today
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <p>
                    We envision people around the world with complementary skills, passion, time and resources coworking online with targeted premium assets just like Freelance.net.
                </p>
            </div>
        </div>
    </div>
</div>

<?include('related_domains.php');?>

<div class="section-2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="absolute-scroll p-5">
                    <h4 class="mb-4 title-color-dark">
                        Follow, Build, and Help Launch
                    </h4>
                    <p>
                        <span class="fnt-600 title-color-dark">Follow <?=ucwords($info['domain'])?></span> and other great ventures on the Contrib platform.
                        <br><br>
                        <span class="fnt-600 title-color-dark">Build <?=ucwords($info['domain'])?></span> and Help cofound a relevant new Startup, Part-Time.
                        <br><br>
                        <span class="fnt-600 title-color-dark">Launch <?=ucwords($info['domain'])?></span> and you could be front and center in the process. Launch <?=ucwords($info['domain'])?> with us today!
                    </p>
                    <p class="text-center mb-0">
                        <a href="https://contrib.com/brand/details/<?=$info['domain']?>" target="_blank" class="btn btn-primary">
                        Learn about <?=$info['domain']?></a>
                    </p>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="owl-carousel">
                    <div class="carousel-owl-domain">
                        <a href="https://applications.net" target="_blank"><img src="https://cdn.vnoc.com/background/applicationsnet.png" alt="applications.net" title="applications.net"></a>
                    </div>
                    <div class="carousel-owl-domain">
                        <a href="https://consultants.com" target="_blank"><img src="https://cdn.vnoc.com/background/consultants.png" alt="consultants.com" title="consultants.com"></a>
                    </div>
                    <div class="carousel-owl-domain">
                        <a href="https://globalventures.com" target="_blank"><img src="https://cdn.vnoc.com/background/globalventures.png" alt="globalventures.com" title="globalventures.com"></a>
                    </div>
                    <div class="carousel-owl-domain">
                        <a href="https://photostream.com" target="_blank"><img src="https://cdn.vnoc.com/background/photostream.png" alt="photostream.com" title="photostream.com"></a>
                    </div>
                    <div class="carousel-owl-domain">
                        <a href="https://referrals.com" target="_blank"><img src="https://cdn.vnoc.com/background/referrals.png" alt="referrals.com" title="referrals.com"></a>
                    </div>
                    <div class="carousel-owl-domain">
                        <a href="https://venturecamp.com" target="_blank"><img src="https://cdn.vnoc.com/background/venturecamp.png" alt="venturecamp.com" title="venturecamp.com"></a>
                    </div>
                    <div class="carousel-owl-domain">
                        <a href="https://virtualinterns.com" target="_blank"><img src="https://cdn.vnoc.com/background/virtualinterns.png" alt="virtualinterns.com" title="virtualinterns.com"></a>
                    </div>
                    <div class="carousel-owl-domain">
                        <a href="https://wellnesschallenge.com" target="_blank"><img src="https://cdn.vnoc.com/background/wellnesschallenge.png" alt="wellnesschallenge.com" title="wellnesschallenge.com"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="title-color-dark mb-3">
                    <?=ucwords($info['domain'])?> Team
                </h2>
            </div>
            <div class="col-lg-12">
                <p>
                    <?=ucwords($info['domain'])?> is a bit different than most startups. We are small, diverse team working remotely and loving what we do. We only cowork with others who also have this same passion.
                </p>
                <p>
                    <?=ucwords($info['domain'])?> seeks to contract and hire the best people and then trust them: it's the thinking behind the work at their own time policy.
                </p>
                <p>
                    The <?=ucwords($info['domain'])?> team loves building things and focus on being the most productive individual, not the amount of time spent in the office. We put a lot of effort into making <?=ucwords($info['domain'])?> a fun place to work for people who like getting things done. So if you're game with this then enter your email address and be a part of the global team.
                </p>
            </div>
        </div>
    </div>
</div>

<div class="section-4">
    <div class="container">
        <div class="row">
            <script type="text/javascript" src="https://tools.contrib.com/eservice?d=<?=$info['title']?>&ver=2"></script>
        </div>
    </div>
</div>
<? include('footer_outer.php'); ?>