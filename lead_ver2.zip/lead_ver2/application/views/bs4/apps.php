<?php include'header.php';?>
<div class="app-page-section py-5">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 mb-3">
				<h1 class="bg-black-inverse text-white py-3 px-3 text-center">
					<i class="fas fa-rocket"></i>
					Contrib Apps
				</h1>
			</div>
			<div class="col-lg-12">
				<div class="row">
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://contrib.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-new-contrib-06.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								A new business model and collaboration platform for business professionals to earn equity and cash grants with premium digital assets in a flexible and transparent value creation system.
							</p>
							<a href="https://contrib.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://socialid.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-socialid4.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								SocialID establishes media distribution and identification management services on valuable, engaged networks.  Creating value for companies and engaging the targeted user bases.
							</p>
							<a href="https://socialid.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://handyman.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-handyman-1.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Find various experienced, and professional contractors in your area.   Efficiently fulfill your home repair or remodel needs and manage your project details online and anytime.
							</p>
							<a href="https://handyman.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://eservices.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-eservices-1-1.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								The marketplace for quick, paid opportunities by doing small online tasks ordered daily through a curated network of professionals.
							</p>
							<a href="https://eservices.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://referrals.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-referrals-beta9-small.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Offers a seamless and easy integration into premium brands while expanding distribution turning contacts and community into commerce.
							</p>
							<a href="https://referrals.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://staffing.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-staffing1.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Professional and Curated Talent for short and long term organizational needs and desires.  Remote, value based talent fulfillment with amazing opportunities to earn equity and cash warrants with leading organizations.
							</p>
							<a href="https://staffing.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://www.photostream.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-photostream.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Shoot, Stream, and Monetize. Import your social photos from popular social networks.
							</p>
							<a href="https://www.photostream.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://micromarkets.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-micromarkets.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Post your small service jobs for free. Connect and get paid with thousands of service suppliers from different Micro Markets.
							</p>
							<a href="https://micromarkets.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://domaindirectory.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-domaindirectory300x82.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Get the best URL for your website or join partnership opportunities with other related assets.  The right domain name can change your business and life.  We help you find, acquire, sell, build or monetize valuable domain assets.
							</p>
							<a href="https://domaindirectory.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://venturebook.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-VentureBook-3.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								The leading venture and equity network for digital assets.  Create Venture Suggestions and proposals with leading and exclusive digital assets.
							</p>
							<a href="https://venturebook.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://eshares.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-eshares1.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								The leading Equity Management and Marketplace for Technology companies in the digital economy. Join the 1,000's of tech focused companies utilizing eShares.com
							</p>
							<a href="https://eshares.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://ifund.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/ifund.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Is a software as a service collaborative funding platform for premium digital ventures.  iFund is not a registered broker-dealer but offers opportunities to find and learn about great companies.
							</p>
							<a href="https://ifund.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://adrate.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-adrate-3.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Adrate is a unique AI program for native advertising platform with access to over a Billion placements daily.  Join and let AdRate use our ad technology to make you profits.
							</p>
							<a href="https://adrate.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://ipartner.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-Ipartner1.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Gain access to a curated network of strategic partners and expand your user base with the right partner opportunities.  iPartner helps filter and attract the best partners within our premium venture opportunities. Forming a mutually beneficial and benchmarkable partnership outline.
							</p>
							<a href="https://ipartner.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://applications.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-Applications-7.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Applications is the new way to list and power leading digital assets and make money from your apps.  Sell, Trade and Lease your code using the leading app hosting systems.  Gain access to leading and exclusive scripts that help grow your business.
							</p>
							<a href="https://applications.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://www.esignatures.com/index.html" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/esignatures-logo-blue-1.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Your best practice resource for transforming your business processes to drive efficiency, automation, insight, and action.  Quick and Easy and legally binding while easy management of all your legal documents.
							</p>
							<a href="https://www.esignatures.com/index.html" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://cookboard.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-CookBoard-2.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Is the #1 Local Food Marketplace where you can buy and sell food items from your local chefs, local cooks in your community.
							</p>
							<a href="https://cookboard.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://builderkit.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-BuilderKit-1.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Provides a fast, affordable, high quality business creation and management platform for digital assets.
							</p>
							<a href="https://builderkit.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://liverep.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-liverep2.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Is a technology gamification company building and managing leading brand platforms. Our scalable, domain based platform creates niche, interactive gaming systems that match sponsors with targeted users creating synergy and engagement.
							</p>
							<a href="https://liverep.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://ichallenge.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-ichallenge-2-small.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Is a technology gamification company building and managing leading assets including MyChallenge, CodeChallenge, SportsChallenge and other great niche locations. Our scalable, domain based platform creates niche, interactive gaming systems that match sponsors with targeted users creating synergy and engagement.
							</p>
							<a href="https://ichallenge.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://www.bidtellect.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/Bidtellect_logoH.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								The First Open, Multi-format, Multi-device Native Marketing Platform Connecting Advertisers and Publishers to Deliver Optimized and Insightful Native Advertising at Scale.
							</p>
							<a href="https://www.bidtellect.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://talentdirect.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-tda.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								TalentDirect uses the most updated, modern technology to showcase, schedule and manage talent - making it effortless for any production, film, commercial or promotional event to make their project the best it can be.
							</p>
							<a href="https://talentdirect.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
					<div class="col-lg-3 mb-3">
						<div class="bg-apps-main p-3 mb-3">
							<div class="d-block mb-3 app-logo-header">
								<a href="https://icontent.com/" class="text-center d-block text-decoration-none" target="_blank">
									<img class="img-fluid" src="https://cdn.vnoc.com/logos/logo-Icontent-2.png" alt="">
								</a>
							</div>
							<p class="app-desc-content">
								Create, publish and make your content viral.
							</p>
							<a href="https://icontent.com/" class="btn btn-secondary btn-block px-3 btn-inverse-app" target="_blank">
								View
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php include'footer_outer.php';?>


