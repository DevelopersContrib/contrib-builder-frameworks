
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('.line-label').click(function(){


			var inputSelect = jQuery('input[type=radio]:checked').val();
			var form = inputSelect.replace('_form','');

			jQuery('.wrap-form').addClass('d-none');

			//jQuery('.wrap-choices').fadeOut(function(){	
				jQuery('.wrap-choices').addClass('d-none');
				//jQuery('.wrap-'+form).fadeIn();
				jQuery('.wrap-'+form).removeClass('d-none');
			//});

		});

	});

	function formback(form){

		//jQuery('.wrap-'+form).fadeOut(function(){
			//jQuery('.wrap-choices').fadeIn();
			//jQuery('.wrap-choices').css('display','');
			jQuery('.wrap-'+form).addClass('d-none');
			jQuery('.wrap-choices').removeClass('d-none');
		//});
	}

</script>

<!-- Start:: Introduction Choices -->
<div class="row mx-0 wrap-form wrap-choices">
	<div class="col-lg-6 bg-left-form flex-bottom-logo ">
		<div class="bg-left-overlay"></div>
		<div class="left-content-main">
			<h1 class="title-left mb-3">
				Send Inquiry
			</h1>
			<p class="desc-left mb-4">
				Please choose any of the options that interests you. 
			</p>
		</div>
		<div class="left-content-logo">
			<? if($info['logo']!=''){ ?>
			    <?php
			        if(strpos($logo,'https') === FALSE){
						$logo_site = str_replace('http','https',$info['logo']);
					}else{
						$logo_site = $logo;
					}
			    ?>
				<img src="<?=$logo_site?>" alt="<?=$info['title']?>" title="<?=$info['domain']?>" width="90">
				
			<? }else{ ?>
				<?echo ucfirst($info['domain'])?>
			<? } ?>
			
		</div>

	</div>
	<!-- End -->

	<!-- Start:: Choices of Inquiry Radio Button -->

	<div class="col-lg-6 align-self-center">
		
			<div class="bg-form-content">
				<h3 class="fnt-300 mb-3 text-primary">
					Apply Today for <span class="text-capitalize"><?echo ucfirst($info['domain'])?></span>
				</h3>
				<div class="form-group">
					<div class="custom-control custom-radio custom-option-control ">
						<input type="radio" id="customRadio1" name="customRadio" class="custom-control-input line-label" value="partner_form" >
						<label class="custom-control-label" for="customRadio1">
							Partner / Develop with <?echo ucfirst($info['domain'])?>
						</label>
					</div>
				</div>
				<div class="form-group">
					<div class="custom-control custom-radio custom-option-control " >
						<input type="radio" id="customRadio2" name="customRadio" class="custom-control-input line-label" value="staffing_form">
						<label class="custom-control-label" for="customRadio2">
							Staffing Opportunities with <?echo ucfirst($info['domain'])?>
						</label>
					</div>
				</div>
				<div class="form-group">
					<div class="custom-control custom-radio custom-option-control line-label">
						<input type="radio" id="customRadio3" name="customRadio" class="custom-control-input line-label" value="offer_form">
						<label class="custom-control-label" for="customRadio3">
							Submitting an Offer for <?echo ucfirst($info['domain'])?>
						</label>
					</div>
				</div>
				<div class="form-group">
					<div class="custom-control custom-radio custom-option-control ">
						<input type="radio" id="customRadio4" name="customRadio" class="custom-control-input line-label" value="inquiry_form">
						<label class="custom-control-label" for="customRadio4">
							Inquire / Sponsor with <?echo ucfirst($info['domain'])?>
						</label>
					</div>
				</div>
			</div>
		
	</div>
</div>

<div class="row mx-0 wrap-form wrap-partner d-none">
	<? include('service_partner.php');?>
</div>
<div class="row mx-0 wrap-form wrap-staffing d-none">
	<? include('service_staffing.php');?>
</div>
<div class="row mx-0 wrap-form wrap-offer d-none">
	<? include('service_offer.php');?>
</div>
<div class="row mx-0 wrap-form wrap-inquiry d-none">
	<? include('service_inquiry.php');?>
</div>


				<!-- End -->