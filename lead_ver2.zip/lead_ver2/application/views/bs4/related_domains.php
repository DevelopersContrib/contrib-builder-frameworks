<? if(sizeof($related_domains)>0){ ?>	
	<div class="container">
		<style>		
		.wrap-lead-vertical{
			padding-right: 5px;
			padding-left: 5px;
			max-height: 55px;
		}
		.wrap-lead-vertical img{
			max-height: 55px;
		}
		.a-vertical{
			font-size: 22px;
			line-height: normal;
			max-height:
		}
		.ellipsis {
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
		}
		.badge-black{
			background-color:black !important;
			font-size: 25px;
			text-transform: capitalize;
			line-height: 30px;
			margin-bottom: 5px;
			font-weight: normal;
		}
		</style>
		<div class="row-fluid">
			<div class="span12 wrap-feature-verticals">
				<div class="row-fluid">	
					
					<?shuffle($related_domains);?>
					<marquee>
					<? for($ci=0;$ci<sizeof($related_domains);$ci++){ ?>
					
						<a title="<?=ucfirst($related_domains[$ci]['domain_name'])?>" href="https://<?=$related_domains[$ci]['domain_name']?>" class="badge badge-info badge-black" target="_blank">
							<?=ucfirst($related_domains[$ci]['domain_name'])?>
						</a>
					
					<? } ?>
					</marquee>
				</div>
			</div>
		</div>
	</div>
		
<? } ?>