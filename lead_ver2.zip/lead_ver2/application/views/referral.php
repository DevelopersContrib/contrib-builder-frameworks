<? include('header.php'); ?>
<style>
    .padd-banner{
        padding: 10px 20px;
        width: 65%;
        margin: auto;
    }
    .banner-main{
        margin-bottom: 30px;
        padding-bottom:10px;
        border-bottom: 1px solid #fff;
    }
    .banner-main textarea{
        resize:none;
        border-radius: 4px;
        border: 1px solid #000000;
    }
    .banner-main:last-child{
        border-bottom: none;
    }
    .banner-header{
        font-weight: 300;
        color: #fff;
        border-bottom: 1px solid #fff;
        line-height: 65px;
        margin:0 0 30px;
    }
    .banner-img-cont{
        margin-bottom: 25px;
    }
    .banner-source{
        color: #fff;
        font-size:18px;
    }
    .banner-info{
        color: #fff;
    }
    /*
    ==============================================
    tossing
    ==============================================
    */

    .tossing{
        animation-name: tossing;
        -webkit-animation-name: tossing;

        animation-duration: 2.5s;
        -webkit-animation-duration: 2.5s;

        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }

    @keyframes tossing {
        0% {
            transform: rotate(-4deg);
        }
        50% {
            transform: rotate(4deg);
        }
        100% {
            transform: rotate(-4deg);
        }
    }

    @-webkit-keyframes tossing {
        0% {
            -webkit-transform: rotate(-4deg);
        }
        50% {
            -webkit-transform: rotate(4deg);
        }
        100% {
            -webkit-transform: rotate(-4deg);
        }
    }
    /*
    ==============================================
    floating
    ==============================================
    */

    .floating{
        animation-name: floating;
        -webkit-animation-name: floating;

        animation-duration: 1.5s;
        -webkit-animation-duration: 1.5s;

        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }

    @keyframes floating {
        0% {
            transform: translateY(0%);
        }
        50% {
            transform: translateY(8%);
        }
        100% {
            transform: translateY(0%);
        }
    }

    @-webkit-keyframes floating {
        0% {
            -webkit-transform: translateY(0%);
        }
        50% {
            -webkit-transform: translateY(8%);
        }
        100% {
            -webkit-transform: translateY(0%);
        }
    }
</style>
<style>
    .animated {
        -webkit-animation-duration: 1s;
        animation-duration: 1s;
        -webkit-animation-fill-mode: both;
        animation-fill-mode: both;
    }
    @-webkit-keyframes rotateIn {
        0% {
            -webkit-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(-200deg);
            transform: rotate(-200deg);
            opacity: 0;
        }

        100% {
            -webkit-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(0);
            transform: rotate(0);
            opacity: 1;
        }
    }

    @keyframes rotateIn {
        0% {
            -webkit-transform-origin: center center;
            -ms-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(-200deg);
            -ms-transform: rotate(-200deg);
            transform: rotate(-200deg);
            opacity: 0;
        }

        100% {
            -webkit-transform-origin: center center;
            -ms-transform-origin: center center;
            transform-origin: center center;
            -webkit-transform: rotate(0);
            -ms-transform: rotate(0);
            transform: rotate(0);
            opacity: 1;
        }
    }
    .rotateIn {
        -webkit-animation-name: rotateIn;
        animation-name: rotateIn;
    }
    .r-d{
        -webkit-animation-delay: 2.5s;
        -moz-animation-delay: 2.5s;
        -ms-animation-delay: 2.5s;
        -o-animation-delay: 2.5s;
        animation-delay: 2.5s;
    }
    .arrw-rela {
        position: relative;
    }
    .arrw-point-white {
        background: url("http://d2qcctj8epnr7y.cloudfront.net/contrib/arrow-1-medium.png") no-repeat scroll 0 0 rgba(0, 0, 0, 0);
        height: 92px;
        left: -130px;
        position: absolute;
        top: -75px;
        width: 100px;
    }
    .badge-postn{
        position: absolute;
        z-index: 10;
        top: 30px;
        right: 90px;
    }
    /* Landscape phones and down */
    @media (max-width: 480px) {
        .badge-postn{
            position: absolute;
            right: 1px;
            top: 2px;
            width: 40px;
            z-index: 10;
        }
        .email-glow input[type="text"] {
            height: 40px;
            width: 163px !important;
        }
        .wrap-email-input{
            width:250px;
        }
        .phne-s1{
            font-size: 14px;
        }
        .span4.features{
            text-align: center;
        }
        .img-phone{
            margin:auto;
        }
        .p-phone{
            text-align:center;
        }
    }
</style>
<style type="text/css">
    /* Add New 2 banner */
    .wrap-allbanner{
        background: url(http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-728x90-1.png)no-repeat scroll;
        height: 90px;
        width: 728px;
        position: relative;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    .bannerType1{
        text-decoration: none;
    }
    .bannerType1, .bannerType1:focus,.bannerType1:hover{
        outline: none;
    }
    .wrap-bannerLeft, .wrap-bannerRight{
        display: inline-block;
        float: left;
    }
    /* Left COntainer */
    .wrap-bannerLeft{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        height: 90px;
        vertical-align: top;
        padding: 15px 5px 20px 10px;
        width: 245px;
        overflow: hidden;
		
    }
    /*Link Domain*/
    .ellipsis {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .aBnnrP{
        display: block;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        font-weight: bold;
        font-size: 22px;
        line-height: normal;
        margin: 0;
        color: #0088CC;
        text-align: center;
        text-transform: capitalize;
        text-decoration: none;
    }

    /* Right Container */
    .wrap-bannerRight{
        color: #FFFFFF;
        height: 90px;
        margin-left: 84px;
        width: 397px;
    }
    .content-rightText{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 350px;
        padding-top: 16px;
        margin: auto;
    }
    .content-rightText span{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
    }
    .content-rightText span, .content-rightText p{
        font-size: 25px;
        text-align: center;
        text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
    }
    .content-rightText p{
        padding: 12px 0 8px;
        margin: 0;
    }
    /*Image*/
    .logo-banners1{
        max-width: 100%;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
		max-height: 58px;
    }

    /*Second Bannder*/
    .wrapBanner-2{
        background: url(http://d2qcctj8epnr7y.cloudfront.net/images/jayson/180x150-1.png) no-repeat scroll;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        margin: auto;
        position: relative;
        height: 150px;
        width: 180px;
        overflow: hidden;
    }
    .bannerType2{
        color: #fff;
        text-decoration: none;
    }
    .bannerType2,.bannerType2:hover,.bannerType2:focus{
        outline: none;
    }

    /*Top banner*/
    .wrap-topBanner{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        position: relative;
        display: block;
        width: 118px;
        margin: 37px auto 0;
    }
    .wrap-contentTop{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        font-size: 20px;
        letter-spacing: 0.01em;
        line-height: 1.1em;
        text-align: center;
        text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
        text-align: center;
    }
    .wrap-contentTop p{
        margin: 0;
    }
    .wrap-contentTop span{
        display: block;
    }

    /*Down banner*/
    .wrap-downBanner{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
        height: 37px;
        margin: 5px 0 0;
        overflow: hidden;
    }
    .wrap-contentDown{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 125px;
        height: 35px;
        margin: auto;
		padding: 1px 0;
    }
    .wrap-contentDown img{
        max-width: 100%;
		max-height: 32px;
		text-align:center;
    }
    .wrap-contentDown p{
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        display: block;
        margin: 0;
        color: #0088CC;
    }
</style>
<style>
    .tab-content.tab-content-cust{
        
    }
    .nav-pills.nav-pills-cust{
        background-color: #f8f8f8;
        border: 1px solid #e7e7e7;
        border-radius: 5px;
        padding: 5px 10px;
        margin-bottom: 5px;
    }
    .wrap-white-container{
        /* background-color: #fff;
        padding: 15px;
        color: #000; */
    }

    .media-body, .media-left, .media-right {
    display: table-cell;
    vertical-align: top;
}
.media-left, .media > .pull-left {
    padding-right: 10px;
}
.media-right, .media > .pull-right {
    padding-left: 10px;
}
.contrib-task-container .media-heading {
    margin: 10px;
}
.contrib-task-container .media-right .btn-danger {
    margin-top: 5px;
}


.hide.fade.in{
display:block !important;
}
#wrap-lead-bckgrnd .content h1 {
    font-size: 65px;
    line-height: 65px;
    color: #91F50E;
    font-weight: bold;
}
.navbar-inner {
    background: #121212;
    color: #ffffff;
    border: none;
    border-radius: 0px;   
    min-height: 0;
    padding: 1rem 1rem;
}
.navbar-inner h5 {   
    font-weight: bold;
    margin-top: 10px;   
}
.navbar-inner a {
	color: #1DA1F2;
}
.navbar-inner a:hover {
	color: #3B5998;
}
.navbar-inner a:hover, .navbar-inner a:focus {
	cursor: pointer;
	text-decoration: none;
}
.claim-note {
	position: absolute;
	top: 13px;
	right: 10px;
}
.claim-note a {
	border: 1px solid #6c757d;
	color: #eaeaea;
	background: #313131;
	padding: 1rem 1rem 1rem .55rem;
	border-radius: 6px;
}
.claim-note a:hover {	
	background: #6c757d;
	color: #ffffff;
	cursor: pointer;
	text-decoration: none;
}
.claim-logo {
	height: 48px;
}

@media (max-width: 1199.98px) {
	h5.text-center {
		text-align: left;
	}
}
@media (max-width: 991.98px) {	
	.inquire-note {
		display: none;
	}
	.inq-btn {
		background: #333;
		padding: 6px 8px;
		border-radius: 6px;
	}
}
@media (max-width: 575.98px) {
	.email-glow input {
	    height: 50px;
	    width: auto;
	}
	.inq-btn {
		display: none;
	}
	.navbar-inner {   
	    padding: 3rem 1rem;
	}
}
.animated {
	display: none;
}

input:focus {
	width: 100%;
	height: 50px;
	font-weight: 300;
}
.input--filled .input__field--kaede {
	width: 100%;
	height: 50px;
	font-weight: 300;
}
#countdown {
	margin-left: 0px;
}
.input__label-content--kaede {
    margin-left: 30px;
}
</style>
<div class="container-fluid lead-reset-padd"  style="background: url(<?echo $base_url?>img/bg-socialholdings.jpg) repeat;">
    <div class="row-fluid">
        <div class="wrap-ad" style="background: none repeat scroll 0 0 rgba(0, 0, 0, 0.8);">
            <div class="container overflow-ad">
                <div class="row-fluid">
                    <div style="position:relative;">
                        <div class="animated rotateIn r-d badge-postn">
                            <a href="<?=$domain_affiliate_link;?>" target="_blank" alt="Contrib">
                                <img alt="contrib" title="contrib bagde" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-3.png">
                            </a>
                        </div>
                    </div>
                    <div class="content-ad" style="text-align: justify;">
                        <div style="margin-top: -40px;" class="text-center">
                          <? if($info['logo']!=''){ ?>
								<a href="http://<?=$info['domain']?>"><img src="<?=$info['logo']?>" alt="<?=$info['title']?>" title="<?=$info['domain']?>" style="max-width:500px" border="0" /></a>
							<? }else{ ?>
								<h1><?=ucwords($info['domain'])?></h1>
							<? } ?>
                            <h4>Learn more about Joining our Partner Network</h4>
                        </div>
                        <a name="top"></a>




                        <div class="padd-banner">
                           <script class="ctb-box" id='referral-script' src='https://www.referrals.com/extension/widget.js?key=356' type='text/javascript'></script>
                           
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!--3rd section-->


<?include('footer_outer.php');?>