<? include('header.php'); ?>
	<div class="container cpt-box">
		<div class="row">
			<div class="col-md-12 text-left">
				<?php echo $content ?>
			</div>
		</div>
	</div>
<? include('footer_outer.php'); ?>