<!DOCTYPE html>
<html>
<head>
<link rel="canonical" href="http://<?=$info['domain']?>/<?=basename($_SERVER['PHP_SELF'])?>/" />
<link rel="icon" type="image/icon" href="favicon.ico">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="index, follow" />
<title><?=$info['title']?> - <?=$metatitle?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="title" content="<?=$info['title']?> " />
<meta name="description" content="<?=ucwords($info['domain'])?> - <?=$info['description']?>" />
<meta name="keywords" content="<?php echo $info['keywords']?>" />
<meta name="author" content="<?=$info['domain']; ?>">

<link rel="stylesheet" href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>css/custom-lead.css"/>
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>css/bootstrap-responsive.css"/>
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>js/jquery.counter-analog.css"  />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>js/jquery.counter-analog2.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>css/serviceforms/partner.css">
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>css/serviceforms/staffing.css">
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>css/serviceforms/offer.css">
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $base_url?>css/serviceforms/inquiry.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<style type="text/css">
<? if($attr['background_image'] != ""){ ?>
	#wrap-lead-bckgrnd{ background: url(<?=$attr['background_image']?>);color: #A0A0A0;
<? }else{ ?>
	#wrap-lead-bckgrnd{ background: url('https://d1p6j71028fbjm.cloudfront.net/backgrounds/photodune-2564773-business-group-m.jpg') no-repeat; }
<? } ?>
.cpt-box {
	padding: 30px 0px; 
	text-align: left !important;
}
.cpt-box .text-center {
	text-align: left !important;
}
.cpt-box h1, .cpt-box .h2 {
	font-size: 28px;
}
.media-body, .media-left, .media-right {
	display: table-cell;
	vertical-align: top;
}
.media-left, .media > .pull-left {
	padding-right: 10px;
}
.media-right, .media > .pull-right {
	padding-left: 10px;
}
.contrib-task-container .media-heading {
	margin: 10px;
}
.contrib-task-container .media-right .btn-danger {
	margin-top: 5px;
}
.hide.fade.in{
display:block !important;
}
#wrap-lead-bckgrnd .content h1 {
    font-size: 65px;
    line-height: 65px;
    color: #91F50E;
    font-weight: bold;
}
.navbar-inner {
    background: #121212;
    color: #ffffff;
    border: none;
    border-radius: 0px;   
    min-height: 0;
    padding: 1rem 1rem;
}
.navbar-inner h5 {   
    font-weight: bold;
    margin-top: 10px;   
}
.navbar-inner a {
	color: #1DA1F2;
}
.navbar-inner a:hover {
	color: #3B5998;
}
.navbar-inner a:hover, .navbar-inner a:focus {
	cursor: pointer;
	text-decoration: none;
}
.claim-note {
	position: absolute;
	top: 13px;
	right: 10px;
}
.claim-note a {
	border: 1px solid #6c757d;
	color: #eaeaea;
	background: #313131;
	padding: 1rem 1rem 1rem .55rem;
	border-radius: 6px;
}
.claim-note a:hover {	
	background: #6c757d;
	color: #ffffff;
	cursor: pointer;
	text-decoration: none;
}
.claim-logo {
	height: 48px;
}

@media (max-width: 1199.98px) {
	h5.text-center {
		text-align: left;
	}
}
@media (max-width: 991.98px) {	
	.inquire-note {
		display: none;
	}
	.inq-btn {
		background: #333;
		padding: 6px 8px;
		border-radius: 6px;
	}
}
@media (max-width: 575.98px) {
	.email-glow input {
	    height: 50px;
	    width: auto;
	}
	.inq-btn {
		display: none;
	}
	.navbar-inner {   
	    padding: 3rem 1rem;
	}
}
</style>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', '<?=$info['account_ga'] ?>', '<?=$info['domain'] ?>');
  ga('send', 'pageview');

</script>
<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->

</head>
<body>
<? if($forsale=='1' || $forsaledefault = '1'){ ?>
<div class="row-fluid">
   <div class="navbar-inner">	
		<h5 class="text-center"> 
		<span class="inquire-note">We have interesting opportunities for work, sponsors and partnerships.</span> <a class="inq-btn" href="http://www.domaindirectory.com/servicepage/?domain=<?=$info['domain']?>" target="_blank">Inquire now!</a>
		<div class="claim-note">			
			<a href="<?=$domain_affiliate_link;?>" target="_blank">
			<img src="https://cdn.vnoc.com/logos/badge-contrib-3.png" class="claim-logo">
			&nbsp;Claim Your CTB Now!
			</a>
		</div>
		</h5>
	</div>
</div>
<? } ?>

	