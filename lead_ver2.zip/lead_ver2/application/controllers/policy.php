<?php

    class Policy extends Controller {
	
        function index()
        {
            $api = $this->loadModel('ApiModel');
            $helper = $this->loadHelper('Url_helper');
            $info = $api->getdomaininfo();

            $template = $this->loadView('bs4/policy');
            $template->set('metatitle', 'Privacy Policy');
            $template->set('info', $info);	
            $template->set('domain_affiliate_link',$api->getaffiliatelink());
            $template->set('content', $api->getcontent($info['domain'],'privacy'));
            $template->render();
        }
    
    }
?>
