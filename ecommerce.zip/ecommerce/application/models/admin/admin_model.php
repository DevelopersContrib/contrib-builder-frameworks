<?php
class Admin_model extends CI_Model {
 
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

 	public function admin_detail($id){
			$this->db->where('id', $id);
 	        $query = $this->db->get("admin");
			return $query->result();
	}
	
 	public function update($id, $data){ 
	$query = $this->db->query("UPDATE admin SET email = '" . $data['email'] . "', password = '" . $data['password'] . "', `name` = '" . $data['name'] . "' WHERE id = '" . (int)$id . "'");
	return $query;
	}
 
  }
