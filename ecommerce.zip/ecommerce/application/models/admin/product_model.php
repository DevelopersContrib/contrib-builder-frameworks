<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Product_model extends CI_Model {

  
 
function get_products($start=0,$limit=10){
        $query = $this->db->query('SELECT product.*, product_description.* 
			FROM product
			INNER JOIN product_description ON product.id=product_description.product_id 
			WHERE product_description.language_id = '.$this->session->userdata('lang').'
			ORDER BY product.id LIMIT '.$start.', '.$limit);
        return $query->result();
 
}

 public function Add($data){
 		$main_update = $this->db->query("INSERT INTO product SET category_id = '" . (int)$data['category_id'] . "',  image = '" . $data['image'] . "', stock = '" . $data['stock'] . "', price = '" . $data['price'] . "', rank = '" . $data['rank'] . "'");
		
		if($main_update){
			return true;
		}
	
		$product_id = $this->db->insert_id();
		
		$seourl = "product/".$product_id."/".$data['url'].".html";
		
		$this->db->query("UPDATE product SET url = '".$seourl."' WHERE id = '" . (int)$product_id . "'");
		
		foreach ($data['product_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO product_description SET product_id = '" . (int)$product_id . "', language_id = '" . (int)$language_id . "', name = '" . strip_tags($value['name']) . "', meta_tags = '" . strip_tags($value['meta_tags']) . "', meta_keys = '" . strip_tags($value['meta_keys']) . "', details = '" . $this->db->escape_str($value['details']) . "'");
		}
 }
 
 public function delete($data){
		$main_update = $this->db->query("DELETE FROM product WHERE id = '" . (int)$data . "'");
		$main_update = $this->db->query("DELETE FROM product_description WHERE product_id = '" . (int)$data . "'");
		
		if($main_update){
			return true;
		}
	
 }
   
 public function product_count() {
        return $this->db->count_all("product");
    }
 
  
 public function product($id){
			$this->db->where('id', $id);
 	        $query = $this->db->get("product");
			return $query->result();
	}
 
	 public function product_description($id) {
		
		$product_description_data = array();
		$query = $this->db->query("SELECT * FROM product_description WHERE product_id = '" . (int)$id . "'");
		foreach ($query->result() as $result) {
			$product_description_data[$result->language_id] = array(
				'name'    		=> $result->name,
				'details'     	=> $result->details,
				'meta_tags'		=> $result->meta_tags,
				'meta_keys'		=> $result->meta_keys,
			);
		}
		return $product_description_data;
	}
	
 public function update($product_id, $data){ // of Opencart
		
		$main_update = $this->db->query("UPDATE product SET category_id = '" . (int)$data['category_id'] . "', url = '".$data['url']."', image = '" . $data['image'] . "', stock = '" . $data['stock'] . "', price = '" . $data['price'] . "', rank = '" . (int)$data['rank'] . "' WHERE id = '" . (int)$product_id . "'");
 		
		if($main_update){
			return true;
		}
	
		$this->db->query("DELETE FROM product_description WHERE product_id = '" . (int)$product_id . "'");
			foreach ($data['product_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO `product_description` SET `product_id` = '" . (int)$product_id . "', language_id = '" . (int)$language_id . "', `name` = '" . $value['name'] . "', meta_tags = '" . $value['meta_tags'] . "', meta_keys = '" . $value['meta_keys'] . "', details = '" . $this->db->escape_str($value['details']) . "'");
		}
 
	}
	
	function get_options($id){
				$this->db->where('product_id', $id);
				$this->db->where('option_description.language_id', $this->session->userdata('lang'));
				$this->db->join('option', 'option.id = product_option.option_id');
				$this->db->join('option_description', 'option_description.option_id = product_option.option_id');
				$query = $this->db->get("product_option");
				return $query->result();
	}

	function get_values($option_id, $product_id){
				$this->db->select('option_value.*, product_option_value.*, product_option_value.id AS pr_value_id');
				$this->db->where('option_id', $option_id);
				$this->db->where('product_id', $product_id);
				$this->db->join('product_option_value', 'product_option_value.value_id = option_value.id');
				$this->db->where('language_id', $this->session->userdata('lang'));
				$query = $this->db->get("option_value");
				return $query->result();


	}
	
	 public function slugstring($string){
   	    $result = strtolower($string);
	    $result = preg_replace("/[^A-Za-z0-9\s-._\/]/", "", $result);
	    $result = trim(preg_replace("/[\s-]+/", " ", $result));
	    $result = trim(substr($result, 0, 30));
	    $result = preg_replace("/\s/", "-", $result);
   
    return $result;
   }
   
	
	public function addimport($data){
 		$main_update = $this->db->query("INSERT INTO product SET category_id = '" . (int)$data['category_id'] . "',  image = '" . $data['image'] . "', image_small = '" . $data['image_small'] . "',image_large = '" . $data['image_large'] . "',  stock = '" . $data['stock'] . "', price = '" . $data['price'] . "', rank = '0', asin = '" . $data['asin'] . "'");
		
		$link = $this->slugstring($data['title']);
	
		$product_id = $this->db->insert_id();
		
		$seourl = "product/".$product_id."/".$link.".html";
		
		$this->db->query("UPDATE product SET url = '".$seourl."' WHERE id = '" . (int)$product_id . "'");
		
		
			$this->db->query("INSERT INTO product_description SET product_id = '" . (int)$product_id . "', language_id = '2', name = '" . strip_tags($data['title']) . "', meta_tags = '" . strip_tags($data['title']) . "', meta_keys = '" . strip_tags($data['title']) . "', details = '" . $this->db->escape_str($data['details']) . "'");
		return true;
 }
 
    public function checkexist($field,$value,$field2=null,$value2=null){
     $returnValue = false;
     if ($field2 && $value2){
     	$query = $this->db->query("SELECT count(*) as count FROM product WHERE `$field` = '".$value."' AND  `$field2` = '".$value2."'");
     }else {
      $query = $this->db->query("SELECT count(*) as count FROM product WHERE `$field` = '".$value."' ");
     }  
      if ($query->num_rows() > 0){
        foreach ($query->result() as $row)
         {
           $count =  $row->count;
         }
     }
     if ($count > 0){
        $returnValue = true;   
     }
    return $returnValue;
	}
	
}


    

 
 