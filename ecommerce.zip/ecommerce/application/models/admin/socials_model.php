<?php
class Socials_model extends CI_Model {
 
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

 	public function socials_detail($id){
			$this->db->where('id', $id);
 	        $query = $this->db->get("settings");
			return $query->result();
	}
	function get_default_currency_id($id){
		$query = $this->db->query("SELECT * FROM settings WHERE id = '".$id."'");
		return $query->row('currency');
	}
	function get_default_language_id($id){
		$query = $this->db->query("SELECT * FROM settings WHERE id = '".$id."'");
		return $query->row('language');
	}
	function get_default_language_filename($id){
		$query = $this->db->query("SELECT * FROM settings WHERE id = '".$id."'");
		$default_lang_id = $query->row('language');
		
		$query_file = $this->db->query("SELECT file_name FROM language WHERE id = '".$default_lang_id."'");
		return $query_file->row('file_name');
	}
	
 	public function update($id, $data){ 
	$query = $this->db->query("UPDATE settings SET social_facebook = '" . $data['social_facebook'] . "', social_twitter = '" . $data['social_twitter'] . "', social_linkedin = '" . $data['social_linkedin'] . "', social_gplus = '" . $data['social_gplus'] . "' WHERE id = '" . (int)$id . "'");
	return $query;
	}
 
  }
