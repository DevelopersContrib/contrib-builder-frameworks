 
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');  
  
class Categories_model extends CI_Model {
  
   public $result;  
   public $result_footer;  
  
 function get_cats(){  
   $this->db->join('category_description','category_description.category_id = category.id');
   $this->db->join('product','product.category_id = category.id');
   $this->db->where('category_description.language_id', 2);
   $this->db->order_by("category_description.category_name", "asc"); 
   $this->db->group_by("category_description.category_name"); 
  $query = $this->db->get('category'); 
    
  if($query->num_rows() > 0){  
   $res = $query->result_array();  
  
   foreach($res as $row):  
    $items[$row['parent_id']][] = $row;  
   endforeach;  
     
   $this->categories_list($items);  
  
   return $this->result;  
  }  
   
 }  
   
 function categories_list($items, $parent = null) {  
 

  $index = $parent == null ? '0' : $parent;  
  if (isset($items[$index])) {  
  
   $this->result .= '<ul class="list-unstyled list-custom-sidebar">';   
  
   foreach ($items[$index] as $child) {  
  
    $this->result .= '<li><a href="'.base_url().''.$child['link'].'">'.$child['category_name'].'</a>';  
      
    $this->categories_list($items, $child['id']);  
      
    $this->result .= '</li>';  
     
   }  
  
   $this->result .= '</ul>';  
  }
 
 }
 
 
 function categories_list_footer($items, $parent = null) {  
 

  $index = $parent == null ? '0' : $parent;  
  if (isset($items[$index])) {  

  	
   foreach ($items[$index] as $child) {  
  
    $this->result_footer .= '<li><a href="'.base_url().''.$child['link'].'"  class="text-capitalize">'.$child['category_name'].'</a>';  
    $this->result_footer .= '</li>';  
     
   }  
  
     
  }
 
 }

 function get_cats_footer(){  
   $this->db->join('category_description','category_description.category_id = category.id');
   $this->db->join('product','product.category_id = category.id');
   $this->db->where('category_description.language_id', 2);
   $this->db->order_by("category_description.category_name", "asc"); 
   $this->db->group_by("category_description.category_name"); 
   $this->db->limit(5); 
   $query = $this->db->get('category'); 
    
  if($query->num_rows() > 0){  
   $res = $query->result_array();  
  
   foreach($res as $row):  
    $items[$row['parent_id']][] = $row;  
   endforeach;  
     
   $this->categories_list_footer($items);  
  
   return $this->result_footer;  
  }  
   
 }  
 
}  
