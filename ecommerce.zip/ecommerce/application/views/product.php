<? $this->load->view('header'); ?>
<script src="<?php echo base_url(); ?>js/plugins/imagezoom/jquery.imagezoom.js"></script>
<script>
	$(document).ready(function(){
		$('.zoom').zoom();
	});
</script>
<!-- Page Content -->
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<br />
		</div>
		<div class="col-md-3">
			<?php echo $categories?> 
		</div>
	<?php foreach ($product AS $products){ ?>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<ol class="breadcrumb">
						<li>
							<a href="<?php echo base_url()?>">
								<i class="fa fa-home"></i>
								Home
							</a>
						</li>
						<li class="active"><?php echo $products['name']; ?></li>
					</ol>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<form action="<?php echo $this->config->item('base_url'); ?>basket/add" method="post" accept-charset="utf-8" class="form-horizontal" role="form">
							<input type="hidden" name="id" value="<?php echo $products['id']; ?>" />
							<div class="row">
								<div class="col-md-4">
									<div class="wrap-item-prodct-img">
										<div data-zoom="large.jpg" class="zoom">
											<img class="img-responsive" src="<?php echo $products['image_large']; ?>" alt="<?php echo $products['name']; ?>">
										</div>
									</div>
								</div>
								<div class="col-md-8">
									<div class="wrap-item-content-solo">
										<h3 class="ttle">
											<?php echo $products['name']; ?>
										</h3>
										<div class="rating-star">
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star-empty"></span>
										</div>
										<div class="solo-price">
											<?php echo $currency_symbol; ?>
											<?php echo $this->cart->format_number(($products['price'] * $currency_currency)); ?> 
										</div>
										<div class="solo-desc">
											<?php echo $products['details']; ?>
										</div>
										<p>
											<button type="submit" class="btn btn-outline-primary btn-lg">
												<span class="glyphicon glyphicon-shopping-cart" ></span> Add Cart
											</button>
										</p>
										<div class="form-group">
											<?php if(@$options){ ?>
												<?php foreach($options AS $option){ ?>
													<?php if($option["option_type"] == "selectbox"){ ?>
														<div class="form-group">
															<div class="row">
																<label class="col-sm-2 col-sm-offset-7 control-label">
																	<p class="text-right"><?php echo $option["option_name"]; ?></p>
																</label>
																<div class="col-sm-3">
																	<select name="option_values[]" class="form-control">
																		<option value=""></option>
																		<?php foreach($option["values"] AS $value){ ?>
																		<option value="<?php echo $value->id; ?>">
																			<?php echo $value->value_name; ?>, <?php echo $value->operation; ?><?php echo $this->cart->format_number(($value->price * $currency_currency)); ?> <?php echo $currency_symbol; ?></option>
																		<?php } ?>
																	</select>
																	<hr>		
																</div>
															</div>
														</div>
													<?php } ?>
													<?php if($option["option_type"] == "checkbox"){ ?>
														<div class="form-group">
															<label class="col-sm-2 col-sm-offset-7 control-label"><p align="right"><?php echo $option["option_name"]; ?></p></label>
															<div class="col-sm-3">
																<div class="checkbox">
																	<?php foreach($option["values"] AS $value){ ?>
																	<label>
																		<input type="radio" name="option_values[]" value="<?php echo $value->id; ?>"> <?php echo $value->value_name; ?>,
																		<?php echo $value->operation; ?><?php echo $this->cart->format_number(($value->price * $currency_currency)); ?> <?php echo $currency_symbol; ?>
																	</label>
																	<?php } ?>
																</div>
																<hr>		
															</div>
														</div>
													<?php } ?>
													<?php if($option["option_type"] == "radio"){ ?>
														<div class="form-group">
															<label class="col-sm-2 col-sm-offset-7 control-label"><p align="right"><?php echo $option["option_name"]; ?></p></label>
															<div class="col-sm-3">
																<div class="checkbox">
																	<?php foreach($option["values"] AS $value){ ?>
																	<label>
																		<input type="radio" name="option_values[]" value="<?php echo $value->id; ?>"> <?php echo $value->value_name; ?>,
																		<?php echo $value->operation; ?><?php echo $this->cart->format_number(($value->price * $currency_currency)); ?> <?php echo $currency_symbol; ?>
																	</label>
																	<?php } ?>
																</div>
																<hr>		
															</div>
														</div>
													<?php } ?>
												<?php } // Option Foreach End ?>
											<?php } // If Option have END ?>
										</div>
									</div>
								</div>
							</div>
						<?php } ?>
					</form>
				</div>
			</div>
			<div class="col-md-12">
				<hr />
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="well">
						<div id="disqus_thread"></div>
						<script>
						
						/**
						*  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
						*  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
						/*
						var disqus_config = function () {
						this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
						this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
						};
						*/
						(function() { // DON'T EDIT BELOW THIS LINE
						var d = document, s = d.createElement('script');
						s.src = 'https://contrib-ecommerce.disqus.com/embed.js';
						s.setAttribute('data-timestamp', +new Date());
						(d.head || d.body).appendChild(s);
						})();
						</script>
						<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
                                
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /.container -->
<? $this->load->view('footer'); ?>
