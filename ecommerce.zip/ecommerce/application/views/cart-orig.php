<? $this->load->view('header'); ?>
	<script>
		$(document).ready(function() {
			function setHeight() {
				windowHeight = $(window).innerHeight();
				resultWinHeight = windowHeight - 421;
				//console.log(windowHeight);
				$('.content-body').css('min-height', resultWinHeight);
			};
			setHeight();

			$(window).resize(function() {
				setHeight();
			});
		});

		window.onload = function(){
	        (function(){
	            var counter = 5;
	            setInterval(function() {
	                counter--;
	                if (counter >= 0) {
	                	span = document.getElementById("count-loading");
	                	span.innerHTML = counter;
	                }
	                if (counter === 0) {
	                	$('.loading-backdrop-container').hide();
	                }
	            }, 1000);
	        })();
	    }
	</script>
	<div class="loading-backdrop-container">
	    <div class="loading-content">
	        <div class="loading-img-block">
	            <img src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/preloader/loading-32x32.gif" alt="">
	        </div>
	        Please wait... <span id="count-loading">5</span> secs...
	    </div>
	</div>
    <!-- Page Content -->
    <div class="container">
        <div class="row">
        	<div class="col-md-12">
        		<br />
        	</div>
            <div class="col-md-3">
            	<?php echo $categories?> 
            </div>
            <div class="col-md-9 content-body">
            	<div class="row">
            		<div class="col-md-12">
            			<ol class="breadcrumb">
            				<li>
            					<a href="/">
            						<i class="fa fa-home"></i>
            						Home
            					</a>
            				</li>
            				<li class="active">
            					Cart
            				</li>
            			</ol>
            		</div>
					<div class="col-md-12">
						<h4 class="fnt-600"><?php echo $this->lang->line('cart_title'); ?></h4>
					</div>
					<div class="col-md-12">
						<?php echo form_open('cart/checkout'); ?>
						<table class="table table-bordered table-striped table-hover">
							<tr>
								<th>
									&nbsp;
								</th>
								<th class="text-uppercase"><?php echo $this->lang->line('item_desc'); ?></th>
								<th class="text-uppercase"><?php echo $this->lang->line('qty'); ?></th>
								<th class="text-uppercase text-center" width="100"><?php echo $this->lang->line('item_price'); ?></th>
								<th class="text-uppercase text-center"><?php echo $this->lang->line('sub_total'); ?></th>
								<th class="text-uppercase text-center"><?php echo $this->lang->line('action'); ?></th>
							</tr>
							<?php foreach ($cart as $items){ ?>
								<input type="hidden" name="rowid[]" value="<?php echo $items['rowid']; ?>" />
								<input type="hidden" name="asin[]" value="<?php echo $items['asin']; ?>" />
								<tr>
									<td align="center">
										<img class="cart-img-item" src="<?php echo $items['image']['small']; ?>" alt="">
									</td>
									<td>
										<?php echo $items['name']; ?>
										<?php if($items['options']){ ?>
										<br>
										<?php foreach($items['options'] AS $option){ ?>

										<b>&not;</b> <small><?php echo $option->value_name; ?> (<?php echo $option->operation; ?> <?php echo $this->cart->format_number($option->price * $currency_currency); ?> <?php echo $currency_symbol; ?>)</small> 
										<?php } ?>

										<? } ?>
									</td> 
									<td>
										<input class="form-control" type="text" name="qty[]" value="<?php echo $items['qty']; ?>" maxlength="3" size="5" />
									</td>
									<td align="center">
										<?php echo $this->cart->format_number(($items['price'] * $currency_currency)); ?> <?php echo $currency_symbol; ?>
									</td>
									<td align="center">
										<?php echo $this->cart->format_number(($items['subtotal'] * $currency_currency)); ?> <?php echo $currency_symbol; ?>
									</td>
									<td align="center">
										<?php echo anchor('cart/remove/'.$items['rowid'], $this->lang->line('cart_delete')); ?>   
									</td>
								</tr>
							<?php } ?>
							<tr>
								<td colspan="3"></td>
								<td class="text-center"><strong><?php echo $this->lang->line('total'); ?> </strong></td>
								<td class="text-center"><?php echo $cart_total; ?> <?php echo $currency_symbol; ?></td>
							</tr>
						</table>
						<?php if($this->cart->total_items() > 0){ ?>
							<div class="form-group">
								<button type="submit" class="btn btn-primary">Proceed Checkout</button>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
 <? $this->load->view('footer'); ?>
