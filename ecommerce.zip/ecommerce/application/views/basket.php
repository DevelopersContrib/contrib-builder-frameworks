 <li>
	<a href="<?php echo base_url(); ?>cart" class="cust-a-navbar">
		<span class="shopping-cart-container-icon">
			<span class="item-selected-red">
				<?php echo $this->cart->total_items(); ?>
			</span>
			<i class="fa fa-shopping-cart fa-3x"></i>
		</span>
		<small> (Total: <?php echo $cart_total; ?> <?php echo $currency_symbol; ?>)</small>
	</a>
</li>
 
