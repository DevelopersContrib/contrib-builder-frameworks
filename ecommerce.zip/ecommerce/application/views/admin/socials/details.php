  <? $this->load->view('admin/header'); ?>
<div id="page-wrapper">

            <div class="container-fluid">
                        <h1 class="page-header">
                            Dashboard <small>// Edit Socials</small>
                        </h1>

		<form action="<?php echo $this->config->item('admin_url'); ?>socials/detail/<?php echo $id; ?>" method="post" accept-charset="utf-8" class="form-horizontal" role="form">				
 
 
    <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Facebook</label>
    <div class="col-sm-10">
      <input name="social_facebook" type="text" value="<?php echo $social_facebook; ?>"  class="form-control">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Twitter</label>
    <div class="col-sm-10">
      <input name="social_twitter" type="text" value="<?php echo $social_twitter; ?>" class="form-control" id="inputEmail3" >
    </div>
  </div>
    <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Linkedin</label>
    <div class="col-sm-10">
      <input name="social_linkedin" type="text" value="<?php echo $social_linkedin; ?>" class="form-control" id="inputEmail3" >
    </div>
  </div>
    <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Google Plus</label>
    <div class="col-sm-10">
      <input name="social_gplus" type="text" value="<?php echo $social_gplus; ?>" class="form-control" id="inputEmail3" >
    </div>
  </div>
   
 
 
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Update</button>
    </div>
  </div>
</form>

 
 
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->



  <? $this->load->view('admin/footer'); ?>