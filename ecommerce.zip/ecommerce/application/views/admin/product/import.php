  <? $this->load->view('admin/header'); ?>
<div id="page-wrapper">

            <div class="container-fluid">
                        <h1 class="page-header">
                            Dashboard <small>// Import Product</small>
                        </h1>
						
<form action="<?php echo $this->config->item('admin_url'); ?>product/import" method="post" accept-charset="utf-8" class="form-horizontal" role="form">		
   <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Search</label>
    <div class="col-sm-10">
      <input name="aws_keyword" type="text" class="form-control" id="inputEmail3" value="<?php echo $keyword?>">
    </div>
  </div>
  
  <div class="form-group">
      <label for="inputEmail3" class="col-sm-2 control-label">Category</label>
    <div class="col-sm-offset-2 col-sm-10">
		<select name="aws_category" class="form-control">
 			<?php foreach($categories as $category){ ?>
				<option value="<?php echo  $category->category_name;  ?>" <?php if ($category_name == $category->category_name) echo "selected"?>><?php echo $category->category_name; ?> </option>
			<? } ?>
		</select>
    </div>
  </div>
  
  <div class="form-group">
      <label for="inputEmail3" class="col-sm-2 control-label">Search Pages</label>
    <div class="col-sm-offset-2 col-sm-10">
		<select name="aws_pages" class="form-control">
 			<option value="1" <?php if ($pages == 1) echo "selected"?>> First page
			</option>
			<option value="2"  <?php if ($pages == 2) echo "selected"?>> First 2 pages
			</option>
			<option value="3"  <?php if ($pages == 3) echo "selected"?>> First 3 pages
			</option>
			<option value="4"  <?php if ($pages == 4) echo "selected"?>> First 4 pages
			</option>
			<option value="5"  <?php if ($pages == 5) echo "selected"?>> First 5 pages
			</option>
			<option value="6"  <?php if ($pages == 6) echo "selected"?>> First 6 pages
			</option>
			<option value="7"  <?php if ($pages == 7) echo "selected"?>> First 7 pages
			</option>
			  <option value="8"  <?php if ($pages == 8) echo "selected"?>> First 8 pages
			  </option>
			  <option value="9"  <?php if ($pages == 9) echo "selected"?>> First 9 pages
			  </option>
			  <option value="10"  <?php if ($pages == 10) echo "selected"?>> First 10 pages
			  </option>
		</select>
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Show Results</button>
    </div>
  </div>		
						
</form>
  
<?php if (count($products)>0):?>
<div style="float:left">
<b>Results found:</b><?php echo count($products)?>
</div>
<div style="float:right">
<button type="button" class="btn btn-primary" onclick="processImport();">Import</button>
</div>

   <table  class="table table-bordered" id="tbl-result">
      <thead>
        <tr>
          <th>Image</th>
		  <th>Name</th>
		  <th>Price</th>
          <th>Category</th>
		  <th>ASIN</th>
          <th><input type="checkbox" id="pcheckall" class="pcheckall"></th>
        </tr>
      </thead>
      <tbody>
      <?php $i=0;?>
 <?php foreach($products as $key=>$val): ?>
     
      	 <tr class="tr_<?php echo $i?>">
				 <td >
				    <a href="<?php echo $val['url'] ?>" target="_blank"><img id="td_image<?php echo $i?>" src="<?php echo $val['image'] ?>" width="75" height="75"></a>
				    <input type="hidden" name="td_image_small<?php echo $i?>" id="td_image_small<?php echo $i?>" value="<?php echo $val['image_small'] ?>">
				    <input type="hidden" name="td_image_large<?php echo $i?>" id="td_image_large<?php echo $i?>" value="<?php echo $val['image_large'] ?>">
				    
				 </td>
				 <td id="td_title<?php echo $i?>"><?php echo $val['title'] ?></td>
				 <td id="td_price<?php echo $i?>"><?php echo $val['price'] ?></td>
				 <td id="td_category<?php echo $i?>"><?php echo $val['category'] ?></td>
				 <td id="td_asin<?php echo $i?>"><?php echo $val['asin'] ?></td>
				 <td>
				 <?php 	if ($this->product_model->checkexist('asin',$val['asin'])===false):?>
				   <input type="checkbox" id="pcheck" name="pcheck" value="<?php echo $i?>">
				   <?php else:?>
				   product exists
				 <?php endif?>  
				 
				 </td>
				
			 </tr>
		<?php $i++;?>		 
 <?php endforeach;?>
      </tbody>
    </table>
<?php endif?>
 
 <div class="modal modal-static fade" id="processing-modal" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="text-center" id="processing_content" style="display:none">
                    <img src="http://www.travislayne.com/images/loading.gif" class="icon" />
                    <h4>Importing... <button type="button" class="close" style="float: none;" data-dismiss="modal" aria-hidden="true">�</button></h4>
                </div>
                  <div class="text-center" id="message_content" style="display:none">
                  </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
function processImport(){
	$('#message_content').html('');
	$('#message_content').hide();
	$('#processing_content').hide();
	
	var cnt = 0;
	var i = 0;
	var entries = [];
	
	 $('#tbl-result tbody tr').each(function() {
			
		    $(this).find('input:checkbox:checked').each(function() {
		      	          i = i+1;
		      	          cnt = jQuery(this).val();
		      	        
		     	          entries.push({
						    image : $("#td_image"+cnt).attr('src'), 
						    title : jQuery("#td_title"+cnt).html(),
						    price : jQuery("#td_price"+cnt).html(),
						    category : jQuery("#td_category"+cnt).html(),
						    asin : jQuery("#td_asin"+cnt).html(),
						    image_small:jQuery("#td_image_small"+cnt).val(),
						    image_large:jQuery("#td_image_large"+cnt).val()
						});
		    	    
		    });
		    
		});

		if (i==0){
			$('#message_content').html('<div class="alert alert-danger">Please select products to import</div>');
			$('#message_content').show();
			$("#processing-modal").modal('show');  
		}else {
            $('#processing_content').show();
			$("#processing-modal").modal('show');  
			jQuery.post("/admin/product/saveimport",
	    			{ 
				     entries:entries
	    			},
	    			function(data){
	    				if (data.success){
	    					$('#processing_content').hide();
	    					$('#message_content').html('<div class="alert alert-success">You successfully imported '+data.count+' products</div>');
	    					$('#message_content').show();
	    				}
	    			}   
	    	 );
		}

     		
}
$('#pcheckall').change(function () {
    $('tbody tr td input[type="checkbox"]').prop('checked', $(this).prop('checked'));
});
</script>
 
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

 

  <? $this->load->view('admin/footer'); ?>