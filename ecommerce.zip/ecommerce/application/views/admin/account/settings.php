  <? $this->load->view('admin/header'); ?>
<div id="page-wrapper">

            <div class="container-fluid">
                        <h1 class="page-header">
                            Dashboard <small>// Account Settings</small>
                        </h1>

		<form action="<?php echo $this->config->item('admin_url'); ?>account/settings/<?php echo $id; ?>" method="post" accept-charset="utf-8" class="form-horizontal" role="form">				
 
 
    <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input name="name" type="text" value="<?php echo $name; ?>"  class="form-control">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input name="email" type="text" value="<?php echo $email; ?>" class="form-control" id="inputEmail3" >
    </div>
  </div>
    <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input name="password" type="password" value="<?php echo $password; ?>" class="form-control" id="inputEmail3" >
    </div>
  </div>
     <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Update Password</label>
    <div class="col-sm-10">
      <input name="confirm_password" type="password" value="<?php echo $password; ?>" class="form-control" id="inputEmail3" >
    </div>
  </div>
   
 
 
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Update</button>
    </div>
  </div>
</form>

 
 
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->



  <? $this->load->view('admin/footer'); ?>