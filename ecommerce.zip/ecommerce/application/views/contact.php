<?php $this->load->view('header'); ?>
<style>
	body{
		background-color: #e5e5e5;
	}
</style>
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2 text-center">
				<br />
				<img src="<?php echo $this->config->item('logo'); ?>" class="img-responsive logo-partners">
				<br />
			
				<h1>
					Join our exclusive community of like minded people on <?php echo ucfirst($this->config->item('domain')); ?>.
				</h1>
				<div class="arrw-rela"><div class="arrw-point-white"></div></div>
				<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?php echo ucfirst($this->config->item('domain')); ?>"></script>
				<br />
			</div>
		</div>
	</div>
<?php $this->load->view('footer'); ?>