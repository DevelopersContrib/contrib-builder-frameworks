        <div class="footer-dark-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3">
                                <h3 class="fnt-bold text-uppercase">
                                   <?php echo ucfirst($this->config->item('domain')); ?>
                                </h3>
                                <p>
                                    <?php echo ucfirst($this->config->item('description')); ?>
                                </p>
                            </div>
                            <div class="col-md-3">
                                <h3 class="fnt-bold text-uppercase">
                                    Shop <?php echo ucfirst($this->config->item('domain')); ?>
                                </h3>
                                <ul class="list-unstyled f-a-links">
                                    <li>
                                        <a href="/" class="text-capitalize">
                                            home
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/" class="text-capitalize">
                                            shop
                                        </a>
                                    </li>
                                    
                                    <?php echo $this->categories_model->get_cats_footer()?>
                                </ul>
                            </div>
                            <div class="col-md-3">
                                <h3 class="fnt-bold text-uppercase">
                                    Get started
                                </h3>
                                <ul class="list-unstyled f-a-links f-a-links-mrgBtm">
                                    <li>
                                        <a href="/home/partners" class="text-capitalize">
                                            Partner With Us
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/home/staffing" class="text-capitalize">
                                            Apply Now
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/home/referral" class="text-capitalize">
                                            Referral
                                        </a>
                                    </li>
                                   
                                    <li>
                                        <a href="http://developers.contrib.com/" class="text-capitalize" target="_blank">
                                           Developers
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/home/contact" class="text-capitalize">
                                            Contact Us
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-3">
                                <h3 class="fnt-bold text-uppercase">
                                    partners
                                </h3>
                                <p>
                                    <a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
                                </p>
                                <h3 class="fnt-bold text-uppercase">
                                    Socials
                                </h3>
                                <ul class="list-inline socials-ul">
                                    <li>
                                        <a title="facebook" class="icon-button facebook" href="<?php echo $this->config->item('social_facebook'); ?>">
                                            <i class="fa fa-facebook"></i>
                                            <span></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a title="twitter" class="icon-button twitter" href="<?php echo $this->config->item('social_twitter'); ?>">
                                            <i class="fa fa-twitter"></i>
                                            <span></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a title="linkedin" class="icon-button linkedin" href="<?php echo $this->config->item('social_linkedin'); ?>">
                                            <i class="fa fa-linkedin-square"></i>
                                            <span></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a title="google-plus" class="icon-button google-plus" href="<?php echo $this->config->item('social_gplus'); ?>">
                                            <i class="fa fa-google-plus"></i>
                                            <span></span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-dark-2">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6 f-a-links">
                                &copy; 2017 <a href="" class="text-capitalize ">contrib.com</a>. All Rights Reserved. Powered by <b><a href="http://vnoc.com" target="_blank">VNOC</a></b>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-inline text-right f-a-links">
                                    <li>
                                        <a href="/home/about" class="text-capitalize">
                                            <i class="fa fa-bookmark-o"></i>
                                            About us
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/home/terms" class="text-capitalize">
                                            <i class="fa fa-book"></i>
                                            Terms
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/home/privacy" class="text-capitalize">
                                            <i class="fa fa-cube"></i>
                                            privacy
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/home/contact" class="text-capitalize">
                                            <i class="fa fa-phone-square"></i>
                                            contact us
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- jQuery Version 1.11.0 
        <script src="<?php echo base_url(); ?>js/jquery-1.11.0.js"></script> -->

        <!-- Bootstrap Core JavaScript 
        <script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>  -->
        <script src="<?php echo base_url(); ?>js/form.js"></script>

        <!-- SmartMenus jQuery plugin -->
        <script src="<?php echo base_url(); ?>js/jquery.smartmenus.js"></script>
        <script src="<?php echo base_url(); ?>js/jquery.smartmenus.bootstrap.js"></script>
        <!-- SmartMenus jQuery plugin -->

        <script>
            $('#main-menu').smartmenus({
                mainMenuSubOffsetX: 1,
                mainMenuSubOffsetY: -8,
                subMenusSubOffsetX: 1,
                subMenusSubOffsetY: -8
            });
        </script>
        <script>
            (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
              (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
              m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-57038033-1', 'auto');
            ga('send', 'pageview');
        </script>
    </body>

</html>


