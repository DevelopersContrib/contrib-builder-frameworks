<?php $this->load->view('header'); ?>
<style>
	body{
		background-color: #e5e5e5;
	}
</style>
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2 text-center">
				<br />
				<img src="<?php echo $this->config->item('logo'); ?>" class="img-responsive logo-partners">
				<br />
			
				<h1>
					Join our exclusive community of like minded people on <?php echo ucfirst($this->config->item('domain')); ?>.
				</h1>
				<div class="arrw-rela"><div class="arrw-point-white"></div></div>
				<div class="box-blck">
					<h2 class="ttle text-capitalize">
						About <?php echo ucfirst($this->config->item('domain')); ?>
					</h2>
					<p>Global Ventures, LLC, established in 1996, invests in young innovators, entrepreneurs and professionals with a desire to solving big problems and help world. We combine our resources with a series of intense challenges, real-world skills development, amazing and flexible opportunities and a shared ownership and experience with the most talented young founders and professionals around the world.</p>
					<p><span class="text-capitalize"><?php echo ucfirst($this->config->item('domain')); ?></span> is a proud venture of Global Ventures, LLC.</p>
					<p>Global Ventures, LLC, established in 1996, invests in young innovators, entrepreneurs and professionals with a desire to solving big problems and help world. We combine our resources with a series of intense challenges, real-world skills development, amazing and flexible opportunities and a shared ownership and experience with the most talented young founders and professionals around the world.</p>
					<p>Join our network of performance based companies using <?php echo ucfirst($this->config->item('domain')); ?></p>
				</div>
			</div>
		</div>
	</div>
<?php $this->load->view('footer'); ?>