<?php $this->load->view('header'); ?>
<style>
	body{
		background-color: #e5e5e5;
	}
</style>
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2 text-center">
				<br />
				<img src="<?php echo $this->config->item('logo'); ?>" class="img-responsive logo-partners">
				<br />
			
				<h1>
					Join our exclusive community of like minded people on <?php echo ucfirst($this->config->item('domain')); ?>.
				</h1>
				<div class="arrw-rela"><div class="arrw-point-white"></div></div>
				<div class="box-blck">
					<h2 class="ttle text-capitalize"> Our Staffing Needs at <?php echo ucfirst($this->config->item('domain')); ?> </h2>
					<p>
						We are looking for the best of the best, Full-Time, Part-Time, Moonlighting, Contractual and Freelance.
					</p>
					<p>
						We consult and manage over 100,000 domain name ventures and are always seeking Strategic Partnerships, Applications, Domains, Engineers, Developers, Specialist and just cool smart people around the Globe. Learn more about openings and opportunities with our partner companies and send us your resume or examples to accelerate the process.
					</p>
					<p>Learn more about <a href="/contact.php">openings and opportunities</a> with our partner companies.</p>
					<br />
					<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?php echo ucfirst($this->config->item('domain')); ?>&amp;f=staffing"></script>
				</div>
			</div>
		</div>
	</div>
<?php $this->load->view('footer'); ?>