 <? $this->load->view('header'); ?>
    <!-- Page Content -->
    <div class="container">
	
        <div class="row">

            <div class="col-md-12">
			<h4>Order Completed</h4>
			<p>Order ID <?php echo $order_id; ?></p>

            </div>

        </div>

    </div>
    <!-- /.container -->
 <? $this->load->view('footer'); ?>
   