<?php $this->load->view('header'); ?>
<style>
	body{
		background-color: #e5e5e5;
	}
</style>
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2 text-center">
				<br />
				<img src="<?php echo $this->config->item('logo'); ?>" class="img-responsive logo-partners">
				<br />
			
				<h1>
					Join our exclusive community of like minded people on <?php echo ucfirst($this->config->item('domain')); ?>.
				</h1>
				<div class="arrw-rela"><div class="arrw-point-white"></div></div>
				<iframe seamless="" scrolling="auto" src="http://referrals.contrib.com/aff_index.php?affiliate=<?php echo ucfirst($this->config->item('domain')); ?>" width="748px" height="800px" frameborder="0"></iframe>
				<br />
			</div>
		</div>
	</div>
<?php $this->load->view('footer'); ?>