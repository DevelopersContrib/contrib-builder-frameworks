 <? $this->load->view('header'); ?>
 <script>
    $(document).ready(function(){
        jQuery('#carousel-1').carousel({
            interval: 100000000
        });
    });
</script>
<!-- Page Content -->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div id="carousel-1" class="carousel slide carousel-cust" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#carousel-1" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-1" data-slide-to="1"></li>
                    <li data-target="#carousel-1" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner carousel-inner-cust" role="listbox">
                 <?php $i=0;?>
                 <?php foreach ($slider_products AS $slider_product): ?>
                      <div class="item <?php if ($i==0) echo 'active'?>" style="background-image: url('<?php echo $slider_product['image_url']?>" alt="Shop Handyman');">
                        <div class="carousel-caption first-item">
                           <?php echo $slider_product['image_desc']?>
                        </div>
                    </div>
                    <?php $i++;?>
                 <?php endforeach;?>
                
                </div>

                <!-- Controls -->
                <a class="left carousel-control" href="#carousel-1" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#carousel-1" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <br />
        </div>
        <div class="col-md-3">
            <div class="row">
                <div class="col-sm-12">
                    <?php echo $categories?> 
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h3 class="ttle-brdr text-uppercase no-mg-top">
                        <span>
                            <?php echo $this->lang->line('best_sell'); ?>
                        </span>
                    </h3>
                </div>
                <?php foreach ($most_sell_products AS $most_sell_product){ ?>
                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail thumbnail-cust-product">
                            <div class="ratings">
                                <p class="star-rating">
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                </p>
                            </div>
                            <a href="<?php echo base_url(); ?><?php echo $most_sell_product['url']; ?>">
                                <img src="<?php echo $most_sell_product['image']; ?>" alt="">
                            </a>
                            <div class="caption caption-cust">
                                <h4>
                                    <a href="<?php echo base_url(); ?><?php echo $most_sell_product['url']; ?>" class="ttle-link-a" title="<?php echo $most_sell_product['name'];?>">
                                        <?php echo strip_tags(substr($most_sell_product['name'], 0, 20))."..."; ?>
                                    </a> 
                                </h4>
                                <h4 class="pull-right num-right"><?php echo $most_sell_product['price']; ?> <?php echo $currency_symbol; ?></h4>
                                <p class="desc-text"><?php echo strip_tags(substr($most_sell_product['details'], 0, 45))."[...]"; ?></p>
                                <div class="form-group">
                                    <form action="<?php echo $this->config->item('base_url'); ?>basket/add" method="post" accept-charset="utf-8" class="form-horizontal" role="form">				
                                        <input type="hidden" name="id" value="<?php echo $most_sell_product['product_id']; ?>" />
                                        <button type="submit" class="btn btn-outline-primary"><span class="glyphicon glyphicon-shopping-cart" ></span><?php echo $this->lang->line('add_basket'); ?></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <h3 class="ttle-brdr text-uppercase">
                        <span>
                            <?php echo $this->lang->line('most_popular'); ?>
                        </span>
                    </h3>
                </div>
                <?php foreach ($most_popular_products AS $most_popular_product){ ?>
                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail thumbnail-cust-product">
                            <div class="ratings">
                                <p class="star-rating">
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                </p>
                            </div>
                            <a href="<?php echo base_url(); ?><?php echo $most_popular_product['url']; ?>">
                                <img src="<?php echo $most_popular_product['image']; ?>" alt="">
                            </a>
                            <div class="caption caption-cust">
                                <h4>
                                    <a href="<?php echo base_url(); ?><?php echo $most_popular_product['url']; ?>" class="ttle-link-a"  title="<?php echo $most_popular_product['name'];?>">
                                        <?php echo strip_tags(substr($most_popular_product['name'], 0, 20))."..."; ?>
                                    </a> 
                                </h4>
                                <h4 class="pull-right num-right"><?php echo $most_popular_product['price']; ?> <?php echo $currency_symbol; ?></h4>
                                <p class="desc-text"><?php echo strip_tags(substr($most_popular_product['details'], 0, 45))."[...]"; ?></p>
                                <div class="form-group">
                                    <form action="<?php echo $this->config->item('base_url'); ?>basket/add" method="post" class="form-horizontal" role="form">				
                                        <input type="hidden" name="id" value="<?php echo $most_popular_product['product_id']; ?>" />
                                        <button type="submit" class="btn btn-outline-primary"><span class="glyphicon glyphicon-shopping-cart" ></span><?php echo $this->lang->line('add_basket'); ?></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <h3 class="ttle-brdr text-uppercase">
                        <span>
                            Latest Products
                        </span>
                    </h3>
                </div>
                <?php foreach ($latest_products AS $latest_product){ ?>
                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail thumbnail-cust-product">
                            <div class="ratings">
                                <p class="star-rating">
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                </p>
                            </div>
                            <a href="<?php echo base_url(); ?><?php echo $latest_product['url']; ?>">
                                <img src="<?php echo $latest_product['image']; ?>" alt="">
                            </a>
                            <div class="caption caption-cust">
                                <h4>
                                    <a href="<?php echo base_url(); ?><?php echo $latest_product['url']; ?>" class="ttle-link-a" title="<?php echo $latest_product['name'];?>">
                                        <?php echo strip_tags(substr($latest_product['name'], 0, 20))."..."; ?>
                                    </a> 
                                </h4>
                                <h4 class="pull-right num-right"><?php echo $latest_product['price']; ?> <?php echo $currency_symbol; ?></h4>
                                <p class="desc-text"><?php echo strip_tags(substr($latest_product['details'], 0, 45)); ?></p>
                                <div class="form-group">
                                    <form action="<?php echo $this->config->item('base_url'); ?>basket/add" method="post" accept-charset="utf-8" class="form-horizontal" role="form">				
                                        <input type="hidden" name="id" value="<?php echo $latest_product['product_id']; ?>" />
                                        <button type="submit" class="btn btn-outline-primary"><span class="glyphicon glyphicon-shopping-cart" ></span><?php echo $this->lang->line('add_basket'); ?></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<!-- /.container -->

<? $this->load->view('footer'); ?>

