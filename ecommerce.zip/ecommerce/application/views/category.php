 <? $this->load->view('header'); ?>
 <script>
    $(document).ready(function() {
        function setHeight() {
            windowHeight = $(window).innerHeight();
            resultWinHeight = windowHeight - 421;
            //console.log(windowHeight);
            $('.content-body').css('min-height', resultWinHeight);
        };
        setHeight();

        $(window).resize(function() {
            setHeight();
        });
    });
</script>
    <!-- Page Content -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <br>
            </div>
            <div class="col-md-3">
                <?php echo $categories?> 
            </div>
            <div class="col-md-9 content-body">
                <div class="row">
    				<div class="col-md-12">
    					<ol class="breadcrumb">
    						<li>
    							<a href="<?php echo base_url()?>">
    								<i class="fa fa-home"></i>
    								Home
    							</a>
    						</li>
    						<li class="active"><?php echo $category_name?></li>
    					</ol>
    				</div>
                    <div class="col-md-12">
                        <h4>Category Products</h4>
                        <div class="row">
        				    <?php if($category_products){ ?>
                            <?php foreach ($category_products AS $category_product){ ?>
                                <div class="col-sm-4 col-lg-4 col-md-4">
                                    <div class="thumbnail thumbnail-cust-product">
                                        <div class="ratings">
                                            <p class="star-rating">
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star-empty"></span>
                                            </p>
                                        </div>
                                        <a href="<?php echo base_url(); ?><?php echo $category_product['url']; ?>">
                                            <img src="<?php echo $category_product['image']; ?>" alt="">
                                        </a>
                                        <div class="caption caption-cust">
                                            <h4>
                                                <a href="<?php echo base_url(); ?><?php echo $category_product['url']; ?>">
                                                    <?php echo strip_tags(substr($category_product['name'], 0, 20))."..."; ?>
                                                </a>
                                            </h4>
                                            <h4 class="pull-right num-right"><?php echo $category_product['price']; ?> $</h4>
                                            <p class="desc-text">
                                                <?php echo strip_tags(substr($category_product['details'], 0, 45))."[...]"; ?>
                                            </p>
                                            <div class="form-group">
                                                <form action="<?php echo $this->config->item('base_url'); ?>basket/add" method="post" accept-charset="utf-8" class="form-horizontal" role="form">               
                                                    <input type="hidden" name="id" value="<?php echo $category_product['id']; ?>" />
                                                    <button type="submit" class="btn btn-outline-primary"><span class="glyphicon glyphicon-shopping-cart" ></span><?php echo $this->lang->line('add_basket'); ?></button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
            				<? } 		// if category_products is TRUE END
            				else{		// ELSE empty message SHOW
            				?>
        				        Category is empty!
                            <?php }?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container -->
 <? $this->load->view('footer'); ?>
   