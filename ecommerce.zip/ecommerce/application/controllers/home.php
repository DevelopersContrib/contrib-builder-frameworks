<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends KoController  {

 
	 	function __construct()
    {
         parent::__construct();

    }
	public function index(){
 		//Most sell products array construct.
		foreach($this->products_model->most_sell_products() AS $most_sell){
				$most_sell_products[] = array(
                   'id'  			=> $most_sell->id,
				   'name'			=> $most_sell->name,
				   'details'		=> $most_sell->details,
				   'type'			=> $most_sell->type,
				   'product_id'		=> $most_sell->product_id,
				   'rank'			=> $most_sell->rank,
				   'category_id'	=> $most_sell->category_id,
				   'price'			=> ''.$this->cart->format_number($most_sell->price * $this->data['currency_currency']),
				   'stock'			=> $most_sell->stock,
				   'image'			=> $most_sell->image,
				   'url'			=> $most_sell->url,
				   'description_id'	=> $most_sell->description_id,
				   'language_id'	=> $most_sell->language_id,
				   'meta_tags'		=> $most_sell->meta_tags,
				   'meta_keys'		=> $most_sell->meta_keys
               );  
			}
		$this->data['most_sell_products'] = $most_sell_products;	
		
			//Most popular products array construct.
			foreach($this->products_model->most_popular_products() AS $most_popular_products){
				$most_popular[] = array(
                   'id'  			=> $most_popular_products->id,
				   'name'			=> $most_popular_products->name,
				   'details'		=> $most_popular_products->details,
				   'type'			=> $most_popular_products->type,
				   'product_id'		=> $most_popular_products->product_id,
				   'rank'			=> $most_popular_products->rank,
				   'category_id'	=> $most_popular_products->category_id,
				   'price'			=> ''.$this->cart->format_number($most_sell->price * $this->data['currency_currency']),
				   'stock'			=> $most_popular_products->stock,
				   'image'			=> $most_popular_products->image,
				   'url'			=> $most_popular_products->url,
				   'description_id'	=> $most_popular_products->description_id,
				   'language_id'	=> $most_popular_products->language_id,
				   'meta_tags'		=> $most_popular_products->meta_tags,
				   'meta_keys'		=> $most_popular_products->meta_keys
               );  
			}
			
			$this->data['most_popular_products'] = $most_popular;
  		
			//Slider products array construct.
			foreach($this->products_model->slider_products() AS $slider_products){
				$slider_product[] = array(
                   'mod_id'  			=> $slider_products->id,
				   'image_url'			=> $slider_products->image_url,
				   'image_desc'			=> stripcslashes($slider_products->details)
               );  
			}
			
		$this->data['slider_products'] = $slider_product;
		//Latest products array construct.
			foreach($this->products_model->latest_products() AS $latest_products){
				$latest[] = array(
                   'id'  			=> $latest_products->id,
				   'name'			=> $latest_products->name,
				   'details'		=> $latest_products->details,
				   'product_id'		=> $latest_products->product_id,
				   'rank'			=> $latest_products->rank,
				   'category_id'	=> $latest_products->category_id,
				   'price'			=> ''.$this->cart->format_number($latest_products->price * $this->data['currency_currency']),
				   'stock'			=> $latest_products->stock,
				   'image'			=>$latest_products->image,
				   'url'			=> $latest_products->url,
				   'description_id'	=> $latest_products->description_id,
				   'language_id'	=> $latest_products->language_id,
				   'meta_tags'		=> $latest_products->meta_tags,
				   'meta_keys'		=> $latest_products->meta_keys
               );  
			}
			
			$this->data['latest_products'] = $latest;
		
		//Categories array
		$this->data['categories'] = $this->categories_model->get_cats();
 		$this->load->view('home', $this->data);
	}

	public function partners(){
		$this->load->view('partners',$this->data);
	}

	public function staffing(){
		$this->load->view('staffing',$this->data);
	}

	public function referral(){
		$this->load->view('referral',$this->data);
	}

	public function contact(){
		$this->load->view('contact',$this->data);
	}

	public function about(){
		$this->load->view('about',$this->data);
	}

	public function terms(){
		$this->load->view('terms',$this->data);
	}

	public function privacy(){
		$this->load->view('privacy',$this->data);
	}
}

 