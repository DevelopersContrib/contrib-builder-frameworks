<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product extends CI_Controller {

 
		function __construct()
		{
			parent::__construct();
      ini_set('memory_limit', '-1');
			if(! $this->session->userdata('validated')){
            redirect('admin/account/login');
        }
		
		}
 
 
	public function index(){
 
	}
	
	public function lists(){
		$this->load->model('admin/product_model');
		$this->load->library("pagination");
 
		$config = array();
        /*$config["base_url"] = base_url() . "admin/product/lists";
        $config["total_rows"] = $this->product_model->product_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 4;*/
        
        
        
        $config['base_url'] = base_url() . "admin/product/lists";
        $config['total_rows'] = $this->product_model->product_count();
        $config['per_page'] = 10;
        $config['use_page_numbers'] = TRUE;

       $this->pagination->initialize($config);
 
        //$this->pagination->initialize($config);
 
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        $data["links"] = $this->pagination->create_links();
        $limit =  $config["per_page"];
		
		if($page) 
		 $start = ($page - 1) * $limit; 			//first item to display on this page
	    else
		 $start = 0;
		
		$data["products"] = $this->product_model->get_products($start, $limit);
 
 
		$this->load->view('admin/product/list', $data);
   }
   
 
   public function detail(){
   	$this->load->model('admin/product_model');
	$this->load->model('admin/category_model');
 	$this->load->model('admin/language_model');
	
 	$data["languages"] = $this->language_model->languages();
		$product_infos = $this->product_model->product($this->uri->segment(4));
 
	foreach($product_infos as $product_info){
			$data["id"] = $product_info->id;
			$data["category_id"] = $product_info->category_id;
			$data["category_name"] = $this->category_model->get_category($product_info->category_id);
			$data["url"] = $product_info->url;
			$data["rank"] = $product_info->rank;
			$data["price"] = $product_info->price;
			$data["stock"] = $product_info->stock;
			$data["image"] = $product_info->image;
			$data["product_description"] = $this->product_model->product_description($product_info->id);
		}
 
			$start = 0;
			$limit = 100000000;
 			$data["categories"] = $this->category_model->get_categories($start, $limit);

   		$this->load->view('admin/product/detail', $data);

   }
   public function Add(){
	$this->load->model('admin/category_model');
	$this->load->model('admin/product_model');
	$this->load->model('admin/language_model');

	
       	if($_POST){
			$add = false;
			$add = $this->product_model->add($_POST);
			if($add){
				$this->session->set_flashdata('action_message', 'New product added!');
				$this->session->set_flashdata('action_message_type', 'success');
				redirect($_SERVER['HTTP_REFERER']);
			}else{
				$this->session->set_flashdata('action_message', 'New product not added!. An error has occured.');
				$this->session->set_flashdata('action_message_type', 'danger');
				redirect($_SERVER['HTTP_REFERER']);
			}
	}
	
 
	
	
	$data["languages"] = $this->language_model->languages();
			$start = 0;
			$limit = 100000000;
 			$data["categories"] = $this->category_model->get_categories($start, $limit);
			
	$this->load->view('admin/product/add', $data);
		 
   }
   
   public function update(){
   	$this->load->model('admin/product_model');

        	if($_POST){
			$update = false;
			$update = $this->product_model->update($this->uri->segment(4), $_POST);
			if($update){
				$this->session->set_flashdata('action_message', 'Product updated!');
				$this->session->set_flashdata('action_message_type', 'success');
				redirect($_SERVER['HTTP_REFERER']);
			}else{
				$this->session->set_flashdata('action_message', 'Product not updated!. An error has occured.');
				$this->session->set_flashdata('action_message_type', 'danger');
				redirect($_SERVER['HTTP_REFERER']);
			}
	}
		
	 
   
   }
   
   public function delete(){
	$this->load->model('admin/product_model');
 
 
 
			$delete = false;
			$delete = $this->product_model->delete($this->uri->segment(4));
			if($delete){
				$this->session->set_flashdata('action_message', 'Product deleted!');
				$this->session->set_flashdata('action_message_type', 'success');
				redirect($_SERVER['HTTP_REFERER']);
			}else{
				$this->session->set_flashdata('action_message', 'Product not deleted!. An error has occured.');
				$this->session->set_flashdata('action_message_type', 'danger');
				redirect($_SERVER['HTTP_REFERER']);
			}
 
   }
   
	public function import(){
		$this->load->model('admin/category_model');
		$this->load->model('admin/product_model');
		$this->load->model('admin/language_model');
		$data['submit'] = false;
		//$category = array('All','Wine','Wireless','ArtsAndCrafts','Miscellaneous','Electronics','Jewelry','MobileApps','Photo','Shoes','KindleStore','Automotive','Vehicles','Pantry','MusicalInstruments','DigitalMusic','GiftCards','FashionBaby','FashionGirls','GourmetFood','HomeGarden','MusicTracks','UnboxVideo','FashionWomen','VideoGames','FashionMen','Kitchen','Video','Software','Beauty','Grocery','FashionBoys','Industrial','PetSupplies','OfficeProducts','Magazines','Watches','Luggage','OutdoorLiving','Toys','SportingGoods','PCHardware','Movies','Books','Collectibles','Handmade','VHS','MP3Downloads','Fashion','Tools','Baby','Apparel','Marketplace','DVD','Appliances','Music','LawnAndGarden','WirelessAccessories','Blended','HealthPersonalCare','Classical');
		$products = array();
		
		$keyword = "";
	   	$u_category = "";
	   	$pages = 1;
		
	   if($_POST){
	   	    $this->load->library('amazon_api'); 
	   	    $data['submit'] = true;
	   	    
	   	    $keyword = trim($_POST['aws_keyword']);
	   	    $u_category = trim($_POST['aws_category']);
	   	    $category = str_replace(' ','',$u_category);
			$pages = intval(trim($_POST['aws_pages']));
			
			for ($i=1;$i<=$pages;$i++){
		   	    
				$pres = $this->amazon_api->getItemByKeyword($keyword, $category,$i);
				$pres = json_decode(json_encode($pres),true); 
			    if (isset($pres['Items']['Item'])){
					$pres = $pres['Items']['Item']; 
				    foreach($pres as $key=>$val){ 
						
						$ires = $this->amazon_api->getItemImages($val['ASIN']);
						$price = $this->amazon_api->getItemPrice($val['ASIN']);
						
						if (($ires['medium']!="") && ($price != "")){
							$products[] = array('image'=>$ires['medium'],'title'=>$val['ItemAttributes']['Title'],'category'=> $val['ItemAttributes']['ProductGroup'],'asin'=>$val['ASIN'],'price'=>$price,'url'=>$val['DetailPageURL'],'image_small'=>$ires['small'],'image_large'=>$ires['large'] );
						}
					}
			    }
			}
			
			
	   }
	
		$start = 0;
		$limit = 100000000;
	 	$data["categories"] = $this->category_model->get_categories($start, $limit);
	 	$data['products'] = $products;
	 	$data['keyword'] = $keyword;
	 	$data['category_name'] = $u_category;
	 	$data['pages'] = $pages;
	 	
	   	$this->load->view('admin/product/import', $data);
	   
	}
	
	public function saveimport(){
		$this->load->model('admin/category_model');
		$this->load->model('admin/product_model');
		$this->load->library('amazon_api'); 
		
		  $entries = $this->db->escape_str($this->input->post('entries'));
		  $status = false;
		  $saved = 0;
		  $updated = 0;
		  if (count($entries)>0){
		  		foreach ($entries as $entry){
		  			$image = $entry['image'];
		  			$image_small = $entry['image_small'];
		  			$image_large = $entry['image_large'];
		  			$title = $entry['title'];
		  			$price = str_replace('$','',trim($entry['price']));
		  			$category = $entry['category'];
		  			$asin = $entry['asin'];
		  			$details = $this->amazon_api->getItemDetails($asin);
		  			if ($details == ''){
		  				$details = $title;
		  			}
					$category_id = $this->category_model->getcategoryidbyname($category);
		  			if ($category_id == ""){
		  				$category_id = $this->category_model->savecategorybyname($category);
		  			}
		  			
		  			if ($this->product_model->checkexist('asin',$asin)===false){
			  			$data = array('category_id'=>$category_id,'price'=>$price,'stock'=>1,'image'=>$image,'asin'=>$asin,'title'=>$title,'image_small'=>$image_small,'image_large'=>$image_large,'details'=>$details);
			  			$this->product_model->addimport($data);
			  			$saved++;
		  			}
		  			
		  			$this->output
								 ->set_content_type('application/json')
								 ->set_output(json_encode(array('success'=>true,'count'=>$saved)));
		  		}
		  }
	}
	
	
	function file_get_contents_curl($url) {
	    $ch = curl_init();
	
	    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
	    curl_setopt($ch, CURLOPT_HEADER, 0);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_URL, $url);
	    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
	
	    $data = curl_exec($ch);
	    curl_close($ch);
	
	    return $data;
	}
	
	public function testrating(){
		include './includes/simple_html_dom.php';
		$asin = 'B01BV2BPVS';
		$url = 'https://www.amazon.com/gp/customer-reviews/widgets/average-customer-review/popover/ref=dpx_acr_pop_?contextId=dpx&asin='.$asin;
		$html_markup = file_get_contents($url);
		$html_markup = trim($html_markup);
		$html_markup = substr($html_markup,0,500);
		
		echo strip_tags($html_markup);
		exit;
		preg_match('{(\d+\.\d+)}', $html_markup, $m);
        $number = $m[0];
        echo $number;
        exit;
		//echo preg_replace("/[^0-9\.]/", '', $html_markup);
	    if (preg_match_all('/[^0-9\.]/', $html_markup, $matches) > 0) {
           var_dump($matches);
        }else{
        	echo 'no match';
        }
		exit;
		$data = array();
		$html = str_get_html($html_markup);
		$current_key = 0;
		var_dump($html);
		foreach ($html->find('div') as $div) {
		    
		    if($div->class == 'a-section') {
		        $data[$current_key]['data'][] = $div->innertext;
		    }
		    
		    $current_key++;
		}
		
		echo '<pre>';
		print_r($data);
	}
	
}