<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account extends CI_Controller {

 
		function __construct()
		{
			parent::__construct();
			session_start(); 	// For KCFinder -> browser.php $_SESSION['validated'] creating.
								// account_model have $_SESSION['validated'] created.

		}
	
	public function login()
	{
		$this->load->view('admin/account/login');

	}
 
	public function check(){
	
		
	$email = $this->input->post("email");
    $this->load->model('admin/account/login');

      $result = $this->login->validate();

        if(!$result){
			$this->load->view('admin/account/login');
        }else{
			$this->session->set_flashdata('action_message', 'Hello, Welcome to '.$this->config->item('shop_domain').' shop');
			$this->session->set_flashdata('action_message_type', 'success');
			redirect('admin/dashboard');
        }
			

	}
	
	public function logout(){
        $this->session->sess_destroy();
		session_start(); 
		session_destroy();

        redirect('admin/account/login');
    
	}
	
	public function settings(){
   		$this->load->model('admin/admin_model');

   		if($_POST){
   			$password = $_POST['password'];
   			$confirm_password = $_POST['confirm_password'];
   			if ($password != $confirm_password){
   				$this->session->set_flashdata('action_message', 'Settings not updated!. Password mismatch.');
				$this->session->set_flashdata('action_message_type', 'danger');
				redirect($_SERVER['HTTP_REFERER']);
   			}else {
	   			$update = false;
				$update = $this->admin_model->update(1, $_POST);
				if($update){
					$this->session->set_flashdata('action_message', 'Settings updated!');
					$this->session->set_flashdata('action_message_type', 'success');
					redirect($_SERVER['HTTP_REFERER']);
				}else{
					$this->session->set_flashdata('action_message', 'Settings not updated!. An error has occured.');
					$this->session->set_flashdata('action_message_type', 'danger');
					redirect($_SERVER['HTTP_REFERER']);
				}
   			}
	}
 
 
			 
 	$settings = $this->admin_model->admin_detail(1);
 
	foreach($settings as $setting){
			$data["id"] = $setting->id;
			$data["email"] = $setting->email;
 			$data["password"] = $setting->password;
			$data["name"] = $setting->name;
     }
			
   		$this->load->view('admin/account/settings', $data);
   }
 
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */