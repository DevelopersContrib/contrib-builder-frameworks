<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Socials extends CI_Controller {

 
		function __construct()
		{
			parent::__construct();
			
			if(! $this->session->userdata('validated')){
            redirect('admin/account/login');
        }
		
		}
 
 
	public function index(){
 
	} 
   
   public function detail(){
   		$this->load->model('admin/settings_model');
   		$this->load->model('admin/socials_model');
   		$this->load->model('admin/language_model');
   		$this->load->model('admin/currency_model');

       	if($_POST){
			$update = false;
			$update = $this->socials_model->update(1, $_POST);
			if($update){
				$this->session->set_flashdata('action_message', 'Settings updated!');
				$this->session->set_flashdata('action_message_type', 'success');
				redirect($_SERVER['HTTP_REFERER']);
			}else{
				$this->session->set_flashdata('action_message', 'Settings not updated!. An error has occured.');
				$this->session->set_flashdata('action_message_type', 'danger');
				redirect($_SERVER['HTTP_REFERER']);
			}
	}
 
 
			 
 	$settings = $this->socials_model->socials_detail(1);
 
	foreach($settings as $setting){
			$data["id"] = $setting->id;
			$data["social_facebook"] = $setting->social_facebook;
 			$data["social_twitter"] = $setting->social_twitter;
			$data["social_linkedin"] = $setting->social_linkedin;
			$data["social_gplus"] = $setting->social_gplus;
 }
			
   		$this->load->view('admin/socials/details', $data);
   }
 
   
   
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */