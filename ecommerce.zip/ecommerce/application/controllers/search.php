<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Search extends KoController {
 
	public function index(){
			
			$keyword = $this->security->xss_clean($this->input->post('search_keyword'));
			
			if ($keyword != ""){
			
				foreach($this->products_model->search_products($keyword) AS $category_products){
					$category_product[] = array(
					   'id'  			=> $category_products->id,
					   'name'			=> $category_products->name,
					   'details'		=> $category_products->details,
					   'product_id'		=> $category_products->product_id,
					   'rank'			=> $category_products->rank,
					   'category_id'	=> $category_products->category_id,
					   'price'			=> ''.$this->cart->format_number($category_products->price * $this->data['currency_currency']),
					   'stock'			=> $category_products->stock,
					   'image'			=> $category_products->image,
					   'url'			=> $category_products->url,
					   'description_id'	=> $category_products->description_id,
					   'language_id'	=> $category_products->language_id,
					   'meta_tags'		=> $category_products->meta_tags,
					   'meta_keys'		=> $category_products->meta_keys
					   );  
				}
				
				@$this->data['category_products'] = $category_product;	
				
				
				//Menu...
				$this->data['categories'] = $this->categories_model->get_cats();
				$this->data['search_keyword'] = $keyword; 
				$this->load->view('search', $this->data);
			}else {
				redirect('/');
			}
   }
}
