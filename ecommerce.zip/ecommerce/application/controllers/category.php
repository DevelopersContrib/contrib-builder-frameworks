<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends KoController {
 
	public function seolink(){
		$this->load->model('categorys');
			//Products...
			$id = $this->security->xss_clean($this->uri->segment(2));

			foreach($this->products_model->category_products($id) AS $category_products){
				$category_product[] = array(
				   'id'  			=> $category_products->id,
				   'name'			=> $category_products->name,
				   'details'		=> $category_products->details,
				   'product_id'		=> $category_products->product_id,
				   'rank'			=> $category_products->rank,
				   'category_id'	=> $category_products->category_id,
				   'price'			=> ''.$this->cart->format_number($category_products->price * $this->data['currency_currency']),
				   'stock'			=> $category_products->stock,
				   'image'			=> $category_products->image,
				   'url'			=> $category_products->url,
				   'description_id'	=> $category_products->description_id,
				   'language_id'	=> $category_products->language_id,
				   'meta_tags'		=> $category_products->meta_tags,
				   'meta_keys'		=> $category_products->meta_keys
				   );  
			}
			
			@$this->data['category_products'] = $category_product;	
			
			//Slider products array construct.
			foreach($this->products_model->slider_products() AS $slider_products){
				$slider_product[] = array(
                   'mod_id'  			=> $slider_products->id,
				   'image_url'			=> $slider_products->image_url,
				   'image_desc'			=> stripcslashes($slider_products->details)
               );  
			}
			
		    $this->data['slider_products'] = $slider_product;
			
			//Menu...
			$this->data['categories'] = $this->categories_model->get_cats();
			$this->data['category_name'] = $this->categorys->getinfo_by_id('category_name',$id); 
			$this->load->view('category', $this->data);
			
}
}
