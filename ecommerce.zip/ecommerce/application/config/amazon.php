<?php
$config = array();
$config['amazon_key']             = '00M6CDC08G05XM832JG2';
$config['amazon_secret']          = 'ik1EKsHGD95JDIMwowD4npTsmgN0fD94OwWbQ7lb';
//$config['amazon_associate_tag']   = 'globalventu04-20';
$config['amazon_associate_tag']   = 'contrib04-20';
?>