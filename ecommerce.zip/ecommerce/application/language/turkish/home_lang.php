<?php
$lang['currency'] = "Para Birimi";
$lang['language'] = "Dil";
$lang['best_sell'] = "Cok Satan Ürünler";
$lang['add_basket'] = "Sepete At";
$lang['reviews'] = "yorum";
$lang['most_popular'] = "Cok Popüler Ürünler";
$lang['delete'] = "Sil";
$lang['update_cart'] = "Sepeti Güncelle";
$lang['total'] = "Toplam";
$lang['view_basket'] = "Sepete Git";





