<?php

 

$lang['order_billing_detail'] = "Siparis Fatura Detaylari";
$lang['order_cargo_detail'] = "Siparis Kargo Detaylari";


$lang['order_billing_cargo_firstname'] = "* Isim ve Soyisim";
$lang['order_billing_cargo_email'] = "* E-Mail";
$lang['order_billing_cargo_tel'] = "* Telefon";
$lang['order_billing_cargo_address'] = "* Adres 1";
$lang['order_billing_cargo_address2'] = "Adres 2";
$lang['order_billing_cargo_city'] = "* Sehir";
$lang['order_billing_cargo_postcode'] = "* Posta Kodu";
$lang['order_billing_cargo_country'] = "* Ülke";
$lang['order_billing_cargo_region'] = "* Eyalet / Bölge";
$lang['order_billing_cargo_company'] = "Sirket Adi";
$lang['order_billing_cargo_companyid'] = "* Sirket Vergi No. / TC Kimlik No.";
$lang['order_billing_cargo_same'] = "Fatura ve Kargo Adresim ayni.";

$lang['order_billing_cargo_cargo'] = "&raquo; Kargo";
