<?php



$lang['cargo_button'] = "&raquo; Ödeme ";
$lang['cargo_error'] = "Br Kargo tipi secmelisiniz!";
