<?php

$lang['payment_button'] = "&raquo; Tamamla";
$lang['payment_error'] = "Bir �deme tipi secmelisiniz";
