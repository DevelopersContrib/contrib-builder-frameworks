<?php

$lang['cart_title'] = "Alisveris Sepeti";
$lang['cart_delete'] = "Sil";
$lang['cart_listupdate'] = "Sepeti Güncelle";
$lang['checkout'] = "Satin Al";

$lang['qty'] = "Ad.";
$lang['item_desc'] = "Ürün Aciklama";
$lang['item_price'] = "Ürün Fiyati";
$lang['sub_total'] = "Ara Toplam";
$lang['action'] = "Islem";
$lang['total'] = "Toplam";
