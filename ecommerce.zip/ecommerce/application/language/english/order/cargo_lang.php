<?php

$lang['cargo_button'] = "&raquo; Payment";
$lang['cargo_error'] = "You must select type of cargo";
