<?php

$lang['payment_button'] = "&raquo; Complete";
$lang['payment_error'] = "You must select type of Payment";
