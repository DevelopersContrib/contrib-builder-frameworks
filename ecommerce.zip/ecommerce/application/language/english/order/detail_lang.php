<?php

 

$lang['order_billing_detail'] = "Order Billing Detail";
$lang['order_cargo_detail'] = "Order Cargo Detail";

$lang['order_billing_cargo_firstname'] = "First and Last Name";
$lang['order_billing_cargo_email'] = "E-Mail";
$lang['order_billing_cargo_tel'] = "Telephone";
$lang['order_billing_cargo_address'] = "Address 1";
$lang['order_billing_cargo_address2'] = "Address 2";
$lang['order_billing_cargo_city'] = "City";
$lang['order_billing_cargo_postcode'] = "Post Code";
$lang['order_billing_cargo_country'] = "Country";
$lang['order_billing_cargo_region'] = "Region / State";
$lang['order_billing_cargo_company'] = "Company Name";
$lang['order_billing_cargo_companyid'] = "Company ID";
$lang['order_billing_cargo_same'] = "My delivery and billing addresses are the same.";

$lang['order_billing_cargo_cargo'] = "&raquo; Cargo";
