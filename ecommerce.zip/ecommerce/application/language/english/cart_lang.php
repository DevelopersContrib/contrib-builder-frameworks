<?php

$lang['cart_title'] = "Shopping Cart";
$lang['cart_delete'] = "Delete";
$lang['cart_listupdate'] = "Update Cart";
$lang['checkout'] = "Checkout";


$lang['qty'] = "Qty";
$lang['item_desc'] = "Item Description";
$lang['item_price'] = "Item Price";
$lang['sub_total'] = "Sub-Total";
$lang['action'] = "Action";
$lang['total'] = "Total";
