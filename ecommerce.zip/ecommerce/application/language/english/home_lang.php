<?php
$lang['currency'] = "Currency";
$lang['language'] = "Language";
$lang['best_sell'] = "The Best-Selling Products";
$lang['add_basket'] = "Add Basket";
$lang['reviews'] = "reviews";
$lang['most_popular'] = "The Most Popular Products";
$lang['delete'] = "Delete";
$lang['update_cart'] = "Update your Cart";
$lang['total'] = "Total";
$lang['view_basket'] = "View Basket";
 
 

