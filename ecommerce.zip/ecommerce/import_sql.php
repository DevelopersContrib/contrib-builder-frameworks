<?php 
$host="localhost"; 
$root=$cpanel_username; 
$root_password=$cpanel_password; 

$user=$cpanel_username."_maida";
$pass='bing2k';


$db=$cpanel_username."_shop";  			//DOMAIN

if(strlen($root)>8){
	$db = substr($root, 0, 8).'_shop';
}


include 'includes/xmlapi.php';

$ip = getenv('REMOTE_HOST');
$root_pass = getenv('REMOTE_PASSWORD');
$xmlapi = new xmlapi($domain);
$xmlapi->set_port( 2083 );
$xmlapi->password_auth($cpanel_username,$cpanel_password);
$xmlapi->set_debug(0); //outpu



$createdb = $xmlapi->api1_query($cpanel_username, "Mysql", "adddb", array($db)); //creates the database


// your cPanel username
$cpanel_user = $cpanel_username;

// your cPanel password
$cpanel_pass = $cpanel_password;

// your cPanel skin
$cpanel_skin = 'paper_lantern';

// your cPanel domain
$cpanel_host = 'localhost';

// database username
$db_user = $user;

// database password
$db_pass = $pass;

$site = "https://$cpanel_username:$cpanel_password@localhost:2083/execute/Mysql/";
$result = @file_get_contents("{$site}create_database?name=$db");
$result .= @file_get_contents("{$site}create_user?name={$db_user}&password={$db_pass}");
$result .= @file_get_contents("{$site}set_privileges_on_database?user={$db_user}&database={$db}&privileges=ALL");

// create the database (old method which is now deprecated)
$site = "https://$cpanel_user:$cpanel_pass@localhost:2083/frontend/$cpanel_skin/sql/";
$result = @file_get_contents("{$site}adddb.html?db=$db");
$result .= @file_get_contents("{$site}adduser.html?user={$db_user}&pass={$db_pass}");
$result .= @file_get_contents("{$site}addusertodb.html?user={$cpanel_username}&db={$db}&ALL=ALL");
    
    
$cpanel_skin = 'x3';

$site = "https://$cpanel_username:$cpanel_password@localhost:2083/execute/Mysql/";
$result = @file_get_contents("{$site}create_database?name=$db");
$result .= @file_get_contents("{$site}create_user?name={$db_user}&password={$db_pass}");
$result .= @file_get_contents("{$site}set_privileges_on_database?user={$db_user}&database={$db}&privileges=ALL");

// create the database (old method which is now deprecated)
$site = "https://$cpanel_user:$cpanel_pass@localhost:2083/frontend/$cpanel_skin/sql/";
$result = @file_get_contents("{$site}adddb.html?db=$db");
$result .= @file_get_contents("{$site}adduser.html?user={$db_user}&pass={$db_pass}");
$result .= @file_get_contents("{$site}addusertodb.html?user={$cpanel_username}&db={$db}&ALL=ALL");
try {
	$dbh = new PDO("mysql:host=$host", $cpanel_username, $cpanel_password);
	$dbh->exec("CREATE DATABASE IF NOT EXISTS `$db`;
			CREATE USER '$user'@'localhost' IDENTIFIED BY '$pass';
			GRANT ALL ON `$db`.* TO '$user'@'localhost';
			FLUSH PRIVILEGES;
		 "); 
	 
	//or die(print_r($dbh->errorInfo(), true));
	$output = shell_exec("mysql -u$cpanel_username -p$cpanel_password $db < import_sql.sql");
	//include "execute_sql_file.php"; //temp 
	
} catch (PDOException $e) {
	die("DB ERROR: ". $e->getMessage());
}

 //die();
$bg_images = array(
'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-shop-first.jpeg',
'https://rdbuploads.s3.amazonaws.com/backgrounds/pexels-photo-291762.jpeg',
'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-phones.jpeg',
'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-starwars.jpeg',
'https://rdbuploads.s3.amazonaws.com/backgrounds/still-life-teddy-white-read.jpg'
); 

$rand_keys = array_rand($bg_images, 3);

$conn = new PDO("mysql:host=$host;dbname=$db", $cpanel_username, $cpanel_password);
 
$sql = "Update `settings` set `title`=?,`description`=?,`meta_tags`=?, `name`=?,"; 
		$sql .=" `owner`=?,`email`=?,`logo`=?,`google_analytics_code`=? ,`piwik_id`=?, `domain`=?,";
		$sql .= "`social_facebook`=?, `social_twitter`=?, `social_linkedin`=?, `social_gplus`=? where `id`=?";
		$q = $conn->prepare($sql);
		$q->execute(array($domain.' Shop','Shop '.$domain.'  - Top Sellers and Best Sellers on Sale Today - '.$domain.'  Shop',
		$keywords,$domain.' Shop',$domain,'admin@domaindirectory.com',$logo,$account_ga,$piwik_id,$domain,$social_fb,$social_twitter,
		$social_linkedin,$social_gplus,1
		));
		 
$sql = "Update modules set image_url=? where id=?";
$q = $conn->prepare($sql);
$q->execute(array($bg_images[$rand_keys[0]],35));

$sql = "Update modules set image_url=? where id=?";
$q = $conn->prepare($sql);
$q->execute(array($bg_images[$rand_keys[1]],36));

$html = '<h3 class="">
                                Huge Sale
                                
                            </h3>
<p class="">on Toys</p>
                           
                            <a href="/" class="btn btn-danger btn-lg">
                                SHOP NOW
                            </a>';
$sql = "Update modules set image_url=?,details=? where id=?";
$q = $conn->prepare($sql);
$q->execute(array('https://rdbuploads.s3.amazonaws.com/backgrounds/still-life-teddy-white-read.jpg',$html,37));


		
?>