/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `admin` */

insert  into `admin`(`id`,`email`,`password`,`name`,`note`) values (1,'admin@domaindirectory.com','school3030','Admin','');

/*Table structure for table `cargo` */

DROP TABLE IF EXISTS `cargo`;

CREATE TABLE `cargo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `cargo` */

insert  into `cargo`(`id`,`name`,`price`,`status`) values (1,'Flat Rate',5,1),(2,'Fast Cargo',10,1);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

/*Data for the table `category` */

insert  into `category`(`id`,`parent_id`,`rank`,`link`) values (1,0,1,'category/1/all.html'),(2,0,2,'category/2/apparel.html'),(3,0,3,'category/3/appliances.html'),(4,0,4,'category/4/arts_and_crafts.html'),(5,0,5,'category/5/automotive.html'),(6,0,6,'category/6/baby.html'),(7,0,7,'category/7/beauty.html'),(8,0,9,'category/8/books.html'),(9,0,10,'category/9/classical.html'),(10,0,12,'category/10/collectibles.html'),(11,0,13,'category/11/dvd.html'),(12,0,14,'category/12/digital_music.html'),(13,0,15,'category/13/electronics.html'),(14,0,16,'category/14/gift_cards.html'),(15,0,17,'category/15/gourmet_food.html'),(16,0,18,'category/16/grocery.html'),(17,0,19,'category/17/health_personal_care.html'),(18,0,20,'category/18/home_garden.html'),(19,0,21,'category/19/industrial.html'),(20,0,22,'category/20/jewelry.html'),(21,0,23,'category/21/kindle_store.html'),(22,0,24,'category/22/kitchen.html'),(23,0,25,'category/23/lawn_and_garden.html'),(24,0,26,'category/24/mp3_downloads.html'),(25,0,27,'category/25/magazines.html'),(26,0,28,'category/26/miscellaneous.html'),(27,0,29,'category/27/mobile_apps.html'),(28,0,31,'category/28/music.html'),(29,0,32,'category/29/musical_instruments.html'),(30,0,33,'category/30/office_products.html'),(31,0,34,'category/31/outdoor_living.html'),(32,0,35,'category/32/pc_hardware.html'),(33,0,36,'category/33/shoes.html'),(34,0,37,'category/34/software.html'),(35,0,38,'category/35/sporting_goods.html'),(36,0,39,'category/36/tools.html'),(37,0,40,'category/37/toys.html'),(38,0,41,'category/38/video.html'),(39,0,42,'category/39/video_games.html'),(40,0,43,'category/40/wireless_accessories.html'),(41,0,44,'category/41/watches.html'),(42,0,0,'category/42/digital-software.html'),(43,0,0,'category/43/office-product.html'),(44,0,0,'category/44/movie.html'),(45,0,0,'category/45/health-and-beauty.html'),(46,0,0,'category/46/furniture.html'),(47,0,0,'category/47/furniture.html'),(48,0,0,'category/48/furniture.html'),(49,0,0,'category/49/furniture.html'),(50,0,0,'category/50/furniture.html'),(51,0,0,'category/51/furniture.html'),(52,0,0,'category/52/furniture.html'),(53,0,0,'category/53/furniture.html'),(54,0,0,'category/54/office-product.html'),(55,0,0,'category/55/office-product.html'),(56,0,0,'category/56/office-product.html'),(57,0,0,'category/57/office-product.html'),(58,0,0,'category/58/office-product.html'),(59,0,0,'category/59/office-product.html'),(60,0,0,'category/60/furniture.html'),(61,0,0,'category/61/furniture.html'),(62,0,0,'category/62/furniture.html'),(63,0,0,'category/63/furniture.html'),(64,0,0,'category/64/office-product.html'),(65,0,0,'category/65/office-product.html'),(66,0,0,'category/66/home.html'),(67,0,0,'category/67/lawn-amp-patio.html'),(68,0,0,'category/68/office-product.html'),(69,0,0,'category/69/wireless.html'),(70,0,0,'category/70/apparel.html'),(71,0,0,'category/71/sports.html'),(72,0,0,'category/72/wireless.html'),(73,0,0,'category/73/apparel.html'),(74,0,0,'category/74/wireless.html'),(75,0,0,'category/75/apparel.html'),(76,0,0,'category/76/health-and-beauty.html'),(77,0,0,'category/77/wireless.html'),(78,0,0,'category/78/home-improvement.html'),(79,0,0,'category/79/office-product.html'),(80,0,0,'category/80/office-product.html'),(81,0,0,'category/81/kitchen.html'),(82,0,0,'category/82/office-product.html');

/*Table structure for table `category_description` */

DROP TABLE IF EXISTS `category_description`;

CREATE TABLE `category_description` (
  `ids` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `node_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ids`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;

/*Data for the table `category_description` */

insert  into `category_description`(`ids`,`category_id`,`language_id`,`category_name`,`description`,`meta_description`,`meta_keyword`,`node_id`) values (1,1,2,'All','All','All','All',''),(2,1,1,'','','','',''),(3,2,2,'Apparel','Apparel','Apparel','Apparel','7141123011'),(4,2,1,'','','','',''),(5,3,2,'Appliances','Appliances','Appliances','Appliances','2619525011'),(6,3,1,'','','','',''),(7,4,2,'Arts And Crafts','Arts And Crafts','Arts And Crafts','Arts And Crafts','2617941011'),(8,4,1,'','','','',''),(9,5,2,'Automotive','Automotive','Automotive','Automotive','15690151'),(10,5,1,'','','','',''),(11,6,2,'Baby','Baby','Baby','Baby','165797011'),(12,6,1,'','','','',''),(13,7,2,'Beauty','Beauty','Beauty','Beauty','11055981'),(14,7,1,'','','','',''),(15,8,2,'Books','Books','Books','Books','1000'),(16,8,1,'','','','',''),(17,9,2,'Classical','Classical','Classical','Classical','85'),(18,9,1,'','','','',''),(19,10,2,'Collectibles','Collectibles','Collectibles','Collectibles','4991426011'),(20,10,1,'','','','',''),(21,11,2,'DVD','DVD','DVD','DVD','2625374011'),(22,11,1,'','','','',''),(23,12,2,'Digital Music','Digital Music','Digital Music','Digital Music','163856011'),(24,12,1,'','','','',''),(25,13,2,'Electronics','Electronics','Electronics','Electronics','493964'),(26,13,1,'','','','',''),(27,14,2,'Gift Cards','Gift Cards','Gift Cards','Gift Cards','2238192011'),(28,14,1,'','','','',''),(29,15,2,'Gourmet Food','Gourmet Food','Gourmet Food','Gourmet Food','3580501'),(30,15,1,'','','','',''),(31,16,2,'Grocery','Grocery','Grocery','Grocery','16310101'),(32,16,1,'','','','',''),(33,17,2,'Health Personal Care','Health Personal Care','Health Personal Care','Health Personal Care','3760931'),(34,17,1,'','','','',''),(35,18,2,'Home Garden','Home Garden','Home Garden','Home Garden','3610851'),(36,18,1,'','','','',''),(37,19,2,'Industrial','Industrial','Industrial','Industrial','228239'),(38,19,1,'','','','',''),(39,20,2,'Jewelry','Jewelry','Jewelry','Jewelry','7192394011'),(40,20,1,'','','','',''),(41,21,2,'Kindle Store','Kindle Store','Kindle Store','Kindle Store','133141011'),(42,21,1,'','','','',''),(43,22,2,'Kitchen','Kitchen','Kitchen','Kitchen','284507'),(44,22,1,'','','','',''),(45,23,2,'Lawn And Garden','Lawn And Garden','Lawn And Garden','Lawn And Garden','2972638011'),(46,23,1,'','','','',''),(47,24,2,'MP3 Downloads','MP3 Downloads','MP3 Downloads','MP3 Downloads','195211011'),(48,24,1,'','','','',''),(49,25,2,'Magazines','Magazines','Magazines','Magazines','599872'),(50,25,1,'','','','',''),(51,26,2,'Miscellaneous','Miscellaneous','Miscellaneous','Miscellaneous','625061011'),(52,26,1,'','','','',''),(53,27,2,'Mobile Apps','Mobile Apps','Mobile Apps','Mobile Apps','2350150011'),(54,27,1,'','','','',''),(55,28,2,'Music','Music','Music','Music','301668'),(56,28,1,'','','','',''),(57,29,2,'Musical Instruments','Musical Instruments','Musical Instruments','Musical Instruments','11091801'),(58,29,1,'','','','',''),(59,30,2,'Office Products','Office Products','Office Products','Office Products','1064954'),(60,30,1,'','','','',''),(61,31,2,'Outdoor Living','Outdoor Living','Outdoor Living','Outdoor Living','1063498'),(62,31,1,'','','','',''),(63,32,2,'PC Hardware','PC Hardware','PC Hardware','PC Hardware','193870011'),(64,32,1,'','','','',''),(65,33,2,'Shoes','Shoes','Shoes','Shoes','672124011'),(66,33,1,'','','','',''),(67,34,2,'Software','Software','Software','Software','409488'),(68,34,1,'','','','',''),(69,35,2,'Sporting Goods','Sporting Goods','Sporting Goods','Sporting Goods','3375301'),(70,35,1,'','','','',''),(71,36,2,'Tools','Tools','Tools','Tools','468240'),(72,36,1,'','','','',''),(73,37,2,'Toys','Toys','Toys','Toys','165793011'),(74,37,1,'','','','',''),(75,38,2,'Video','Video','Video','Video','130'),(76,38,1,'','','','',''),(77,39,2,'Video Games','Video Games','Video Games','Video Games','468642'),(78,39,1,'','','','',''),(79,40,2,'Wireless Accessories','Wireless Accessories','Wireless Accessories','Wireless Accessories','13900851'),(80,40,1,'','','','',''),(81,41,2,'Watches',' Watches',' Watches',' Watches','377110011'),(82,41,1,'','','','',''),(83,42,2,'Digital Software','Digital Software','Digital Software','Digital Software',NULL),(84,43,2,'Office Product','Office Product','Office Product','Office Product',NULL),(85,44,2,'Movie','Movie','Movie','Movie',NULL),(86,45,2,'Health and Beauty','Health and Beauty','Health and Beauty','Health and Beauty',NULL),(87,46,2,'Furniture','Furniture','Furniture','Furniture',NULL),(88,47,2,'Furniture','Furniture','Furniture','Furniture',NULL),(89,48,2,'Furniture','Furniture','Furniture','Furniture',NULL),(90,49,2,'Furniture','Furniture','Furniture','Furniture',NULL),(91,50,2,'Furniture','Furniture','Furniture','Furniture',NULL),(92,51,2,'Furniture','Furniture','Furniture','Furniture',NULL),(93,52,2,'Furniture','Furniture','Furniture','Furniture',NULL),(94,53,2,'Furniture','Furniture','Furniture','Furniture',NULL),(95,54,2,'Office Product','Office Product','Office Product','Office Product',NULL),(96,55,2,'Office Product','Office Product','Office Product','Office Product',NULL),(97,56,2,'Office Product','Office Product','Office Product','Office Product',NULL),(98,57,2,'Office Product','Office Product','Office Product','Office Product',NULL),(99,58,2,'Office Product','Office Product','Office Product','Office Product',NULL),(100,59,2,'Office Product','Office Product','Office Product','Office Product',NULL),(101,60,2,'Furniture','Furniture','Furniture','Furniture',NULL),(102,61,2,'Furniture','Furniture','Furniture','Furniture',NULL),(103,62,2,'Furniture','Furniture','Furniture','Furniture',NULL),(104,63,2,'Furniture','Furniture','Furniture','Furniture',NULL),(105,64,2,'Office Product','Office Product','Office Product','Office Product',NULL),(106,65,2,'Office Product','Office Product','Office Product','Office Product',NULL),(107,66,2,'Home','Home','Home','Home',NULL),(108,67,2,'Lawn &amp; Patio','Lawn &amp; Patio','Lawn &amp; Patio','Lawn &amp; Patio',NULL),(109,68,2,'Office Product','Office Product','Office Product','Office Product',NULL),(110,69,2,'Wireless','Wireless','Wireless','Wireless',NULL),(111,70,2,'Apparel','Apparel','Apparel','Apparel',NULL),(112,71,2,'Sports','Sports','Sports','Sports',NULL),(113,72,2,'Wireless','Wireless','Wireless','Wireless',NULL),(114,73,2,'Apparel','Apparel','Apparel','Apparel',NULL),(115,74,2,'Wireless','Wireless','Wireless','Wireless',NULL),(116,75,2,'Apparel','Apparel','Apparel','Apparel',NULL),(117,76,2,'Health and Beauty','Health and Beauty','Health and Beauty','Health and Beauty',NULL),(118,77,2,'Wireless','Wireless','Wireless','Wireless',NULL),(119,78,2,'Home Improvement','Home Improvement','Home Improvement','Home Improvement',NULL),(120,79,2,'Office Product','Office Product','Office Product','Office Product',NULL),(121,80,2,'Office Product','Office Product','Office Product','Office Product',NULL),(122,81,2,'Kitchen','Kitchen','Kitchen','Kitchen',NULL),(123,82,2,'Office Product','Office Product','Office Product','Office Product',NULL);

/*Table structure for table `category_path` */

DROP TABLE IF EXISTS `category_path`;

CREATE TABLE `category_path` (
  `category_id` int(11) NOT NULL,
  `path_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`path_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `category_path` */

insert  into `category_path`(`category_id`,`path_id`,`level`) values (1,1,0),(2,2,0),(3,3,0),(4,4,0),(5,5,0),(6,6,0),(7,7,0),(8,8,0),(9,9,0),(10,10,0),(11,11,0),(12,12,0),(13,13,0),(14,14,0),(15,15,0),(16,16,0),(17,17,0),(18,18,0),(19,19,0),(20,20,0),(21,21,0),(22,22,0),(23,23,0),(24,24,0),(25,25,0),(26,26,0),(27,27,0),(28,28,0),(29,29,0),(30,30,0),(31,31,0),(32,32,0),(33,33,0),(34,34,0),(35,35,0),(36,36,0),(37,37,0),(38,38,0),(39,39,0),(40,40,0),(41,41,0),(42,42,0),(43,43,0),(44,44,0),(45,45,0),(46,46,0),(47,47,0),(48,48,0),(49,49,0),(50,50,0),(51,51,0),(52,52,0),(53,53,0),(54,54,0),(55,55,0),(56,56,0),(57,57,0),(58,58,0),(59,59,0),(60,60,0),(61,61,0),(62,62,0),(63,63,0),(64,64,0),(65,65,0),(66,66,0),(67,67,0),(68,68,0),(69,69,0),(70,70,0),(71,71,0),(72,72,0),(73,73,0),(74,74,0),(75,75,0),(76,76,0),(77,77,0),(78,78,0),(79,79,0),(80,80,0),(81,81,0),(82,82,0);

/*Table structure for table `ci_sessions` */

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `ci_sessions` */

insert  into `ci_sessions`(`session_id`,`ip_address`,`user_agent`,`last_activity`,`user_data`) values ('345e917954b12e8b94d6b958c861ae7e','182.18.250.84','Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/201001',1489547735,'a:3:{s:4:\"lang\";s:1:\"2\";s:9:\"lang_file\";s:7:\"english\";s:8:\"currency\";s:1:\"1\";}'),('0170f328d78e24ad1a946817dd2f7a53','182.18.250.84','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (K',1489541659,'a:3:{s:4:\"lang\";s:1:\"2\";s:9:\"lang_file\";s:7:\"english\";s:8:\"currency\";s:1:\"1\";}'),('f2a061e79e06a058c4d31fa5404c364c','64.233.172.141','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',1489545513,'a:3:{s:4:\"lang\";s:1:\"2\";s:9:\"lang_file\";s:7:\"english\";s:8:\"currency\";s:1:\"1\";}'),('6546b521b4a0576bdb534e597cbd993f','182.18.250.84','Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/201001',1489547734,'a:3:{s:4:\"lang\";s:1:\"2\";s:9:\"lang_file\";s:7:\"english\";s:8:\"currency\";s:1:\"1\";}'),('3d861c95e26b02e55ba1abc1cc3fc462','182.18.250.84','Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/201001',1489547600,'a:8:{s:4:\"lang\";s:1:\"2\";s:9:\"lang_file\";s:7:\"english\";s:8:\"currency\";s:1:\"1\";s:2:\"id\";s:1:\"1\";s:5:\"email\";s:5:\"admin\";s:4:\"name\";s:5:\"Admin\";s:9:\"validated\";b:1;s:13:\"cart_contents\";a:3:{s:32:\"2838023a778dfaecdc212708f721b788\";a:8:{s:5:\"rowid\";s:32:\"2838023a778dfaecdc212708f721b788\";s:2:\"id\";s:2:\"51\";s:3:\"qty\";s:1:\"1\";s:4:\"asin\";s:10:\"B00LZSJ642\";s:5:\"price\";s:5:\"12.50\";s:4:\"name\";s:76:\"Gatorade 32 Oz Squeeze Water Sports Bottle -Pack of 2 - New Easy Grip Design\";s:7:\"options\";a:0:{}s:8:\"subtotal\";d:12.5;}s:11:\"total_items\";i:1;s:10:\"cart_total\";d:12.5;}}'),('0c3ef2e729373a6f4673bf668ccc87da','182.18.250.84','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko',1489547469,'a:4:{s:4:\"lang\";s:1:\"2\";s:9:\"lang_file\";s:7:\"english\";s:8:\"currency\";s:1:\"1\";s:13:\"cart_contents\";a:4:{s:32:\"642e92efb79421734881b53e1e1b18b6\";a:8:{s:5:\"rowid\";s:32:\"642e92efb79421734881b53e1e1b18b6\";s:2:\"id\";s:2:\"48\";s:3:\"qty\";s:1:\"1\";s:4:\"asin\";s:10:\"B01GCG0BTU\";s:5:\"price\";s:5:\"34.95\";s:4:\"name\";s:97:\"SYROKAN Women\'s High Impact Support Wirefree Workout Racerback Sports Bra Top Multicoloured #5 XL\";s:7:\"options\";a:0:{}s:8:\"subtotal\";d:34.9500000000000028421709430404007434844970703125;}s:32:\"2838023a778dfaecdc212708f721b788\";a:8:{s:5:\"rowid\";s:32:\"2838023a778dfaecdc212708f721b788\";s:2:\"id\";s:2:\"51\";s:3:\"qty\";s:1:\"1\";s:4:\"asin\";s:10:\"B00LZSJ642\";s:5:\"price\";s:5:\"12.50\";s:4:\"name\";s:76:\"Gatorade 32 Oz Squeeze Water Sports Bottle -Pack of 2 - New Easy Grip Design\";s:7:\"options\";a:0:{}s:8:\"subtotal\";d:12.5;}s:11:\"total_items\";i:2;s:10:\"cart_total\";d:47.4500000000000028421709430404007434844970703125;}}'),('f6b01645f86ae848af0473eac2d5a895','182.18.250.84','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko',1489547762,'a:3:{s:4:\"lang\";s:1:\"2\";s:9:\"lang_file\";s:7:\"english\";s:8:\"currency\";s:1:\"1\";}');

/*Table structure for table `currency` */

DROP TABLE IF EXISTS `currency`;

CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `currency` float NOT NULL,
  `code` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `standart` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `currency` */

insert  into `currency`(`id`,`name`,`currency`,`code`,`symbol`,`standart`) values (1,'USD',1,'USD','$',1),(2,'Euro',0.353,'EUR','€',0);

/*Table structure for table `extension` */

DROP TABLE IF EXISTS `extension`;

CREATE TABLE `extension` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `loadpage` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `extension` */

insert  into `extension`(`id`,`name`,`type`,`loadpage`) values (1,'Paypal','payment','paypal'),(2,'Bank Transfer / EFT','payment','banktransfer');

/*Table structure for table `language` */

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `flag` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `default` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `language` */

insert  into `language`(`id`,`language_name`,`file_name`,`flag`,`code`,`default`) values (1,'Türkce','turkish','http://www.sanmak.com.tr/img/trFlagBig.png','tr',''),(2,'English','english','http://www.sanmak.com.tr/img/enFlagBig.png','en','1');

/*Table structure for table `modules` */

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `image_url` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

/*Data for the table `modules` */

insert  into `modules`(`id`,`name`,`details`,`type`,`product_id`,`rank`,`image_url`) values (1,'Slider','','slide',1,1,NULL),(2,'Slider','','slide',2,2,NULL),(3,'Most Sell Products','','sell',3,2,NULL),(4,'Most Sell Products','','sell',4,1,NULL),(5,'Populer Products','','popular',5,1,NULL),(6,'Populer Products','','popular',6,2,NULL),(17,'Most Sell Products','','sell',7,3,NULL),(18,'Populer Products','','popular',2,3,NULL),(21,'Most Sell Products','','sell',0,0,NULL),(22,'Slider','','slide',0,4,NULL),(26,'Most Sell Products','','sell',17,1,NULL),(27,'Most Sell Products','','sell',18,2,NULL),(29,'Populer Products','','popular',20,1,NULL),(30,'Populer Products','','popular',17,2,NULL),(31,'Most Sell Products','','sell',26,3,NULL),(35,'Slider','<h3 class=\"\">\n                                Huge Sale\n                            </h3>\n                            <p class=\"\">Up to 70% off</p>\n                            <a href=\"\" class=\"btn btn-outline-white btn-lg\">\n                                SHOP ALL\n                            </a>','slide',0,1,'http://shop.handyman.com/wp-content/uploads/2017/01/Home-Improvement-1.jpg'),(36,'Slider','<h3 class=\"\">\n                                upgrade your <br>\n                                <span class=\"red-soft-text\">home</span> on a <br>\n                                budget\n                            </h3>\n                            <p class=\"\">FROM 19$</p>\n                            <a href=\"\" class=\"btn btn-outline-red btn-lg\">\n                                SHOP NOW\n                            </a>','slide',0,2,'http://shop.handyman.com/wp-content/uploads/2017/01/pexels-photo-245208-1.jpeg'),(37,'Slider',' <h3 class=\"\">\n                                Found your <br>\n                                handyman\n                            </h3>\n                            <p class=\"\">\n                                Join our community and get matched to a <br>\n                                screened and friendly handyman near you!\n                            </p>\n                            <a href=\"\" class=\"btn btn-danger btn-lg\">\n                                FIND MY HANDYMAN\n                            </a>','slide',0,3,'http://shop.handyman.com/wp-content/uploads/2017/01/U-GoGirl-Work-Tools-Household-Pink-Tool-Kit-with-a-Balanced-Fit-for-Womans-Hands-As-tough-as-mens-toolsfor-Lady-DIYers-and-Handywomen-0-3.jpg'),(38,'Most Sell Products','','sell',44,1,NULL),(39,'Most Sell Products','','sell',48,2,NULL),(40,'Most Sell Products','','sell',51,3,NULL),(41,'Populer Products','','popular',49,1,NULL),(42,'Populer Products','','popular',47,2,NULL),(43,'Populer Products','','popular',46,3,NULL);

/*Table structure for table `option` */

DROP TABLE IF EXISTS `option`;

CREATE TABLE `option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_type` varchar(255) NOT NULL,
  `rank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `option` */

insert  into `option`(`id`,`option_type`,`rank`) values (1,'selectbox',1),(2,'checkbox',2),(3,'radio',3),(4,'textarea',6),(5,'date',5),(6,'file',4),(7,'input',7);

/*Table structure for table `option_description` */

DROP TABLE IF EXISTS `option_description`;

CREATE TABLE `option_description` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `option_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

/*Data for the table `option_description` */

insert  into `option_description`(`id`,`option_id`,`language_id`,`option_name`) values (18,2,1,'Boyut'),(17,2,2,'Size'),(13,1,2,'Color'),(14,1,1,'Renk'),(15,2,2,'Gift'),(16,2,1,'Hediye');

/*Table structure for table `option_value` */

DROP TABLE IF EXISTS `option_value`;

CREATE TABLE `option_value` (
  `option_value_row_id` int(11) NOT NULL AUTO_INCREMENT,
  `option_value_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `value_name` varchar(255) NOT NULL,
  PRIMARY KEY (`option_value_row_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

/*Data for the table `option_value` */

insert  into `option_value`(`option_value_row_id`,`option_value_id`,`option_id`,`language_id`,`value_name`) values (28,27,15,1,'Anahtarlik'),(27,27,15,2,'Keychain'),(26,25,15,1,'Çakmak'),(25,25,15,2,'Lighter'),(24,23,13,1,'Turuncu'),(23,23,13,2,'Orange'),(22,21,13,1,'Beyaz'),(21,21,13,2,'Wheit'),(18,17,13,1,'Kirmizi'),(17,17,13,2,'Red'),(19,19,13,2,'Black'),(20,19,13,1,'Siyah'),(29,29,17,2,'Large'),(30,29,17,1,'Büyük'),(31,31,17,2,'Small'),(32,31,17,1,'Kücük'),(33,33,17,2,'Middle'),(34,33,17,1,'Orta');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `billing_first_name` varchar(255) NOT NULL,
  `billing_email` varchar(255) NOT NULL,
  `billing_telephone` varchar(255) NOT NULL,
  `billing_address1` varchar(255) NOT NULL,
  `billing_address2` varchar(255) NOT NULL,
  `billing_city` varchar(255) NOT NULL,
  `billing_postcode` int(11) NOT NULL,
  `billing_country` varchar(255) NOT NULL,
  `billing_region` varchar(255) NOT NULL,
  `billing_company` varchar(255) NOT NULL,
  `billing_companyid` varchar(255) NOT NULL,
  `cargo_first_name` varchar(255) NOT NULL,
  `cargo_email` varchar(255) NOT NULL,
  `cargo_telephone` varchar(255) NOT NULL,
  `cargo_address1` varchar(255) NOT NULL,
  `cargo_address2` varchar(255) NOT NULL,
  `cargo_city` varchar(255) NOT NULL,
  `cargo_postcode` int(11) NOT NULL,
  `cargo_country` varchar(255) NOT NULL,
  `cargo_region` varchar(255) NOT NULL,
  `cargo_type` int(11) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `currency_symbol` varchar(255) NOT NULL,
  `currency_currency` float NOT NULL,
  `status` int(11) NOT NULL,
  `comment` text NOT NULL,
  `total` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

/*Data for the table `order` */

insert  into `order`(`order_id`,`customer_id`,`billing_first_name`,`billing_email`,`billing_telephone`,`billing_address1`,`billing_address2`,`billing_city`,`billing_postcode`,`billing_country`,`billing_region`,`billing_company`,`billing_companyid`,`cargo_first_name`,`cargo_email`,`cargo_telephone`,`cargo_address1`,`cargo_address2`,`cargo_city`,`cargo_postcode`,`cargo_country`,`cargo_region`,`cargo_type`,`payment_type`,`currency_symbol`,`currency_currency`,`status`,`comment`,`total`,`ip`,`date`) values (33,0,'test','test@test.com','test','test','','test',0,'test','test','test','test','test','test@test.com','test','test','','test',0,'test','test',2,2,'0',0,1,'','2731','78.43.43.36','2015-03-19 23:42:37'),(34,0,'jf','aw@mil.co','20606500','jbhjggs','xfchgvhb','gcvbhv',123434,'ctfghv','dxcfgv','sdcfvgbhj','r56tg','jf','aw@mil.co','20606500','jbhjggs','xfchgvhb','gcvbhv',123434,'ctfghv','dxcfgv',2,2,'0',0,1,'','1321','180.242.201.185','2015-05-03 05:59:19'),(36,0,'Koray','korayzorluoglu1@hotmail.com','+4917684222401','Eisenbahn str. 28','','Steinen',79585,'test','Deutschland','','Herr','Koray','korayzorluoglu1@hotmail.com','+4917684222401','Eisenbahn str. 28','','Steinen',79585,'test','Deutschland',1,2,'€',0.353,1,'','1432','78.43.43.56','2015-05-12 22:24:59');

/*Table structure for table `order_detail` */

DROP TABLE IF EXISTS `order_detail`;

CREATE TABLE `order_detail` (
  `oid` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `options` varchar(255) NOT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

/*Data for the table `order_detail` */

insert  into `order_detail`(`oid`,`order_id`,`product_id`,`count`,`options`) values (25,33,4,1,'36'),(26,33,4,1,'39,40'),(27,34,4,1,''),(30,36,4,1,''),(31,36,3,1,'');

/*Table structure for table `page` */

DROP TABLE IF EXISTS `page`;

CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `page` */

insert  into `page`(`id`,`page_name`) values (1,'Deneme');

/*Table structure for table `page_description` */

DROP TABLE IF EXISTS `page_description`;

CREATE TABLE `page_description` (
  `page_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `meta_tags` text NOT NULL,
  `meta_keys` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `page_description` */

insert  into `page_description`(`page_id`,`language_id`,`name`,`details`,`meta_tags`,`meta_keys`) values (1,1,'Deneme Sayfa','Deneme sayfa icerik alani...','Deneme sayfa icerik alani...','Deneme sayfa icerik alani...'),(1,2,'Test Page','Test Page detail is here..','Test Page detail is here..','Test Page detail is here..');

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `stock` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_small` varchar(255) DEFAULT NULL,
  `image_large` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `rank` int(11) NOT NULL,
  `asin` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

/*Data for the table `product` */

insert  into `product`(`id`,`category_id`,`price`,`stock`,`image`,`image_small`,`image_large`,`url`,`rank`,`asin`) values (44,'69','29.99',1,'https://images-na.ssl-images-amazon.com/images/I/41n4HODIEiL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/41n4HODIEiL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/41n4HODIEiL.jpg','product/44/taotronics-bluetooth-headphone.html',0,'B01BV2BPVS'),(45,'70','79.99',1,'https://images-na.ssl-images-amazon.com/images/I/51qYQO+f4-L._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/51qYQO+f4-L._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/51qYQO+f4-L.jpg','product/45/mirity-women-racerback-sports.html',0,'B01NBVM096'),(46,'71','24.97',1,'https://images-na.ssl-images-amazon.com/images/I/51l8UEyXrcL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/51l8UEyXrcL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/51l8UEyXrcL.jpg','product/46/professional-grade-athletic-ta.html',0,'B01ENZ7B1I'),(47,'72','249.99',1,'https://images-na.ssl-images-amazon.com/images/I/41HEgImrcJL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/41HEgImrcJL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/41HEgImrcJL.jpg','product/47/jabra-elite-sport-true-wireles.html',0,'B01N53RO3X'),(48,'73','34.95',1,'https://images-na.ssl-images-amazon.com/images/I/51thGg+rA2L._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/51thGg+rA2L._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/51thGg+rA2L.jpg','product/48/syrokan-womens-high-impact-sup.html',0,'B01GCG0BTU'),(49,'74','149.99',1,'https://images-na.ssl-images-amazon.com/images/I/41+Lit9SNVL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/41+Lit9SNVL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/41+Lit9SNVL.jpg','product/49/motorola-moto-360-sport-45mm-b.html',0,'B016CKHAZO'),(50,'75','69.00',1,'https://images-na.ssl-images-amazon.com/images/I/51n5GIwexgL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/51n5GIwexgL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/51n5GIwexgL.jpg','product/50/lataly-womens-racerback-sports.html',0,'B01IP3Y310'),(51,'76','12.50',1,'https://images-na.ssl-images-amazon.com/images/I/419XBwch81L._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/419XBwch81L._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/419XBwch81L.jpg','product/51/gatorade-32-oz-squeeze-water-s.html',0,'B00LZSJ642'),(52,'77','249.99',1,'https://images-na.ssl-images-amazon.com/images/I/414a53IKk9L._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/414a53IKk9L._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/414a53IKk9L.jpg','product/52/garmin-sport-pro-bundle-dog-tr.html',0,'B01276FRQG'),(53,'78','42.30',1,'https://images-na.ssl-images-amazon.com/images/I/41Ax4oZwZmL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/41Ax4oZwZmL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/41Ax4oZwZmL.jpg','product/53/howard-leight-impact-sport-od.html',0,'B001T7QJ9O'),(54,'79','8.99',1,'https://images-na.ssl-images-amazon.com/images/I/51Xgy32YcpL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/51Xgy32YcpL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/51Xgy32YcpL.jpg','product/54/fovo-computer-monitors-screen.html',0,'B01GZGW5CS'),(55,'80','5.75',1,'https://images-na.ssl-images-amazon.com/images/I/51VlWjIvwJL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/51VlWjIvwJL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/51VlWjIvwJL.jpg','product/55/knock-knock-wtf-nifty-notes.html',0,'1601063385'),(56,'81','22.88',1,'https://images-na.ssl-images-amazon.com/images/I/51zYOkdDRrL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/51zYOkdDRrL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/51zYOkdDRrL.jpg','product/56/mind-reader-perch-pc-laptop-im.html',0,'B01D1XUBRO'),(57,'82','27.80',1,'https://images-na.ssl-images-amazon.com/images/I/41Lz80fb6yL._SL160_.jpg','https://images-na.ssl-images-amazon.com/images/I/41Lz80fb6yL._SL75_.jpg','https://images-na.ssl-images-amazon.com/images/I/41Lz80fb6yL.jpg','product/57/deflecto-20504op-five-bin-hori.html',0,'B0015ZYU9G');

/*Table structure for table `product_description` */

DROP TABLE IF EXISTS `product_description`;

CREATE TABLE `product_description` (
  `description_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `meta_tags` text NOT NULL,
  `meta_keys` text NOT NULL,
  PRIMARY KEY (`description_id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

/*Data for the table `product_description` */

insert  into `product_description`(`description_id`,`product_id`,`language_id`,`name`,`details`,`meta_tags`,`meta_keys`) values (146,44,2,'TaoTronics Bluetooth Headphones Wireless In Ear Earbuds Sports Sweatproof Earphones with Built in Mic (Cordless 4.1, Secure Ear Hooks Design, 7 Hours Play Time)','Sweat in Style: The Winner in Sports Audio Features Innovative Sweat Proof Covering and Flexible Ear Hooks That Stay in Place No Matter the Physical Activity<br>Top Quality Audio: Hear Richer and More Natural Sound from Your Smartphones, Tablets, and Audio Devices with the Aptx Codec<br>Last Longer, Sweat Longer: Bluetooth 4.1 Offers a Faster, More Energy Efficient Connection so You Can Listen to Music for up to 7 Hours<br>Crystal Clear Communication: Featuring CVC Noise Cancellation technology, the integrated microphone lets you chat without external noise or other interference<br>Absolute Wireless Stability: Built-in Ceramic Antenna Provides Enhanced Audio Quality and More Stable Bluetooth Pairing, Meaning Minimal Lost Connections','TaoTronics Bluetooth Headphones Wireless In Ear Earbuds Sports Sweatproof Earphones with Built in Mic (Cordless 4.1, Secure Ear Hooks Design, 7 Hours Play Time)','TaoTronics Bluetooth Headphones Wireless In Ear Earbuds Sports Sweatproof Earphones with Built in Mic (Cordless 4.1, Secure Ear Hooks Design, 7 Hours Play Time)'),(147,45,2,'Mirity Women Racerback Sports Bras - High Impact Workout Gym Activewear Bra Color Black Blue Size M','Pullover Style and Removeable Pads High support Sports Bra.<br>This High-support sport bra and a comfy racerback in smooth Body-Wick fabric to keep you cool, from cycling to circuit training.<br>The Ladies High-support Bra Top Is Perfect For Training Sessions Down At The Gym, Constructed With A Built In Bra For Added Support Along With Ventilation Panels And Wide Shoulder Straps For A Cool And Comfortable Fit. This Sports Bra Also Benefits From An Elasticated Hem, Finished Off With Reflective Detail To The Racer Back Sport Bras.<br>Soft, Stretchy, And Super Breathable,This Is An Awesome Saturday Bra. Tough Enough To Handle Hot Class, Then Slips Seamlessly Under Your Favorite Tank Or T-Shirt For Whatever Else You Want To Get Into That Day. Built For High /Medium-Impact Activity And All-Day Comfort.<br>Why We Made This High-support sport bra?This Double Straight-Strap Bra Is Killing It From Every Angle. In The Front, High Coverage Keeps Us Feeling Comfortable During Plank Pose. In The Back, A Wide Racer And Strategically-Placed Cut-Out Provides Support And Keeps The Air Flowing. The Result? An All-Around Winner.','Mirity Women Racerback Sports Bras - High Impact Workout Gym Activewear Bra Color Black Blue Size M','Mirity Women Racerback Sports Bras - High Impact Workout Gym Activewear Bra Color Black Blue Size M'),(148,46,2,'Professional Grade Athletic Tape by 1st Elite- Pro Athletes Coaches Trainers in Gymnastics Boxing Basketball Hockey Soccer Crossfit MMA Martial Arts Football Sports &amp; Medical First Aid','★ PUT ME IN COACH -1st Elite\'s premium 100% Cotton based Athletic Tape is your premier choice in joint protection. Latex free, our self adhesive wrap is easy on skin and offers a tensile strength that really safeguards your most vulnerable joints!<br>★ ALL FOR ONE -No matter if you\'re the coach, personal trainer, or just an everyday athlete, our ten yard spools are sure to last while offering reliable rigidity to sensitive fingers, toes and joints.<br>★ STAY PUT -While some tapes offer too much stick irritating the skin and others just won\'t stay in place, we\'ve given our remarkable tape the perfect amount of adhesion to make sure it stays in place, but won\'t be a hassle to remove!<br>★ PROFESSIONAL GRADE -Forget low quality stability tapes, and buy a step above with 1st Elite! Anyone who knows proper protection knows that we\'ve done it right, and for the right price.<br>★ GUARANTEED -Best of all, we\'re always here for you! If we don\'t meet your needs, all you have to do is let us know. It\'s really that easy. You\'ll never be told you can\'t return or be refunded here!','Professional Grade Athletic Tape by 1st Elite- Pro Athletes Coaches Trainers in Gymnastics Boxing Basketball Hockey Soccer Crossfit MMA Martial Arts Football Sports &amp; Medical First Aid','Professional Grade Athletic Tape by 1st Elite- Pro Athletes Coaches Trainers in Gymnastics Boxing Basketball Hockey Soccer Crossfit MMA Martial Arts Football Sports &amp; Medical First Aid'),(149,47,2,'Jabra Elite Sport True-Wireless Bluetooth Stereo Earbuds (U.S. Retail Packaging)','Advanced wireless connectivity and superior quality calls and music<br>Waterproof design and 3-year warranty against sweat (registration via Jabra Sport Life App required)<br>3 hours talk/music time in earbuds. Charging case adds additional 6 hours of battery life.<br>Comfortable and secure cord-free fit, with option to wear one or both earbuds<br>In-ear precision heart rate monitor and fitness analyzer. Personalized in-ear audio coaching, race pace calculator and recovery advice.','Jabra Elite Sport True-Wireless Bluetooth Stereo Earbuds (U.S. Retail Packaging)','Jabra Elite Sport True-Wireless Bluetooth Stereo Earbuds (U.S. Retail Packaging)'),(150,48,2,'SYROKAN Women\'s High Impact Support Wirefree Workout Racerback Sports Bra Top Multicoloured #5 XL','Double layer for additional protection and more comfort<br>Mesh panels to add ventilation right where you want it most<br>Slightly padded for better shape and extra support<br>Elastic underband to support medium to high impact activities like running<br>Power racerback for better stability and ensuring freedom of movement','SYROKAN Women\'s High Impact Support Wirefree Workout Racerback Sports Bra Top Multicoloured #5 XL','SYROKAN Women\'s High Impact Support Wirefree Workout Racerback Sports Bra Top Multicoloured #5 XL'),(151,49,2,'Motorola Moto 360 Sport - 45mm, Black','Displays Notifications, Cards, and More, LCD Touchscreen with Gorilla Glass 3<br>Button-Free Voice Control, Turn-by-Turn Navigation<br>Heart Rate & Activity Monitoring, GPS, Customizable Watch Faces<br>Water Resistant to 3-ft, Wireless Charging with Included Dock, Just tell your Moto 360 Sport where you want to go, then let the step-by-step navigation instructions in the watch display guide you to your destination. Navigation instructions that you set up on your phone will also appear in your watch display.<br>Compatible with Android and iOS<br>Android Wear OS','Motorola Moto 360 Sport - 45mm, Black','Motorola Moto 360 Sport - 45mm, Black'),(152,50,2,'Lataly Womens Racerback Sports Bras Seamless High Impact Support Workout Yoga Bra,4Pack,XL','Compression: Ultra-Tight, Second Skin Fit.<br>Built For Mid-Impact Support So You Can Stay Fit & Focused.<br>Lightweight, 4-Way Stretch Construction Improves Mobility & Maintains Shape.<br>Classic Pullover Style With Racer Back Design For Enhanced Range Of Motion.<br>Super-Soft Jacquard Elastic Band Delivers A Custom, Stay-Put Fit Allover Seasonal Prints.','Lataly Womens Racerback Sports Bras Seamless High Impact Support Workout Yoga Bra,4Pack,XL','Lataly Womens Racerback Sports Bras Seamless High Impact Support Workout Yoga Bra,4Pack,XL'),(153,51,2,'Gatorade 32 Oz Squeeze Water Sports Bottle -Pack of 2 - New Easy Grip Design','Hydrate just like the pros do with these squeeze bottles from Gatorade.<br>Contoured design for easy gripping<br>Built-in one-way valve means there\'s no opening and closing this prevents spillage and allows you to just squeeze and drink screw on lid with wide-mouth opening for easy refilling and emptying<br>You will receive a two pack of bottles. Each with a capacity of 32oz.','Gatorade 32 Oz Squeeze Water Sports Bottle -Pack of 2 - New Easy Grip Design','Gatorade 32 Oz Squeeze Water Sports Bottle -Pack of 2 - New Easy Grip Design'),(154,52,2,'Garmin Sport PRO Bundle Dog Training Device','QUICK TURN DIAL - Quick turn dial on handheld with positive clicks when changing between 10 stimulation levels and controlling auxiliary functions and 1-HAND OPERATION Simple, intuitive, \"no look\" 1-hand operation<br>4 TRAINING BUTTONS - 4 training buttons for continuous and momentary stimulation, vibration and tone<br>TONE AND VIBRATION - Buttons on the handheld can activate tone signal and vibration control on the dog device<br>BEACON LIGHTS - Remote control of LED beacon lights on the dog device for low light conditions; visible up to 100 yards away and LED STATUS LIGHT LED status light for quick, at-a-glance read<br>Includes:-Sport PRO handheld, dog device, 3/4\" black collar strap, AC adapter, split adapter cable, charging clip, contact point sets (long and short) with wrench, manual','Garmin Sport PRO Bundle Dog Training Device','Garmin Sport PRO Bundle Dog Training Device'),(155,53,2,'Howard Leight Impact Sport OD Electric Earmuff, Green','Built-in directional microphones amplify range commands and other ambient sounds to a safe 82dB, providing more natural listening and enhanced communication<br>Actively listens and automatically shuts off amplification when ambient sound reaches 82 dB; Noise Reduction Rating (NRR): 22<br>Features low profile earcups for stock clearance; adjustable headband for secure fit; compact folding design for convenient storage; Matte black color<br>Includes AUX input and 3.5mm connection cord for MP3 players and scanners<br>Includes 2 AAA batteries;  automatic shut-off feature after 4 hours increases battery life','Howard Leight Impact Sport OD Electric Earmuff, Green','Howard Leight Impact Sport OD Electric Earmuff, Green'),(156,54,2,'FoVo Computer Monitors Screen Acrylic Message Boards Memo Pads','1.Stand on the left of monitor,good strategy for making schedule, notes and Conversation with long-term<br>2. Using 3M sticker, completely will not damage the display<br>3.TOP:Clip design for A4 paper, pictures, business cards etc; Bottom: Super wide design at the bottom, can put thick Post-it . It also has a hole designed for Mobile phone,you can connect to the socket to charge the phone<br>4.Material:Acrylic, Size:30×8×2cm<br>5.LIFETIME WARRANTY: We have confidence in our product, and we believe you will love it .So we offer a free service change or full refund','FoVo Computer Monitors Screen Acrylic Message Boards Memo Pads','FoVo Computer Monitors Screen Acrylic Message Boards Memo Pads'),(157,55,2,'Knock Knock WTF Nifty Notes','Harness the power of the checkbox for effective communication<br>WTF Notes put the words you want right at your fingertips<br>Find the joy in bitterness and befuddlement<br>Pad is 4 x 5.25 inches and has 50 sheets<br>Nifty Notes are an excellent source of irony<br>Knock Knock is an independent maker of clever gifts, books, and whatever else we can think up; our mission is to bring humor, creativity, and smarts to everyday life','Knock Knock WTF Nifty Notes','Knock Knock WTF Nifty Notes'),(158,56,2,'Mind Reader \' Perch\' Pc Laptop IMac Monitor Stand And Desk Organizer, Black','10 different compartments to store and organizer your desk accessories<br>Save valuable desk space by putting your monitor on top<br>Elevate your monitor by 2 Inch for healthy neck<br>Removable legs to elevate monitor<br>Space below stows a keyboard','Mind Reader \' Perch\' Pc Laptop IMac Monitor Stand And Desk Organizer, Black','Mind Reader \' Perch\' Pc Laptop IMac Monitor Stand And Desk Organizer, Black'),(159,57,2,'Deflecto 20504OP Five-bin horizontal tilt bin storage system, 23-5/8w x 5-1/4d x 6-1/2h, black','1 Five-bin horizontal Interlocking storage system.<br>Units stack and connect together to form a custom modular system.<br>Transparent bins tilt out and stay open while in use.<br>Can be wall mounted or used on countertop.<br>Bins can be easily removed from locking mechanism for cleaning and refilling.','Deflecto 20504OP Five-bin horizontal tilt bin storage system, 23-5/8w x 5-1/4d x 6-1/2h, black','Deflecto 20504OP Five-bin horizontal tilt bin storage system, 23-5/8w x 5-1/4d x 6-1/2h, black');

/*Table structure for table `product_option` */

DROP TABLE IF EXISTS `product_option`;

CREATE TABLE `product_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `product_option` */

insert  into `product_option`(`id`,`product_id`,`option_id`) values (19,2,3),(18,4,2),(17,1,2);

/*Table structure for table `product_option_value` */

DROP TABLE IF EXISTS `product_option_value`;

CREATE TABLE `product_option_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `value_id` int(11) NOT NULL,
  `operation` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

/*Data for the table `product_option_value` */

insert  into `product_option_value`(`id`,`product_id`,`value_id`,`operation`,`price`) values (36,4,29,'+','66'),(35,1,25,'+','22'),(33,4,23,'+','11'),(34,1,27,'+','11'),(32,4,19,'+','55'),(31,4,17,'+','44'),(30,4,21,'+','33'),(41,1,29,'+','22'),(40,4,25,'+','1'),(39,4,27,'+','22'),(38,4,31,'+','11'),(37,4,33,'+','22'),(42,1,31,'+','11'),(43,1,33,'+','16');

/*Table structure for table `settings` */

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `meta_tags` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `google_analytics_code` varchar(100) DEFAULT NULL,
  `piwik_id` varchar(100) DEFAULT NULL,
  `domain` varchar(100) DEFAULT NULL,
  `social_facebook` varchar(255) DEFAULT NULL,
  `social_twitter` varchar(255) DEFAULT NULL,
  `social_linkedin` varchar(255) DEFAULT NULL,
  `social_gplus` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `settings` */

insert  into `settings`(`id`,`title`,`description`,`meta_tags`,`name`,`owner`,`address`,`email`,`telefon`,`logo`,`language`,`currency`,`google_analytics_code`,`piwik_id`,`domain`,`social_facebook`,`social_twitter`,`social_linkedin`,`social_gplus`) values (1,'Shoppingcorp.com Shop','Shop Shoppingcorp.com  - Top Sellers and Best Sellers on Sale Today - Shoppingcorp.com  Shop','shop,  Shoppingcorp.com ','Shoppingcorp.com ','Contrib/Vnoc','5455 N. Federal Highway Suite 3 Boca Raton, Fl 33487','social@shoppingcorp.com','+13174143751','https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-shoptangerine1.png','2','1','UA-47677208-16','5616','shoppingcorp.com','https://www.facebook.com/Contrib.Official','https://twitter.com/contrib','https://www.linkedin.com/company/contrib-com','https://plus.google.com/u/1/105733839510740941811/');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
