<?php
//ini_set('display_errors', 'On');
//error_reporting(E_ALL);
$file_config = 'config-framework.php';
$currentconfig = file_get_contents($file_config);

 global $title, $logo, $desc, $bg_type, $bg_color, $bg_image, $keywords,
	$image_style, $about_desc, $domain,$domain_affiliate_link, $partners,$cpanel_username,$cpanel_password, $related_domains,
	$social_fb,$social_gplus,$social_twitter,$social_twitter,$social_linkedin,$footer_html;

$headers = array('Accept: application/json');
function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null){
	if (($method == 'PUT') || ($method=='DELETE')){
		$headers[] = 'X-HTTP-Method-Override: '.$method;
	}

	$handle = curl_init();
	curl_setopt($handle, CURLOPT_URL, $url);
	curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
	if ($user){
		curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
	} 

	switch($method){
		case 'GET':
		break;
		case 'POST':
		curl_setopt($handle, CURLOPT_POST, true);
		curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
		break;
		case 'PUT':
		curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
		curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
		break;
		case 'DELETE':
		curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
		break;
	}
	$response = curl_exec($handle);
	return $response;
}
$api_url = "http://api2.contrib.co/request/";
$domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
$key = md5('vnoc.com');
	
$explodedomain = explode('.', $domain);
$subname = $explodedomain[0];
	
$filename = 'import_sql.php';


//if ($_SERVER["HTTP_HOST"]!='contrib.com' && !file_exists('config-framework.php')) {
	if ($_SERVER["HTTP_HOST"]!='contrib.com' && empty($currentconfig)) {

    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $error = 0;
    
    if(stristr($domain,'~') ===FALSE) {
    	$domain = $_SERVER["HTTP_HOST"];
      $domain = str_replace("http://","",$domain);
    	$domain = str_replace("www.","",$domain);
    	$key = md5($domain);
    }else {
       $key = md5('vnoc.com');
       $d = explode('~',$domain);
       $user = str_replace('/','',$d[1]);
       
       $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
       $result =  createApiCall($url, 'GET', $headers, array());
       $data_domain = json_decode($result,true);
       $domain =   $data_domain['data']['domain'];
    }
	
      $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
	  $data_domain = NULL;
	  while ($data_domain == NULL){ 
	    $result = createApiCall($url, 'GET', $headers, array());
	    $data_domain = json_decode($result,true);
	  }

    if ($data_domain['success']){

    	$domainid = $data_domain['data']['DomainId'];
    	$domainname = $data_domain['data']['DomainName'];
    	$memberid = $data_domain['data']['MemberId'];
    	$title = $data_domain['data']['Title'];
		if(empty($title)) $title = ucwords($domainname);
    	$logo = $data_domain['data']['Logo'];
    	$desc = $data_domain['data']['Description'];
    	$account_ga = $data_domain['data']['AccountGA'];
    	$keywords = $data_domain['data']['Keywords'];
    	$desc = stripslashes(str_replace('\n','<br>',$desc));

        $url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
        $result2 = createApiCall($url2, 'GET', $headers, array());
        $data_domain2 = json_decode($result2,true);

    	if ($data_domain2['success']) {
    		 $keywords = $data_domain2['data']['keywords'];
         if (isset($data_domain2['data']['footer_html'])){
           $footer_html = $data_domain2['data']['footer_html'];
         }else {
           $footer_html= "";
         }
         
         
    	}

	}else{
		$error++;
	}

	$url = $api_url.'getcpanelinfo?domain_id='.$domainid.'&key='.$key;
	$result =  createApiCall($url, 'GET', $headers, array());
	$data_cpanel = json_decode($result,true);
	
	if($data_cpanel['success']){
		$DomainId = $data_cpanel['data']['DomainId'];
		$cpanel_username = $data_cpanel['data']['Username'];
		$cpanel_password = $data_cpanel['data']['Password'];
		$ServerId = $data_cpanel['data']['ServerId'];
	}else {
    	$error++;
    }
	
	//get related domains
	$related_domains = array();
    	$url = $api_url.'getrelateddomains?domain='.$domain.'&limit=10';
      $result = createApiCall($url, 'GET', $headers, array());
      $data_domains = json_decode($result,true);
    	if ($data_domains['success']){
    		$related_domains = $data_domains['data'];
    	}
	
   $url3 = $api_url.'GetPiwikId?domain='.$domain.'&key='.$key;
   $result3 = createApiCall($url3, 'GET', $headers, array());
   $data_domain3 = json_decode($result3,true);
   $piwik_id = $data_domain3['data']['idsite'];
      
	  $sitename =  $domain;
	//get monetize ads from vnoc
    $url = $api_url.'getbannercode?d='.$domain.'&p=footer';
    $result = createApiCall($url, 'GET', $headers, array());
    $data_ads = json_decode($result,true);
    $footer_banner = html_entity_decode(base64_decode($data_ads['data']['content']));
    
    //get domain affiliate id
    $url = $api_url.'getdomainaffiliateid?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $data_domain_affiliate = json_decode($result,true);
    if ($data_domain_affiliate['success']){
    	$domain_affiliate_id = $data_domain_affiliate['data']['affiliate_id'];
    }else {
    	$domain_affiliate_id = '391'; //contrib.com affiliate id
    }
    $domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$domain;

	if ($error > 0){
		echo "<center><h3>Please wait while page is loading...</h3></center>";
		if(!file_exists($filename)){
			echo "<center><h3>Please wait while page is loading...</h3>
				<br><small>Server Time:".date('m/d/Y h:i:s a', time())."</small>
			</center>";
			$page = $_SERVER['PHP_SELF'];
			$sec = "5";
			header("Refresh: $sec; url=$page");
		}
		exit;
	}
	
	$part = explode('.',$domain);
	if (count($part)>2){
		$flag_sub = 1;
	}else {
		$flag_sub = 0;
	}

	  // if no keywords presented at domaininfo -> process this
	  if ($keywords == "") {
	      $api1_url = 'http://api1.contrib.co/request/';
	      $url = $api1_url.'DomainKeywords?key='.$key.'&domain='.$domain;
	      $result = createApiCall($url, 'GET', $headers, array());
	      $res_keywords = json_decode($result,true);
	      $keywords = $res_keywords['data']['keywords'];
	  }

    	$url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=fb';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_fb = $social_result['data']['profile_url'];
	  }else {
	    $social_fb = "";
	  } 

	    $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=gplus';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_gplus  = $social_result['data']['profile_url'];
	  }else {
	    $social_gplus = "";
	  } 

	    $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=twitter';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_twitter  = $social_result['data']['profile_url'];
	  }else {
	    $social_twitter = "";
	  } 

	   $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=linkedin';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_linkedin  = $social_result['data']['profile_url'];
	  }else {
	      $social_linkedin = "";
	  } 

	  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=gtube';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_gtube  = $social_result['data']['profile_url'];
	  }else {
	      $social_gtube = "";
	  }  
	      


	  $db=$cpanel_username."_shop";  			//DOMAIN

	  if(strlen($cpanel_username)>8){
			$db = substr($cpanel_username, 0, 8).'_shop';
	   }
		  


	$file='<?php '.
		'$domain="'.$domain.'"; '.
		'$db="'.$db.'"; '.
		'$sitename="'.$sitename.'"; '.
		'$cpanel_username="'.$cpanel_username.'"; '.
		'$cpanel_password="'.$cpanel_password.'"; '.
		'$title="'.$title.'"; '.
		'$account_ga="'.$account_ga.'"; '.
  		'$piwik_id="'.$piwik_id.'"; '.
		'$desc="'.$desc.'"; '.
		'$keywords="'.$keywords.'"; '.
        '$footer_html="'.$footer_html.'"; '.
		'$social_fb="'.$social_fb.'"; '.
		'$social_gplus="'.$social_gplus.'"; '.
		'$social_twitter="'.$social_twitter.'"; '.
		'$social_gtube="'.$social_gtube.'"; '.
		'$social_linkedin="'.$social_linkedin.'"; '.
		'$memberid="'.$memberid.'"; '.
		'$domainname="'.$domainname.'"; '.
		'$domainid="'.$domainid.'"; '.
		'$domain_affiliate_link="'.$domain_affiliate_link.'"; '.
		'$footer_banner="'.$footer_banner.'"; '.
		'$related_domains='.var_export($related_domains, true).';'.
		'?>';
	//file_put_contents('config-framework.php', $file);
	file_put_contents($file_config, $file);
	
	if(!file_exists($filename)){//update only
		
		$bg_images = array(
'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-shop-first.jpeg',
'https://rdbuploads.s3.amazonaws.com/backgrounds/pexels-photo-291762.jpeg',
'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-phones.jpeg',
'https://rdbuploads.s3.amazonaws.com/backgrounds/bg-starwars.jpeg'
); 

$rand_keys = array_rand($bg_images, 3);
		
		$conn = new PDO("mysql:host=$host;dbname=$db", $cpanel_username, $cpanel_password);
	 
		$sql = "Update `settings` set `title`=?,`description`=?,`meta_tags`=?, `name`=?,"; 
		$sql .=" `owner`=?,`email`=?,`logo`=?,`google_analytics_code`=? ,`piwik_id`=?, `domain`=?,";
		$sql .= "`social_facebook`=?, `social_twitter`=?, `social_linkedin`=?, `social_gplus`=? where `id`=?";
		$q = $conn->prepare($sql);
		$q->execute(array($domain.' Shop','Shop '.$domain.'  - Top Sellers and Best Sellers on Sale Today - '.$domain.'  Shop',
		$keywords,$domain.' Shop',$domain,'admin@domaindirectory.com',$logo,$account_ga,$piwik_id,$domain,$social_fb,$social_twitter,
		$social_linkedin,$social_gplus,1
		)); 
		
		$sql = "Update modules set image_url=? where id=?";
$q = $conn->prepare($sql);
$q->execute(array($bg_images[$rand_keys[0]],35));

$sql = "Update modules set image_url=? where id=?";
$q = $conn->prepare($sql);
$q->execute(array($bg_images[$rand_keys[1]],36));

$html = '<h3 class="">
                                Huge Sale
                                
                            </h3>
<p class="">on Toys</p>
                           
                            <a href="/" class="btn btn-danger btn-lg">
                                SHOP NOW
                            </a>';
$sql = "Update modules set image_url=?,details=? where id=?";
$q = $conn->prepare($sql);
$q->execute(array('https://rdbuploads.s3.amazonaws.com/backgrounds/still-life-teddy-white-read.jpg',$html,37));

	}
}

//include 'config-framework.php';

include $file_config;

if(empty($cpanel_username)){
	header("Refresh:0");
	exit();
}
//partners 
$url = $api_url.'getpartners?domain='.$domain.'&key='.$key;
$result = createApiCall($url, 'GET', $headers, array());
$partners_result = json_decode($result,true);
$partners = array();  
if ($partners_result['success']){
	$partners = $partners_result;
}

if (file_exists($filename)) {
    include('import_sql.php'); //creates DB
	unlink($filename); //deletes file
	
}


?>