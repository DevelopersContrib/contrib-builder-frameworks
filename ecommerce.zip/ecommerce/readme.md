KoCART
============================
Codeigniter Based Open Source E-Commerce System

##### Note
Demo : http://www.jolyjokerz.com
Admin Panel Demo : http://www.jolyjokerz.com/admin/dashboard
Admin Username : demo
Admin Password : demo

##### Note
Admin Panel Template : http://startbootstrap.com/template-overviews/sb-admin/

Homepage Template    : http://startbootstrap.com/template-overviews/shop-homepage/

Requirements
------------- 
    * PHP, MySQL
	
	
	Roadway
-------------
 
1. Inovice Print, Show, Send Operations
2. Account Page(Orders, Account Detail, ..)

Maybe Later (I have no experience)
-------------------------
1. Payment Methods.
2. Shipping Methods.


    
