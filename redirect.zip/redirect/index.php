<?php
include "includes/config.php";
if ($redirect_url==""){
	$redirect_url = "contrib.com/signup/firststep?domain=".$domain;
}
header('Location: http://'.$redirect_url,true,302);
exit;