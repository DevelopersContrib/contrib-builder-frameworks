<?php
function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}


    $api_url = "http://api2.contrib.com/request/";
    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $key = md5('vnoc.com');

if (!file_exists('./includes/config-framework.php')) {
    $file = file_get_contents('./includes/config-template.php');
    $api_url = "http://api2.contrib.com/request/";
    $headers = array('Accept: application/json');
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    $error = 0;
    
    if(stristr($domain,'~') ===FALSE) {
    	$domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("http://","",$domain);
    	$domain = str_replace("www.","",$domain);
    	$key = md5($domain);
    }else {
       $key = md5('vnoc.com');
       $d = explode('~',$domain);
       $user = str_replace('/','',$d[1]);
       
       $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
       $result =  createApiCall($url, 'GET', $headers, array());
       $data_domain = json_decode($result,true);
       $domain =   $data_domain['data']['domain'];
       
    }
    
    $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $data_domain = json_decode($result,true);
    
    if ($data_domain['success']){
    	$domainid = $data_domain['data']['DomainId'];
    	$domainname = $data_domain['data']['DomainName'];
    	
      $url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
      $result2 = createApiCall($url2, 'GET', $headers, array());
      $data_domain2 = json_decode($result2,true);
      	
      if($data_domain2['success']){
    		$redirect_url = $data_domain2['data']['domain_where_to_redirect_'];
            $redirect_url = str_replace('http://','',$redirect_url);
				$redirect_url = str_replace('www.','',$redirect_url);
				if ($redirect_url == "contrib.com"){
					 $redirect_url = "contrib.com/signup/firststep?domain=".$domain;
				}	
    	}else{
    		$error++;
    	}
    			
    }else {
    	$error++;
    }
    
    
  //create file
  $file = str_replace('{{DOMAIN}}',$domain , $file);
  $file = str_replace('{{DOMAIN_ID}}',$domainid , $file);
  $file = str_replace('{{URL}}',$redirect_url, $file);
  file_put_contents('./includes/config-framework.php', $file);
}
	include "./includes/config-framework.php";
?>