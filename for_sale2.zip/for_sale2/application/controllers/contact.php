<?php
/**
 *
 */
class Contact extends Controller {
  
  function index() 
  {
   		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();	
		$company = $api->getcompany_listI();
		$title = 'Contact Us';
		$template = $this->loadView('contact');
		$template->set('title',$title);	
		$template->set('info',$info);
		$template->set('company',$company);
		$template->render();
	}
} //end of class

?>
