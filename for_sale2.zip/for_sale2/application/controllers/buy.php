<?php
/**
 *
 */
class Buy extends Controller {
  
  function index() 
  {
   		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();	
		$countries = $api->getcountries();
		$roles = $api->getroles();
		$company = $api->getcompany_listI();
		$related_domains = $api->relatedsiteswithlogo();
		$title = 'Buy';
		$template = $this->loadView('buy');
		$template->set('title',$title);	
		$template->set('related_domains',$related_domains);
		$template->set('countries',$countries);
		$template->set('roles',$roles);
		$template->set('info', $info);
		$template->set('company',$company);
		$template->render();
	}
} //end of class

?>
