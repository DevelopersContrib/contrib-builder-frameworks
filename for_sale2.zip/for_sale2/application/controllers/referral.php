<?php
/**
 *
 */
class Referral extends Controller {
  
  function index() 
  {
   		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');	
		$info = $api->getdomaininfo();	
		$title = 'Referral';
		$template = $this->loadView('referral');
		$template->set('title',$title);	
		$template->set('info',$info);
		$template->render();
	}
} //end of class

?>
