<?php
/**
 *
 */
class Staffing extends Controller {
  
  function index() 
  {
   		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();	
		$title = 'Staffing';
		$template = $this->loadView('staffing');
		$template->set('title',$title);	
		$template->set('info', $info);
		$template->render();
	}
} //end of class

?>
