<?php
/**
 *
 */
class Terms extends Controller {
  
  function index() 
  {
   		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');	
		$title = 'Terms of Service';
		$info = $api->getdomaininfo();	
		$template = $this->loadView('terms');
		$template->set('title',$title);	
		$template->set('info',$info);
		$template->render();
	}
} //end of class

?>
