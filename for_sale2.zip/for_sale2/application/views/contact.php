<?php include('includes/header.php');?>

<style>
.pc-box {
    background: #fafafa;
    padding: 10px 30px 30px 30px;
    margin-bottom: 50px;
}
.breadcrumb {
    margin: 60px 0 0px 0;
}
.navbar-inverse {
    background: #000 !important;
}
</style>
<body>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <!-- container -->
    <div class="container">
        <div class="row">
        <div class="col-md-8 col-md-offset-2 pc-box">
               <h3 class="text-center">Contact <? echo $info['domain']?></h3>
          <hr>
              <script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?=$info['domain']?>"></script>
        </div>
        </div>
    </div>

   <?php include('includes/footer.php'); ?>
