<?php include('includes/header.php'); ?>
		<div class="section-container">
			<div class="container section-bg-white">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 class="ttle-bg-danger"><?php echo ucfirst($info['domain']); ?> is for sale</h1>
						 <br />
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<div class="row">
									<div class="col-md-10">
										<div class="border-radius-boxed-bg">
											<span class="buy-now-head hide">Buy Now: $1695</span>
											<div class="form-group">
												<a href="/buy" class="btn btn-lg btn-danger btn-cust-danger">
													Make an Offer
												</a>
											</div>
											<ul class="cust-ul-dot">
											<h4>Invest in a premium domain<br/>
                                                 name to be your brand.</h4>
												
											</ul>
										</div>
									</div>
									<div class="col-md-1">
										<span class="meta-span">
											OR
										</span>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="border-radius-boxed-bg">
									<span class="buy-now-head hide">Finance This Domain: $1695</span>
									<h4 class="text-warning fnt-bold hide">
										12 monthly payments of $142
									</h4>
									<div class="form-group">
										<a href="/partnership" class="btn btn-lg btn-danger btn-cust-danger">
											Submit Partnership
										</a>
									</div>
									<ul class="cust-ul-dot">
									<h4>
										Get a premium domain name<br/>
                                        without the premium price tag.
									</h4>
										
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12 text-center">
						<p class="talk-to-expert"> Talk to a domain expert: <span>1-303-893-0552</span> </p>
						<h2 class="ttle-blck-bg fnt-bold">Hurry - once it's sold this opportunity will be gone!</h2>
						<div class="row">
							<div class="col-md-offset-1 col-md-10">
								<p class="fnt-17 text-left">
									Besides being memorable, .com domains are unique: This is the one and only .com name of it's kind. Other extensions usually just drive traffic to their .com counterparts. To learn more about premium .com domain valuations, watch the video below:
								</p>
								<br>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-offset-3 col-md-8">
								<iframe src="https://www.youtube.com/embed/9wCygJtW_SQ?rel=0&amp;autoplay=1&amp;showinfo=0&amp;controls=0" allowfullscreen="" width="480" height="270" frameborder="0"></iframe>
							</div>
						</div>
						<div class="text-center">
							<h4 class="fnt-bold">
								Turbocharge your Web site. Watch our video to learn how.
							</h4>
						</div>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<h2>Improves Your Web Presence</h2>
						<h4 class="text-muted">Get noticed online with a great domain name</h4>
						<img class="pull-right" alt="" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/forsale-template/crown.jpg" width="180" height="76">
						<p class="fnt-17">73% of all domains registered on the Web are .coms. The reason is simple: .com is the where most of Web traffic happens. Owning a premium .com gives you great benefits including better SEO, name recognition, and providing your site with a sense of authority.</p>
						<br>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<div class="text-block">
							<h2 class="fnt-bold">
								Here's What Others Are Saying
							</h2>
							<h4 class="fnt-bold text-muted">Since 2005, we've helped thousands of people get the perfect domain name</h4>
							<br>
						</div>
						<ul class="list-unstyled star-ul-rating">
							<li>
								<b class="stars-container"></b>
								Easy to purchase and easy to configure. Would recommended any all.
								<em>- Mohammad Rahman, <a href="#" class="star-link-a">HyperStructure.com</a>, 8/12/2016</em>
							</li>
							<li>
								<b class="stars-container"></b>
								HugeDomains.com is right for buy premium Domains, hassle free, zero interest rate financing, get your dream domains and very reliable, highly recommend. 
								<em>- Srini Chakwal, <a href="#" class="star-link-a">CrowdNext.com</a>, 8/11/2016</em>
							</li>
							<li>
								<b class="stars-container"></b>
								Great 
								<em>- GUY HOQUET, <a href="#" class="star-link-a">MonAgentPrive.com</a>, 8/10/2016</em>
							</li>
						</ul>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-8 text-right">
								<h3 class="red-text"><?php echo ucfirst($info['domain']); ?></h3>
							</div>
							<div class="col-md-4 text-left">
								<div class="form-group">
									<a href="http://hugedomains.com/" class="btn btn-lg btn-danger btn-cust-danger">
										Buy Now
									</a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-7 text-right">
								<h2 class="fnt-bold no-mtop">
									Own this domain today
								</h2>
							</div>
							<div class="col-md-5 text-left hide">
								<p class="meta-price">
									Our Price:
									<span class="text-danger fnt-bold">
										$1,695
									</span>
									<small class="text-muted">
										(USD)
									</small>
								</p>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<br>
						<div class="row">
							<div class="col-md-6">
								<div class="box4">
									<h1 class="fnt-bold cust-h1">
										Questions? 
									</h1>
									<span class="cust-stack">
										<i class="fa fa-volume-control-phone"></i>
									</span>
									<h4 class="fnt-bold text-muted">
										Speak with a domain specialist!
									</h4>
									<ul class="list-inline">
										<li>
											<h4 class="fnt-bold text-muted">
												Call us:
											</h4>
										</li>
										<li>
											<h2 class="fnt-bold cust-h1">
												1-303-893-0552
											</h2>
										</li>
									</ul>
									<hr class="hr-gray">
									<h3 class="cust-h1 text-muted">
										<span class="cust-stack">
											<i class="fa fa-info"></i>
										</span>
										Visit our
										<a href="/contact">
											Help Center
										</a>
										for answers to
										Frequently Asked Questions
									</h3>
									<a href="/contact">Click here.</a>
								</div>
							</div>
							<div class="col-md-6">
								<div class="box4">
									<h4 class="fnt-bold">
										Other Domains You Might Like
									</h4>
									<hr class="hr-gray">
									<ul class="list-unstyled section-links-out">
									<?php $counter = 0; ?>
									<?php foreach ($related_domains as $related_domainss): ?>
										<li>
											<a href="http://www.<?php echo $related_domainss['domain_name']?>/" class="a-links-out"><?php echo ucfirst($related_domainss['domain_name']); ?></a>
											<b class="hide">$20,800</b>
											<em></em>
										</li>
										<?php if ($counter++ == 7) break; ?>
									<?php endforeach ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
			<?php include('includes/footer.php'); ?>

	
