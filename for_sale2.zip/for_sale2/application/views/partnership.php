<?php include('includes/header.php'); ?>
		<div class="section-container">
			<div class="container section-bg-white">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 class="ttle-bg-danger"><?php echo ucfirst($info['domain']); ?> is for sale</h1>
						 <br />
					</div>
						<div class="loading hide">Loading&#8230;</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<div class="border-radius-boxed-bg">
									<p class="talk-to-expert talk-to-expert-2"> Talk to a domain expert: <span>1-303-893-0552</span> </p>
									<h2 class="ttle-blck-bg fnt-bold">Hurry - once it's sold this opportunity will be gone!</h2>
									<p class="fnt-17 text-left">
										Besides being memorable, .com domains are unique: This is the one and only .com name of it's kind. Other extensions usually just drive traffic to their .com counterparts. To learn more about premium .com domain valuations, watch the video below:
									</p>
									<br>
									<iframe src="https://www.youtube.com/embed/9wCygJtW_SQ?rel=0&amp;autoplay=1&amp;showinfo=0&amp;controls=0" allowfullscreen="" width="100%" height="270" frameborder="0"></iframe>
									<div class="text-center">
										<h4 class="fnt-bold">
											Turbocharge your Web site. Watch our video to learn how.
										</h4>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="border-radius-boxed-bg">
									<div class="" id="first_form">
										<center><span class="buy-now-head buy-now-head-2">Partner with <?php echo ucfirst($info['domain']);?> today</span>
										<h4 class="text-warning fnt-bold">
											Create your Profile to make an offer
										</h4>
										</center>
										<div class="form-group">
												<select id="partner_type" name="partner_type" class="form-control" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Select Partnership">
													<option value="">Partnership Type</option>
													<option value="Sponsorship Marketing Partnerships">Sponsorship Marketing Partnerships</option>
													<option value="Distribution Marketing Partnerships">Distribution Marketing Partnerships</option>
													<option value="Affiliate Marketing Partnerships">Affiliate Marketing Partnerships</option>
													<option value="Added Value Marketing Partnerships">Added Value Marketing Partnerships</option>
												</select>
										</div>
										<div class="form-group">
											<input type="text" id="name" class="form-control" placeholder="First Name" />
										</div>
										<div class="form-group">
											<input type="text" id="lname" class="form-control" placeholder="Last Name" />
										</div>
										<div class="form-group">
											<input type="text" id="email" class="form-control" placeholder="Email" />
										</div>
										<div class="form-group">
											<input type="password" id="password" class="form-control" placeholder="Password" />
										</div>
										<div class="form-group">
											<textarea rows="5" id="message" placeholder="Message" class="form-control"></textarea>
										</div>
										<div class="bp-alert" id="erroralert" style="display:none"></div>	
										<div class="form-group">
											<a href="javascript:void(0);" id="next" class="btn btn-lg btn-danger btn-cust-danger">
												Next
											</a>
										</div>
									
									</div>
									<div class="second_form hide">
										<center><span class="buy-now-head buy-now-head-2">Partner with <?php echo ucfirst($info['domain']);?> today</span>
										<h4 class="text-warning fnt-bold">
											Create your Profile to make an offer
										</h4>
										</center>
										<div class="form-group">
											<input type="text" id="website" class="form-control" placeholder="Website" />
										</div>
										<div class="form-group">
											<input type="text" id="state" class="form-control" placeholder="State" />
										</div>
										<div class="form-group">
											<input type="text" id="company" class="form-control" placeholder="Company" />
										</div>
										<div class="form-group">
											<select name="country" id="country" class="form-control">
											<?php foreach ($countries as $country): ?>
												<option value="<?php echo $country['country_id']; ?>"><?php echo $country['name']; ?></option>
											<?php endforeach ?>
											</select>
										</div>
										<div class="form-group">
											<input type="text" id="phone" class="form-control" placeholder="Phone" />
										</div>
										<div class="form-group">
											<input type="text" id="zip" class="form-control" placeholder="Zip" />
										</div>
										<div class="form-group">
											<input type="text" id="address" class="form-control" placeholder="Address" />
										</div>
										<div class="form-group">
											<input type="text" id="city" class="form-control" placeholder="City" />
										</div>
										<div class="bp-alert" id="erroralertnextpage" style="display:none"></div>
										<div class="form-group">
											<a href="javascript:void(0);" id="next_offer" class="btn btn-lg btn-danger btn-cust-danger">
												Next
											</a>
										</div>
									</div>
									<div class="third_form hide">
									<center>
										<h2>Complete your offer </h2><h4 class="text-warning fnt-bold">Please complete your profile in order to present your offer to the domain owner.*</h4></center>
											<div class="form-group">
												<input type="text" id="company_title" class="form-control" placeholder="Company Title" />
											</div>
												<div class="form-group">
												<input type="text" id="company_description" class="form-control" placeholder="Company Description" />
											</div>
											<div class="form-group">
												<input type="text" id="company_link" class="form-control" placeholder="Company Link" />
											</div>
											<div class="form-group">
												<input type="text" id="company_image" class="form-control" placeholder="Company Image" />
											</div>
												<div class="form-group">
												<p>By clicking the button below, I understand that the offer that I am about to submit is binding and I agree to Ecorp domain name sales and rental terms.</p>
											</div>
											<div class="bp-alert" id="erroralertlastpage" style="display:none"></div>
												<div class="form-group">
												<a href="javascript:void(0);" id="submit" class="btn btn-lg btn-danger btn-cust-danger">
													Complete your Offer
												</a>
											</div>
									</div>
									<div class="hide" id="thankyou">
										<img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" style="width:250px; margin:0px auto;">
										<h2 class="text-center">for submitting your offer.</h2>
										<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> You will be receiving three (3)-emails from Contrib.</h4>
										<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> Please check your spam box for safe measure.</h4>
										<div class="clearfix"><br></div>
										<div class="contrib-box-o">
											<p class="text-center">Contrib is our contribution platform and it allows us to get people to help contribute, make offer or partner with premium world class brands. You could check your Offer submission in your <br><b>"My Offers Contrib App"</b>.</p>
											<a href=""><h4 class="text-center"><i class="fa fa-envelope"></i> Please check your email for your Contrib access.</h4></a>
										</div>
										<div class="clearfix"><br></div>
										<div class="row">
											<div class="contrib-box-in">
												<h2 class="text-center">How It Works?</h2>
												<div class="col-md-4 text-center">
													<h3><i class="fa fa-search"></i><br>Step 1</h3>
													<h4>Browse the Marketplace</h4>
													<p>Browse the marketplace and search for sites to submit offers. </p>
												</div>
												<div class="col-md-4 text-center">
													<h3><i class="fa fa-file-text-o"></i><br>Step 2</h3>
													<h4>Submit an Offer</h4>
													<p>Click on sumbit offer and fill up the form.</p>
												</div>
												<div class="col-md-4 text-center">
													<h3><i class="fa fa-desktop"></i><br>Step 3</h3>
													<h4>View Offers</h4>
													<p>View all your offer applications that you have submitted to here. </p>
												</div>
												<div class="clearfix"><br></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<h2>Improves Your Web Presence</h2>
						<h4 class="text-muted">Get noticed online with a great domain name</h4>
						<img class="pull-right" alt="" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/forsale-template/crown.jpg" width="180" height="76">
						<p class="fnt-17">73% of all domains registered on the Web are .coms. The reason is simple: .com is the where most of Web traffic happens. Owning a premium .com gives you great benefits including better SEO, name recognition, and providing your site with a sense of authority.</p>
						<br>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<div class="text-block">
							<h2 class="fnt-bold">
								Here's What Others Are Saying
							</h2>
							<h4 class="fnt-bold text-muted">Since 2005, we've helped thousands of people get the perfect domain name</h4>
							<br>
						</div>
						<ul class="list-unstyled star-ul-rating">
							<li>
								<b class="stars-container"></b>
								Easy to purchase and easy to configure. Would recommended any all.
								<em>- Mohammad Rahman, <a href="#" class="star-link-a">HyperStructure.com</a>, 8/12/2016</em>
							</li>
							<li>
								<b class="stars-container"></b>
								HugeDomains.com is right for buy premium Domains, hassle free, zero interest rate financing, get your dream domains and very reliable, highly recommend. 
								<em>- Srini Chakwal, <a href="#" class="star-link-a">CrowdNext.com</a>, 8/11/2016</em>
							</li>
							<li>
								<b class="stars-container"></b>
								Great 
								<em>- GUY HOQUET, <a href="#" class="star-link-a">MonAgentPrive.com</a>, 8/10/2016</em>
							</li>
						</ul>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-8 text-right">
								<h3 class="red-text"><?php echo ucfirst($info['domain']); ?></h3>
							</div>
							<div class="col-md-4 text-left">
								<div class="form-group">
									<a href="/buy" class="btn btn-lg btn-danger btn-cust-danger">
										Buy Now
									</a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-7 text-right">
								<h2 class="fnt-bold no-mtop">
									Own this domain today
								</h2>
							</div>
							<div class="col-md-5 text-left hide">
								<p class="meta-price">
									Our Price:
									<span class="text-danger fnt-bold">
										$1,695
									</span>
									<small class="text-muted">
										(USD)
									</small>
								</p>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<br>
						<div class="row">
							<div class="col-md-6">
								<div class="box4">
									<h1 class="fnt-bold cust-h1">
										Questions? 
									</h1>
									<span class="cust-stack">
										<i class="fa fa-volume-control-phone"></i>
									</span>
									<h4 class="fnt-bold text-muted">
										Speak with a domain specialist!
									</h4>
									<ul class="list-inline">
										<li>
											<h4 class="fnt-bold text-muted">
												Call us:
											</h4>
										</li>
										<li>
											<h2 class="fnt-bold cust-h1">
												1-303-893-0552
											</h2>
										</li>
									</ul>
									<hr class="hr-gray">
									<h3 class="cust-h1 text-muted">
										<span class="cust-stack">
											<i class="fa fa-info"></i>
										</span>
										Visit our
										<a href="/contact">
											Help Center
										</a>
										for answers to
										Frequently Asked Questions
									</h3>
									<a href="/contact">Click here.</a>
								</div>
							</div>
							<div class="col-md-6">
								<div class="box4">
									<h4 class="fnt-bold">
										Other Domains You Might Like
									</h4>
									<hr class="hr-gray">
									<ul class="list-unstyled section-links-out">
									<?php $counter = 0; ?>
									<?php foreach ($related_domains as $related_domainss): ?>
										<li>
											<a href="http://www.<?php echo $related_domainss['domain_name']?>/" class="a-links-out"><?php echo ucfirst($related_domainss['domain_name']); ?></a>
											<b class="hide">$20,800</b>
											<em></em>
										</li>
										<?php if ($counter++ == 7) break; ?>
									<?php endforeach ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php include('includes/footer.php'); ?>

<script type="text/javascript">

  $(document).ready(function() {

		 $("#phone").keydown(function (e) {
           		restrict(e);
         });
         $('#amount').keydown(function (e) {
          	 	restrict(e);
        });

         $('#next').click(function(){

        var partner_type = $('#partner_type').val();
		var fname = $('#name').val();
		var lname = $('#lname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var numeric = /^[0-9]+$/;
		var domain = '<?php echo $info['domain']?>';
		
		if(partner_type == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Partner type should not be blank</p>');
			$('#partner_type').focus();
			
		}else if(fname == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >First name should not be blank</p>');
			$('#name').focus();
			
		}else if(email == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >email should not be blank</p>');
			$('#email').focus();
			
		}else if(password == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should not be blank</p>');
			$('#password').focus();
			
		}else if(password.length < 5){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should be more than 5 characters</p>');
			$('#password').focus();
		}else if(message == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >message should not be blank</p>');
			$('#message').focus();
		}else if(!emailfilter.test(email)){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >invalid email</p>');
			$('#email').focus();
		}else if(lname == ''){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Last name should not be blank</p>');
			$('#lname').focus();
			
		}else{
         	$('#first_form').addClass('hide');
         	$('.second_form').removeClass('hide');
		}

    });

     $('#next_offer').click(function(){

        var state = $('#state').val();
		var company = $('#company').val();
		var phone = $('#phone').val();
		var zip = $('#zip').val();
		var country_id = $('#country').val();
		var country =   $("#country :selected").text();
		var address = $('#address').val();
		var city = $('#city').val();
		var numeric = /^[0-9]+$/;
		var website = $('#website').val();
		var url_check = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		
		
		if(state == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >State/Province should not be blank</p>');
			$('#state').focus();
			
		}else if(address == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Address should not be blank</p>');
			$('#address').focus();
			
		}else if(phone == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Phone should not be blank</p>');
			$('#phone').focus();
			
		}else if(city == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >City should not be blank</p>');
			$('#city').focus();
			
		}else if(company == ''){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Company should not be blank</p>');
			$('#company').focus();
			
		}else if(zip == ''){
			
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Zipcode should not be blank</p>');
			$('#zip').focus();
			
		}else if(!numeric.test(zip)){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Zip should be numbers only</p>');
			$('#zip').focus();
			
		}else if(website==""){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Website should be numbers only</p>');
			$('#website').focus();
			
		}else if(!url_check.test(website)){
			$('#erroralertnextpage').css('display','block');
			$('#erroralertnextpage').html('<p role="alert" class="alert alert-danger" >Website invalid</p>');
			$('#website').focus();
			
		}else{
			$('.second_form').addClass('hide');
         	$('.third_form').removeClass('hide');
		}
      
         });

         $('#submit').click(function(){

        var state = $('#state').val();
		var company = $('#company').val();
		var phone = $('#phone').val();
		var zip = $('#zip').val();
		var country_id = $('#country').val();
		var country =   $("#country :selected").text();
		var address = $('#address').val();
		var city = $('#city').val();
		var partner_type = $('#partner_type').val();
		var fname = $('#name').val();
		var lname = $('#lname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var domain = '<?php echo $info['domain']?>';
		var company_title = $('#company_title').val();
		var company_description = $('#company_description').val();
		var company_image = $('#company_image').val();
		var company_link = $('#company_link').val();
		var website = $('#website').val();
		var url_check = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		
		if(company_title == ""){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Company title should not be blank</p>');
			$('#company_title').focus();
			
		}else if(company_description == ""){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Company description should not be blank</p>');
			$('#company_description').focus();
			
		}else if(!url_check.test(company_link)){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Invalid url</p>');
			$('#zip').focus();
			
		}else if(company_link == ""){
			
			$('#erroralertlastpage').css('display','block');
			$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >Company link should not be blank</p>');
			$('#company_link').focus();
			
		}else{
			$('#submit').attr('disabled', 'disabled');
			$('.loading').removeClass('hide');
			$.post("http://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){
			
				if(data.status){
					
					$('#erroralertlastpage').css('display','block');
					$('#erroralertlastpage').html('<p role="alert" class="alert alert-danger" >* Email already have an account. *<a target="_top" href="http://www.contrib.com">Please LOGIN here.</a></p>');
					$('#submit').removeAttr('disabled', 'disabled');
					$('.loading').addClass('hide');

				}else{
					
					$.post("http://www.contrib.com/forms/save_partner",
							{
								city:city,
								company:company_title,
								companydesc:company_description,
								companyimage:company_image,	
								companyurl:company_link,
								country:country,
								country_id:country_id,
								domain:domain,
								email:email,
								exchange_url:'',
								firstname:fname,
								lastname:lname,
								message:message,
								partnertype:partner_type,	
								password:password,
								website:website
							
							},function(data){
								if(data.success){
									    sendOfferEmail(fname,email,domain);
									 	$('#thankyou').removeClass('hide');
         								$('.third_form').addClass('hide');
         								$('#thankyou').fadeIn();
         								$('.loading').addClass('hide');
								     	//$('#button_redirect').html('<a class="btn btn-success btn-lg btn-block" id="resend_email" href="http://www.contrib.com/account/autologinforms?email='+data.email+'&form=partnership">Go to your contrib account</a>');
								}
						});
						
					$.post("http://www.manage.vnoc.com/salesforce/addlead",
					{
						city:city,
						country:country,
						domain:domain,
						email:email,
						firstName:fname,
						form_type:'VNOC Partnership',
						lastName:lname,
						message:message,
						partner_type:partner_type,
						phone:phone,
						state:state,
						street:address,
						title:company_title,
						zip:zip
					});
					
				}
					
			})
		}

        
         });


	  function restrict(e)
      {
      	  // Allow: backspace, delete, tab, escape, enter and .
          if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
               // Allow: Ctrl+A, Command+A
              (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
               // Allow: home, end, left, right, down, up
              (e.keyCode >= 35 && e.keyCode <= 40)) {
                   // let it happen, don't do anything
                   return;
          }
          // Ensure that it is a number and stop the keypress
          if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
              e.preventDefault();
          }

      }

   });

	function sendOfferEmail(firstname,email,domain){
		$.post(
			'http://www.contrib.com/forms/autoresponderEmail',
			{ firstname:firstname,email:email,domain:domain,template_name:'Offer' },
			function(response){
				console.log(response.result);
			}
		);
	}

</script>

	
