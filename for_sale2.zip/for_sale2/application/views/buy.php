<?php include('includes/header.php'); ?>
		<div class="section-container">
			<div class="container section-bg-white">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 class="ttle-bg-danger"><?php echo ucfirst($info['domain']); ?> is for sale</h1>
						 <br />
					</div>
					<div class="loading hide">Loading&#8230;</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<div class="border-radius-boxed-bg">
									<p class="talk-to-expert talk-to-expert-2"> Talk to a domain expert: <span>1-303-893-0552</span> </p>
									<h2 class="ttle-blck-bg fnt-bold">Hurry - once it's sold this opportunity will be gone!</h2>
									<p class="fnt-17 text-left">
										Besides being memorable, .com domains are unique: This is the one and only .com name of it's kind. Other extensions usually just drive traffic to their .com counterparts. To learn more about premium .com domain valuations, watch the video below:
									</p>
									<br>
									<iframe src="https://www.youtube.com/embed/9wCygJtW_SQ?rel=0&amp;autoplay=1&amp;showinfo=0&amp;controls=0" allowfullscreen="" width="100%" height="270" frameborder="0"></iframe>
									<div class="text-center">
										<h4 class="fnt-bold">
											Turbocharge your Web site. Watch our video to learn how.
										</h4>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="border-radius-boxed-bg">
									<div class="" id="offerform">
									<center>
										<span class="buy-now-head buy-now-head-2">Purchase <?php echo ucfirst($info['domain']);?> today</span>
										<h4 class="text-warning fnt-bold">
											Create your Profile to make an offer
										</h4>
											</center>
										<div class="form-group">
											<div class="input-group">
												<span class="input-group-addon">$</span>
												<input id="amount" type="text" class="form-control">
											</div>
										</div>
										<div class="form-group">
											<input type="text" id="fname" class="form-control" placeholder="First Name" />
										</div>
										<div class="form-group">
											<input type="text" id="lname" class="form-control" placeholder="Last Name" />
										</div>
										<div class="form-group">
											<input type="text" id="email" class="form-control" placeholder="Email" />
										</div>
										<div class="form-group">
											<input type="password" id="password" class="form-control" placeholder="Password" />
										</div>
										<div class="form-group">
											<select name="country" id="country" class="form-control">
											<?php foreach ($countries as $country): ?>
												<option value="<?php echo $country['country_id']; ?>"><?php echo $country['name']; ?></option>
											<?php endforeach ?>
											</select>
										</div>
										<div class="form-group">
											<input type="text" id="phoneno" class="form-control" placeholder="Phone" />
										</div>
										<div class="form-group">
											<textarea rows="5" id="message" placeholder="Message" class="form-control"></textarea>
										</div>
				<div class="bp-alert" id="erroralert" style="display:none"></div>										<div class="form-group">
											<a href="javascript:void(0);" id="submit" class="btn btn-lg btn-danger btn-cust-danger">
												Submit
											</a>
										</div>
									</div>
									<div class="hide" id="thankyou">
										<img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" style="width:250px; margin:0px auto;">
										<h2 class="text-center">for submitting your offer.</h2>
										<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> You will be receiving three (3)-emails from Contrib.</h4>
										<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> Please check your spam box for safe measure.</h4>
										<div class="clearfix"><br></div>
										<div class="contrib-box-o">
											<p class="text-center">Contrib is our contribution platform and it allows us to get people to help contribute, make offer or partner with premium world class brands. You could check your Offer submission in your <br><b>"My Offers Contrib App"</b>.</p>
											<a href=""><h4 class="text-center"><i class="fa fa-envelope"></i> Please check your email for your Contrib access.</h4></a>
										</div>
										<div class="clearfix"><br></div>
										<div class="row">
											<div class="contrib-box-in">
												<h2 class="text-center">How It Works?</h2>
												<div class="col-md-4 text-center">
													<h3><i class="fa fa-search"></i><br>Step 1</h3>
													<h4>Browse the Marketplace</h4>
													<p>Browse the marketplace and search for sites to submit offers. </p>
												</div>
												<div class="col-md-4 text-center">
													<h3><i class="fa fa-file-text-o"></i><br>Step 2</h3>
													<h4>Submit an Offer</h4>
													<p>Click on sumbit offer and fill up the form.</p>
												</div>
												<div class="col-md-4 text-center">
													<h3><i class="fa fa-desktop"></i><br>Step 3</h3>
													<h4>View Offers</h4>
													<p>View all your offer applications that you have submitted to here. </p>
												</div>
												<div class="clearfix"><br></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<h2>Improves Your Web Presence</h2>
						<h4 class="text-muted">Get noticed online with a great domain name</h4>
						<img class="pull-right" alt="" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/forsale-template/crown.jpg" width="180" height="76">
						<p class="fnt-17">73% of all domains registered on the Web are .coms. The reason is simple: .com is the where most of Web traffic happens. Owning a premium .com gives you great benefits including better SEO, name recognition, and providing your site with a sense of authority.</p>
						<br>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<div class="text-block">
							<h2 class="fnt-bold">
								Here's What Others Are Saying
							</h2>
							<h4 class="fnt-bold text-muted">Since 2005, we've helped thousands of people get the perfect domain name</h4>
							<br>
						</div>
						<ul class="list-unstyled star-ul-rating">
							<li>
								<b class="stars-container"></b>
								Easy to purchase and easy to configure. Would recommended any all.
								<em>- Mohammad Rahman, <a href="#" class="star-link-a">HyperStructure.com</a>, 8/12/2016</em>
							</li>
							<li>
								<b class="stars-container"></b>
								HugeDomains.com is right for buy premium Domains, hassle free, zero interest rate financing, get your dream domains and very reliable, highly recommend. 
								<em>- Srini Chakwal, <a href="#" class="star-link-a">CrowdNext.com</a>, 8/11/2016</em>
							</li>
							<li>
								<b class="stars-container"></b>
								Great 
								<em>- GUY HOQUET, <a href="#" class="star-link-a">MonAgentPrive.com</a>, 8/10/2016</em>
							</li>
						</ul>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-8 text-right">
								<h3 class="red-text"><?php echo ucfirst($info['domain']); ?></h3>
							</div>
							<div class="col-md-4 text-left">
								<div class="form-group">
									<a href="/buy" class="btn btn-lg btn-danger btn-cust-danger">
										Buy Now
									</a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-7 text-right">
								<h2 class="fnt-bold no-mtop">
									Own this domain today
								</h2>
							</div>
							<div class="col-md-5 text-left hide">
								<p class="meta-price">
									Our Price:
									<span class="text-danger fnt-bold">
										$1,695
									</span>
									<small class="text-muted">
										(USD)
									</small>
								</p>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="hr_top"></div>
					</div>
					<div class="col-md-12">
						<br>
						<div class="row">
							<div class="col-md-6">
								<div class="box4">
									<h1 class="fnt-bold cust-h1">
										Questions? 
									</h1>
									<span class="cust-stack">
										<i class="fa fa-volume-control-phone"></i>
									</span>
									<h4 class="fnt-bold text-muted">
										Speak with a domain specialist!
									</h4>
									<ul class="list-inline">
										<li>
											<h4 class="fnt-bold text-muted">
												Call us:
											</h4>
										</li>
										<li>
											<h2 class="fnt-bold cust-h1">
												1-303-893-0552
											</h2>
										</li>
									</ul>
									<hr class="hr-gray">
									<h3 class="cust-h1 text-muted">
										<span class="cust-stack">
											<i class="fa fa-info"></i>
										</span>
										Visit our
										<a href="/contact">
											Help Center
										</a>
										for answers to
										Frequently Asked Questions
									</h3>
									<a href="/contact">Click here.</a>
								</div>
							</div>
							<div class="col-md-6">
								<div class="box4">
									<h4 class="fnt-bold">
										Other Domains You Might Like
									</h4>
									<hr class="hr-gray">
									<ul class="list-unstyled section-links-out">
									<?php $counter = 0; ?>
									<?php foreach ($related_domains as $related_domainss): ?>
										<li>
											<a href="http://www.<?php echo $related_domainss['domain_name']?>/" class="a-links-out"><?php echo ucfirst($related_domainss['domain_name']); ?></a>
											<b class="hide">$20,800</b>
											<em></em>
										</li>
										<?php if ($counter++ == 7) break; ?>
									<?php endforeach ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php include('includes/footer.php'); ?>

<script type="text/javascript">

  $(document).ready(function() {

		 $("#phoneno").keydown(function (e) {
           		restrict(e);
         });
         $('#amount').keydown(function (e) {
          	 	restrict(e);
        });

	  function restrict(e)
          {
          	  // Allow: backspace, delete, tab, escape, enter and .
              if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                   // Allow: Ctrl+A, Command+A
                  (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                   // Allow: home, end, left, right, down, up
                  (e.keyCode >= 35 && e.keyCode <= 40)) {
                       // let it happen, don't do anything
                       return;
              }
              // Ensure that it is a number and stop the keypress
              if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                  e.preventDefault();
              }

          }
   });

	$('#submit').click(function(){

		var myphone = $('#phoneno').val();
		var country_id = $('#country').val();
		var country = $("#country :selected").text();
		var amount = $('#amount').val();
		var fname = $('#fname').val();
		var lname = $('#lname').val();
		var email = $('#email').val();
		var password = $('#password').val();
		var message = $('#message').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var numeric = /^[0-9]+$/;
		var domain = '<?php echo $info['domain']?>';
		 
		if(amount == ""){

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Amount should not be blank</p>');
			$('#amount').focus();
			
		}else if(amount < 10000){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Amount should not be less than $10000</p>');
			$('#amount').focus();
			
		}else if(fname == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >First name should not be blank</p>');
			$('#name').focus();
			
		}else if(email == ""){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >email should not be blank</p>');
			$('#email').focus();
			
		}else if(password == ""){
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should not be blank</p>');
			$('#password').focus();
			
		}else if(password.length < 5){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >password should be more than 5 characters</p>');
			$('#password').focus();

		}else if(message == ""){

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >message should not be blank</p>');
			$('#message').focus();
		
		}else if(!emailfilter.test(email)){

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >invalid email</p>');
			$('#email').focus();

		}else if(!numeric.test(amount)){

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Numbers only</p>');
			$('#amount').focus();
			
		}else if(lname == ''){
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Last name should not be blank</p>');
			$('#lname').focus();

		}else if(myphone == '') {
			
			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >phone should not be blank</p>');
			$('#phoneno').focus();

		}else if (!numeric.test(myphone)) {

			$('#erroralert').css('display','block');
			$('#erroralert').html('<p role="alert" class="alert alert-danger" >Your Phone # must be a Number</p>');
			$('#phoneno').focus();

		}else{

			var formdata = {
				amount:amount,
				fname:fname,
				password:password,
				message:message,
				email:email,
				lname:lname,
				country_id:country_id,
				country:country,
				domain:domain,
				myphone:myphone
			}
			$('.loading').removeClass('hide');
			$('#submit').attr('disabled','disabled');
			$.post("http://www.contrib.com/signup/checkexist",{'field':'EmailAddress','value':email},function(data){
		
				if(data.status){
						$.post('http://www.contrib.com/forms/save_offer_for_existing_account',{
									domain:domain,
									email:email,
									message:message,
									amount:amount	

						},function(res){
									sendOfferEmail(fname,email,domain);
									$('#offerform').fadeOut();
									$('#thankyou').removeClass('hide');
									$('#thankyou').fadeIn();
						 });
				}
				else
				{
						$.post('http://www.contrib.com/forms/save_offer',{
								domain:domain,
								firstname:fname,
								lastname:lname,
								email:email,
								country_id:country_id,
								country:country,
								password:password,
								contact:myphone,
								message:message,						   
								amount:amount,
								city:'null'
						}
						,function(res2)
						{

							      sendOfferEmail(fname,email,domain);
							      $('.loading').addClass('hide');
						      	  $('#offerform').fadeOut();
						      	  $('#thankyou').removeClass('hide');
								  $('#thankyou').fadeIn();
						});
				 }
			})
		}
	});

	function sendOfferEmail(firstname,email,domain){
		$.post(
			'http://www.contrib.com/forms/autoresponderEmail',
			{ firstname:firstname,email:email,domain:domain,template_name:'Offer' },
			function(response){
				console.log(response.result);
			}
		);
	}

</script>

	
