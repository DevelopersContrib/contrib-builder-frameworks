
<?php include('includes/header.php');?>
<style>
.pc-box {
    background: #fff;
    padding: 10px 30px 30px 30px;
    margin-bottom: 50px;
    margin-top: 20px;
}
.partner-box h3 {
   margin-top: 0px;
}
.blur-box {
   border-bottom: 1px solid #ddd;
   margin-bottom: 10px;
   margin-top: 10px;
}
.breadcrumb {
    margin: 60px 0 0px 0;
}
.navbar-inverse {
    background: #000 !important;
}

.sfc-form-outer {
    padding: 0px 30px 20px;
    margin-bottom: 80px;
}
.innerbg{background-color: rgba(0, 0, 0, 0.8);
border-radius: 5px;
box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);}
.innerbgw{background-color: #fff;
}
.ww-block-content h3 {
   margin-top:0px;
}
.ww-block-content hr {
    border-top: 1px solid #333;
}
</style>

<body>



<div class="partners-container">
	<!-- container -->
	  <div class="container">
		
	    <!--   <div class="row innerbg">
   		  <div class="col-md-7" id="partners-domain">
   		   <script src="https://tools.contrib.com/cwidget/partners/?d=<?php echo $info['domain']; ?>"></script>
   		  </div> -->
   		
		  
				<div class="col-md-8 col-md-offset-2 pc-box partner-box">
               <h3 class="text-center">Partner With Us</h3>
					<hr>
                  <div class="blur-box text-left">
                       <div class="row">
                           <div class="col-sm-4">
                               <a href="http://www.contrib.com">
                                   <img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-174x35.png" alt="Partner" title="Partner">
                               </a>
                           </div>
                           <div class="col-sm-8">
                               <h3>
                                   <a href="http://www.contrib.com">Contrib.com</a>
                               </h3>
                               <p>
                                   We are a community of Entrepreneurs, Developers, Designers, Marketers and Specialists from around the world building, managing and monetizing virtual businesses on premium domains for equity and cash grants.                                        </p>
                           </div>
                       </div>
                   </div>
                  <div class="blur-box text-left">
                       <div class="row">
                           <div class="col-sm-4">
                               <a href="http://globalventures.com">
                                   <img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png" alt="Partner" title="Partner">
                               </a>
                           </div>
                           <div class="col-sm-8">
                               <h3>
                                   <a href="http://globalventures.com">GlobalVentures.com</a>
                               </h3>
                               <p>
                                   With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.                                        </p>
                           </div>
                       </div>
                   </div>

                    <div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://ifund.com">
                                    <img class="img-responsive" src="http://www.contrib.com/uploads/logo/ifund.png" alt="iFund.com" title="iFund.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://ifund.com">iFund.com</a>
                                </h3>
                                <p>
                                    iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
                                    advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
                                    investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
                                    iFund receives no compensation in connection with the purchase or sale of securities.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://ichallenge.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png" alt="iChallenge.com" title="iChallenge.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://ichallenge.com">iChallenge.com</a>
                                </h3>
                                <p>
                                     The best internet challenges. Solve and win online prizes.
                                </p>
                            </div>
                        </div>
               </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://socialid.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-socialid1.png" alt="Socialid.com" title="Socialid.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://socialid.com">SocialId.com</a>
                                </h3>
                                <p>
                                     SocialId helps you get the social name for all major social networking websites.
                                </p>
                            </div>
                        </div>
               </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://virtualinterns.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png" alt="Virtualinterns.com" title="Virtualinterns.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://virtualinterns.com">Virtualinterns.com</a>
                                </h3>
                                <p>
                                      Join our exclusive community of like minded people on virtualinterns.com
                                </p>
                            </div>
                        </div>
               </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://referrals.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png" alt="Referrals.com" title="Referrals.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://referrals.com">Referrals.com</a>
                                </h3>
                                <p>
                                      Most effective Business Referral Program and Tools Available. Find and share referrals locally.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://adrate.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-adrate-3.png" alt="Adrate.com" title="Adrate.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://adrate.com">Adrate.com</a>
                                </h3>
                                <p>
                                   Insightful Ad Content Direct To Your Target Market Advertising That Will Reach. Attract. Target. & Engage Your Future Customers
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://consultants.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png" alt="Consultants.com" title="Consultants.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://consultants.com">Consultants.com</a>
                                </h3>
                                <p>
                                     Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://domaindirectory.com">
                                    <img class="img-responsive" src="http://www.domaindirectory.com/images/logo-domaindirectory300x82.png" alt="Domaindirectory.com" title="Domaindirectory.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://domaindirectory.com">Domaindirectory.com</a>
                                </h3>
                                <p>
                                       Domain Directory - Buy, Sell, Trade, Develop, Partner with premium domains on the Domain Directory platform.
                                </p>
                            </div>
                        </div>
                    </div>
					<div class="blur-box text-left">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="http://handyman.com">
                                    <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png" alt="Handyman.com" title="Handyman.com">
                                </a>
                            </div>
                            <div class="col-sm-8">
                                <h3>
                                    <a href="http://handyman.com">Handyman.com</a>
                                </h3>
                                <p>
                                     Handyman.com is the best place to find a professional contractor.
                                </p>
                            </div>
                        </div>
               </div>
				</div>
        
	      </div>
	  </div>
</div>
	 <?php include('includes/footer.php'); ?>
<script type="text/javascript">

var partner_domain = jQuery('#partners-domain').html();

if (partner_domain == '') {
  console.log('wala');
} else
{
  console.log('naa');
};


jQuery('#submit').click(function(){

     var domain = jQuery('#domain').val();
     var email = jQuery('#email').val();
     var firstname = jQuery('#fname').val();
     var lastname = jQuery('#lname').val();
     var message = jQuery('#message').val();
     var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     var loading = jQuery('#submit');
     var companytitle = jQuery('#companytitle').val();
     var companylink = jQuery('#companylink').val();
     var partnertype = jQuery('#partner_type').val();
     var code = '<?=$_SESSION['captcha']['code']?>';
     var captcha = $('#captcha').val();


     if (email == '') {
           error('Please Enter an Email');
     }else if(!emailfilter.test(email)){
         error('Please Enter a Valid Email Address');
     }else if(firstname == ''){
           error('Please Enter your FirstName');
     }else if(lastname == ''){
           error('Please Enter Your Lastname!');
     }else if(message == ''){
           error('Please Enter Your Message!');
     }else if(companytitle == ''){
           error('Please Enter Your Company Name!');
     }else if(companylink == ''){
           error('Please Enter Your Company Website!');
     }else if(validateURL(companylink)===false){
           error('Please Enter Your Valid Company Website!');
     }else if(code !== captcha){
           error('Code not match!');
     }else{

        loading.attr('disabled', 'disabled').html("Please wait for a while ");
        jQuery.post('http://api.contrib.com/forms/save_partner_lv3',
           {
            domain:domain,
            email:email,
            firstname:firstname,
            lastname:lastname,
            company:companytitle,
            companyurl:companylink,
            partnertype:partnertype,
            message:message

           }
           ,function(data)
           {
              if (data.success == true) { jQuery('#thankyou').removeClass('hide'); jQuery('#inquiry_form').addClass('hide'); } else{ error('Something Went Wrong'); };
           });
        console.log('success');
     }
});

function error(param){
  jQuery('#str_error').removeClass('hide').html(param);
  setTimeout(function(){ jQuery('#str_error').addClass('hide');  }, 5000);
  return false;
}

function validateURL(url){
    return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
  }

</script>
