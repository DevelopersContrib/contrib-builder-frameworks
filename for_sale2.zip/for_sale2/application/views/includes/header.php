<!DOCTYPE html>
<html>
	<head>
		<meta name="description" content="<?php echo $info['description']; ?>">
		<meta name="keywords" content="<?php echo $info['keywords']; ?>">
		<meta name="author" content="<?php echo $info['domain']; ?>">
		<title><?php echo $title ?> - <?php echo ucfirst($info['domain']); ?> : <?php echo $info['description']; ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<script src="https://use.fontawesome.com/0ca618674e.js"></script>
		<link rel="stylesheet" href="static/css/style.fs.2.css">
		<link rel="stylesheet" href="static/css/absolute.css">
		<style type="text/css">
		</style>
	</head>
	<body>

	<nav class="navbar navbar-inverse navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<?php if (!empty($info['logo'])): ?>
							<a class="navbar-brand" href="<?php echo $info['domain'] ?>">
						<img src="<?php echo $info['logo']; ?>" alt="referral.com" title="referral.com" style="height:30px">
					</a>
				<?php else: ?>
					<h1></h1>
					<h3 style="color:white;" title="<?php echo ucfirst($info['domain']); ?>"><?php echo ucfirst($info['domain']); ?></h1>
					<?php endif ?>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="/">HOME</a></li>
						<li><a href="/about">ABOUT</a></li>
						<li><a href="/partner">PARTNER</a></li>
						<li><a href="/privacy">PRIVACY POLICY</a></li>
					</ul>
				</div><!-- /.navbar-collapse -->
			</div><!-- /.container-fluid -->
		</nav>

 
    <script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?=$info['account_ga']?>']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$info['piwik_id'];?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id']?>" style="border:0;" alt="" /></p></noscript>
	