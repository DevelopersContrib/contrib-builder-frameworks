<?php

class Referral extends Controller {



	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
			$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
	
		/* $template = $this->loadView('handyman/referral'); */
		$template = $this->loadView('bs4/handyman/referral');
		$template->set('info', $info);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('widget_id', $api->getwidgetid());
		$template->set('programs',$api->getprograms());
		$template->render();
	
	}
}