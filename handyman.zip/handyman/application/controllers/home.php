<?php

class Home extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$relatedsiteswithlogo = $api->relatedsiteswithlogo();
		$relatedsitesnologo = $api->relatedsitesnologo();
		//$formdata = $api->getsignupformdata();
		
		
		//$rolesarray = $formdata['data']['roles'];
		//$countriesarray = $formdata['data']['countries'];
		//$industriesarray = $formdata['data']['industries'];
		$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
		
		
		$template = $this->loadView('handyman/home');
		$template->set('countriesarray',$countriesarray);
		$template->set('rolesarray',$rolesarray);
		$template->set('industriesarray',$industriesarray);
		$template->set('parnershiptypes',$parnershiptypes);
		$template->set('relatedsiteswithlogo',$relatedsiteswithlogo);
		$template->set('relatedsitesnologo',$relatedsitesnologo);
		$template->set('info', $info);
		$template->set('projecttypes',$projecttypes);
		$template->render();
	}
	
	function terms(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/terms');
		$template->set('info', $info);
		$template->render();
	
	}
	
	function fund(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$fundsites = $api->getfund();
		$template = $this->loadView('handyman/fund');
		$template->set('info', $info);
		$template->set('fundsites', $fundsites);
		$template->render();
	
	}
	
	function developers(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/developers');
		$template->set('info', $info);
		$template->render();
	
	}
	
	function about(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/about');
		$template->set('title', $title);
		$template->set('info', $info);
		$template->render();
	
	}
    
}

?>