<?php

class Home extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$relatedsiteswithlogo = $api->relatedsiteswithlogo();
		$relatedsitesnologo = $api->relatedsitesnologo();

		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();

		//$formdata = $api->getsignupformdata();
		//$rolesarray = $formdata['data']['roles'];
		//$countriesarray = $formdata['data']['countries'];
		//$industriesarray = $formdata['data']['industries'];
		$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
		

		/* $template = $this->loadView('handyman/home'); */
		$template = $this->loadView('bs4/handyman/index');
		$template->set('countriesarray',$countriesarray);
		$template->set('rolesarray',$rolesarray);
		$template->set('industriesarray',$industriesarray);
		$template->set('parnershiptypes',$parnershiptypes);
		$template->set('relatedsiteswithlogo',$relatedsiteswithlogo);
		$template->set('relatedsitesnologo',$relatedsitesnologo);
		$template->set('info', $info);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('projecttypes',$projecttypes);
		$template->set('programs',$api->getprograms());
		$template->render();
	}
	
	function indexv2()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$relatedsiteswithlogo = $api->relatedsiteswithlogo();
		$relatedsitesnologo = $api->relatedsitesnologo();

		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();

		//$formdata = $api->getsignupformdata();
		//$rolesarray = $formdata['data']['roles'];
		//$countriesarray = $formdata['data']['countries'];
		//$industriesarray = $formdata['data']['industries'];
		$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
		

		$template = $this->loadView('bs4/handyman/index');
		$template->set('countriesarray',$countriesarray);
		$template->set('rolesarray',$rolesarray);
		$template->set('industriesarray',$industriesarray);
		$template->set('parnershiptypes',$parnershiptypes);
		$template->set('relatedsiteswithlogo',$relatedsiteswithlogo);
		$template->set('relatedsitesnologo',$relatedsitesnologo);
		$template->set('info', $info);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('projecttypes',$projecttypes);
		$template->set('programs',$api->getprograms());
		$template->render();
	}
	
	function terms(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();

		$template = $this->loadView('handyman/terms');
				$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function termsv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();

		$template = $this->loadView('bs4/handyman/terms');
				$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function privacyv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();

		$template = $this->loadView('bs4/handyman/privacy');
				$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function contactv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();

		$template = $this->loadView('bs4/handyman/contact');
				$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function fund(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$fundsites = $api->getfund();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
		
		$template = $this->loadView('handyman/fund');
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->set('fundsites', $fundsites);
		$template->render();
	
	}
	
	function developers(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
	
		$template = $this->loadView('handyman/developers');
			$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function developerv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
	
		$template = $this->loadView('bs4/handyman/developer');
			$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function cookiev2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
	
		$template = $this->loadView('bs4/handyman/cookie');
			$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function about(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
			$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
		
		$template = $this->loadView('handyman/about');
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('title', $title);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function aboutv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
		
		$template = $this->loadView('bs4/handyman/about');
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('title', $title);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function apps(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
			$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
		
		$template = $this->loadView('handyman/apps');
		$template->set('title', $title);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function appsv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
			$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
		
		$template = $this->loadView('bs4/handyman/apps');
		$template->set('title', $title);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function partnerv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
			$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
		
		$template = $this->loadView('bs4/handyman/partner');
		$template->set('title', $title);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function referralv2(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
			$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
		
		$template = $this->loadView('bs4/handyman/referral');
		$template->set('title', $title);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function sitemap(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();
	
		$template = $this->loadView('handyman/sitemap');
		$template->set('title', $title);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->set('info', $info);
		$template->render();
	
	}
    
}

?>