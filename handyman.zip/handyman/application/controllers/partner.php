<?php

class Partner extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$socialfb = $api->getsocialfb();
		$socialtwitter = $api->getsocialtwitter();
		$sociallinkedin = $api->getsociallinkedin();		
		/* $template = $this->loadView('handyman/partner'); */
		$template = $this->loadView('bs4/handyman/partner');
		$template->set('info', $info);
		$template->set('socialfb',$socialfb);
		$template->set('socialtwitter',$socialtwitter);
		$template->set('sociallinkedin', $sociallinkedin);
		$template->render();
	
	
	}




}