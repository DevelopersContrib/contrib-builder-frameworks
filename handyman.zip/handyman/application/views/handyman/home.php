<?php
    include('header.php');
?>
	<style type="text/css">
		.brdr{
			border:1px solid;
		}
		.section4{
			background-color: #fff;
			padding-top: 10px;
			padding-bottom: 10px;
			border-top: 1px solid #ddd;
			padding: 60px 0 100px;
		}
		.section4 h1 {
			font-weight: 600;
			margin-bottom: 30px;
		}
		.ul-rv img{
			max-height: 43px;
		}
		.ul-rv li{
			margin-bottom: 10px;
		}
		.rv-text-a{
			background: #f6f6f6;
			border-radius: 2px;
			font-size: 18px;
			padding: 20px;
		}
		.rv-text-a:before,.rv-text-a:after{
			display: table;
			content: "";
		}
		.rv-text-a:after{
			clear: both;
		}
		.brdr-lead:before{
			content: "";
			border-bottom: 1px solid #404040;
			height: 15px;
			width: 500px;
			position: absolute;
		}
		.brdr-lead:before{
			left: -482px;
		}
		.brdr-lead:after{
			content: "";
			border-bottom: 1px solid #404040;
			height: 15px;
			width: 500px;
			position: absolute;
		}
		.brdr-lead:after{
			right: -485px;
		}
		.brdr-lead{
			padding: 0 30px;
			display: inline;
			font-size: 18pt;
			font-weight: bold;
			line-height: 30px;
			position: relative;
			text-transform: uppercase;

		}
		.section5 {
			background: #f1f1f1;
			padding: 50px 0;
		}
		.item-container-rp {
			margin-top: 20px;
		}
		.bg-overlay {
			background-color: rgba(13, 13, 14, 0.7);
			bottom: 0;
			left: 0;
			position: absolute;
			right: 0;
			top: 0;
		}
	</style>
	<body>
		<?php include('navigation.php');?>
		<div class="section1"
			<?php if($info_attributes['background_image_url'] != ""):?>
			style="background:url('<?php echo $info_attributes['background_image_url']?>') no-repeat scroll center center / cover rgba(0, 0, 0, 0);"
			<?php endif; ?>>
			<div class="bg-overlay"></div>
			<div class="container text-center project">
				<div class="wrap-menu-content">
					<div id="estimate_display" class="row content-menu active">
						<div class="col-lg-6 col-lg-offset-3">
							<h1>
								Get an Estimate!
							</h1>
						</div>
						<div class="col-lg-8 col-lg-offset-2 form-project">
							<div class="row">
								<div class="col-lg-5">
									<div class="form-group">
										<select name="proj_types" id="proj_types" class="form-control input-lg">
											<option value="0">Project Type</option>
											<?php
												foreach($projecttypes as $array)
												{
													foreach($array as $key => $info2)
													{
													  echo '<option value="'.$info2['ProjectTypeId'].'" name='.$info2['Name'].'>'.$info2['Name'].'</option>';
													}
												}
											?>
										</select>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="form-group">
										<label for="zip" class="sr-only">ZIP</label>
										<input placeholder="ZIP" type="text" class="form-control input-lg" id="zipcodes2">
									</div>
								</div>
								<div class="col-lg-2">
									<div class="form-group">
										<a href="javascript:;" id="estiredirect" class="btn btn-primary btn-lg btn-block">Go!</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="expert_display" class="row content-menu" style="display:none;">
						<div class="col-lg-6 col-lg-offset-3">
							<h1>Ask an Expert</h1>
						</div>
						<div class="col-lg-6 col-lg-offset-3 form-project form-blue">
							<div class="row">
								<div class="col-lg-5">
									<div class="form-group">
										<select name="proj_cat" id="proj_cat" class="form-control input-lg">
											<option value="0">Category</option>
											<?php
												foreach($projecttypes as $array)
												{
													foreach($array as $key => $info2)
													{
													  echo '<option value="'.$info2['ProjectTypeId'].'">'.$info2['Name'].'</option>';
													}
												}
											?>
										</select>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="form-group">
										<label for="" class="sr-only">Ask</label>
										<input placeholder="Ask" type="text" class="form-control input-lg">
									</div>
								</div>
								<div class="col-lg-2">
									<div class="form-group">
										<a href="javascript:;" class="btn btn-danger btn-lg btn-block" id="askredirect">Go!</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row nav-menu">
					<div class="col-lg-6 col-lg-offset-3">
						<div class="row wrap-menu-nav">
							<div id="esticlass" class="col-lg-6 sub-menu active">
								<a href="javascript:;" id="estimate"><i class="fa fa-fax "></i> Get an Estimate</a>
							</div>
							<div id="askclass" class="col-lg-6 sub-menu">
								<a href="javascript:;" id="expert"><i class="fa fa-info-circle "></i> Ask an Expert</a>
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="section2">
			<div class="container hide">
				<div class="row">
				  	<div class="col-lg-12">
						<h1 class="ftre-style1-link">Acquired by Handyman.com</h1>
				    </div>
			  	</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<h1>Get Matched to a Screened Professional Handyman</h1>
						<p><?php echo ucfirst($info['domain'])?> helps you find an experienced, professional Handyman contractor in your local area, FREE, NO OBLIGATIONS. <?php echo ucfirst($info['domain'])?> is the industry leading portal for the home improvement, home repair and remodeling industry. Our free tools and services help both homeowners and contractors facilitate the process to accomplish your home repair and remodeling needs. Serving the Home and Contractor market. Why use our pros?</p>
						<p>For the commercial real estate market or projects over $5,000, <?php echo ucfirst($info['domain'])?> offers a free consultation service to analyze your needs and find suppliers, general contractors and local professional service providers. Are you lacking a professional website or want to communicate more efficiently with your customer or contractor? Get a Free Webpage and Free Consultation and manage it online. Need professional and experienced contractors, subcontractors or handymen due to an increase in your work load? You have come to the right place at <?php echo ucfirst($info['domain'])?>, your local referral and local handyman service provider.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="section3">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 f1">
						<a href="<?php echo BASE_URL; ?>postproject" class="feature-link text-center">
							post a project
							<span class="meta-desc">Home owner post your project free<i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f2">
						<a href="http://handyman.com/contractor/find" class="feature-link text-center">
							FIND CONTRACTOR
							<span class="meta-desc">Contractors in Your Area Now  <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f3">
						<a href="http://handyman.com/project/find" class="feature-link text-center">
							FIND PROJECT
							<span class="meta-desc">Get Contractor Projects  <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
					<div class="col-lg-3 f4">
						<a href="http://handyman.com/home/how-it-works" class="feature-link text-center">
							HOW IT WORKS
							<span class="meta-desc">Free Match-up for your project!   <i class="fa fa-angle-right"></i></span>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="section4">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h1 class="text-center">
							Other Brands on <?php echo ucfirst($info['domain'])?> Vertical
						</h1>
					</div>
					<div class="col-lg-6">
						<div class="row">
							<div class="col-lg-6">
								<ul class="list-inline ul-rv">
								<? $row_cnt = 0; ?>
								<? shuffle($relatedsiteswithlogo); ?>
								<? foreach($relatedsiteswithlogo as $row){ ?> 
									<li>
										<a href="http://<?=$row['domain_name']?>" target="_blank">
											<img class="img-responsive" src="<?=$row['logo']?>" alt="<?=$row['domain_name']?>" title="<?=ucfirst($row['domain_name'])?>">
										</a>
									</li>
									<? $row_cnt++; ?>
									<? if($row_cnt==6) break; ?>
									<? if($row_cnt%3==0){ ?>
								</ul>
							</div>
							<div class="col-lg-6">
								<ul class="list-inline ul-rv">
							<? }?> 
						<? } ?>
								</ul>
							</div>

						</div>
					</div>
					<div class="col-lg-6">
						<div class="row">
							<div class="rv-text-a">
								<div class="col-lg-6">
									<ul class="list-unstyled">
									<? $row_cnt1 = 0; ?>
									<? shuffle($relatedsitesnologo); ?>
									<? foreach($relatedsiteswithlogo as $row1){ ?> 
										<li>
											<i class="fa fa-star-o"></i>
											<a href="http://<?=$row1['domain_name']?>" target="_blank">
												<?=ucwords($row1['domain_name'])?>
											</a>
										</li>
									<? $row_cnt1++; ?>
									<? if($row_cnt1==12) break; ?>
									<? if($row_cnt1%6==0){ ?>
									</ul>
								</div>
								<div class="col-lg-6">
									<ul class="list-unstyled">
										
								<? } ?>
											<? } ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="section5 hide">
			<div class="container">
				<div class="row-fluid text-center lead-ttle-top">
					<h1 class="brdr-lead">
						Referral Programs
					</h1>
				</div>
				<div class="row item-container-rp">
				   <?php if (count($programs)>0):?>
							 <?php foreach ($programs as $key=>$val):?>
									<div class="col-md-4 text-center item-selector">
										<div classs="rp-img-box" style="background:#fff !important;border:1px solid #dedede;padding:5px 0;">
											<?php echo $val['code']?> 
										</div>
								   </div>
							 <?php endforeach;?>
					<?php endif?>         
				  
				</div>
			</div>
		</div>

<script src="<?php echo BASE_URL; ?>js/home.js"></script>
<?php include ('footer.php')?>
