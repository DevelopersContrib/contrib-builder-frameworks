<?php  
    include('header.php');
?>
	<body>
		<?php include('navigation.php');?>

		
	<div class="pages-container">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h1>Privacy Policy</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="page-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<?php echo $content; ?>
					</div>
				</div>
			</div>
		</div>
		
<?php include ('footer.php')?>