<?php  
    include('header.php');
?>
	<body>
		<?php include('navigation.php');?>
		
		
		<div class="pages-container">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h1>Contact Us - <span>Learn more about Joining our Partner Network</span></h1>
					</div>
				</div>
			</div>
		</div>
		<div class="page-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="row">
							<div class="col-lg-4">
								<div class="form_script" style="padding-top:5px">
								<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?php echo $info['domain']?>"></script>
								</div>
								<br>
								<br>
							</div>
							<div class="col-lg-8">
								<br>
								<br>
								<p class="p-desc stripe-text right text-left">
									<span><?php echo ucfirst($info['domain'])?></span>
									is a venture of eCorp.com Inc.
									<br>
									<br>
									Join our exclusive community of like minded people on <?php echo ucfirst($info['domain'])?><br><br>

									<span>eCorp</span> is the worlds largest virtual domain development incubator on the planet. Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms. We build and manage world class web-based, domain centric operating businesses for clients and internal ventures. Learn more about our ventures, staffing opportunites and partnership models.
								</p>
								<p>
									<a class="btn btn-primary" target="_blank" href="https://www.contrib.com/brand/details/<?php echo $info['domain']?>"> Learn about this site </a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

<?php include ('footer.php')?>
