<?php  
    include('header.php');
?>
	<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" />
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/fd.css">
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/masonry/3.1.5/masonry.pkgd.min.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('#wrapper-container').masonry({
				columnWidth: '.col-lg-3',
				transitionDuration: '0.4s',
				itemSelector : '.item'
			});
		});
	</script>
	<body>
		<?php include('navigation.php');?>
		<div class="hf-wrap">
			<div class="hf-wrap-sub">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="text-center lead-ttle-top">
								<h1 class="brdr-lead">
									Fund Our Ventures
									
								</h1>
							</div>
						</div>
						
						<div class="col-lg-12">
							<div class="row" id="wrapper-container">
								
								<?php foreach($fundsites as $item):?>
								<?if($item['post_title'] != 'Micro Markets'):?>
								<div class="col-lg-3 item">
									<div class="wrap-ifund-container">
										<div class="ribbon-wrapper-orange">
											<div class="ribbon-orange">
												<a href="<?=$item['permalink']?>">Staff Pick</a>
											</div> 
										</div>
										<a rel="bookmark" title="<?=$item['post_title']?>" href="<?=$item['permalink']?>">
											<img class="img-responsive"  alt="Cook board" class="attachment-campaign wp-post-image" src="<?=$item['logo']?>">
										</a>
										<h3 class="fnt-size1-lato fnt-lato">
											<a href="<?=$item['permalink']?>" class="fund-ttle-a"><?=$item['post_title']?></a>
										</h3>
										<p>
											<?=$item['post_content']?>
										</p>
										<div class="digits">
											<div class="bar">
												<span style="width: 10%"></span>
											</div>
											<ul>
												<li><strong>10%</strong> Funded</li>
												<li><strong>$10,000.00</strong> Funded</li>
											</ul>
										</div>
									</div>
								</div>
								<?endif;?>
								<?php endforeach;?>
								
								

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php include ('footer.php')?>