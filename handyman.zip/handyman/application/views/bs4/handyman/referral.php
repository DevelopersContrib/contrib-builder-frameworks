<style>
.bg-custom {
	background: #333 !important;
	z-index: 999;
}
.boxcon {
    background: #fff;
    padding: 80px 50px 80px;
    margin-top: 20px;
    margin-bottom: 20px;
}
.section-1 {
    min-height: 0px !important;
}
</style>
<?php include 'header.php'; ?>

<?php include('navigation.php');?>
<div class="section-1 secpage">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="row"> 
            <div class="col-sm-12 text-center"> 
                <div class="boxcon">
                <script class="ctb-box" id="referral-script" src="https://www.referrals.com/extension/widget.js?key=<?=$widget_id?>" type="text/javascript"></script>
                </div> 
            </div>
        </div>
    </div>
</div>

                
<?php include_once 'footer.php';?>          