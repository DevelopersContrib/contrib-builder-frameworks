<style>
.bg-custom {
	background: #333 !important;
	z-index: 999;
}
.boxcon {
	background: rgba(0,0,0,0.3);
	padding: 30px 40px 40px;
	margin-top: 20px;
	margin-bottom: 20px;
}
.section-1 {
	min-height: 0px !important;
}
<?php include('navigation.php');?>
<?php include 'header.php'; ?>
       <div class="section-1 secpage">
	<div class="bg-overlay"></div>
		<div class="container">
			<div class="row"> 
				<div class="col-sm-12 text-center">                      
				   <script type="text/javascript" src="https://tools.contrib.com/contactform?d=<?=$info['domain']?>"></script>
				</div>
			</div>
		</div>
	</div>
<?php include_once 'footer.php';?>          
