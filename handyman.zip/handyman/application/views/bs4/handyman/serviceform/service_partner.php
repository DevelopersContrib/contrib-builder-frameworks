
<!-- Start:: Partner Form Text Content -->
<div class="col-lg-6 bg-left-form ">
	<div class="bg-left-overlay"></div>
	<div class="left-content-main">
		<h1 class="title-left mb-3">
			Partner with <?=ucfirst($info['domain'])?>
		</h1>
		<p class="desc-left mb-4">
			When you submit your registration, you can quickly partner with <?=ucfirst($info['domain'])?>. This is a great way to build your service and at the same way add value to this asset.
		</p>
		<div class="box-steps p-3 mb-3">
			<div class="media">
				<img class="mr-3 align-self-center" src="https://cdn.vnoc.com/icons/submit-application.png" width="40" alt="">
				<div class="media-body">
					<div class="steps-header-title d-block fnt-500 mb-2">
						Submit Your Partnership Application
					</div>
					<div class="d-block">
						<small>
							You'll receive an email when we feel it will be a win-win.
						</small>
					</div>
				</div>
			</div>
		</div>
		<div class="box-steps p-3">
			<div class="media">
				<img class="mr-3 align-self-center" src="https://cdn.vnoc.com/icons/team.png" width="40" alt="">
				<div class="media-body">
					<div class="steps-header-title d-block fnt-500 mb-2">
						Join a Team
					</div>
					<div class="d-block">
						<small>
							Once your partnership proposal is something we could take on, we will make you part of our team and our partner.
						</small>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: Loading -->
<div class="col-lg-6 align-self-center d-none" id="loading_partner">
	<div class="text-center">
		<img src="https://cdn.vnoc.com/icons/loader-circle-outline.gif">
		<div class="d-block small">
			Please wait . . .
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: First Step -->
<div class="col-lg-6 align-self-center " id="partner2_step1">
	<div class="bg-form-content">
		<div class="note note-danger d-none" id="partstep1_error">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<h3 class="fnt-300 mb-3 text-primary">
			Partner with <span class="text-capitalize"><?=ucfirst($info['domain'])?></span>
		</h3>
		<div class="form-group">
			<label for="">Email Address <span class="text-danger">*</span></label>
			<input type="text" class="form-control" id="partner2_initialemail" >
		</div>
		<a href="javascript:;" id="partner2_btn_1" class="btn btn-primary btn-block pulse-btn">
			Apply Today
			<i class="fas fa-arrow-right ml-2"></i>
		</a>
		<a href="javascript:formback('partner');" class="btn btn-secondary btn-block">
			<small class="d-block"><i class="fas fa-home" aria-hidden="true"></i> Back</small>
		</a>
	</div>
</div>
<!-- End -->

<!-- Start:: Second Step -->
<div class="col-lg-6 align-self-center d-none" id="partner2_step2">
	<div class="bg-form-content">
		<h3 class="fnt-300 mb-3 text-primary">
			Partner with <span class="text-capitalize"><?=ucfirst($info['domain'])?></span>
		</h3>
		<div class="note note-danger d-none" id="partstep2_error">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							First Name
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_firstname">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Last Name
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_lastname">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Email
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_email">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Website
						</small>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_website">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Country
						</small>
						<span class="text-danger">*</span>
					</label>
					
					<select class="form-control form-control-sm" id="partner2_country">
						<option value=""></option>									
						<?php for($ci=0;$ci<sizeof($countriesarray);$ci++){ ?>											
						<option value="<?=$countriesarray[$ci]['country_id']?>"><?=$countriesarray[$ci]['name']?></option>
						<?php } ?>
					</select>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							City
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_city">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Password
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="password" class="form-control form-control-sm" id="partner2_password">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Confirm Password
						</small>
						<span class="text-danger">*</span>
					</label>
					<input type="password" class="form-control form-control-sm" id="partner2_password2">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<a href="javascript:formback('partner');" class="btn btn-danger btn-block">
					<i class="fas fa-arrow-left mr-2"></i>
					Back
				</a>
			</div>
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-primary btn-block" id="partner2_btn_2">
					Next
					<i class="fas fa-arrow-right ml-2"></i>
				</a>
			</div>
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: Third Step -->
<div class="col-lg-6 align-self-center d-none" id='partner2_step3'>
	<div class="bg-form-content">
		<h3 class="fnt-300 mb-3 text-primary">
			Partner with <span class="text-capitalize"><?=ucfirst($info['domain'])?></span>
		</h3>
		<div class="note note-danger d-none" id="partstep3_error">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Partnership Type
						</small>
						<span class="text-danger">*</span>
					</label>
					<select id="partner2_type" class="form-control form-control-sm">
						<option value=""></option>
						<?if(sizeof($parnershiptypes) > 0):?>
							<?php foreach ($parnershiptypes as $type){ ?>
							<option value="<?php echo $type;?>"><?php echo $type;?></option>
							<?php } ?>
						<?endif;?>
					</select>
				</div>
			</div>

			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Why we should partner with you
						</small>
						<span class="text-danger">*</span>
					</label>
					<textarea rows="3" class="form-control form-control-sm" id="partner2_message"></textarea>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-danger btn-block" id="partner2_back_3">
					<i class="fas fa-arrow-left mr-2"></i>
					Back
				</a>
			</div>
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-primary btn-block" id="partner2_btn_3">
					Next
					<i class="fas fa-arrow-right ml-2"></i>
				</a>
			</div>
		</div>
		<input type="hidden" id="partner2_domain" value="<?=$info['domain']?>">
	</div>
</div>
<!-- End -->

<!-- Start:: Fourth Step -->
<div class="col-lg-6 align-self-center d-none" id='partner2_step4'>
	<div class="bg-form-content">
		<h3 class="fnt-300 mb-3 text-primary">
			Partner with <span class="text-capitalize"><?=ucfirst($info['domain'])?></span>
		</h3>
		<div class="note note-danger d-none" id="partstep4_error">
			<div class="note-header">
				<i class="fas fa-exclamation-circle" aria-hidden="true"></i>
				Error
			</div>
			<div class="note-body">
				<small>
					Please fill-in all required fields (<span class="text-danger">*</span>).
				</small>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Company Title
						</small>
						<span class="text-danger">*</span>
						<small class="text-muted d-block">
							title/name of your company to promote.
						</small>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_company">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Company Description
						</small>
						<span class="text-danger">*</span>
						<small class="text-muted d-block">
							a short summary of your company
						</small>
					</label>
					<textarea rows="3" class="form-control form-control-sm" id="partner2_companydescription"></textarea>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Company Image
						</small>
						<span class="text-danger">*</span>
						<small class="text-muted d-block">
							URL/link to yourcompany's image or logo.
						</small>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_companyimage">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="d-block mb-2">
					<label for="">
						<small>
							Company Link
						</small>
						<span class="text-danger">*</span>
						<small class="text-muted d-block">
							allow us to promote your company.
						</small>
					</label>
					<input type="text" class="form-control form-control-sm" id="partner2_companyurl">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-danger btn-block" id="partner2_back_4">
					<i class="fas fa-arrow-left mr-2"></i>
					Back
				</a>
			</div>
			<div class="col-lg-6">
				<a href="javascript:;" class="btn btn-primary btn-block" id="partner2_btn_4">
					Submit
					<i class="fas fa-arrow-right ml-2"></i>
				</a>
			</div>
		</div>
	</div>
</div>
<!-- End -->

<!-- Start:: Fifth Step -->
<div class="col-lg-6 align-self-center d-none" id="partner2_final">
	<div class="bg-form-content">
		<div class="d-block pb-3 text-center">
			<img src="https://cdn.vnoc.com/icons/email.svg" width="100" alt="">
		</div>
		<h2 class="text-center mb-3">
			Thank you for your Partnership application.
		</h2>
		<p class="text-center text-secondary mb-5">
			You are now minutes away to joining <span class="text-capitalize"><?=ucfirst($info['domain'])?></span> team.
		</p>
		<ul class="list-unstyled text-secondary">
			<li class="mb-3 small">
				1. Please <a href="/referral" target="_blank">login</a> to get your referral widgets. 
			</li>
			<li class="mb-3 small">
				2. All you need to do right now is click the link in the <span class="text-success">Verification email</span> that we have just sent you. If you still haven't received it, please check your spam inbox. Your verification link will redirect you to our <a href="https://www.contrib.com" target="_blank">Marketpalce hub</a> where you can login and check out your application status.
			</li>
			<li class="small">
				3. You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.
			</li>
		</ul>
		<div id="viewcontriblink">Thank You!</div>
	</div>
</div>
<!-- End -->
<script src="/js/serviceforms/bs4/service_partner.js"></script>
