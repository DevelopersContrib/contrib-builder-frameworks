<style>
.bg-custom {
	background: #333 !important;
	z-index: 999;
}
.boxcon {
    background: rgba(0,0,0,0.6);
    padding: 60px 60px 60px;
    margin-top: 60px;
    margin-bottom: 60px;
}
.section-1 {
    min-height: 0px !important;
}
</style>
<?php include 'header.php'; ?>          

<?php include('navigation.php');?>            
<div class="section-1 secpage">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="row"> 
            <div class="col-sm-12 text-center"> 
                <div class="boxcon">
                    <h2 class="ttle text-capitalize text-center">
                        <b><?php echo ucfirst($info['domain'])?> Developers</b>
                    </h2>
                    <br /> 
                    <p class="devdesc">
                        <i class="fa fa-arrows"></i>
                        Do you have code or an app that could run this brand? <?php echo ucfirst($info['domain'])?> is connected with <a href="http://contrib.com/signup/firststep?domain=<?=$info['domain']?></p>" target="_blank">Contrib</a>. 
                    </p>
                    <p class="devdesc">
                        <i class="fa fa-arrows"></i>
                        <a href="http://contrib.com/signup/firststep?domain=<?=$info['domain']?></p>" target="_blank">Contrib</a> is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?=$info['domain']?>?</p>
                    </p>                    
                </div> 
            </div>
        </div>
    </div>
</div>
<?php include_once 'footer.php';?>       

