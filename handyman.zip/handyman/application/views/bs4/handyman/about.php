<style>
.bg-custom {
	background: #333 !important;
	z-index: 999;
}
.boxcon {
    background: rgba(0,0,0,0.3);
    padding: 80px 50px 80px;
    margin-top: 20px;
    margin-bottom: 20px;
}
.section-1 {
    min-height: 0px !important;
}
</style>
<?php include 'header.php'; ?>

<?php include('navigation.php');?>
<div class="section-1 secpage">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="row"> 
            <div class="col-sm-12 text-center"> 
                <div class="boxcon">
                    <h2 class="ttle text-capitalize">
                        About <?php echo ucfirst($info['domain'])?>
                    </h2>
                    <p><?php echo ucfirst($info['domain'])?> is a proud venture of Global Ventures, LLC.</p>
                    <p>Global Ventures, LLC, established in 1996, invests in young innovators, entrepreneurs and professionals with a desire to solving big problems and help world. We combine our resources with a series of intense challenges, real-world skills development, amazing and flexible opportunities and a shared ownership and experience with the most talented young founders and professionals around the world.</p>
                    <p>Join our network of performance based companies using <?=$info['domain']?></p>
                </div> 
            </div>
        </div>
    </div>
</div>

                
<?php include_once 'footer.php';?>          