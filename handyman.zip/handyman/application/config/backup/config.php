<?php

	
function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
       // curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}


$api_url = "https://api1.contrib.co/request/";
$api2_url = "https://api2.contrib.co/request/";
$api_content_url = "https://api3.contrib.co/announcement/";
$handyman_api = "https://handyman.com/api/";
$headers = array('Accept: application/json');

if (!file_exists('config-framework.php')) {
	$file = file_get_contents('config-template.php');

	$domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    //$domain = 'https://www.javapoint.com';
    if(stristr($domain, '~') ===FALSE) {
    	$domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("https://","",$domain);
    	$domain = str_replace("www.","",$domain);
    	$key = md5($domain);
    }else {
       $key = md5('vnoc.com');
       $d = explode('~',$domain);
       $user = str_replace('/','',$d[1]);
        $host = $_SERVER["HTTP_HOST"];
		$host = str_replace("https://","",$host);
		$host = str_replace("www.","",$host);
		$url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key.'&host='.$host;
       $result =  createApiCall($url, 'GET', $headers, array());
       $data_domain = json_decode($result,true);
       $error = 0;
       $domain =   $data_domain['data']['domain'];	
    }

    $data_domain = NULL;
    while ($data_domain == NULL){
      $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
      $result = createApiCall($url, 'GET', $headers, array());
      $data_domain = json_decode($result,true);
    }

    if ($data_domain['success']){
    	$domainid = $data_domain['data']['DomainId'];
    	$domain = $data_domain['data']['DomainName'];
    	$memberid = $data_domain['data']['MemberId'];
    	$title = $data_domain['data']['Title'];
    	$logo = $data_domain['data']['Logo'];
    	$description = $data_domain['data']['Description'];
    	$account_ga = $data_domain['data']['AccountGA'];
    	$description = stripslashes(str_replace('\n','<br>',$info['description']));
    	
    	$url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
      	$result2 = createApiCall($url2, 'GET', $headers, array());
    	$data_domain2 = json_decode($result2,true);

    	if($data_domain2['success']){
    		$background_image = $data_domain2['data']['background_image_url'];
    		$keywords = $data_domain2['data']['keywords'];
    		$footer_html = $data_domain2['data']['footer_html'];
    		if ($footer_html != ""){
    			if (!base64_decode($footer_html)){
    				$footer_html = base64_encode($footer_html);
    			}
    		}
    		$url3 = $api_url.'GetPiwikId?domain='.$domain.'&key='.$key;
    		$result3 = createApiCall($url3, 'GET', $headers, array());
    		$data_domain3 = json_decode($result3,true);
    		$piwik_id = $data_domain3['data']['idsite'];
    	}else{
    		$error++;
    	}
    }else{
    	$error++;
    }


    // if no keywords presented at domaininfo -> process this
    if ($keywords == "") {
    	$api1_url = 'https://api1.contrib.co/request/';
    	$url = $api1_url.'DomainKeywords?key='.$key.'&domain='.$domain;
    	$result = createApiCall($url, 'GET', $headers, array());
    	$res_keywords = json_decode($result,true);
    	$keywords = $res_keywords['data']['keywords'];
    }

    //get project_types
    $url = $handyman_api.'getprojecttypes';
    $result = createApiCall($url, 'GET', $headers, array());
    $project_types = json_decode($result,true);
	$project_types_data = array();
	if ($project_types['success']){
		$project_types_data = $project_types['data'];
	}

	//get monetize ads from vnoc
    $url = $api_url.'getbannercode?d='.$domain.'&p=footer';
    $result = createApiCall($url, 'GET', $headers, array());
    $data_ads = json_decode($result,true);
    $footer_banner = html_entity_decode(base64_decode($data_ads['data']['content']));

    //get fund campaigns
	$url = $api_url.'getfundcampaigns';
	$result = createApiCall($url, 'GET', $headers, array());
	$data_fundcampaigns = json_decode($result,true);
	$fundcampaigns = array();
	if ($data_fundcampaigns['success']){
		$fundcampaigns = $data_fundcampaigns['data'];
	}

	//get related domains with nologos and with category slug
	$url = $api_url.'getrelateddomainsnologo?domain='.$domain.'&limit=20';
	$result = createApiCall($url, 'GET', $headers, array());
	$vertical_nologo = json_decode($result,true);
	$vertical_domains_nologo = array();
	if ($vertical_nologo['success']){
		$vertical_domains_nologo = $vertical_nologo['data'];
	}

	//get related domains with logos only and with category slug
	$url = $api_url.'getrelateddomains?domain='.$domain.'&limit=20';
	$result = createApiCall($url, 'GET', $headers, array());
	$vertical = json_decode($result,true);
	$vertical_domains = array();
	if ($vertical['success']){
		$vertical_domains = $vertical['data'];
	}

	//get domain affiliate id
    $url = $api_url.'getdomainaffiliateid?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $data_domain_affiliate = json_decode($result,true);
    if ($data_domain_affiliate['success']){
    	$domain_affiliate_id = $data_domain_affiliate['data']['affiliate_id'];
    }else {
    	$domain_affiliate_id = '391'; //contrib.com affiliate id
    }
    $domain_affiliate_link = 'https://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=https://www.contrib.com/signup/firststep?domain='.$domain;


    $url = $api_url.'getReferralBanners?domain='.$domain.'&key='.$key.'&affiliate_id='.$domain_affiliate_id;
    $result = createApiCall($url, 'GET', $headers, array());
    $program_result = json_decode($result,true);
    $programs = array();  
    if ($program_result['success']){
    	$programs = $program_result['data'];
    }

    //get domain socials

	  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=fb';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_fb = $social_result['data']['profile_url'];
	  }else {
	    $social_fb = "";
	  } 
	    
	  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=gplus';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_gplus  = $social_result['data']['profile_url'];
	  }else {
	    $social_gplus = "";
	  } 
	  
	  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=twitter';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_twitter  = $social_result['data']['profile_url'];
	  }else {
	    $social_twitter = "";
	  } 
	  
	  
	  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=linkedin';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_linkedin  = $social_result['data']['profile_url'];
	  }else {
	      $social_linkedin = "";
	  } 
	      
	  $url = $api_url.'GetDomainSocial?domain='.$domain.'&key='.$key.'&default=contrib.com&social=gtube';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $social_result = json_decode($result,true);
	  if ($social_result['success']){
	      $social_gtube  = $social_result['data']['profile_url'];
	  }else {
	      $social_gtube = "";
	  }

	  //get contractors
	  $url = $api2_url.'GetHandymanContractors';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $contractors = json_decode($result,true);
	  $contractors_data = array();
	  if ($contractors['success']){
	  	$contractors_data = $contractors['data'];
	  }

	  //get states
	  $url = $api2_url.'GetHandymanStates';
	  $result = createApiCall($url, 'GET', $headers, array());
	  $states = json_decode($result,true);
	  $states_data = array();
	  if ($states['success']){
	  	$states_data = $states['data'];
	  }

	  $file = str_replace('{{DOMAIN}}',$domain , $file);
	  $file = str_replace('{{DOMAIN_ID}}',$domainid , $file);
	  $file = str_replace('{{MEMBER_ID}}',$memberid, $file);
	  $file = str_replace('{{TITLE}}',$title, $file);
	  $file = str_replace('{{LOGO}}',$logo, $file);
	  $file = str_replace('{{KEYWORDS}}', $keywords, $file);
	  $file = str_replace('{{DESCRIPTION}}',$description, $file);
	  $file = str_replace('{{ACCOUNT_GA}}',$account_ga, $file);   
	  $file = str_replace('{{PIWIK_ID}}',$piwik_id, $file);
	  $file = str_replace('{{BACKGROUND_IMAGE}}',$background_image, $file);
   	  $file = str_replace('{{FOOTER_HTML}}',$footer_html, $file);
   	  $file = str_replace('{{FOOTER_BANNER}}',$footer_banner, $file);
   	  $file = str_replace('{{AFFILIATE_LINK}}',$domain_affiliate_link, $file);
   	  $file = str_replace('{{SOCIAL_FB}}',$social_fb, $file);
  	  $file = str_replace('{{SOCIAL_GPLUS}}',$social_gplus, $file);
  	  $file = str_replace('{{SOCIAL_TWITTER}}',$social_twitter, $file);
  	  $file = str_replace('{{SOCIAL_LINKEDIN}}',$social_linkedin, $file);
  	  $file = str_replace('{{SOCIAL_GTUBE}}',$social_gtube, $file);
  	  $file = str_replace('{{FUND_CAMPAIGNS}}',var_export($fundcampaigns, true), $file);
  	  $file = str_replace('{{VERTICAL_DOMAINS}}',var_export($vertical_domains, true), $file);
   	  $file = str_replace('{{VERTICAL_DOMAINS_NOLOGO}}',var_export($vertical_domains_nologo, true), $file);
   	  $file = str_replace('{{STATES}}',var_export($states_data, true), $file);
   	  $file = str_replace('{{CONTRACTORS}}',var_export($contractors_data, true), $file);
   	  $file = str_replace('{{PROGRAMS}}',var_export($programs, true), $file);
   	  $file = str_replace('{{AFFILIATE_ID}}',$domain_affiliate_id,$file);

   	  file_put_contents('config-framework.php', $file);

}
include "./config-framework.php";
$config['base_url']	= '/';



$config['default_controller'] = 'home'; // Default controller to load
$config['error_controller'] = 'error'; // Controller used for errors (e.g. 404, 500 etc)

if(defined('ENV')){
	$config['db_host'] = ''; // Database host (e.g. localhost)
	$config['db_name'] = ''; // Database name
	$config['db_username'] = ''; // Database username
	$config['db_password'] = ''; // Database password
}else {
	// $config['db_host'] = '162.242.169.48'; // Database host (e.g. localhost)
	$config['db_host'] = '69.64.76.77'; // Database host (e.g. localhost)
	$config['db_name'] = 'contrib_rdb'; // Database name
	$config['db_username'] = 'contread'; // Database username
	$config['db_password'] = 't1ng1nd4w'; // Database password
}
?>