<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $piwik_id = "{{PIWIK_ID}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "{{BACKGROUND_IMAGE}}";
    $keywords = "{{KEYWORDS}}";
    $top_description = stripslashes(str_replace('\n','<br>',$top_description));
	$footer_html = "{{FOOTER_HTML}}";
    $footer_banner = "{{FOOTER_BANNER}}";
    $domain_affiliate_id = "{{AFFILIATE_ID}}";
    $domain_affiliate_link = "{{AFFILIATE_LINK}}";
    $vertical_domains = {{VERTICAL_DOMAINS}};
    $vertical_domains_nologo = {{VERTICAL_DOMAINS_NOLOGO}};
    $fundcampaigns = {{FUND_CAMPAIGNS}};
    $states = {{STATES}};
	$contrators = {{CONTRACTORS}};
    $programs = {{PROGRAMS}};
	$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
   
    $social_fb = '{{SOCIAL_FB}}';
    $social_gplus = '{{SOCIAL_GPLUS}}';
    $social_twitter = '{{SOCIAL_TWITTER}}';
    $social_linkedin = '{{SOCIAL_LINKEDIN}}';
    $social_gtube = '{{SOCIAL_GTUBE}}';
?>