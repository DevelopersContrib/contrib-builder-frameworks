<?php include('header.php');?>
	<div class="span3"></div>
		
	<div class="span6 follow-desc" style="">
		<div class="wrap-rght">
				<h1 class="rght-ttle text-center">Contact <?=ucfirst($info['domain'])?></h1>
					<center>
						<iframe src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?echo $info['domain']?>" scrolling="no" frameborder="0" style="width: 350px;background: whitesmoke;height: 500px;padding: 15px 0 0 15px;border-radius: 5px;margin:40px"></iframe>																		
					</center>
		</div>

	</div>
	<div class="span3"></div>
	
<?php include('footer.php');?>