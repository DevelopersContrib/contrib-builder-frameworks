<? include('header.php');?>

<div id="contents">
		<div class="background">
			<h3>Lorem ipsum dolor</h3>
			<p>
				Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, <a href="#">totam rem aperiam</a>, eaque ipsa quae ab illo inventore 
				veritatis et quasi <a href="#">architecto beatae vitae</a> dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia 
				consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
			</p>

			<h3>Lorem ipsum dolor</h3>
			<p>
				Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore 
				veritatis et quasi <a href="#">architecto beatae vitae</a> dicta sunt explicabo. Nemo enim ipsam voluptatem quia <a href="#">voluptas</a> sit aspernatur aut odit aut fugit, sed quia 
				consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
			</p>

			<h3>Lorem ipsum dolor</h3>
			<p>
				Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo <a href="#">inventore</a> 
				veritatis et quasi <a href="#">architecto beatae vitae</a> dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia 
				consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
			</p>

		</div>
	</div> <!-- /#contents -->

	
<? include('footer.php');?>