<? include('header.php');?>

	<div id="contents">
		<div class="background">
			<div id="blogs">
				<div class="sidebar">
					<div class="posts">
						<h3>Recent Posts</h3>
						<ul>
							<li><a href="blog.php">Aliquam varius pulvinar lorem ipsum dolor sit amet</a></li>
							<li><a href="blog.php">Fusce purus urna, commodo ac tempus id </a></li>
							<li><a href="blog.php">Praesent pharetra molestie massa ornare</a></li>
							<li><a href="blog.php">Vestibulum tempus erat sit amet nam non erat neque</a></li>
							<li><a href="blog.php">Sed quis diam ac neque mauris vulputate ut blandit </a></li>
						</ul>
					</div>
					<div class="archives">
						<h3>Archives</h3>
						<ul>
							<li><a href="">December</a></li>
							<li><a href="">June</a></li>
							<li><a href="">November</a></li>
							<li><a href="">May</a></li>
							<li><a href="">October</a></li>
							<li><a href="">April</a></li>
							<li><a href="">September</a></li>
							<li><a href="">March</a></li>
							<li><a href="">August</a></li>
							<li><a href="">February</a></li>
							<li><a href="">July</a></li>
							<li><a href="">January</a></li>
						</ul>
					</div>
				</div>
				<div class="section">
					<h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ut turpis vitae purus cursus malesuada at sed lacus.</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ut turpis vitae purus cursus malesuada at sed lacus. Integer pretium luctus felis, a dictum dui malesuada in. Praesent nunc erat, mollis sed varius id, 
						blandit ut nisi.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ut turpis vitae purus cursus malesuada at sed lacus. Integer pretium luctus felis, a dictum dui malesuada in. Praesent nunc erat, mollis sed varius id, 
						blandit ut nisi.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ut turpis vitae purus cursus malesuada at sed lacus. Integer pretium luctus felis, a dictum dui malesuada in. Praesent nunc erat, mollis sed varius id, 
						blandit ut nisi. Aliquam in ipsum purus, in dignissim turpis. Nullam a adipiscing felis. Etiam a egestas dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc eu neque vel 
						velit fringilla placerat at eu nulla. Sed tempus metus a lectus tristique in malesuada dolor mollis. Praesent nisl leo, aliquet elementum ullamcorper ut, accumsan et justo. Curabitur porttitor, dolor dapibus sodales 
						tristique, nisi dui interdum lorem, et bibendum nisi massa ac magna. Donec vitae velit nec metus faucibus aliquam. Donec at ligula sem, sit amet euismod turpis. In ac augue sed orci ultrices mollis ut ut felis. Quisque 
						condimentum facilisis velit, vel sollicitudin ligula lobortis eget. Nulla ut metus nulla. Proin vulputate tristique feugiat. Nulla et dui est, a scelerisque turpis. Ut id augue velit. Morbi lobortis quam aliquam felis 
						commodo hendrerit. Nulla sit amet velit iaculis sem tempor mattis id nec augue. Curabitur eleifend tempus quam, condimentum mollis massa rhoncus sed. Curabitur vel lacus mauris. Phasellus id ligula a felis scelerisque 
						tempor. Mauris in odio ligula. Duis sit amet euismod neque. Aenean consectetur pulvinar enim nec lobortis. Donec eget enim purus. Curabitur ut erat turpis. Mauris sollicitudin porta elit, nec accumsan est vestibulum eget. 
						Nam quis rutrum orci. Integer sit amet imperdiet orci. Vestibulum pretium consectetur lectus, in porta eros mattis at. Pellentesque in tortor nec metus blandit pellentesque.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ut turpis vitae purus cursus malesuada at sed lacus. Integer pretium luctus felis, a dictum dui malesuada in. Praesent nunc erat, mollis sed varius id, 
						blandit ut nisi. Aliquam in ipsum purus, in dignissim turpis. Nullam a adipiscing felis. Etiam a egestas dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc eu neque vel 
						velit fringilla placerat at eu nulla. Sed tempus metus a lectus tristique in malesuada dolor mollis. Praesent nisl leo, aliquet elementum ullamcorper ut, accumsan et justo. Curabitur porttitor, dolor dapibus sodales 
						tristique, nisi dui interdum lorem, et bibendum nisi massa ac magna.</p>
				</div>
			</div>
		</div>
	</div> <!-- /#contents -->

<? include('footer.php');?>