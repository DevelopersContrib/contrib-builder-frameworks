<?php
$domain = $_SERVER["HTTP_HOST"];//input sitename without www
$domain = str_replace("http://","",$domain);
$domain = str_replace("www.","",$domain);

$api_url = "http://developers.contrib.com/api/";
$api_key = '';


require('curl_client.php');
$max_redirect = 3;  // Skipable: default => 3
$client = new Curl_Client(array(
	CURLOPT_FRESH_CONNECT => 1,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_USERAGENT => ''
), $max_redirect);

/*GET DOMAIN DETAILS*/
$url = $api_url."getdomaindetails?api_key=$api_key&domain=$domain"; 
$client->get($url);
$result = $client->currentResponse('body');
$data_domain = json_decode($result,true);
$error = 0;
if (!$data_domain['error'])
{
	$FrameworkTypeId = $data_domain[0]['FrameworkTypeId'];
	$DomainId = $data_domain[0]['DomainId'];
	
	/*GET FRAMEWORK ATTRIBUTES*/
	$url = $api_url."getattributes?api_key=$api_key&framework_id=$FrameworkTypeId"; 
	$client->get($url);
	$result = $client->currentResponse('body');
	$data_attributes = json_decode($result,true);

	if (!$data_attributes['error'])
	{	
		$attribute_ids = array();
		$logo = ''; 
		$description = ''; 
		$title = ucwords($domain);
			
		foreach($data_attributes as $data){
			$attribute_id = $data['attribute_id'];
			
			/*GET ATTRIBUTE VALUES*/
			$url = $api_url."getattributevalue?api_key=$api_key&attribute_id=$attribute_id&domain_id=$DomainId"; 
			$client->get($url);
			$result = $client->currentResponse('body');
			$data_attributevalue = json_decode($result,true);
						
			if (!$data_attributevalue['error'])
			{
				if($attribute_id=='45') 
					$logo = $data_attributevalue[0]['value'];	//fetch logo value
					
				if($attribute_id=='46') 
					$description = $data_attributevalue[0]['value'];	//fetch description value
					
				if($attribute_id=='44') 
					$title = $data_attributevalue[0]['value'];	//fetch title value

			}
			else{
				$error++;
			}
		}
		
		if($logo!='')
			$logo = '<img src="'.$logo.'" alt="LOGO" style="height: 70px;" />';
		else
			$logo = '<span class="title">'.$title.'</span>';
	}
	else{
		$error++;
	}
}
else{
	$error++;
}

if($error>0){ echo 'error'; EXIT; }

/*

CONNECT TO YOUR DATABASE

$host = "CHANGE_HOSTNAME";
$user = "CHANGE_USERNAME";
$pwd = "CHANGE_PASSWORD";
$db = "CHANGE_DATABASE";

$link = mysql_connect($host, $user,$pwd);

if (!$link) {
	echo "Error establishing connection.";
}
$db_selected = mysql_select_db($db, $link);
*/


?>