<?php include 'includes/config.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<title><?=$title?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="<?php echo $description ?>"/>
    <meta name="keywords" content="<?php echo $keywords; ?>"/>
    <meta name="author" content="<?php echo $domain; ?>"/>
    <!-- Bootstrap -->
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/main.css">
		<link rel="stylesheet" media="screen" type="text/css" href="css/serviceforms/partner.css">
		<link rel="stylesheet" media="screen" type="text/css" href="css/serviceforms/staffing.css">
		<link rel="stylesheet" media="screen" type="text/css" href="css/serviceforms/offer.css">
		<link rel="stylesheet" media="screen" type="text/css" href="css/serviceforms/inquiry.css">
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://code.jquery.com/jquery.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <script type="text/javascript" src="js/owl.carousel.js"></script>
        <script type="text/javascript" src="js/owl.carousel.min.js"></script>
        <style type="text/css">
			.brdr{
				border: 1px solid;
			}
        </style>
        <style type="text/css">
    
  /* carousel css here */

    .wrap-marketplace-box-item {
        background-color: #fff;
        border-radius: 2px;
        border-top: 1px solid #d9d9d9;
        box-shadow: 0 1px 0 1px #d9d9d9;
        display: block;
        padding: 15px;
        text-align: center;
        word-wrap: break-word;
        color: #000;
        text-shadow: none;
        margin-bottom: 25px;
    }
    /* Logo Found */
    .wmbi-img-logo {
        display: block;
        margin-bottom: 15px;
    }
    .wmbi-img-logo img {
        display: inline-block;
        max-height: 60px;
    }
    /* Title Brand */
    .wmbi-ttle {
        background-color: #f5f5f5;
        color: #2e9f3e;
        font-size: 1.3em;
        font-weight: bold;
        padding: 10px 5px;
    }
    .marg-m-ttlTop {
        margin-top: 0;
    }
    .p-marg-btm {
        margin-bottom: 0;
    }
    .ul-wmbi-zero li {
       list-style: outside none none;
        padding: 0;
    }
    .ul-wmbi-zero li .btn{
        margin: 0;
    }
    /* Carousel Custom Brands */
    #brandsCarousel .owl-item{
        padding:15px;
    }
    #brandsCarousel .owl-prev::before,#brandsCarousel .owl-next::before{
        background-color: #e1e1e1;
    }

   /* ===================================
      Owl carousel
  ====================================== */

  .owl-carousel { overflow: hidden; }
  .owl-buttons { position: static; }
  .owl-prev, .owl-next { color: #111; display: block; font-size: 16px; height: 105px; line-height: 105px; margin-top:-35px; opacity: 0; position: absolute; text-align: center; top: 50%; width: 105px; z-index: 6; }
  .owl-prev {left: -70px;}
  .owl-next {right: -70px;}
  .owl-prev:before, .owl-next:before { background-color:#fff; border-radius:2px; box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1); content: ""; display: block; height: 66%; left: 0; position: absolute; width: 66%; }
  .owl-next:before { left: auto; right: 0; }
  .owl-prev .fa, .owl-next .fa {color: #000; font-size: 24px; position: relative; top: -15%;}
  .owl-prev .fa{ right: 4%}
  .owl-next .fa { left: 4%;}
  .owl-carousel:hover .owl-prev {left: -35px; opacity: 1; }
  .owl-carousel:hover .owl-next { opacity: 1; right: -35px; }
  .owl-pagination { bottom: 30px; display: block; left: 0; position: absolute; text-align: center; width: 100%; z-index: 100 !important; }
  .owl-page { display: inline-block; padding: 6px 5px; }
  .owl-page span { background: none repeat scroll 0 0 rgba(255, 255, 255, 0.7); border-radius: 4px; box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1); display: block; height: 7px; transition: all 0.27s cubic-bezier(0, 0, 0.58, 1) 0s; width: 7px; }
  .owl-page:hover span { background: none repeat scroll 0 0 rgba(255, 255, 255, 1); }
  .owl-page.active span { background: none repeat scroll 0 0 transparent; border: 1px solid rgba(255, 255, 255, 0.8); transform: scale(1.33333); }
  .owl-bg-img { background-position: center center; background-repeat: no-repeat; background-size: cover; display: block; overflow: hidden; position: relative; width: 100%; }
  .owl-subtitle { font-size: 14px; letter-spacing: 10px; text-transform: uppercase; font-weight: 400; line-height: 80px; display:block}
  .owl-title { font-size: 35px; font-weight: 600; text-transform: uppercase; display: block; letter-spacing: 7px;}
  .owl-title-big { background: rgba(0, 0, 0, 0.5); display: inline-block; font-size: 25px; font-weight: 600; letter-spacing: 7px; line-height: 40px; padding: 35px 50px; text-transform: uppercase; width: 60% }
  .dark-pagination .owl-page span { background: none repeat scroll 0 0 rgba(0, 0, 0, 1); box-shadow: none }
  .dark-pagination .owl-page.active span {background:transparent; border: 1px solid rgba(0, 0, 0, 1); }
  .dark-pagination .owl-prev, .owl-next { opacity: 1; }
  .dark-pagination .owl-next:before { left: auto; right: 0; }
  .dark-pagination .owl-prev {left: -35px; opacity: 1; }
  .dark-pagination .owl-next { opacity: 1; right: -35px; }
  .light-pagination .owl-page.active span {background: transparent; border: 1px solid rgba(255, 255, 255, 1); }


#featured-wrap {
    background: #fff none repeat scroll 0 0;
    border-bottom: 1px solid #ccc;
    float: left;
    padding: 30px 0;
    width: 100%;
}


.min {
     background: #F8F8F8 none repeat scroll 0 0;
    color: #333333;
    margin-top: 0;
    padding-bottom: 50px;
    padding-top: 50px;
}
.min h1 {
    color: #457FBA;
    font-weight: 700;
    line-height: 45px;
    margin: 0;
    padding: 0;
    text-transform: uppercase;
}

</style>
          <script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?=$account_ga?>']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$piwik_id?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
	</head>
	<body>
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					
						<?if($logo == "" || empty($logo) || $logo == "_"){ ?>
                        
                           <a href="http://<?=$domain?>" alt="<?=$title?>" title="<?=$domain?>" style="font-size: 24px;line-height: 50px;">
                                <b><?=ucwords($domain)?></b>
                           </a>
                        
                        <? }else{ ?>
							<a class="navbar-brand" href="http://<?=$domain?>">
								<img class="img-responsive img-logo"  src="<?=$logo?>" alt="<?=$title?>" title="<?=$domain?>" border="0" />
							</a>
                        <? } ?>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<!--ul class="nav navbar-nav navbar-right">
						<li>
							<a href="#" style="font-size:18px;">Call Us. tel:+1 (317)4143751</a>
						</li>
					</ul-->
				</div><!-- /.navbar-collapse -->
			</div><!-- /.container-fluid -->
		</nav>
		<div <?=($background_image!=''?'style="background:url('.$background_image.') center fixed;"':'')?>>
			<div class="section" <?=($background_image!=''?'style="background: rgba(0,0,0,.3);"':'')?>>
				<div class="container" style="min-height:450px">
			
				