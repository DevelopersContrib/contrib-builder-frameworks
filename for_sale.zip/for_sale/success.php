<?php include 'header.php'; ?>			

<style>
.well {
    min-height: 20px;
    padding: 20px 50px 40px 50px;
    margin-bottom: 20px;
	margin-top: 20px;
    background-color: #fff;
	color:#333;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
    box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
}
.contrib-box-in {
	background:#fafafa;
	color:#333;
	padding: 20px 10px 10px 10px;
	border:1px solid #dedede;
	border-radius:4px;
	margin:20px 0px 20px 0px;
}
</style>
	<div class="row">
	  <div class="col-md-8 col-md-offset-2">
		<div class="well verify-box aboutus">
			<img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" style="width:250px; margin:0px auto;">
			<h2 class="text-center">for submitting your offer.</h2>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> You will be receiving three (3)-emails from Contrib.</h4>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> Please check your spam box for safe measure.</h4>
			<div class="clearfix"><br></div>
			<div class="contrib-box-o">
				<p class="text-center">Contrib is our contribution platform and it allows us to get people to help contribute, make offer or partner with premium world class brands. You could check your Offer submission in your <br><b>"My Offers Contrib App"</b>.</p>
				<a href=""><h4 class="text-center"><i class="fa fa-envelope"></i> Please check your email for your Contrib access.</h4></a>
			</div>
			<div class="clearfix"><br></div>
			<div class="row">
				<div class="contrib-box-in">
					<h2 class="text-center">How It Works?</h2>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-search"></i><br>Step 1</h3>
						<h4>Browse the Marketplace</h4>
						<p>Browse the marketplace and search for sites to submit offers. </p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-file-text-o"></i><br>Step 2</h3>
						<h4>Submit an Offer</h4>
						<p>Click on submit offer and fill up the form.</p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-desktop"></i><br>Step 3</h3>
						<h4>View Offers</h4>
						<p>View all your offer applications that you have submitted to here. </p>
					</div>
					<div class="clearfix"><br></div>
				</div>
			</div>
		</div>		
	  </div>
	</div>

<?php include 'footer.php'; ?>