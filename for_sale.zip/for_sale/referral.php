<?php include 'header.php'; ?>
<style type="text/css">
    
    .line{
        border-bottom: 1px solid;
        width: 95%;
        margin: auto;
    }
    #container2{
        background: rgba(0,0,0,.7) !important;
        color: white;
        width:800px;
        margin-top:50px;
    }	
    legend.title{
        color: white;
        text-align: left;
        width: 95%;
        margin: 10px auto;
        padding-bottom: 10px;
        font-size: 25px;
    }
    .padd-banner{
        padding: 10px 20px;
    }
    .banner-main{
        margin-bottom: 30px;
        padding-bottom:10px;
        border-bottom: 1px solid #fff;
    }
    .banner-main textarea{
        resize:none;
        border-radius: 4px;
        border: 1px solid #000000;
    }
    .banner-main:last-child{
        border-bottom: none;
    }
    .banner-header{
        font-weight: 300;
        color: #fff;
        border-bottom: 1px solid #fff;
        line-height: 65px;
        margin:0 0 30px;
    }
    .banner-img-cont{
        margin-bottom: 25px;
    }
    .banner-source{
        color: #fff;
        font-size:18px;
    }
    .banner-info{
        color: #fff;
    }
    /*
    ==============================================
    tossing
    ==============================================
    */
    
    .tossing{
        animation-name: tossing;
        -webkit-animation-name: tossing;	
        
        animation-duration: 2.5s;	
        -webkit-animation-duration: 2.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes tossing {
        0% {
            transform: rotate(-4deg);	
        }
        50% {
            transform: rotate(4deg);
        }
        100% {
            transform: rotate(-4deg);	
        }						
    }
    
    @-webkit-keyframes tossing {
        0% {
            -webkit-transform: rotate(-4deg);	
        }
        50% {
            -webkit-transform: rotate(4deg);
        }
        100% {
            -webkit-transform: rotate(-4deg);	
        }				
    }
    /*
    ==============================================
    floating
    ==============================================
    */
    
    .floating{
        animation-name: floating;
        -webkit-animation-name: floating;
        
        animation-duration: 1.5s;	
        -webkit-animation-duration: 1.5s;
        
        animation-iteration-count: infinite;
        -webkit-animation-iteration-count: infinite;
    }
    
    @keyframes floating {
        0% {
            transform: translateY(0%);	
        }
        50% {
            transform: translateY(8%);	
        }	
        100% {
            transform: translateY(0%);
        }			
    }
    
    @-webkit-keyframes floating {
        0% {
            -webkit-transform: translateY(0%);	
        }
        50% {
            -webkit-transform: translateY(8%);	
        }	
        100% {
            -webkit-transform: translateY(0%);
        }			
    }
</style>
    <div class="row">
        <div class="col-lg-21">
         <script class="ctb-box" id='referral-script' src='https://www.referrals.com/extension/widget.js?key=<?php echo $widget_id?>' type='text/javascript'></script>
        <div id="script-container"></div>
        </div>
    </div>
    <script type="text/javascript">
    /*$(document).ready(function() {
        var domain = '<?=$domain?>';
    
        $.ajax({
            url: 'https://api1.contrib.co/request/Getdomainwidget?key=5c1bde69a9e783c7edc2e603d8b25023&domain='+domain,
            method: 'POST',
            beforeSend: function() {
        
            },
            success: function(res) {
                if (res.success === true) {
                    $('#script-container').html(`<script class="ctb-box" id="referral-script" src="https://www.referrals.com/extension/widget.js?key=${res.data['widget_id']}" type="text/javascript"><\/script>`);                
                    console.log(res.data['widget_id']);
                }
            },
            complete: function() {
        
            },
        });
    });*/
    </script>
<?php include 'footer.php'; ?>