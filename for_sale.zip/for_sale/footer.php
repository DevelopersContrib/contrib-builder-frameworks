				</div>
			</div>
		</div>	
	<div class="min">
		<div class="container">
				<div class="row">
	      <div class="col-md-12 text-center">
	        <h1>Our Top Brands</h1>
	        <div class="col-md-12">
	          <div id="brandsCarousel" class="owl-carousel">
	          <?php foreach($featuredsites as $featuredsites): ?>
	                 <div>
	                      <div class="wrap-marketplace-box-item">
	                              <a class="wmbi-img-logo" href="http://<?php echo $featuredsites['domain_name']; ?>">
	                                  <?php if(!empty($featuredsites['logo'])):?>
	                              <img src="<?php echo $featuredsites['logo']; ?>" class="img-responsive" alt="<?php echo $featuredsites['domain_name']; ?>" title="<?php echo $featuredsites['domain_name']; ?>">
	                            <?php else: ?>
	                              <img src="https://d2qcctj8epnr7y.cloudfront.net/contrib/logo-contrib-brand2.png" class="img-responsive" alt="contrib.com" title="contrib.com">
	                            <?php endif; ?>
	                                        </a>
	                              <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
	                                  <?php echo $featuredsites['domain_name']; ?>
	                              </h3>
	                              <p class="p-marg-btm">
	                                  Join our exclusive community of like minded people on 
	                              </p>
	                              <p>
	                                  <a target="_blank" href="http://<?php echo $featuredsites['domain_name']; ?>"><?php echo $featuredsites['domain_name']; ?></a>
	                              </p>
	                              <ul class="list-inline ul-wmbi-zero">
	                                  <li>
	                                      <a class="btn btn-success btn" target="_blank" href="http://<?php echo $featuredsites['domain_name']; ?>">Visit</a>
	                                  </li>
	                                  <li>
	                                      <a class="btn btn-success btn" target="_blank" href="https://contrib.com/brand/details/<?php echo $featuredsites['domain_name']; ?>">Details</a>
	                                  </li>
	                              </ul>
	                          </div>
	                      </div>
	          <?php endforeach; ?>
	         </div>
	        </div>
	      </div>
	    </div>
		</div>
	</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<script  src="https://code.jquery.com/jquery-3.0.0.min.js" integrity="sha256-JmvOoLtYsmqlsWxa7mDSLMwa6dZ9rrIdtrrVYRnDRH0="crossorigin="anonymous"></script>
<script type="text/javascript" src="js/owl.carousel.js"></script>
<div id="chat_content" data="<?=$domain?>"></div>
<script type="text/javascript" src="https://tools.contrib.com/js/chat.js"></script>	
<script>
    jQuery(document).ready(function(){
        jQuery("#brandsCarousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            items: 3,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        });
    }); 
</script>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
		<div class="footer" style="display:none">
			<div class="container">
				<div class="row">
					<div class="row">
						<div class="col-lg-12">
						<ul class="list-inline text-center ul-link-footer-nav">
							<li>
								<a href="/">Home</a>
							</li>
							<li>
								<a href="/about">About</a>
							</li>
							<li>
								<a href="/contact">Contact Us</a>
							</li>
							<li>
								<a href="/partner">Partner with us</a>
							</li>
							<li>
								<a href="/apply">Apply now</a>
							</li>
							<li>
								<a href="/terms">Terms</a>
							</li>
							<li>
								<a href="/privacy">Privacy</a>
							</li>
							<li>
								<a href="/referral">Referral</a>
							</li>
						</ul>
					</div>
					</div>
					<div class="col-lg-12">
						<p class="text-center">&copy; 2014 <?=ucwords($domain);?> All rights reserved. </p>
					</div>
				</div>
			</div>
		</div>
		<!-- new footer-->
<div class="footer-top">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-3">
			<h3><?php echo $domain?></h3>
			<p>is a proud venture of Global Ventures, LLC. Join our network of performance based companies using <?php echo $domain?>.</p>
		  </div>
		  <div class="border col-md-3">
			<h3>Get Started</h3>
			<ul class="list-unstyled">
				<li><a href="/partner">Partner With Us</a></li>
				<li><a href="/apply">Apply Now</a></li>
				<li><a href="/referral">Referral</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3>Company</h3>
			<ul class="list-unstyled">
				<li><a href="/about">About Us</a></li>
				<li><a href="/terms">Terms</a></li>
				<li><a href="/privacy">Privacy</a></li>
				<li><a href="/contact">Contact Us</a></li>
				<li><a href="/apps">Apps</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3>Partners</h3>
				<?if($footer_html != ""):?>
				<?echo base64_decode($footer_html)?>
					<?php else:?>
					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
				<?endif;?>
			<h3>Social</h3>
			<ul class="list-inline socials-ul">
											<li>
												<a title="facebook" class="icon-button facebook" href="<?php echo $social_fb ?>">
													<i class="fa fa-facebook-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="google-plus" class="icon-button google-plus" href="<?php echo $social_gplus ?>">
													<i class="fa fa-google-plus-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="youtube" class="icon-button youtube" href="<?php echo $social_twitter ?>">
													<i class="fa fa-twitter-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="linkedin" class="icon-button linkedin" href="<?php echo $social_linkedin ?>">
													<i class="fa fa-linkedin-square"></i>
													<span></span>
												</a>
											</li>
			</ul>
		  </div>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-6"><span style="color:#fff">&copy; <?php echo $domain?>. All Rights Reserved.</span></div>
		  <div class="border col-md-6">
			  <ul class="list-inline">			
				<li><a href="/about"><i class="fa fa-bookmark-o"></i> About Us</a></li>
				<li><a href="/terms"><i class="fa fa-book"></i> Terms</a></li>
				<li><a href="/privacy"><i class="fa fa-cube"></i> Privacy</a></li>
				<li><a href="/contact"><i class="fa fa-phone-square"></i> Contact Us</a></li>
			  </ul>
		  </div>
		</div>
	</div>
</div>
<!-- new footer-->
	</body>
</html>
<script src="http://tools.contrib.com/cwidget?d=<?php echo $domain?>&p=sb&c=f"></script>