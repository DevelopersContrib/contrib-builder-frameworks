<?php include 'header.php'; ?>
<?php include 'serviceforms/variables.php'; ?>
				<div class="row">
					<div class="col-lg-12">
						<h3 class="text-center">
							Our Staffing Needs At <?=ucwords($domain)?>
						</h3>						
						<hr class="lineLines">
						<br>
						<p class="text-center">
							We are looking for the best of the best, Full-Time, Part-Time, Moonlighting, Contractual and Freelance.
							<br>
							We consult and manage over 100,000 domain name ventures and are always seeking Strategic Partnerships, Applications, Domains, Engineers, Developers, Specialist and just cool smart people around the Globe. Learn more about openings and opportunities with our partner companies and send us your resume or examples to accelerate the process.
							<br>
							Learn more about openings and opportunities with our partner companies
						</p>
					</div>
				</div>
				
				<div class="row">
					<div class="col-lg-3">&nbsp;</div>
									
					<div class="col-lg-6">
						
					
						<div class="wrap-forSale-form">
							<div class="col-lg-12 whiteBckg" style="min-height: 335px;">
													
								<? include('serviceforms/service_staffing.php');?>					
													
							</div>
						</div>
											
					</div>
										
					<div class="col-lg-3">&nbsp;</div>
				</div>
<?php include 'footer.php'; ?>