<?php include 'header.php'; ?>
<?php include 'serviceforms/variables.php'; ?>
				<div class="row">
					<div class="col-lg-12">
						<h3 class="text-center">
							Interested In Sponsoring, Partnering Or Supporting Designerservice.Com, Join Free Today
						</h3>
						<hr class="lineLines">
					</div>
				</div>
				
				<div class="row">
					<div class="col-lg-3">&nbsp;</div>
									
					<div class="col-lg-6">
						
					
						<div class="wrap-forSale-form">
							<div class="col-lg-12 whiteBckg" style="min-height: 335px;">
													
								<? include('serviceforms/service_partner.php');?>					
													
							</div>
						</div>
											
					</div>
										
					<div class="col-lg-3">&nbsp;</div>
				</div>
<?php include 'footer.php'; ?>