
    <div class="inquiryMainCont" id="inquiry_step1">
        <h2 class="ttleCapt">Inquire about <?=ucwords($domain)?></h2>
        <div class="formDesc">
            <small>
                Enter a correct email, your email and inquiry will be deemed private but you will receive a response from our team as soon as we receive your inquiry.
            </small>
        </div>
		
        <div class="stepsMain">
            <div class="step text-center">
                 <h4>Step 1: <i class="icon-file-alt"></i> Submit Your Inquiry</h4>
                 <p>If you have questions, feel free to contact us.</p>
            </div>
            <div class="step text-center">
                <h4>Step 2: <i class="icon-tasks"></i>We Will Contact You Shortly</h4>
                <p>You will receive an email addressing your concern.</p>
            </div>
        </div>
        <div class="col-lg-12">
            <form onsubmit="return false;">
                <div class="emailContainer">
                   <div class="text-center s3Input">
                        <input class="s1Input form-control" type="text" id="inquiry_initialemail" placeholder="Enter e-mail address" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="form-actions f-a-style">
                    <span class="pull-left text-error" id="inquiry_warning1"></span>
                    <button type="submit" class="btn blue pull-right" id="inquiry_btn_1">Apply Today <i class="icon-circle-arrow-right"></i></button>
                    <input type="hidden" id="inquiry_domain" value="<?=$domain?>" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Website">
                </div>
            </form>
        </div>
    </div>
    <div class="inquiryMainCont" id="inquiry_step2" style="display:none">
        <h2 class="ttleCapt">Inquire about <?=ucwords($domain)?></h2>
        <div class="formDesc">
            <small>
                Enter a correct email, your email and inquiry will be deemed private but you will receive a response from our team as soon as we receive your inquiry.
            </small>
        </div>
        <form class="" onsubmit="return false;">
            
                <div class="col-lg-12">
                    <div class="formTwo 1">
                        <label for="inquiry_firstname" class="control-label">
                            First Name <i class="text-error">*</i>
                        </label>
                        <input class="s1Input form-control" type="text" id="inquiry_firstname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Firstname">
                    </div>
                    <div class="formTwo">
                        <label for="inquiry_lastname" class="control-label">
                            Last Name <i class="text-error">*</i>
                        </label>
                        <input class="s1Input form-control" type="text" id="inquiry_lastname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Lastname">
                    </div>
                    <div class="formTwo 1">
                        <label for="inquiry_email" class="control-label">
                            Email <i class="text-error">*</i>
                        </label>
                        <input class="s1Input form-control" type="text" id="inquiry_email" placeholder="Email" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
                    </div>
                    <div class="formTwo">
                        <label for="inquiry_company" class="control-label">
                            Contact Number <i class="text-error">*</i>
                        </label>
                        <input class="s1Input form-control" type="text" id="inquiry_contact" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Contact Number">
                    </div>
                    <div class="formTwo 1">
                        <label for="inquiry_country" class="control-label">
                            Country <i class="text-error">*</i>
                        </label>
                        <select class="selectS2 form-control" name="" id="inquiry_country" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Country">
                            <option value=""></option>
							<?php for($ci=0;$ci<sizeof($countriesarray);$ci++){ ?>
                            <option value="<?=$countriesarray[$ci]['country_id']?>"><?=$countriesarray[$ci]['name']?></option>
                            <?}?>
                        </select>
                    </div>
                    <div class="formTwo">
                        <label for="inquiry_city" class="control-label">
                          City <i class="text-error">*</i>
                        </label>
                        <input class="s1Input form-control" type="text" id="inquiry_city" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your City">
                    </div>
                    <div class="formTwo 1">
                        <label for="inquiry_password" class="control-label">
                            Password <i class="text-error">*</i>
                        </label>
                      <input class="s1Input form-control" type="password" id="inquiry_password" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Password">
                    </div>
                    <div class="formTwo">
                        <label for="inquiry_cpassword" class="control-label">
                            Confirm Password <i class="text-error">*</i>
                        </label>
                        <input class="s1Input form-control" type="password" id="inquiry_password2" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Confirm Password">
                    </div>
                    <div class="formTwo 1" style="width:98%">
                        <label for="partner_message" class="control-label">
                            Message <i class="text-error">*</i>
                        </label>
                        <textarea class="textS2 form-control" id="inquiry_message" rows="4" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Message Here"></textarea>
                    </div>
                
            </div>
            
            <div class="col-lg-12">
                    <div class="requiredFieldError" id="inquiry_warning2"></div>
                    <div class="form2Button">
                        <button type="submit" class="btn blue" id="inquiry_btn_2" style="float: right;">Next <i class="icon-circle-arrow-right"></i></button>
                    </div>
                
            </div>
        </form>
    </div>
    <div class="inquiryMainCont" id="inquiry_final" style="display:none">
        <h2 class="ttleCapt">Inquire about <?=ucwords($domain)?></h2>
        <hr />
        <h4 class="text-error text-center">Thank you for contacting us.</h4>
        <div class="formDesc2" style="text-align: center;">
            <small>You are now minutes away to joining <?=ucwords($domain)?> team.</small><br>
            <br>
            <ol>
                <li>
                    <small>
                        Click the link in the <span class="text-info">Verification email</span> that we have just sent you. If you still haven't received it, please check your spam inbox.
                    </small>
                </li>
                <li>
                    <small>
                        Your verification link will redirect you to our <a target="_blank" href="https://www.contrib.com">Marketpalce hub</a> where you can login and check out your application status.
                    </small>
                </li>
                <li>
                    <small>
                        You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.
                    </small>
                </li>
            </ol>
			<br><br>
			<div id="viewcontriblink">Thank You!</div>
        </div>
    </div>

	<script>
$(document).ready(function(){
    // $('input[rel="txtTooltip"]').tooltip();
    // $('data-toggle="tooltip"').tooltip();
});
$(document).ready(function(){
    // $('textarea[rel="txtTooltip"]').tooltip();
});
$(document).ready(function(){
    // $('select[rel="txtTooltip"]').tooltip();
});
</script>

	<script src="<?php echo $base_url?>js/serviceforms/service_inquiry.js"></script>