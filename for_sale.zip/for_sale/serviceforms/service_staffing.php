
	<div class="staffingMainCont" id="staffing2_step1">
		<h2 class="ttleCapt">Apply Today for <?=ucwords($domain)?></h2>
		<div class="formDesc">
			<small>
				When you submit your registration, you can quickly join the <?=ucfirst($domain)?>. team and take part in micro tasks and be paid in services fees, equity or performance equities.
			</small>
		</div>
		<br>
		<div class="stepsMain">
			<div class="step text-center">
				<h4>Step 1: <i class="fa fa-file-alt"></i> Submit an Application</h4>
				<p>You will receive an email when we approve your application.</p>
			</div>
			<div class="step text-center">
				<h4>Step 2: <i class="fa fa-tasks"></i> Start working on Tasks and Requests </h4>
				<p>Make money by getting equity or pay per performance for tasks rendered and service requests fulfilled.</p>
			</div>
		</div>
		
		<div class="col-lg-12">
				<form class="" onsubmit="return false;">
					<div class="emailContainer">
						<div class="text-center s3Input">
							<input class="s1Input form-control" type="text" id="staffing2_initialemail" placeholder="Enter e-mail address" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="form-actions f-a-style">
						<span class="pull-left text-error" id="staffing2_warning1"></span>
						<button type="submit" class="btn blue pull-right" id="staffing2_btn_1">Apply Today <i class="fa fa-circle-arrow-right"></i></button>
					</div>
				</form>
			
		</div>
	</div>
	<div class="staffingMainCont" id="staffing2_step2" style="display:none">
		<h2 class="ttleCapt">Apply Today for <?=ucwords($domain)?></h2>
		<div class="formDesc">
			<small>
				When you submit your registration, you can quickly join the <?=ucfirst($domain)?>. team and take part in micro tasks and be paid in services fees, equity or performance equities.
			</small>
		</div>
		<form class="" onsubmit="return false;">
			
			<div class="col-lg-12">
					<div class="formTwo 1">
						<label for="staffing2_firstname" class="control-label">
							First Name <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="staffing2_firstname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Firstname">
					</div>
					<div class="formTwo">
						<label for="staffing2_lastname" class="control-label">
							Last Name <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="staffing2_lastname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Lastname">
					</div>
					<div class="formTwo 1">
						<label for="staffing2_email" class="control-label">
							Email <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="staffing2_email" placeholder="Email" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
					</div>
					<div class="formTwo">
						<label for="staffingwebsite" class="control-label">
							Website
						</label>
						<input class="s1Input form-control" type="text" id="staffing2_website" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Website if any" placeholder="http://">
					</div>
					<div class="formTwo 1">
						<label for="staffing2_country" class="control-label">
							Country <i class="text-error">*</i>
						</label>
						<select class="selectS2 form-control" name="" id="staffing2_country" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Country">
							<option value=""></option>
							<?php for($ci=0;$ci<sizeof($countriesarray);$ci++){ ?>
							<option value="<?=$countriesarray[$ci]['country_id']?>"><?=$countriesarray[$ci]['name']?></option>
							<?php } ?>
						</select>
					</div>
					<div class="formTwo">
						<label for="staffing2_city" class="control-label">
							City <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="staffing2_city" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your City">
					</div>
					<div class="formTwo 1">
						<label for="staffing2_password" class="control-label">
							Password <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="password" id="staffing2_password" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Password">
					</div>
					<div class="formTwo">
						<label for="staffing2_cpassword" class="control-label">
							Confirm Password <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="password" id="staffing2_password2" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Confirm Password">
					</div>
				
			</div>
			
			<div class="col-lg-12" style="margin-top: 10px;">
					<div class="requiredFieldError" id="staffing2_warning2"></div>
					<div class="form2Button">
						<button type="submit" class="btn blue" id="staffing2_btn_2" style="float: right;">Next <i class="fa fa-circle-arrow-right"></i></button>
					</div>
				
			</div>
		</form>
	</div>
	<div class="staffingMainCont" id="staffing2_step3" style="display:none">
		<h2 class="ttleCapt">Apply Today for <?=ucwords($domain)?></h2>
		<div class="formDesc">
			<small>
				When you submit your registration, you can quickly join the <?=ucfirst($domain)?>. team and take part in micro tasks and be paid in services fees, equity or performance equities.
			</small>
		</div>
		<form class="" onsubmit="return false;">
			
			<div class="col-lg-12">
					<div class="formTwo" style="width:100%">
						<label for="staffing2_role" class="control-label">
							Team Role <i class="text-error">*</i>
						</label>
						<select class="selectS2 form-control" name="" id="staffing2_role" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Select Team Role">
							<option value=""></option>
							<?php for($ci=0;$ci<sizeof($rolesarray);$ci++){ ?>	
								<?if(!($rolesarray[$ci]['role_id'] == 29 || $rolesarray[$ci]['role_id'] == 11)){?>
									<option value="<?=$rolesarray[$ci]['role_id']?>"><?=$rolesarray[$ci]['role_name']?></option>
								<?php } ?>
							<?php } ?>
						</select>
					</div>
					<div class="formTwo" style="width:100%">
						<label for="staffing2_companyurl" class="control-label">
							Resume Link <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="staffing2_resumeurl" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Resume Link" placeholder="http://">
					</div>
					<div class="formTwo" style="width:100%">
						<label for="staffing2_message" class="control-label">
							Why you should join in our team? <i class="text-error">*</i>
						</label>
						<textarea class="textS2 form-control" id="staffing2_message" rows="5" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Message"></textarea>
					</div>
				
			</div>
			
			<div class="col-lg-12">
					<div class="requiredFieldError" id="staffing2_warning3" style="margin: 5px 0 10px;text-align:center"></div>
					<div class="form2Button">
						<button type="submit" class="btn blue" style="float: right;" id="staffing2_btn_3">Next <i class="fa fa-circle-arrow-right"></i></button>

						<button type="submit" class="btn blue" id="staffing2_back_3"><i class="fa fa-circle-arrow-left"></i>Back</button>
					</div>
				
			</div>
		</form>
	</div>
	<div class="staffingMainCont" id="staffing2_step4" style="display:none">
		<h2 class="ttleCapt">Apply Today for <?=ucwords($domain)?></h2>
		<div class="formDesc">
			<small>
				When you submit your registration, you can quickly join the <?=ucfirst($domain)?>. team and take part in micro tasks and be paid in services fees, equity or performance equities.
			</small>
		</div>
		<form class="" onsubmit="return false;">
			
			<div class="col-lg-12">
				<br>
					<table class="generic_form" style="width: 100%;">
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/facebook.png">
								<input class="input-medium" type="text" name="facebook" id="staffing2_facebook" value="" placeholder="link to your facebook profile">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/linkedin.png">
								<input class="input-medium" type="text" name="linkedin" id="staffing2_linkedin" value="" placeholder="link to your linkedin profile">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/github.png">
								<input class="input-medium" type="text" name="github" id="staffing2_github" value="" placeholder="link to your github account">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/skype.png">
								<input class="input-medium" type="text" name="skype" id="staffing2_skype" value="" placeholder="your skype id">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/yahoo.png">
								<input class="input-medium" type="text" name="yahoo" id="staffing2_yahoo" value="" placeholder="your yahoo id">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/gtalk.png">
								<input class="input-medium" type="text" name="talk" id="staffing2_talk" value="" placeholder="your gtalk id">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/aol.png">
								<input class="input-medium" type="text" name="aol" id="staffing2_aol" value="" placeholder="your AOL id">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
						<tr>
							<td>
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/icons/windows.png">
								<input class="input-medium" type="text" name="wlive" id="staffing2_wlive" value="" placeholder="your windows live id">
								<span style="font-size: 9px;">(optional)</span>
							</td>
						</tr>
					</table>
				</div>
			
			
			<div class="col-lg-12">
					<div class="requiredFieldError" id="staffing2_warning4" style="margin: 0 0 15px;text-align:center"></div>
					<div class="form2Button">
						<button type="submit" class="btn blue" style="float: right;" id="staffing2_btn_4">Apply Today <i class="fa fa-circle-arrow-right"></i></button>
						<button type="submit" class="btn blue" id="staffing2_back_4"><i class="fa fa-circle-arrow-left"></i>Back</button>
						<input type="hidden" id="staffing2_domain" value="<?=$domain?>" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Website">
					</div>
				
			</div>
		</form>
	</div>
	<div class="staffingMainCont" id="staffing2_final" style="display:none">
		<h2 class="ttleCapt">Apply Today for <?=ucwords($domain)?></h2>
		<hr />
		<h4 class="text-error text-center">Thank you for your application.</h4>
		<div class="formDesc2" style="text-align: center;">
			<small>You are now minutes away to joining <?=ucwords($domain)?> team.</small>
			<br>
			<br>
			<ol>
				<li>
					<small>
						Click the link in the <span class="text-info">Verification email</span> that we have just sent you. If you still haven't received it, please check your spam inbox.
					</small>
				</li>
				<li>
					<small>
						Your verification link will redirect you to our <a target="_blank" href="http://www.contrib.com">Marketpalce hub</a> where you can login and check out your application status.
					</small>
				</li>
				<li>
					<small>
						You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.
					</small>
				</li>
			</ol>
			<br><br>
			<div id="viewcontriblink">Thank You!</div>
		</div>
	</div>

	<script>
$(document).ready(function(){
    // $('input[rel="txtTooltip"]').tooltip();
		// $('data-toggle="tooltip"').tooltip();
});
$(document).ready(function(){
    // $('textarea[rel="txtTooltip"]').tooltip();
});
$(document).ready(function(){
    // $('select[rel="txtTooltip"]').tooltip();
});
</script>

<script src="<?php echo $base_url?>js/serviceforms/service_staffing.js"></script>