<style>
	.well {
		min-height: 20px;
		padding: 20px 50px 40px 50px;
		margin-bottom: 20px;
		margin-top: 20px;
		background-color: #fff;
		color:#333;
		border: 1px solid #ccc;
		border-radius: 4px;
		-webkit-box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
		box-shadow: 0 0 0.55rem 0 rgba(0, 0, 0, 0.25);
	}
	.contrib-box-in {
		background:#fafafa;
		color:#333;
		padding: 20px 10px 10px 10px;
		border:1px solid #dedede;
		border-radius:4px;
		margin:20px 0px 20px 0px;
	}
</style>

<div class="offerMainCont" id="offer_step1">
	<h2 class="ttleCapt">Submit An Offer for <?=ucwords($domain)?></h2>
	<div class="formDesc">
		<small>
			Enter a correct email, your email and offer inquiry will be deemed private but you will receive a response from the domain owner as soon as we receive your inquiry.
		</small>
	</div>
	<div class="stepsMain">
		<div class="step text-center">
			<h4>Step 1: <i class="icon-file-alt"></i> Submit Your Offer</h4>
			<p>Interested in our domain? Send an offer now.</p>
		</div>
		<div class="step text-center">
			<h4>Step 2: <i class="icon-tasks"></i> We'll Contact You Shortly</h4>
			<p>You will receive an email addressing your offer.</p>
		</div>
	</div>
	<div class="col-lg-12">
		<form class="" onsubmit="return false;">
			<div class="emailContainer">
				<div class="text-center s3Input">
					<input class="s1Input input-block form-control" type="text" id="offer_initialemail" placeholder="Enter e-mail address" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="form-actions f-a-style">
				<span class="pull-left text-error" id="offer_warning1"></span>
				<button type="submit" class="btn blue pull-right" id="offer_btn_1">Next <i class="icon-circle-arrow-right"></i></button>
			</div>
		</form>
	</div>
</div>
<div class="offerMainCont" id="offer_step2" style="display:none">
	<h2 class="ttleCapt">Submit An Offer for <?=ucwords($domain)?></h2>
	<div class="formDesc">
		<small>
			Enter a correct email, your email and offer inquiry will be deemed private but you will receive a response from the domain owner as soon as we receive your inquiry.
		</small>
	</div>
	<form onsubmit="return false;">
		<div class="col-lg-12">

			<div class="formTwo 1">
				<label for="offer_firstname" class="control-label">
					First Name <i class="text-error">*</i>
				</label>
				<input class="s1Input form-control" type="text" id="offer_firstname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Firstname">
			</div>
			<div class="formTwo">
				<label for="offer_lastname" class="control-label">
					Last Name <i class="text-error">*</i>
				</label>
				<input class="s1Input form-control" type="text" id="offer_lastname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Lastname">
			</div>
			<div class="formTwo 1">
				<label for="offer_email" class="control-label">
					Email <i class="text-error">*</i>
				</label>
				<input class="s1Input form-control" type="text" id="offer_email" placeholder="Email" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
			</div>
			<div class="formTwo">
				<label for="offer_company" class="control-label">
					Contact Number <i class="text-error">*</i>
				</label>
				<input class="s1Input form-control" type="text" id="offer_contact" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Contact Number">
			</div>
			<div class="formTwo 1">
				<label for="offer_country" class="control-label">
					Country <i class="text-error">*</i>
				</label>
				<select class="selectS2 form-control" name="" id="offer_country" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Country">
					<option value=""></option>
					<?php for($ci=0;$ci<sizeof($countriesarray);$ci++){ ?>
					<option value="<?=$countriesarray[$ci]['country_id']?>"><?=$countriesarray[$ci]['name']?></option>
					<?php } ?>
				</select>
			</div>
			<div class="formTwo">
				<label for="offer_city" class="control-label">
					City <i class="text-error">*</i>
				</label>
				<input class="s1Input form-control" type="text" id="offer_city" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your City">
			</div>
			<div class="formTwo 1">
				<label for="offer_password" class="control-label">
					Password <i class="text-error">*</i>
				</label>
				<input class="s1Input form-control" type="password" id="offer_password" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Password">
			</div>
			<div class="formTwo">
				<label for="offer_cpassword" class="control-label">
					Confirm Password <i class="text-error">*</i>
				</label>
				<input class="s1Input form-control" type="password" id="offer_password2" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Confirm Password">
			</div>

		</div>
		<div class="col-lg-12">
			<div class="requiredFieldError" id="offer_warning2"></div>
			<div class="form2Button">
				<button type="submit" class="btn blue" id="offer_btn_2" style="float: right;">Next <i class="icon-circle-arrow-right"></i></button>
			</div>
		</div>
	</form>
</div>
<div class="offerMainCont" id="offer_step3" style="display:none">
	<h2 class="ttleCapt">Submit An Offer for <?=ucwords($domain)?></h2>
	<div class="formDesc">
		<small>
			Enter a correct email, your email and offer inquiry will be deemed private but you will receive a response from the domain owner as soon as we receive your inquiry.
		</small>
	</div>
	<form class="" onsubmit="return false;">
		<div class="col-lg-12">
			<div class="formTwo" style="width: 99%;">
				<label for="offer_firstname" class="control-label" style="display: block;">
					Sponsor/Bid Price($) <i class="text-error">*</i>
				</label>
				<span class="price-label">$</span>
				<input class="s1Input form-control" type="text" id="offer_price" style="width: 50%;display:inline;" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Price Offer">
				<span class="price-label">.00</span>
			</div>
			<div class="formTwo" style="width:99%">
				<label for="partner_message" class="control-label">
					Message <i class="text-error">*</i>
				</label>
				<textarea class="textS2 form-control" id="offer_message" rows="8" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Your Message Here"></textarea>
			</div>
		</div>
		<div class="col-lg-12">
			<div class="requiredFieldError" id="offer_warning3" style="margin: 15px 0 15px;text-align:center"></div>
			<div class="form2Button">
				<button type="submit" class="btn blue" id="offer_btn_3" style="float: right;">Submit My Offer <i class="icon-circle-arrow-right"></i></button>
				<button type="submit" class="btn blue" id="offer_back_3"><i class="icon-circle-arrow-left"></i>Back</button>
				<input type="hidden" id="offer_domain" value="<?=$domain?>">
			</div>
		</div>
	</form>
</div>
<div class="offerMainCont" id="offer_final_new" style="display:none">
    <h2 class="ttleCapt">Inquire about <?=ucwords($domain)?></h2>
    <hr />
    <h4 class="text-error text-center">Thank you for contacting us.</h4>
    <div class="formDesc2" style="text-align: center;">
        <small>You are now minutes away to joining <?=ucwords($domain)?> team.</small><br>
        <br>
        <ol>
            <li>
                <small>
                    Click the link in the <span class="text-info">Verification email</span> that we have just sent you. If you still haven't received it, please check your spam inbox.
                </small>
            </li>
            <li>
                <small>
                    Your verification link will redirect you to our <a target="_blank" href="http://www.contrib.com">Marketpalce hub</a> where you can login and check out your application status.
                </small>
            </li>
            <li>
                <small>
                    You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.
                </small>
            </li>
        </ol>
		<br><br>
		<div id="viewcontriblink">Thank You!</div>
    </div>
</div>
<script>
	$(document).ready(function(){
    // $('input[rel="txtTooltip"]').tooltip();
		// $('data-toggle="tooltip"').tooltip();
	});
	$(document).ready(function(){
    // $('textarea[rel="txtTooltip"]').tooltip();
});
	$(document).ready(function(){
    // $('select[rel="txtTooltip"]').tooltip();
});
</script>

<script src="<?php echo $base_url?>js/serviceforms/service_offer.js"></script>
<!--end partner-->
