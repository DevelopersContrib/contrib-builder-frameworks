
	<div class="partnerMainCont" id="partner2_step1">
        <h2 class="ttleCapt">Partner with <?=ucwords($domain)?></h2>
        <div class="formDesc">
            <small>
                When you submit your registration, you can quickly partner with <?=ucfirst($domain)?>. This is a great way to build your service and at the same way add value to this asset.
            </small>
        </div>
		<br>	
        <div class="stepsMain">
            <div class="step text-center">
                <h4>Step 1: <i class="fa fa-file-alt"></i> Submit Your Partnership Application</h4>
                <p>You will receive an email when we feel our partnership will be win-win.</p>
            </div>
            <div class="step text-center">
                <h4>Step 2: <i class="fa fa-tasks"></i> Join a Team</h4>
                <p>Once your partnership proposal is something we could take on, we will make you part of our team and our partner.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
            	<form class="" onsubmit="return false;">
	                <div class="emailContainer">
	                    <div class="text-center s3Input">
	                        <input class="s1Input form-control" type="text" id="partner2_initialemail" placeholder="Enter e-mail address" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
	                    </div>
	                    <div class="clearfix"></div>
	                </div>
	                <div class="form-actions f-a-style">
	                    <span class="pull-left text-error" id="partner2_warning1"></span>
	                    <button type="submit" class="btn blue pull-right" id="partner2_btn_1">Apply Today <i class="fa fa-circle-arrow-right"></i></button>
	                </div>
	            </form>
            </div>
        </div>
    </div>
	<div class="partnerMainCont" id="partner2_step2" style="display:none">
        <h2 class="ttleCapt">Partner with <?=ucwords($domain)?></h2>
        <div class="formDesc">
            <small>
                When you submit your registration, you can quickly partner with <?=ucfirst($domain)?>. This is a great way to build your service and at the same way add value to this asset.
            </small>
        </div>
		<form class="" onsubmit="return false;">
			<div class="row">
				<div class="col-lg-12">
					<div class="formTwo 1">
						<label for="partner2_firstname" class="control-label">
							First Name <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="partner2_firstname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Firstname">
					</div>
					<div class="formTwo">
						<label for="partner2_lastname" class="control-label">
							Last Name <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="partner2_lastname" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Lastname">
					</div>
					<div class="formTwo 1">
						<label for="partner2_email" class="control-label">
							Email <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="partner2_email" placeholder="Email" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Email">
					</div>
					<div class="formTwo">
						<label for="partner2_company" class="control-label">
							Website
						</label>
						<input class="s1Input form-control" type="text" id="partner2_website" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Website" placeholder="example.com">
					</div>
					<div class="formTwo 1">
						<label for="partner2_country" class="control-label">
							Country <i class="text-error">*</i>
						</label>
						<select class="selectS2 form-control" name="" id="partner2_country" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Country">
							<option value=""></option>
							<?php for($ci=0;$ci<sizeof($countriesarray);$ci++){ ?>
							<option value="<?=$countriesarray[$ci]['country_id']?>"><?=$countriesarray[$ci]['name']?></option>
							<?php } ?>
						</select>
					</div>
					<div class="formTwo">
						<label for="partner2_city" class="control-label">
							City <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="text" id="partner2_city" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your City">
					</div>
					<div class="formTwo 1">
						<label for="partner2_password" class="control-label">
							Password <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="password" id="partner2_password" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Password">
					</div>
					<div class="formTwo">
						<label for="partner2_cpassword" class="control-label">
							Confirm Password <i class="text-error">*</i>
						</label>
						<input class="s1Input form-control" type="password" id="partner2_password2" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Confirm Password">
					</div>
				</div>
			</div>
			<div class="row"style="margin-top: 10px;">
				<div class="col-lg-12">
					<div class="requiredFieldError" id="partner2_warning2"></div>
					<div class="form2Button">
						<button type="submit" class="btn blue" id="partner2_btn_2" style="float: right;">Next <i class="fa fa-circle-arrow-right"></i></button>
					</div>
				</div>
			</div>
		</form>
    </div>
	<div class="partnerMainCont" id="partner2_step3" style="display:none">
        <h2 class="ttleCapt">Partner with <?=ucwords($domain)?></h2>
        <div class="formDesc">
            <small>
                When you submit your registration, you can quickly partner with <?=ucfirst($domain)?>. This is a great way to build your service and at the same way add value to this asset.
            </small>
        </div>
		<form class="" onsubmit="return false;">
			<div class="row">
				<div class="col-lg-12">
					<div class="formTwo" style="width:99%">
						<label for="partner2_type" class="control-label">
							Partnership Type <i class="text-error">*</i>
						</label>
						<select class="selectS2 form-control" name="" id="partner2_type" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Select Partnership Type">
							<option value=""></option>
							<?php foreach ($parnershiptypes as $type){ ?>
							<option value="<?php echo $type;?>"><?php echo $type;?></option>
							<?php } ?>
						</select>
					</div>

					<div class="formTwo" style="width:99%">
						<label for="partner2_message" class="control-label">
							Why we should partner with you? <i class="text-error">*</i>
						</label>
						<textarea class="textS2 form-control" id="partner2_message" rows="4" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Your Message Here"></textarea>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="col-lg-12">
					<div class="requiredFieldError" id="partner2_warning3" style="text-align: center;padding: 15px 0 0;"></div>
					<div class="form2Button">
						<button type="submit" class="btn blue" style="float: right;" id="partner2_btn_3">Next <i class="fa fa-circle-arrow-right"></i></button>
						<button type="submit" class="btn blue" id="partner2_back_3"><i class="fa fa-circle-arrow-left"></i>Back</button>
					<input type="hidden" id="partner2_domain" value="<?=$domain?>" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Website">
					</div>
				</div>
			</div>
		</form>
	</div>


	<div class="partnerMainCont" id="partner2_step4" style="display:none">
                    <h2 class="ttleCapt">Partner with <?=ucwords($domain)?></h2>
                    <div class="formDesc">
                        <small>
                            When you submit your registration, you can quickly partner with <?=ucfirst($domain)?>. This is a great way to build your service and at the same way add value to this asset.
                        </small>
                    </div>
					<form class="" onsubmit="return false;">
						<div class="row-fluid" style="display:inline-block">
							<div class="formTwo" style="width: 99%;">
								<label for="" class="control-label">
									Company Title <i class="text-error" style="font-weight:normal">* title/name of your company to promote.</i>
								</label>
								<input class="s1Input form-control" type="text" id="partner2_company" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Enter Your Company">
							</div>
							<div class="formTwo" style="width: 99%;">
								<label for="" class="control-label">
									Company Description <i class="text-error" style="font-weight:normal">* a short summary of your company.</i>
								</label>
								<textarea class="textS2 form-control" id="partner2_companydescription" rows="3" style="font-size: 12px;margin-bottom: 0;" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Company Description"></textarea>
							</div>
							<div class="formTwo" style="width: 99%;">
								<label for="" class="control-label">
									Company Image <i class="text-error" style="font-weight:normal">* URL/link to your company&#39;s image or logo</i>
								</label>
								<input class="s1Input form-control" type="text" id="partner2_companyimage" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Company Image" placeholder="http://">
							</div>
							<div class="formTwo" style="width: 99%;">
								<label for="partner_companyurl" class="control-label">
									Company Link <i class="text-error" style="font-weight:normal">* allows us to promote your company</i>
								</label>
								<input class="s1Input form-control" type="text" id="partner2_companyurl" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Company Website Link" placeholder="http://">
							</div>
						</div>
						<div class="row-fluid">
							<div class="requiredFieldError" id="partner2_warning4" style="font-size: 11px;font-weight:bold;text-align:center"></div>
							<div class="form2Button">
								<button type="button" class="btn blue" style="float: right;" id="partner2_btn_4">Apply Today <i class="fa fa-circle-arrow-right"></i></button>
								<button type="button" class="btn blue" id="partner2_back_4"><i class="fa fa-circle-arrow-left"></i>Back</button>
							<input type="hidden" id="partner_domain" value="<?=$domain?>" rel="txtTooltip" data-toggle="tooltip" data-placement="top" title="Website">
							</div>
						</div>
					</form>
	</div>

 	<div class="partnerMainCont" id="partner2_final" style="display:none">
		<h2 class="ttleCapt">Partner with <?=ucwords($domain)?></h2>
		<hr />
		<h4 class="text-error text-center">Thank you for your Partnership application.</h4>
		<div class="formDesc2" style="text-align: center;">
			<small>
				<b>Step 1:</b> Please <a href="/referral">login</a> to get your referral widgets. <br><b>Step 2:</b>You are now minutes away to joining <?=ucwords($domain)?> team. All you need to do right now is click the link in the <span class="text-info">Verification email</span> that we have just sent you. If you still haven&rsquo;t received it, please check your spam inbox. Your verification link will redirect you to our <a href="http://www.contrib.com" target="_blank">Marketpalce hub</a> where you can login and check out your application status. <br><b>Step 3:</b>You can now take part in actually building out an asset by sending proposals, partnering with brands, joining teams.
			</small>
			<br><br>
			<div id="viewcontriblink">Thank You!</div>
		</div>
	</div>

	<script>
$(document).ready(function(){
    // $('input[rel="txtTooltip"]').tooltip();
	// $('data-toggle="tooltip"').tooltip();
});
$(document).ready(function(){
    // $('textarea[rel="txtTooltip"]').tooltip();
});
$(document).ready(function(){
    // $('select[rel="txtTooltip"]').tooltip();
});
</script>
	
	<script src="<?php echo $base_url?>js/serviceforms/service_partner.js"></script>
	<!--end partner-->
