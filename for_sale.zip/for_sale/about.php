<?php include 'header.php'; ?>

				<div class="row">
					<div class="col-lg-12">
						<h2 class="text-center">
							About <?=ucwords($domain)?>
						</h2>
						<hr class="lineLines">
					</div>
				</div>

				<div class="row">
				
					<div class="col-lg-2">&nbsp;</div>
					
					<div class="col-lg-8 text-center">
												
						<br>

						<h4 style="line-height:24px"><?=ucwords($domain)?> a venture of eCorp.com Inc. eCorp is the worlds largest virtual domain development incubator on the planet. Founded in 1996, we create, acquire, match, manage and liquidate premium domain assets and platforms. We build and manage world class web-based, domain centric operating businesses for clients and internal ventures. Learn more about our ventures, staffing opportunites and partnership models.</h4>
					</div>
					
					<div class="col-lg-2">&nbsp;</div>
					
				</div>

<?php include 'footer.php'; ?>