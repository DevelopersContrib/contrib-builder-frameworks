<?php include 'header.php'; ?>

				<div class="row">
					<div class="col-lg-12 for-sale-top">
						<h3 class="text-center">
							<? if(str_replace(' ','',$top_description)!=''){ ?>
								<?=stripslashes($top_description)?>
							<? } ?>
							<br>
							<span style="font-size: 21px;">
								The owners of this domain have recently changed their business plan.
							</span>
						</h3>
						<h2 class="text-center">
							This Domain is Possibly for Sale.
						</h2>
						<hr class="lineLines">
					</div>
				</div>
				<div class="row" id="fs_main_content">
					<div class="col-lg-7">
						<h1 class="text-center">
							* All Offers Below $10,000 USD will be discarded *
						</h1>
						<br><br>
						<h4 style="line-height: 24px;">
							<b>
								Please note that domains represented by Domain Holdings are considered premium domain names with prices ranging between $10,000 to well over six figures.
							</b>
						</h4>
						<br><br>
						<p>
							Every domain has a unique set of characteristics which all collectively determine the asking price.  To learn more about domain name values or inquire about a specific domain please contact one of our experienced professionals using the form.
						</p>
					</div>
					<div class="col-lg-5">
						<div class="row">
							<!-- begin offer form -->
							<div class="form-area" id="DetailsForm">
							  <div class="alert alert-danger hide" role="alert" id="str_error" >Firstname is required!</div>
									<div class="col-md-12"><h3 class="off-title text-center">Submit Your Offer</h3></div>
								<div class="initial form_area" id="EmailForm">
									   <div class="form-group col-md-12">
			                           <label>Email&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
			                           <input type="text" class="form-control" id="email" name="email">
			                            <a href="javascript:void(0);" id="next" class="btn btn-primary pull-right hide">Next&nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i></a>
			                        </div>
								</div>
		                     <div id="inquiry_form" class="sfc-step-one"><!-- STEP 1 -->
		                        <div class="form-group col-md-6">
		                           <label>Firstname&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
		                           <input type="text" class="form-control" id="fname" name="fname">
		                        </div>
		                        <div class="form-group col-md-6">
		                           <label>Lastname&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
		                           <input type="text" class="form-control" id="lname" name="lname">
		                        </div>

		                        <div class="form-group col-md-12">
		                           <label>Contact No:&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
		                           <input type="text" class="form-control" id="contactno" name="contactno">
		                        </div>
										<div class="form-group col-md-6">
		                           <label>Password&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
		                           <input type="password" class="form-control" id="password" name="password">
		                        </div>
										<div class="form-group col-md-6">
		                           <label>Confirm Password&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
		                           <input type="password" class="form-control" id="confirm_password" name="confirm_password">
		                        </div>
										<div class="form-group col-md-12">
		                           <label>Bid Price in USD&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
		                           <input type="text" class="form-control" id="bidprice" name="bidprice">
		                        </div>
		                        <div class="form-group col-md-12">
		                           <label>Your Message<i class="fa fa-asterisk" aria-hidden="true"></i></label>
		                           <textarea id="message" class="form-control" rows="3" style="height:60px;"></textarea>
		                        </div>
										<div class="col-md-12">
			                        <input type="hidden" id="domain" value="<?php echo $domain; ?>">
			                        <a href="javascript:void(0);" id="submit" class="btn btn-primary pull-right">Submit&nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i></a>
										</div>
										<div class="clearfix"></div>
		                     </div>
		                     <div id="thankyou" class="sfc-step-final hide">
		                        <div class="text-center">
		                           <h3>Thank you for your Submission.</h3>
		                           <p class="hide">All you need to do right now is click the link in the Verification email that we have just sent you. If you still haven't received it, please check your spam inbox. Your verification link will redirect you to our Marketplace hub where you can login and check out your application status. </p>
		                           <p>We will be replying once we take interest in your offer. In the meantime, check out our other related assets. </p>
		                           <hr>
		                           <a href="https://contrib.com/"  class="btn btn-primary hide">View Your Contrib Account Now!</a>
		                           <div class="clearfix"></div>
		                        </div>
		                     </div>
		               </div>
							<!-- end offer form-->
						</div>
					</div>
				</div>
        <div class="row hide" id="offer_final_new">
	  <div class="col-md-8 col-md-offset-2">
		<div class="well verify-box aboutus">
			<img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/icons/icon-thankyou-800x400.png" title="thank you" alt="thank you" style="width:250px; margin:0px auto;">
			<h2 class="text-center">for submitting your offer.</h2>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> You will be receiving three (3)-emails from Contrib.</h4>
			<h4 class="text-center"><i class="fa fa-arrow-circle-right"></i> Please check your spam box for safe measure.</h4>
			<div class="clearfix"><br></div>
			<div class="contrib-box-o">
				<p class="text-center">Contrib is our contribution platform and it allows us to get people to help contribute, make offer or partner with premium world class brands. You could check your Offer submission in your <br><b>"My Offers Contrib App"</b>.</p>
				<a href=""><h4 class="text-center"><i class="fa fa-envelope"></i> Please check your email for your Contrib access.</h4></a>
			</div>
			<div class="clearfix"><br></div>
			<div class="row">
				<div class="contrib-box-in">
					<h2 class="text-center">How It Works?</h2>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-search"></i><br>Step 1</h3>
						<h4>Browse the Marketplace</h4>
						<p>Browse the marketplace and search for sites to submit offers. </p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-file-text-o"></i><br>Step 2</h3>
						<h4>Submit an Offer</h4>
						<p>Click on submit offer and fill up the form.</p>
					</div>
					<div class="col-md-4 text-center">
						<h3><i class="fa fa-desktop"></i><br>Step 3</h3>
						<h4>View Offers</h4>
						<p>View all your offer applications that you have submitted to here. </p>
					</div>
					<div class="clearfix"><br></div>
				</div>
			</div>
		</div>
	  </div>
	</div>
<?php include 'footer.php'; ?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.loadingoverlay/latest/loadingoverlay.min.js"></script>
<script>

	   function restrict(e)
      {
      	  // Allow: backspace, delete, tab, escape, enter and .
          if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
               // Allow: Ctrl+A, Command+A
              (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
               // Allow: home, end, left, right, down, up
              (e.keyCode >= 35 && e.keyCode <= 40)) {
                   // let it happen, don't do anything
                   return;
          }
          // Ensure that it is a number and stop the keypress
          if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
              e.preventDefault();
          }
      }

	function ErrorMessage(param)
	{
		jQuery('#str_error').removeClass('hide');
		jQuery('#str_error').html(param);
		setTimeout(function(){ jQuery('#str_error').addClass('hide'); }, 3000);
	}

	  $("#bidprice").keydown(function (e) {
         restrict(e);
      });

	  $("#contactno").keydown(function (e) {
          restrict(e);
      });

      $('#bidprice').blur(function(){
      		var amount = jQuery('#bidprice');
      		amount.val(parseInt(amount.val()).toFixed(2));
      });

	jQuery('#next').click(function(){
		var button = jQuery(this);
		var email = jQuery('#email').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if (email == '') {
				ErrorMessage('Provide a Email Address!');
		}else if(!emailfilter.test(email)){
				ErrorMessage('Provide a Valid Email Address!')
		} else{
			button.attr('disabled', true).html('Please wait .. checking is in progress.');
			jQuery.post('http://www.contrib.com/signup2/checkemailexists',
			{
				email:email
			}
			,function(data)
			{
				if (data.exists==true) {
					ErrorMessage('Email already have an account.');
					button.attr('disabled', false).html('Next&nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i>');
				}else{
					jQuery('#inquiry_form').removeClass('hide');
					jQuery('#EmailForm').addClass('hide');
				}
			});
		}
	});

	jQuery('#submit').click(function(){

		var email = jQuery('#email').val();
		var firstname = jQuery('#fname').val();
		var lastname = jQuery('#lname').val();
		var contact = jQuery('#contactno').val();
		var password = jQuery('#password').val();
		var cpassword = jQuery('#confirm_password').val();
		var price = jQuery('#bidprice').val();
		var message = jQuery('#message').val();
		var alphanumeric = /^[0-9a-zA-Z ]+$/;
		var letters = /^[a-zA-Z ]+$/;
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var domain = jQuery('#domain').val();

		if (email == '') {
			ErrorMessage('Please a Email Address');
		}else if(!emailfilter.test(email)){
			ErrorMessage('Please Provide a Valid Email Address');
		}else if(firstname == ''){
			ErrorMessage('Please Provide a Firstname');
		}else if (lastname == '') {
			ErrorMessage('Please Provide a Lastname');
		}else if(contact == ''){
			ErrorMessage('Please Provide a Contact No.');
		}else if(!letters.test(lastname)){
			ErrorMessage('Only Accept letters');
		}else if(!letters.test(firstname)){
			ErrorMessage('Only Accept Letter');
		}else if (parseInt(price) < 10000) {
			ErrorMessage('* Offer amount should not be lower than $10000 *');
		}else if(message == ''){
			ErrorMessage('Message is Required');
		}else if(password.length < 5){
			ErrorMessage('Password should have atleast 5 characters');
		}else if(password ==''){
			ErrorMessage('Please Provide a Password');
		}else if(cpassword == ''){
			ErrorMessage('Please Provide a Confirm Password');
		}else if(password!=cpassword){
			ErrorMessage('Password not match ');
		}else{
			$.LoadingOverlay("show");
				jQuery.post('http://www.contrib.com/signup2/checkemailexists',
			{
				email:email
			}
			,function(data)
			{
				if (data.exists==true) {
					ErrorMessage('Email already have an account.');
					$.LoadingOverlay("hide");
				}else{
						jQuery.post('http://www.api.contrib.com/forms/save_offer',
			{
				domain:domain,
				firstname:firstname,
				lastname:lastname,
				email:email,
				password:password,
				contact:contact,
				message:message,		
				amount:price,
				country_id:'1',
				country:'United States',
				city:'city'

			},function(data)
			{

				if (data.success==true) {
						$.post("http://www.manage.vnoc.com/salesforce/addlead",
                               {
                                   'firstName':firstname,
                                   'lastName':lastname,
                                   'title':'',
                                   'email':email,
                                   'phone':contact,
                                   'street':'',
                                   'city':'',
                                   'country':'',
                                   'state':'',
                                   'zip':'',
                                   'domain':domain,
                                   'message':message,
                                   'price':price,
                                   'form_type':'VNOC Offers'
                               }
                               ,function(data2){
																 sendOfferEmail(firstname,email,domain);
                                     jQuery('#offer_final_new').removeClass('hide');
									jQuery('#fs_main_content').addClass('hide');
									$.LoadingOverlay("hide");
                               }
                        );
				};

			}
			);
				}
			});


		
			//console.log('Right');
		};

	});
	function sendOfferEmail(firstname,email,domain){
		$.post(
			'http://www.api.contrib.com/forms/autoresponderEmail',
			{ firstname:firstname,email:email,domain:domain,template_name:'Offer' },
			function(response){
				console.log(response.result);
			}
		);
	}
</script>
