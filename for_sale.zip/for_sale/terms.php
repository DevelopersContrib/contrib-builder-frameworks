<?php include 'header.php'; ?>

	<div class="row">
		<div class="col-lg-12">
			<h2 class="text-center">
				<?=ucwords($domain)?> Terms Of Use
			</h2>
			<hr class="lineLines">
		</div>
	</div>

	<div class="row">
				
		<div class="col-lg-1">&nbsp;</div>
					
		<div class="col-lg-10">
												
			<?php 
					  $api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
					  $url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=terms';
					  $result =  createApiCall($url, 'GET', $headers, array());
					  $data_domain = json_decode($result,true);
					  if (isset($data_domain['data']['content'])){
					   $terms =   $data_domain['data']['content'];
					  }else {
					  	$terms = "";
					  }

					  echo $terms;
                ?>
		
		</div>
					
		<div class="col-lg-1">&nbsp;</div>
					
	</div>
				
<?php include 'footer.php'; ?>