<?php include 'header.php'; ?>
<br>
</div>
                    <div class="row">
                <div class="col-md-12 text-center">
                    <div class="blur-box">
					
                        <h2 class="fundht">Fund Our Ventures</h2>
                        <div class="row">
						<?foreach($fund_campaigns as $funds):?>
						<?if($funds['post_title'] != 'Micro Markets'):?>
                            <div class="col-sm-4 col-xs-12">
                                <div class="fund-container">
                                    <div class="ribbon-wrapper-green">
                                        <div class="ribbon-green">Staff Pick</div>
                                    </div>
									<?php if($funds['logo'] != ""):?>
                                    <img src="<?php echo $funds['logo']?>" class="img-responsive" />
									<?php endif;?>
                                    <a target="_blank" class="alink" href="<?php echo $funds['permalink']?>">
                                        <h3><?php echo $funds['post_title']?></h3>
                                    </a>
                                    <p class="fund-desc"><?php echo strip_tags($funds['post_content'])?></p>
                                    <div class="funded-l">
                                        <div class="fund-icon"><i class="fa fa-usd"></i></div>
                                        <div class="fund-details">
                                            <p>Funded</p>
                                            <p><b><?php echo number_format($funds['campaign_goal'],2)?></b></p>
                                        </div>
                                        <div style="clear:both"></div>
                                    </div>
                                    <div class="funded-r">
                                        <div class="fund-icon"><i class="fa fa-bar-chart"></i></div>
                                        <div class="fund-details">
                                            <p>Funded</p>
                                            <p><b>10%</b></p>
                                        </div>
                                        <div style="clear:both"></div>
                                    </div>
                                    <div style="clear:both"></div>
                                </div>
                            </div>
                         <?endif;?>
						<?endforeach?>
                        </div>
                    </div>
                </div>
            </div>
                
<?php include_once 'footer.php';?>       

