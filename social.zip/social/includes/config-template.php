<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    
    $background_image = "{{BACKGROUND_IMAGE}}";
    $introduction =  "{{INTRODUCTION}}";
    $about =  "{{ABOUT}}";
    $forsale = "{{SHOW_FOR_SALE}}";
		$forsaletext = "{{FOR_SALE_TEXT}}";
    
    
    $follow_count = "{{FOLLOW_COUNT}}";
    
    $domain_affiliate_link = "{{AFF_LINK}}";
   
    $roles = {{ROLES}};
    $intentions = {{INTENTIONS}};
    $industries = {{INDUSTRIES}};
    $experiences = {{EXPERIENCES}};
    $partners = {{PARTNERS}};
?>