<?php
    $domain =   "artdigest.com";
    $domainid = "";
    $memberid = "";
    $title = "";
    $logo =  "";
    $description = "";
    $account_ga = "";
    $description = stripslashes(str_replace('\n','<br>',$description));
    
    $background_image = "";
    $introduction =  "";
    $about =  "";
    $forsale = "";
		$forsaletext = "This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.";
    
    
    $follow_count = "25";
    
    $domain_affiliate_link = "http://referrals.contrib.com/idevaffiliate.php?id=&url=http://www.contrib.com/signup/firststep?domain=artdigest.com";
   
    $roles = NULL;
    $intentions = NULL;
    $industries = NULL;
    $experiences = NULL;
    $partners = NULL;
?>