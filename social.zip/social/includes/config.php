<?php
//new api call
function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}

if (!file_exists('./includes/config-framework.php')) {
     
    $file = file_get_contents('./includes/config-template.php');
    //$api_url = "http://api.contrib.com/requestreplicated/";
    $api_url = "http://api2.contrib.co/request/";
    $headers = array('Accept: application/json');
    
    $domain = $_SERVER["HTTP_HOST"]."".$_SERVER['REQUEST_URI'];//input sitename without www
    
    if(stristr($domain, '~') ===FALSE) {
    	$domain = $_SERVER["HTTP_HOST"];
      $domain = str_replace("http://","",$domain);
    	$domain = str_replace("www.","",$domain);
    	$key = md5($domain);
    }else {
       $key = md5('vnoc.com');
       $d = explode('~',$domain);
       $user = str_replace('/','',$d[1]);
       $url = $api_url.'getdomainbyusername?username='.$user.'&key='.$key;
       $result =  createApiCall($url, 'GET', $headers, array());
       $data_domain = json_decode($result,true);
       $error = 0;
       $domain =   $data_domain[0]['domain'];
    	
    }
    
    
    
    
    
    $url = $api_url.'getdomaininfo?domain='.$domain.'&key='.$key;
    $result =  createApiCall($url, 'GET', $headers, array());
    $data_domain = json_decode($result,true);
    $error = 0;
    if (!$data_domain['error'])
           {
                $domainid = $data_domain[0]['DomainId'];
                $domainname = $data_domain[0]['DomainName'];
                $memberid = $data_domain[0]['MemberId'];
                $title = $data_domain[0]['Title'];
                $logo = $data_domain[0]['Logo'];
                $description = $data_domain[0]['Description'];
                $account_ga = $data_domain[0]['AccountGA'];
    			
    			
    			
    			$url2 = $api_url.'getdomainattributes?domain='.$domain.'&key='.$key;
    			 $result2 =  createApiCall($url2, 'GET', $headers, array());
    			$data_domain2 = json_decode($result2,true);
    			
    			if(!$data_domain2[0]['error']){
    				$background_image = $data_domain2[0]['background_image_url'];
    				$introduction = $data_domain2[1]['introduction'];
    				$about = $data_domain2[2]['about'];
    				$forsale = $data_domain2[3]['show_for_sale_banner'];
    				$forsaletext = $data_domain2[4]['for_sale_text'];
    	
    				if($forsaletext=='') $forsaletext = 'This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.';
    	
    			}
    			
          	}else {
          		$error++;
    }
    
    
    $url = $api_url.'getfollowedsites?key='.$key;
     $result =  createApiCall($url, 'GET', $headers, array());
    $data_domains = json_decode($result,true);
    
    
    
    $url = $api_url.'getdomainfollowcount?domain='.$domain.'&key='.$key;
    $result =  createApiCall($url, 'GET', $headers, array());
    $data_follow_count = json_decode($result,true);
    if (!$data_follow_count['error']){
    	$follow_count = ($data_follow_count[0]['total'] + 1 ) * 25;
    }else {
    	$follow_count = 1 * 25;
    }
    
    
    
    $url = $api_url.'getsignupformdata';
     $result =  createApiCall($url, 'GET', $headers, array());
    $data_signup = json_decode($result,true);
    if (!$data_signup['error']){
    	$roles = $data_signup['roles'];
    	$intentions = $data_signup['intentions'];
    	$industries = $data_signup['industries'];
    	$experiences = $data_signup['experiences'];
    }
    
    
    //get domain affiliate id
    $url = $api_url.'getdomainaffiliateid?domain='.$domain.'&key='.$key;
     $result =  createApiCall($url, 'GET', $headers, array());
    $data_domain_affiliate = json_decode($result,true);
    if (!$data_domain_affiliate['error']){
    	$domain_affiliate_id = $data_domain_affiliate['affiliate_id'];
    }else {
    	$domain_affiliate_id = '391'; //contrib.com affiliate id
    }
    $domain_affiliate_link = 'http://referrals.contrib.com/idevaffiliate.php?id='.$domain_affiliate_id.'&url=http://www.contrib.com/signup/firststep?domain='.$domain;

	//partners
	$api_url2 = "http://api2.contrib.com/request/";
	$url = $api_url2.'getpartners?domain='.$domain.'&key='.$key;
    $result = createApiCall($url, 'GET', $headers, array());
    $partners_result = json_decode($result,true);
    
    if ($partners_result['success']){
		$approved_partner = $partners_result;
    }	
    //create file
  $file = str_replace('{{DOMAIN}}',$domain , $file);
  $file = str_replace('{{DOMAIN_ID}}',$domainid , $file);
  $file = str_replace('{{MEMBER_ID}}',$memberid, $file);
  $file = str_replace('{{TITLE}}',$title, $file);
  $file = str_replace('{{LOGO}}',$logo, $file);
  $file = str_replace('{{DESCRIPTION}}',$description, $file);
  $file = str_replace('{{ACCOUNT_GA}}',$account_ga, $file);
  $file = str_replace('{{BACKGROUND_IMAGE}}',$background_image, $file);
  $file = str_replace('{{INTRODUCTION}}',$introduction, $file);
  $file = str_replace('{{ABOUT}}',$about, $file);
  $file = str_replace('{{SHOW_FOR_SALE}}',$forsale, $file);
  $file = str_replace('{{FOR_SALE_TEXT}}',$forsaletext, $file);
  $file = str_replace('{{FOLLOW_COUNT}}',$follow_count, $file);
  $file = str_replace('{{AFF_LINK}}',$domain_affiliate_link, $file);
  $file = str_replace('{{ROLES}}',var_export($roles, true), $file);
  $file = str_replace('{{INTENTIONS}}',var_export($intentions, true) , $file);
  $file = str_replace('{{INDUSTRIES}}',var_export($industries, true), $file);
  $file = str_replace('{{EXPERIENCES}}',var_export($experiences, true), $file);
   $file = str_replace('{{PARTNERS}}',var_export($approved_partner, true), $file);
  file_put_contents('./includes/config-framework.php', $file);
}

include "./includes/config-framework.php";

/**
	generate robots.txt if not exist
**/
$filename = '/robots.txt';
if(!(file_exists($filename))) {
    $my_file = 'robots.txt';
	$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
	$data = '---BEGIN ROBOTS.TXT ---
User-Agent: *
Disallow:

Sitemap: http://'.$domain.'/sitemap.html
--- END ROBOTS.TXT ----';
	fwrite($handle, $data);
}



$__page = $_SERVER['PHP_SELF'];

if($__page =='/about.php')
	$title = 'About '.ucwords($domain);
else if($__page =='/terms.php')
	$title = ucwords($domain).' - Terms of Use';
else if($__page =='/privacy.php')
	$title = ucwords($domain).' - Privacy & Policy';
else if($__page =='/contact.php')
	$title = ucwords($domain).' - We are Hiring!';


?>