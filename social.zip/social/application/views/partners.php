<?include('header.php')?>
<?	
	$partners_list = array();
	if(!$partners == ""):
		$partners_list = $partners['data'];
	endif;
?>
<style type="text/css">
	.blckBckgrnd{
		background: rgba(0,0,0,.8);
		padding: 20px 15px;
		margin-bottom: 10px;
		box-shadow: 0 0 3px rgba(255, 255, 255, 0.4);
		color: #fff;
	}
</style>

<div class="col-lg-12">

	<div class="col-lg-2"></div>
		
	<div class="col-lg-8">
        
                    
                    <div class="content-ad" style="text-align: justify;">
                        
                        <a name="top"></a>

						<br>
						<br>
                        <div class="text-center">
                        	<a href="/contact" class="btn btn-large btn-primary">
                        		Join Our Partner Network
                        	</a>
                        	<br/>
                        </div>
                        <br/>
                       
                                
                                <div class="">
                                    <div class="col-lg-12 blckBckgrnd">
                                        <div class="col-lg-4">
                                            <a href="http://contrib.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png" alt="Contrib.com" style="width: 100%;"/>
                                            </a>
                                        </div><!-- col-lg-4 -->
                                        <div class="col-lg-8">
                                            <h3><a href="http://contrib.com">Contrib.com</a></h3>
                                            <p>
                                                Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today.
                                            </p>
                                        </div><!-- col-lg-8 -->
                                    </div>

                                    <div class="col-lg-12 blckBckgrnd">
                                        <div class="col-lg-4">
                                            <a href="http://globalventures.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png" alt="GlobalVentures.com" style="width: 100%;"/>
                                            </a>
                                        </div><!-- col-lg-4 -->
                                        <div class="col-lg-8">
                                            <h3><a href="http://globalventures.com">GlobalVentures.com</a></h3>
                                            <p>
                                                Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly.
                                                Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.
                                            </p>
                                            <p>
                                                With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.
                                            </p>
                                        </div><!-- col-lg-8 -->
                                    </div>

                                    <div class="col-lg-12 blckBckgrnd">
                                        <div class="col-lg-4">
                                            <a href="http://ifund.com">
                                                <img src="http://www.contrib.com/uploads/logo/ifund.png" alt="iFund.com" style="width: 100%;"/>
                                            </a>
                                        </div><!-- col-lg-4 -->
                                        <div class="col-lg-8">
                                            <h3><a href="http://ifund.com">iFund.com</a></h3>
                                            <p>
                                                iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
                                                advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
                                                investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
                                                iFund receives no compensation in connection with the purchase or sale of securities.
                                            </p>
                                        </div><!-- col-lg-8 -->
                                    </div>

                                    <div class="col-lg-12 blckBckgrnd">
                                        <div class="col-lg-4">
                                            <a href="http://ichallenge.com">
                                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png" alt="iChallenge.com" style="width: 100%;" />
                                            </a>
                                        </div><!-- col-lg-4 -->
                                        <div class="col-lg-8">
                                            <h3><a href="http://ichallenge.com">iChallenge.com</a></h3>
                                            <p>
                                                The best internet challenges. Solve and win online prizes.
                                            </p>
                                        </div><!-- col-lg-8 -->
                                    </div>



                                    <!-- start dynmic partners -->

	
                                    <? if(sizeof($partners_list)>0){?>
									
									<?foreach($partners_list AS $partner_detail):?>
										<div class="col-lg-12 blckBckgrnd">
											<div class="col-lg-4">
												<a href="<?echo $partner_detail['url'];?>">
													<img src="<?echo $partner_detail['image'];?>" alt="<?echo $partner_detail['company_name'];?>" style="width: 100%;">
												</a>
											</div><!-- col-lg-4 -->
											<div class="col-lg-8">
												<h3><a href="<?echo $partner_detail['url'];?>"><?echo $partner_detail['company_name'];?></a></h3>
												<p><?echo $partner_detail['summary'];?></p>
												<p><?echo $partner_detail['description'];?></p>
											</div><!-- col-lg-8 -->
										</div>
                                    <?endforeach;?>
									
                                    <? }?>
                                    <!-- dynamic partners -->
                                </div>
                                
                           
                    </div>
                
    </div>
	
	<div class="col-lg-2"></div>
	
</div><!--3rd section-->

<?include('footer.php');?>