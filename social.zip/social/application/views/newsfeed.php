<?include('header.php')?>
<?	
	$partners_list = array();
	if(!$partners == ""):
		$partners_list = $partners['data'];
	endif;
?>
<style type="text/css">
	.blckBckgrnd{
		background: rgba(0,0,0,.8);
		padding: 20px 15px;
		margin-bottom: 10px;
		box-shadow: 0 0 3px rgba(255, 255, 255, 0.4);
		color: #fff;
	}
</style>
  <link rel="stylesheet" href="/css/newsfeed.css" type="text/css" media="screen" />

<div class="container-fluid lead-reset-padd"  style="background: url(/img/bg-socialholdings.jpg) repeat;">
    <div class="row-fluid">
        <div class="wrap-ad">
            <div class="container overflow-ad">
                <div class="row-fluid">
                    
                    <div class="content-ad" style="text-align: justify;">
                        
                        <a name="top"></a>


                        <div class="row-fluid text-center">
                        	<a href="/contact" class="btn btn-large btn-primary">
                        		Join Our Partner Network
                        	</a>
                        	<br/>
                        </div>
                        <br/>
                        <div class="padd-banner">
                            <div class="row-fluid">
                                <div class="span2">
                                    &nbsp;
                                </div>
                                <div class="span8">
                                    <?if($newsfeed!=null):?>
										<?foreach($newsfeed AS $feed):?>
											<?echo $feed['message']?>
										<?endforeach;?>
									<?else:?>
										<p>No discussions yet.</p>
									<?endif;?>
                                </div><!-- span8 -->
                                <div class="span2">
                                    &nbsp;
                                </div>
                            </div><!-- row-fluid -->
                        </div><!-- padd-banner -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!--3rd section-->

<?include('footer.php');?>