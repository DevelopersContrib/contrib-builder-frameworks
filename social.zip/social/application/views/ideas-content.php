 <?if($ideas == null || sizeof($ideas) == 0):?>
	<div class="alert alert-warning" role="alert">No ideas submitted yet</div>
 <?else:?>
 <?foreach($ideas AS $idea):?>
 <div class="col-lg-12 marg prop">
            <div class="wrap-proposal-style2">
                <div class="col-lg-4">
                    <div class="wrap-prop-box">
						<?if($idea['logo'] !== ""):?>
							<div style="text-align: center;">
								<a target="_blank" href="<?echo $idea['domain']?>">
								<img class="img-responsive" src="<?echo $idea['logo']?>" alt="<?echo $idea['domain']?>" title="<?echo $idea['domain']?>">
									<b><?echo $idea['domain']?></b>
								</a>
							</div>
						<?endif;?>
                        <div class="text-center link-details">
                            <a target="_blank" class="btn btn-mini btn-info" href="http://www.contrib.com/brand/details/<?echo $idea['domain']?>">View Brand Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="wrap-prop-details">
                        <a target="_blank" class="a-link-prop" href="http://www.contrib.com/proposal/details/<?echo $idea['slug']?>">
                            <h5 class="ellipsis">
                                <?echo $idea['title']?>
                            </h5>
                        </a>
                        <p>
                            <?echo stripcslashes($idea['summary'])?><br /><a href="http://www.contrib.com/proposal/details/<?echo $idea['slug']?>">...read more</a>
                            <?//echo substr(stripcslashes($idea['description']),0,50)?>
                        </p>
                        
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="wrap-meta-prop-main">
                        <div class="col-lg-6">
                            <div class="pull-left posted-by">
                                <a target="_blank" class="a-link-prop" href="http://www.contrib/people/me/<?echo $idea['Username']?>">
                                    <img alt="Jessica Collier" title="Jessica Collier" src="http://www.contrib.com/uploads/profile/<?echo $idea['profile_image']?>">
                                </a>
                            </div>
                            <div class="posted-name">
                                <b><i class="icon-laptop"></i> Posted by:</b>
                                <p class="ellipsis">
                                    <a target="_blank" class="a-link-prop" href="http://www.contrib/people/me/<?echo $idea['Username']?>">
                                        <?echo $idea['FirstName']." ".$idea['LastName']?>
                                    </a>
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="meta-date-prop">
                                        <i class="icon-calendar"></i>
                                        <b>Submitted: </b> <br>
                                       <?echo $idea['date_submitted']?>
                                    </p>
                                </div>
                                <div class="col-lg-6">
                                <p class="meta-date-prop zoomMain">
                                        <i class="icon-thumbs-up"></i>
                                        <b>Votes: </b> <br>
                                        <span class="zoom-num"><?echo $idea['total']?></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
<?endforeach;?>
<?endif;?>