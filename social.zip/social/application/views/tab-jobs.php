<div class="tab-pane" id="b-jobs">
    <div class="row" id="jobs_container">
        
    </div>
</div>