<?php include('header.php');?>
<style>
iframe {
	background: #fff !important;
	border-radius: 0px !important;
}
</style>
<div class="col-lg-12">

	<div class="col-lg-3"></div>
		
	<div class="col-lg-6">
		
		<br><h2 class="rght-ttle text-center">Contact Us @ <?=ucfirst($info['domain'])?></h2>
		
		<center>
		
			<iframe src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?echo $info['domain']?>" scrolling="no" frameborder="0" style="width: 365px;background: whitesmoke;height:525px;padding: 15px 0 0 15px;border-radius: 5px;margin:40px"></iframe>																		
		
		</center>

	</div>
	
	<div class="col-lg-3"></div>
	
</div>	
<div class="clearfix"></div>
<?php include('footer.php');?>