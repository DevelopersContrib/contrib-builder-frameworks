<?if($jobs == null):?>
	<div class="alert alert-warning" role="alert">No job posts</div>
<?else:?>
<?foreach($jobs AS $job):?>
	<div class="col-lg-12">
            <div class="alert alert-warning a-jobs">
                <h4>
                    <?echo $job['title']?>
                </h4>
                <a target="_blank" href="http://www.contrib.com/brand/jobs/<?echo $info['domain']?>/<?echo $job['job_id']?>">
                    Read More...
                </a>
                <a class="pull-right btn btn-warning" target="_blank" href="http://www.contrib.com/brand/jobs/<?echo $info['domain']?>/<?echo $job['job_id']?>">
                    Apply now!
                </a>
                <div class="clearfix"></div>
            </div>
        </div>
<?endforeach;?>
<?endif;?>
