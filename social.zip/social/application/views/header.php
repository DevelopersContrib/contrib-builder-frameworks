<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $info['title']?></title>
		<link rel="canonical" href="http://<?=$info['domain']?>/<?=str_replace('.php','',basename($_SERVER['PHP_SELF']))?>" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php echo $info['description']; ?>"/>
        <meta name="keywords" content="<?php echo $info['keywords']; ?>"/>
        <meta name="author" content="<?php echo $info['domain']; ?>"/>
        <!-- Bootstrap -->
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/buttons-style-1.css">
        <link rel="stylesheet" href="/css/main.css">

        <script src="https://code.jquery.com/jquery.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script src="/js/jquery.pulsate.js"></script>
        <script>
            $(function () {
                //$(".email-ftre").pulsate({glow:false});
            });
        </script>
		<?if($attr['background_image'] != "" || $attr['background_image'] != null):?>
			<style>
			.section.section-feature-mail{
				 background-image: url(<?echo $attr['background_image']?>);
			}
			.media-body, .media-left, .media-right {
				display: table-cell;
				vertical-align: top;
			}
			.media-left, .media > .pull-left {
				padding-right: 10px;
			}
			.media-right, .media > .pull-right {
				padding-left: 10px;
			}
			.contrib-task-container .media-heading {
				margin: 10px;
			}
			.contrib-task-container .media-right .btn-danger {
				margin-top: 5px;
			}
			#scrollbox {
				background: #ffffff !important;
			}
			ul.scroll {
				margin-left: -35px !important;
			}
			ul.scroll li {
				background: #f3efef !important;
				border: none !important;
				padding: 15px !important;
			}
			.ver-right .panel {
				border: none;
			}
			.ver-right .cntrbwdgt-panel-heading {
				border: none;
			}
			.ver-right .cntrbwdgt-panel {
				border: none;
			}
			h2.tut {
				background: #5c5cb0 !important;
			}
			</style> <!-- default: http://d2qcctj8epnr7y.cloudfront.net/uploads/bg-signup-2.jpg -->
		<?endif;?>
		
		<!-- GA -->
    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', '<?=$info['account_ga']?>', 'auto');
        ga('send', 'pageview');
    </script>
    <!-- Piwik -->
    <script type="text/javascript">
        var _paq = _paq || [];
        _paq.push(['trackPageView']);
        _paq.push(['enableLinkTracking']);
        (function() {
            var u="//www.stats.numberchallenge.com/";
            _paq.push(['setTrackerUrl', u+'piwik.php']);
            _paq.push(['setSiteId', <?=$info['piwik_id']; ?>]);
            var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
            g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
        })();
    </script>
    <noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$piwik_id?>" style="border:0;" alt="" /></p></noscript>
	</head>
    <body>
       <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/">
					<? if($info['logo']==''){ ?>
						<?php echo ucfirst($info['domain']);?>
                    <? }else{ ?>
						<img class="img-responsive ver-6-logo" src="<?php echo $info['logo'];?>" alt="<?php echo ucfirst($info['domain']);?>" title="<?php echo ucfirst($info['domain']);?>" style="height:30px;">
                    <? } ?>
            </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo $base_url?>contact">We are hiring!</a></li>
                <li><a href="<?php echo $base_url?>about">About</a></li>
                <li><a href="<?php echo $base_url?>terms">Terms</a></li>
                <li><a href="<?php echo $base_url?>privacy">Privacy</a></li>
                <li><a href="<?php echo $base_url?>partners">Partners</a></li>
                <li><a href="<?php echo $base_url?>referral">Referral</a></li>
				<li><a href="<?php echo $base_url?>apps">Apps</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<? if($attr['forsale']=='1'){ ?>
		<div style="padding:10px 0 10px 0; margin:0; color: #fff; background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
            <?=$attr['forsaletext']?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$info['domain']?>" target="_blank" style="color:blue;">Inquire now</a>.
        </div>
		<? } ?>