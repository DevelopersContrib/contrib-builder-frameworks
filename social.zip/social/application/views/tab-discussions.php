<div class="tab-pane" id="b-social">

	<br>
	<div class="col-lg-12">
		
		<iframe width="100%" scrolling="auto" height="700px" frameborder="0" style="width: 100%; height: 700px; border: 0px none; display: block;" border="0" src="http://board.contrib.com/discussion/<?=$discussionid?>" name="" id=""></iframe>

	</div>
	
</div>