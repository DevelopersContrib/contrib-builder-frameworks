<div class="tab-pane" id="b-earn">

	<ul class="nav nav-pills">
	  <li class="active"><a data-toggle="tab" href="#eservices">eServices</a></li>
	  <li><a data-toggle="tab" href="#crowdtasks">Crowdtasks</a></li>
	</ul>
	
	<div class="tab-content">
		<div class="tab-pane active" id="eservices">
				
			<!-- h4>Brand eservices</h4 -->
			
			<?//var_dump($eservices);?>
				
			<?foreach($alleservices AS $es):?>
				<div class="wrap-taskApply-cotainer">
							<h3><a href="<?echo $es['link']?>"><?echo $es['title']?></a></h3>
							<p class="taskApply-desc">
								<?echo $es['description']?></p>
													<p class="taskApply-desc">
														<a href="<?echo $es['link']?>" class="btn btn-danger btn-large">
															<i class="icon-check"></i> Apply
														</a>
													</p>
							<div class="taskApply-taskInfo">
								<ul class="inline">
									<li>
										<img src="http://www.contrib.com/images/coin.png">
										Earn: 
										<span class="text-error">
											<?echo $es['price']?>
										</span>
									</li>
									<li>
										<i class="icon-globe"></i> 
										Category: 
										<span class="text-capitalize text-error">
											<?echo $es['category']?>										</span>
									</li>
									<li>
										<i class="icon-user"></i> 
										Employer : 
										<span class="text-capitalize text-error">
											<?echo $es['employer']?>												</span>
									</li>
									<li>
										<i class="icon-calendar"></i> 
										Date Posted: 
										<span class="text-capitalize text-error"><?echo strftime("%b %d, %Y",strtotime($es['date_ordered']));?></span>
									</li>
								</ul>
							</div>
						</div>
			<?endforeach;?>
			
			<div class="alert alert-info" role="alert">
				Find more eServices in our <a href="www.contrib.com/marketplace/microtasks">marketplace</a>!
			</div>	
			
		</div>
		
	<div class="tab-pane" id="crowdtasks">

			<?foreach($allcrowdtasks AS $ct):?>
				<div class="wrap-taskApply-cotainer">
											<h3><a href="http://www.contrib.com/crowdtasks/details/dfsdfsg/<?echo $ct['task_id']?>"><?echo stripcslashes($ct['title'])?></a></h3>
											<p class="taskApply-desc">
												<p><?echo stripcslashes($ct['description'])?></p>
											</p>
										<p class="taskApply-desc">
														<a href="http://www.contrib.com/crowdtasks/details/dfsdfsg/<?echo $ct['task_id']?>" class="btn btn-danger btn-large">
															<i class="icon-check"></i> Apply
														</a>
													</p>
											<div class="taskApply-taskInfo">
												<ul class="inline">
													<li>
														<img src="http://www.contrib.com/images/coin.png">
														Equity Hours: 
														<span class="text-error">
															1
														</span>
													</li>
													<li>
														<i class="icon-globe"></i> 
														Domain: 
														<span class="text-capitalize text-error">
															<?echo $ct['domain_name']?></span>
													</li>
													<li>
														<i class="icon-user"></i> 
														Employer : 
														<span class="text-capitalize text-error">
															<?echo $ct['employer']?>
															</span>
													</li>
													<!-- li>
														<i class="icon-calendar"></i> 
														Goal Date
														<span class="text-capitalize text-error"><?echo $ct['goal_date']?></span>
													</li -->
												</ul>
											</div>
									</div><!-- wrap-taskApply-cotainer -->
			<?endforeach;?>
			<div class="alert alert-info" role="alert">
				Find more CrowdTasks in our <a href="http://www.contrib.com/crowdtasks">marketplace</a>!
			</div>		
		</div><!--crowdtasks-->
		
	</div>
	
	
</div>
<link rel="stylesheet" href="http://www.contrib.com/css/font-awesome.css" type="text/css" media="screen" />	
<style type="text/css">
	.wrap-taskApply-cotainer {
    background: none repeat scroll 0 0 #fff;
    border-color: #e2e5e8 #e2e5e8 #d8d6d1;
    border-style: solid;
    border-width: 1px 1px 2px;
    font-family: "Open Sans",sans-serif;
    margin-bottom: 20px;
    padding: 15px;
}

.wrap-taskApply-cotainer h3 {
    color: #222;
    font-weight: 400;
}
.taskApply-taskInfo {
    border-top: 1px solid #e2e5e8;
    padding-top: 10px;
}

ul.inline > li, ol.inline > li {
    display: inline-block;
    padding-left: 5px;
    padding-right: 5px;
}
</style>