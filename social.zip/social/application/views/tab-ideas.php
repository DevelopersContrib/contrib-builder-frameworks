<div class="tab-pane " id="b-ideas">
    <div class="row">
        <div class="col-lg-12">
            <a target="_blank" href="http://www.contrib.com/proposal/apply/<?echo $info['domain_name']?>">
                <img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-1-3.png">
            </a>
            <br>
            <br>
            <br>
        </div>
    </div>
    <div class="row" id="ideas_container">
       
    </div><!-- ideas container -->
</div>