<link href="http://www.contrib.com/css/marketplace/brand_custom.css" rel="stylesheet">
<div class="tab-pane active" id="b-details">
	<br>
		<div class="col-lg-12">
			<p>Linking people, skills and opportunities to create the worlds largest crowd commerce business creation system. Join us today!</p>
			<div class="alert alert-info">
				 Welcome To Contrib. Help us build out
				<a href="http:www.contrib.com/brand/details/<?echo $info['domain']?>"> <?echo strtoupper($info['domain'])?></a>
				with other great people around the world and earn equity, compensation and experience with other like minded people. Apply today before the desired opportunities are taken.
			</div>
		</div>
		<div class="col-lg-12">
			<h4>UPDATES </h4>
			<div class="col-lg-11" style="height:300px;width:740px;overflow:auto;margin-bottom:20px;">			
				<?if($newsfeed != null):?>
					 <link href="http://www.contrib.com/css/home-ver-0220.css" rel="stylesheet">
					<?foreach($newsfeed AS $newsfeed):?>
						<?echo str_replace('href="/','href="http://www.contrib.com/',str_replace('src="/','src="http://www.contrib.com/',$newsfeed['message']));?>
						<br/>
					<?endforeach;?>
				<?else:?>
					<div class="alert alert-warning" role="alert">
						No discussions yet.
					</div>
				<?endif;?>
			</div>
		</div>
		<br>
		<div class="col-lg-11">
			<div class="wrap-widgetbox">
				<div class="wrap-title">
					<div style="position: relative;">
					<i class="icon-tasks icon-white" style="margin:18px 0 0 12px;	position: absolute;"></i>
					</div>
					<h2 class="tabbed">
						<span>Equity Percentage</span>
					</h2>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
			<div class="row-fluid">
				<div class="wrap-widget-content" >
				  <div id="valpie1" style="margin-top:20px; margin:auto; width:250px; height:250px;"></div>
				</div>
			</div>
		</div>
	
		<br>
		<div class="col-lg-11">
		<div class="wrap-widgetbox">
			<div class="wrap-title">
				<div style="position: relative;">
				<i class="icon-tasks icon-white" style="margin:18px 0 0 12px;	position: absolute;"></i>
				</div>
				<?php
					$theoval = (isset($theovalues['total'])) ? $theovalues['total']: '0';
				?>
				<span class="pull-right" style="padding-top: 15px; margin-right: 15px; color: #fff; font-size: 24px;">$<?=number_format($theoval,2)?></span>
				<h2 class="tabbed">
					<span>Theoretical Value</span>
				</h2>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
		<div class="row-fluid">
			<div class="wrap-widget-content" >
			 <table class="table table-bordered table-hover table-striped">
				<tbody>
					<tr>
						<td><i class="icon-dollar"></i> Price</td>
						<td style="text-align:right">$<?php if (isset($theovalues['price'])) {echo number_format($theovalues['price']);}else {echo '0';}?></td>
					</tr>
					<tr>
						<td><i class="icon-group"></i> Team</td>
						<td style="text-align:right">$<?php if (isset($theovalues['team'])) {echo number_format($theovalues['team']);}else {echo '0';}?></td>
					</tr>
					<tr>
						<td><i class="icon-user"></i> User</td>
						<td style="text-align:right">$<?php if (isset($theovalues['user'])) {echo number_format($theovalues['user']);}else {echo '0';}?></td>
					</tr>
					<tr>
						<td>
							<i class="icon-desktop"></i>
							Social Setup
						</td>
						<td style="text-align:right">
							$<?php if (isset($theovalues['social'])) {echo number_format($theovalues['social']);}else {echo '0';}?>
						</td>
					</tr>
					<tr>
						<td><i class="icon-keyboard"></i> Social Engagement</td>
						<td style="text-align:right">$<?php if (isset($theovalues['sengagement'])) {echo number_format($theovalues['sengagement']);}else {echo '0';}?></td>
					</tr>
					<tr>
						<td><i class="icon-list-alt"></i> Content</td>
						<td style="text-align:right">$<?php if (isset($theovalues['content'])) {echo number_format($theovalues['content']);}else {echo '0';}?></td>
					</tr>
					<tr>
						<td><i class="icon-thumbs-up-alt"></i> Partners</td>
						<td style="text-align:right">$<?php if (isset($theovalues['partners'])) {echo number_format($theovalues['partners']);}else {echo '0';}?></td>
					</tr>
					<tr>
						<td><i class="icon-dollar"></i> Monetization</td>
						<td style="text-align:right">$<?php if (isset($theovalues['monetization'])) {echo number_format($theovalues['monetization']);}else {echo '0';}?></td>
					</tr>
				</tbody>
			</table>
			</div>
		</div>
	</div>
	
	<br>
	<?if(count($equity_members) > 0):?>
	<div class="col-lg-11">
		<div class="wrap-widgetbox">
			<div class="wrap-title">
				<div style="position: relative;">
				<i class="icon-tasks icon-white" style="margin:18px 0 0 12px;	position: absolute;"></i>
				</div>
				<?php
					$total_user_equity = 0;
					//$eshare_user_equity = [];
					
					foreach($equity_members as $item){	
						if($item['firstname'] != " "){
							$total_user_equity +=$item['equity_points'];
						}						
						/*foreach($eshares_ep as $p){
							
							if($p->label === $item['firstname']){
								$total_equity = $p->data * $theoval;
								$total_user_equity +=$total_equity;
								//echo $total_equity.' = '. $p->data.' * '.$theoval.'<br>';
								$eshare_user_equity[] = [
									'name'=>$item['firstname'].' '.$item['lastname'],
									'equity'=>$total_equity
								];
							}
						}*/
					}
				?>
					
				<span class="pull-right" style="padding-top: 15px; margin-right: 15px; color: #fff; font-size: 24px;"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/coin-equity-points-50x50.png" style=" padding-right: 5px;width: 20px;" /><?php echo number_format($total_user_equity)?></span>
				<h2 class="tabbed">
					<span>Member Equity Points</span>
				</h2>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
		<div class="row-fluid">
			<div class="wrap-widget-content" >
			 <table class="table table-bordered table-hover table-striped">
				<tbody>
					<?php 
						foreach($equity_members as $item){
						//foreach($eshare_user_equity as $item){
						
					?>
						<? if($item['firstname'] != " "){?>
						<tr>
							<td><i class="icon-user"></i> <?php echo $item['firstname']." ".$item['lastname']?> </td>
							<?php /*?><td><i class="icon-user"></i> <?php echo $item['name']?></td><?php */?>
							<td style="text-align:right"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/coin-equity-points-50x50.png" style=" padding-right: 5px;width: 20px;" /> <?php echo number_format($item['equity_points'],2)?></td>
							
						</tr>
					<?php
							}
						}
					?>
				</tbody>
			</table>
			<?php /*?>
			<div style="display:none">
				<pre>
				<?php
					print_r($user_equity);
				?>
				</pre>
			</div>
			<?php */?>
			</div>
		</div>
	</div>
	<?endif;?>
	

	
	
</div>
<style type="text/css">
.previewImagesPosted {
width: 15% !important;
margin-right: 50px !important;
float: left;
cursor: pointer;
}
</style>

<?
//---eshares equity points 11.10.2014---------------------------
			$ch = curl_init();
			$url = 'http://eshares.com/api/Getpie?domain='.$info['domain'];
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			$result = curl_exec($ch);
			curl_close ($ch);
			
			$result = json_decode($result);
			$p = [];
			
			if(!empty($result)){
				if(!empty($result->data)){
					$data['eshares_ep'] = $result->data;
					
					foreach($result->data as $item){
						$p[] = [$item->label,$item->data];
					}
				}
			}
			$points = json_encode($p);
//-------------------------------------------------------------
?>

<script class="code" type="text/javascript">
$(document).ready(function(){
	    
    var data = <?echo $points?>;
    //var data =  [["Investor",50],["Crowd",18],["Open",15],["Partnerships",15],["Charity",2]];
    var plot1 = $.jqplot('valpie1', [data], {
        gridPadding: {top:0, bottom:38, left:0, right:0},
        seriesDefaults:{
            renderer:$.jqplot.PieRenderer, 
            trendline:{ show:false }, 
            rendererOptions: { padding: 8, showDataLabels: true }
        },
        legend:{
            show:true, 
            placement: 'outside', 
            rendererOptions: {
                numberRows: 1
            }, 
            location:'s',
            marginTop: '15px'
        }       
    });   
});
</script>
<script src="http://tools.contrib.com/cwidget?d=<?=$info['domain']?>&p=sb&c=f"></script>
<script class="include" type="text/javascript" src="/js/jqplot/jquery.jqplot.min.js"></script>
<script type="text/javascript" src="/js/jqplot/syntaxhighlighter/scripts/shCore.min.js"></script>
<script type="text/javascript" src="/js/jqplot/syntaxhighlighter/scripts/shBrushJScript.min.js"></script>
<script type="text/javascript" src="/js/jqplot/syntaxhighlighter/scripts/shBrushXml.min.js"></script>
<script class="include" type="text/javascript" src="/js/jqplot/plugins/jqplot.pieRenderer.min.js"></script>

