<div class="tab-pane" id="b-affiliate">
	<div class="">
		<div class="col-lg-12">
			<h3>Banners</h3>
			<hr class="lineLines lineLines-2">
			<!--<dl class="dl-horizontal">
				<dt>Marketing Group</dt><dd>Contrib</dd>
				<dt>Banner Size</dt><dd>150 x 150</dd>
				<dt>Banner Description</dt><dd>Proud member of Contrib Sticker</dd>
				<dt>Target URL</dt><dd>http://www.contrib.com</dd>
			</dl>

			<img src="http://referrals.contrib.com/banners/badge-contrib-2.png">
			<br>

			<p>Source Code - Copy/Paste Into Your Website</p>
			<textarea class="form-control" readonly="readonly" onclick="this.focus();this.select()" rows="4" style="width:90%">&lt;a href="<?//echo $domain_affiliate_link?>" target="_blank"&gt;&lt;img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-2.png" width="150" height="150" alt="Proud Member of Contrib"&gt;&lt;/a&gt;</textarea>
			<br><p class="line">&nbsp;</p>

			<dl class="dl-horizontal">
				<dt>Marketing Group</dt><dd>Contrib</dd>
				<dt>Banner Size</dt><dd>150 x 150</dd>
				<dt>Banner Description</dt><dd>Contrib Sticker 1</dd>
				<dt>Target URL</dt><dd>http://www.contrib.com</dd>
			</dl>

			<img src="http://referrals.contrib.com/banners/badge-contrib-3.png">
			<br>

			<p>Source Code - Copy/Paste Into Your Website</p>
			<textarea class="form-control" readonly="readonly" onclick="this.focus();this.select()" rows="4" style="width:90%">&lt;a href="<?//echo $domain_affiliate_link?>" target="_blank"&gt;&lt;img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-3.png" width="150" height="150" alt="Contrib"&gt;&lt;/a&gt;</textarea>
			<br><p class="line">&nbsp;</p>


			<dl class="dl-horizontal">
				<dt>Marketing Group</dt><dd>Contrib</dd>
				<dt>Banner Size</dt><dd>150 x 150</dd>
				<dt>Banner Description</dt><dd>I love Contrib Sticker</dd>
				<dt>Target URL</dt><dd>http://www.contrib.com</dd>
			</dl>

			<img src="http://referrals.contrib.com/banners/badge-contrib-heart5.png">
			<br>

			<p>Source Code - Copy/Paste Into Your Website</p>
			<textarea class="form-control" readonly="readonly" onclick="this.focus();this.select()" rows="4" style="width:90%">			&lt;a href="<?//echo $domain_affiliate_link?>" target="_blank"&gt;&lt;img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-heart5.png" width="150" height="150" alt="I love Contrib"&gt;&lt;/a&gt;</textarea>
			<br><p class="line">&nbsp;</p>

			<dl class="dl-horizontal">
				<dt>Marketing Group</dt><dd>Contrib</dd>
				<dt>Banner Size</dt><dd>200 x 200</dd>
				<dt>Banner Description</dt><dd>Contrib Banner</dd>
				<dt>Target URL</dt><dd>http://www.contrib.com</dd>
			</dl>

			<img src="http://referrals.contrib.com/banners/ban-contrib-200x200-4.png">
			<br>

			<p>Source Code - Copy/Paste Into Your Website</p>
			<textarea class="form-control" readonly="readonly" onclick="this.focus();this.select()" rows="4" style="width:90%">&lt;a href="<?//echo $domain_affiliate_link?>" target="_blank"&gt;&lt;img style="border:0px" src="http://referrals.contrib.com/banners/ban-contrib-200x200-4.png" width="200" height="200" alt="Proud Member of Contrib"&gt;&lt;/a&gt;</textarea>
			<br><p class="line">&nbsp;</p>

			<dl class="dl-horizontal">
				<dt>Marketing Group</dt><dd>Contrib</dd>
				<dt>Banner Size</dt><dd>228 x 90</dd>
				<dt>Banner Description</dt><dd>Contrib Banner</dd>
				<dt>Target URL</dt><dd>http://www.contrib.com</dd>
			</dl>

			<img src="http://referrals.contrib.com/banners/ban-contrib-228x90-4.png">
			<br>

			<p>Source Code - Copy/Paste Into Your Website</p>
			<textarea class="form-control" readonly="readonly" onclick="this.focus();this.select()"  rows="4" style="width:90%">&lt;a href="http://referrals.contrib.com/idevaffiliate.php?id=1874_0_1_12" target="_blank"&gt;&lt;img style="border:0px" src="http://referrals.contrib.com/banners/ban-contrib-228x90-4.png" width="228" height="90" alt="Proud Member of Contrib"&gt;&lt;/a&gt;</textarea>-->
			
			
			<dl class="dl-horizontal">
			  <dt>Marketing Group</dt><dd>Contrib</dd>
			  <dt>Banner Size</dt><dd>728 x 90</dd>
			  <dt>Banner Description</dt><dd><?php echo ucfirst($domain)?> Banner</dd>
			  <dt>Target URL</dt><dd>http://www.<?echo $domain?></dd>
			</dl>
		
		    <script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?php echo $domain?>/"></script>
                        
			<br>
			
			<p>Source Code - Copy/Paste Into Your Website</p>
			<textarea style="width:90%" onclick="this.focus();this.select()" readonly="readonly">
				<script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?php echo $domain?>/"></script>
			</textarea>
			<br><p class="line">&nbsp;</p>
			
			<dl class="dl-horizontal">
			  <dt>Marketing Group</dt><dd>Contrib</dd>
			  <dt>Banner Size</dt><dd>180 x 150</dd>
			  <dt>Banner Description</dt><dd><?php echo ucfirst($domain)?> Banner</dd>
			  <dt>Target URL</dt><dd>http://www.<?echo $domain?></dd>
			</dl>
			
				<script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?php echo $domain?>/"></script>
							
			<br>
			
			<p>Source Code - Copy/Paste Into Your Website</p>
			<textarea style="width:90%" onclick="this.focus();this.select()" readonly="readonly">
				<script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?php echo $domain?>/"></script>
			</textarea>
			
		</div>
	</div>
	<div style="clear:both;"></div>
</div>