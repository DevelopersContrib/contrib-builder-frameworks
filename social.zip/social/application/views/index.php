<?$header->render();?>

	<div class="section section-feature-mail">
		<div class="bg-overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        
							<? if($info['logo']==''){ ?>
								<h1 class="text-center domain-name-center"><?php echo ucfirst($info['domain']);?></h1>
							<? }else{ ?>
								<p class="text-center"><img class="img-responsive email-logo-domain" src="<?php echo $info['logo'];?>" alt="<?php echo ucfirst($info['domain']);?>" title="<?php echo ucfirst($info['domain']);?>"> </p>
							<? } ?>	
                       
                        <p class="email-text"><?echo $info['description']?></p>
                        <div class="row" id="leadcontent">
                            <div class="col-lg-6 col-lg-offset-3" id="leadform">
                                <div class="input-group">
									<input type="hidden" id="refid" value="0">
									<input type="hidden" id="domain" value="<?php echo $info['domain']?>">
									<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
                                    <input type="text" name="email" id="email" class="form-control input-lg" placeholder="ie. contrib@yahoo.com">
                                    <input type="text" name="secret" id="secret" class="form-control" value="" style="display:none;">
                                    <span class="input-group-btn">
                                        <button type="button" class="email-ftre btn btn-danger btn-lg" target="_blank" href="" id="submitLead">
                                            <i class="fa fa-envelope"></i>
                                            Join us today!
                                        </button>
                                    </span>
                                </div>
                            </div>
                        </div><!-- row -->
                        <div class="addhtml" style="text-align:center;display: none">
								<?if($attr['additional_html'] != ""):?>
								<?echo base64_decode($attr['additional_html'])?>
								<?endif;?>
						</div>
                    </div>
                </div>
            </div>
    </div><!-- section section-feature-mail -->
	
	<div class="container container2">
            <div class="row">
                <div class="col-lg-8 ver-left">
                    <ul class="nav nav-tabs ver-6-tabs hidden-xs">
                        <li class="active"><a data-toggle="tab" href="#b-details">Home</a></li>
                        <li class=""><a id="tabteam" data-toggle="tab" href="#b-team">Team</a></li>
                        <li class=""><a data-toggle="tab" href="#b-partners">Partners</a></li>
                        <li class=""><a data-toggle="tab" href="#b-earn">Earn</a></li>
                        <li class=""><a data-toggle="tab" href="#b-affiliate">Referral Program</a></li>
                    </ul> <!-- For Big Screen -->
                    <ul class="nav nav-pills nav-stacked ver-6-tabs visible-xs">
                        <li class="active"><a data-toggle="tab" href="#b-details">Home</a></li>
                        <li class=""><a id="tabteam" data-toggle="tab" href="#b-team">Team</a></li>
                        <li class=""><a data-toggle="tab" href="#b-partners">Partners</a></li>
                        <li class=""><a data-toggle="tab" href="#b-earn">Earn</a></li>
                        
                        <li class=""><a data-toggle="tab" href="#b-affiliate">Referral Program</a></li>
                    </ul> <!-- For small devices -->
                    <div class="tab-content">
                        <?php $tab_details->render()?>
                        <?php $tab_teams->render()?>
                        <?php $tab_partners->render()?>
                        <?php $tab_earn->render()?>
                        
                        <?php $tab_referrals->render()?>
                    </div>
                </div>
                <div class="col-lg-4 ver-right">
                    
                    
                   
				   
					
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <strong><i class="fa fa-desktop"></i> Social Media</strong>
                        </div>
                        <div class="panel-body">
                            <ul class="list-inline" id="socials">
                               
                            </ul>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <strong><i class="fa fa-group"></i> Teams</strong>
                        </div>
                        <div class="panel-body">
                            <ul class="list-inline">
								<?foreach($team_members AS $m):?>
									 <li>
										<a href="#" title="<?echo $m['firstname']." ".$m['lastname']?>" >
											<?
											$avatar_src = 'http://manage.vnoc.com/uploads/picture/'.$m['picture'];
											if(empty($m['picture'])){
												$avatar_src = 'http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/default_avatar.png';
											}?>
											
											<img alt="<?echo $m['firstname']." ".$m['lastname']?>" title="<?echo $m['firstname']." ".$m['lastname']?>"  src="<?echo $avatar_src?>" class="img-thumbnail team-lv6-img">
										</a>
									</li>
								<?endforeach;?>
                            </ul>
                        </div>
                    </div>
					<div class="panel panel-default" style="display:none">
					<script type="text/javascript" src="http://contrib.com/widgets?ma=micronews&d=<?=$info['domainid']?>"></script> 
					</div>
                </div>
            </div>
        </div>
<input type="hidden" name="domain_name" id="domain_name" value="<?echo $info['domain']?>"/>
<script type="text/javascript" src="/js/lead.js"></script>
<script type="text/javascript">
	$(function(){
		$.post('/home/loadjobs',{},function(data_html){
			$('#jobs_container').html(data_html);
		});
		
		$.post('/home/loadideas',{},function(data_html){
			$('#ideas_container').html(data_html);
		});
		
		/*$.post('/statistics/getfollowers',{},function(data){
			if(data.length == 0){
				$('#followers_count').text(Math.floor((Math.random() * 100) + 1));
			}else{
				$('#followers_count').text(data);
			}
		});
		
		$.post('/statistics/getofferscount',{},function(data){
			if(data.length == 0){
				$('#followers_count').text(Math.floor((Math.random() * 100) + 1));
			}
			else{
				$('#offers_count').text(data);
			}
		});
		
		$.post('/statistics/getleadscount',{},function(data){
			if(data.length == 0){
				$('#followers_count').text(Math.floor((Math.random() * 100) + 1));
			}
			else{
				$('#leads_count').text(data);
			}
		});*/
		
		var domain_name = $('#domain_name').val();
			//var domain_name = 'referrals.com';
			getsocial(domain_name,'fb','fa fa-facebook');
			getsocial(domain_name,'twitter','fa fa-twitter');
			getsocial(domain_name,'linkedin','fa fa-linkedin');
			getsocial(domain_name,'gplus','fa fa-google-plus');
			//getsocial(<?echo $info['domain']?>,'linkedin','fa fa-instagram');
			getsocial(domain_name,'gtube','fa fa-youtube');
			//getsocial(<?echo $info['domain']?>,'linkedin','fa fa-github');
			//getsocial(<?echo $info['domain']?>,'linkedin','fa fa-vimeo-square');
		
	});
	
	function getsocial(domain_name,social,li_class){
	
			$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
							var socialdata = data[0];
							if(socialdata.error == true){
								//do nothing
							}else if(socialdata.profile_url == ""){
								//do nothing
							}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
								//do nothing
							}else{
								//$('#socials_container').append('&nbsp;<a href="'+socialdata.profile_url+'"><img src="'+icon_src+'" height="40px"></a>&nbsp;');
								$("ul#socials ").append('<li><a href="'+socialdata.profile_url+'" target="_blank"><div class="round-it-social">&nbsp;&nbsp;<i class="'+li_class+'">&nbsp;&nbsp;</i></div></a></li>');
							}		
			});
	}
	
	
	
</script>	
<?php include("footer.php"); ?>
<?//$footer->render();?>