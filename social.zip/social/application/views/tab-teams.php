<div class="tab-pane" id="b-team">
	<h1><?echo ucfirst($info['domain'])?> Teams</h1>
	
	<hr class="lineLines">
	<div class="row">
		
		<?if(count($team_members) > 0):?>
			<?//var_dump($team_members);?>
			<?foreach($team_members AS $member):?>
				<div class="col-lg-6 col-xs-12">
					<div class="widget-team">
						<div class="team-simple bckgrdn-dark">
								<?if($member['picture'] == "")
									{	
										$src = 'http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/default_avatar.png';
									}else{
										$src = 'http://manage.vnoc.com/uploads/picture/'.$member['picture'];
									}
								?>
								<img class="widget-image img-circle pull-left" src="<?echo $src?>">
							<h4 class="widget-content widget-content-light ellipsis">
									<?echo $member['firstname']." ".$member['lastname']?>
								<small>
									<?echo $member['teamid']?>
								</small>
							</h4>
						</div>
					</div>
				</div>
			<?endforeach;?>
		<?endif;?>
		
	
	</div><!-- row -->
</div>	