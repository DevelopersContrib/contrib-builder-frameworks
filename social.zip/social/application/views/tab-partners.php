<div class="tab-pane" id="b-partners">
    <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-info">
                <h4>Would you like to Partner with <?echo ucfirst($info['domain'])?></h4>
                <p>We have different types of partnership options you could choose from, moreover, you can add and partner with as many
                    assets in the marketplace that suits your brand.<a href="http://www.contrib.com/partner/apply/<?echo $info['info']?>">Send in your Partnership Application Today</a></p>
                </div>
            </div>
        </div>
	
	<?if($partners == null):?>
		<div class="alert alert-warning" role="alert">
			No partners approved for <?echo ucfirst($info['domain'])?>.
		</div>
	
	<?else:?>
		
		<?foreach($partners AS $partner):?>
			
			<div class="partner-box">
				<div class="col-md-4">
					<img class="img-rounded" src="<?echo $partner['image']?>" alt="<?echo $partner['company_name']?>">
				</div>
				<div class="col-md-8">
					<h3><a href="<?echo $partner['url']?>"><?echo $partner['company_name']?></a></h3>
					<p><?echo $partner['description']?></p>
				</div>
				<div class="pclear"></div>
			</div>
			
		<?endforeach;?>
	<?endif;?>
	
</div>
<style type="text/css">
	.img-rounded{max-width: 255px;}
</style>