		<div class="col-lg-12" style="padding: 30px 0 0 0;">	
			<div class="footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<ul class="list-inline ul-footer">
								<li>
									<a href="/">Home</a>
								</li>
								<li>
									<a href="/about">About</a>
								</li>
								<li>
									<a href="/privacy">Privacy</a>
								</li>
								<li>
									<a href="/terms">Terms and Condtion</a>
								</li>								
								<li>
									<a href="/partners">Partner with us</a>
								</li>
								<li>
									<a href="/referral">Referral</a>
								</li>
							</ul>
							<p class="copyright">
								&copy;  2013-<?echo date('Y')?> <?=ucwords($info['domain'])?> | All Rights Reserved
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
    </body>
</html>