<?global $footer_html?>
		<div class="col-lg-12" style="padding: 30px 0 0 0; display:none">
			<div class="footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<ul class="list-inline ul-footer">
								<li>
									<a href="/">Home</a>
								</li>
								<li>
									<a href="/about">About</a>
								</li>
								<li>
									<a href="/privacy">Privacy</a>
								</li>
								<li>
									<a href="/terms">Terms and Condtion</a>
								</li>								
								<li>
									<a href="/partners">Partner with us</a>
								</li>
								<li>
									<a href="/referral">Referral</a>
								</li>
							</ul>
							<p class="copyright">
								&copy;  2013-<?echo date('Y')?> <?=ucwords($info['domain'])?> | All Rights Reserved :<?=$info['domain_temp']?>:
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- new footer-->
<div class="footer-top">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-3">
			<h3><?php echo $info['domain'];?></h3>
			<p>is a proud venture of Global Ventures, LLC. Join our network of performance based companies using <?php echo $info['domain']; ?>.</p>
		  </div>
		  <div class="border col-md-3">
			<h3>Get Started</h3>
			<ul class="list-unstyled">
				<li><a href="/partners">Partner With Us</a></li>
				<li><a href="/staffing">Apply Now</a></li>
				<li><a href="/referral">Referral</a></li>
				<li><a href="/fund">Fund</a></li>
				<li><a href="/developers">Developers</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3>Company</h3>
			<ul class="list-unstyled">
				<li><a href="/about">About Us</a></li>
				<li><a href="/terms">Terms</a></li>
				<li><a href="/privacy">Privacy</a></li>
				<li><a href="/contact">Contact Us</a></li>
				<li><a href="/apps">Apps</a></li>
			</ul>
		  </div>
		  <div class="border col-md-3">
			<h3 class="fnt-bold text-uppercase">
				partners
			</h3>
			<p>
				<?if($footer_html != ""):?>
					<?echo base64_decode($footer_html)?>
					<?php else:?>
					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
				<?endif;?>
			</p>
			<h3>Social</h3>
			<ul class="list-inline socials-ul">
											<?php global $social_fb; global $social_gplus; global $social_gtube; global $social_linkedin; ?>
											<li>
												<a title="facebook" class="icon-button facebook" href="<?=$social_fb?>" target="_blank">
													<i class="fa fa-facebook-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="google-plus" class="icon-button google-plus" href="<?=$social_gplus?>" target="_blank">
													<i class="fa fa-google-plus-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="youtube" class="icon-button youtube" href="<?=$social_gtube?>" target="_blank">
													<i class="fa fa-youtube-square"></i>
													<span></span>
												</a>
											</li>
											<li>
												<a title="linkedin" class="icon-button linkedin" href="<?=$social_linkedin?>" target="_blank">
													<i class="fa fa-linkedin-square"></i>
													<span></span>
												</a>
											</li>
			</ul>
		  </div>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class="border row">
		  <div class="border col-md-6"><span style="color:#fff">&copy; <?php echo date("Y")." ".ucfirst($info['domain'])?>. All Rights Reserved.</span></div>
		  <div class="border col-md-6">
			  <ul class="list-inline">			
				<li><a href="/about"><i class="fa fa-bookmark-o"></i> About Us</a></li>
				<li><a href="/terms"><i class="fa fa-book"></i> Terms</a></li>
				<li><a href="/privacy"><i class="fa fa-cube"></i> Privacy</a></li>
				<li><a href="/contact"><i class="fa fa-phone-square"></i> Contact Us</a></li>
			  </ul>
		  </div>
		</div>
	</div>
</div>
<!-- new footer-->
    </body>
</html>