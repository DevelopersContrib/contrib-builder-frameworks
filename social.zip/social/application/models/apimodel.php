<?php
include("php_fast_cache.php");

class ApiModel extends Model {
	
	//private $api_url = "http://api2.contrib.com/jobs/";
	private $api_url = "http://api1.contrib.co/request/";
	private $headers = array('Accept: application/json');
	
	function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}
	
	function getdomain(){
		global $domain;
	 	return $domain;
	}

	function getkey(){
		return md5($this->getdomain());
	}
	
	
	function getdomaininfo(){
		global $domainid;
		global $title;
		global $logo;
		global $description;
		global $account_ga;
		global $description;
		global $domain;
		global $keywords;
		global $piwik_id;

		$info['domainid'] = $domainid;
		$info['domain'] = $domain;
		$info['title'] = $title;
		$info['keywords'] = $keywords;
		$info['logo'] = $logo;
		$info['description'] = $description;
		$info['account_ga'] = $account_ga;
		$info['description'] = stripslashes(str_replace('\n','<br>',$info['description']));
		$info['piwik_id'] = $piwik_id;
		
		return $info;
   }
   
   
   function getalleservices(){
		global $alleservice;
		    if ($alleservice['success']){	
			  	
			    $i = 0;
				foreach($alleservice['data'] AS $data){
					$info[$i]['link'] = $data['link'];
					$info[$i]['title'] = $data['title'];
					$info[$i]['price'] = $data['price'];
					$info[$i]['category'] = $data['category'];
					$info[$i]['description'] = stripslashes(str_replace('\n','<br>',$data['description']));
					$info[$i]['employer'] = $data['posted_by'];
					$info[$i]['date_ordered'] = $data['date_ordered'];
					$i++;
				}
			
	       
        }
        
		return $info;
		
	}
   
	
	function geteservicesperdomain(){
		global $eservices;
		$info = array();
		    
		    if ($eservices['success']){	
				$i = 0;
				foreach($eservices['data'] AS $data){
					$info[$i]['link'] = $data['link'];
					$info[$i]['title'] = $data['title'];
					$info[$i]['price'] = $data['price'];
					$info[$i]['category'] = $data['category_name'];
					$info[$i]['description'] = stripslashes(str_replace('\n','<br>',$data['description']));
					$info[$i]['employer'] = $data['posted_by'];
					$i++;
				}
			
			}
		return $info;
	}
	
	
	function getallcrowdtask(){
		global $crowdtasks;
		
		    $info = array();

		    if ($crowdtasks['success']){	
			  $i = 0;
				foreach($crowdtasks['data'] AS $data){
					$info[$i]['task_id'] = $data['task_id'];
					$info[$i]['title'] = $data['title'];
					$info[$i]['description'] = stripslashes(str_replace('\n','<br>',$data['description']));
					$info[$i]['goal_date'] = $data['goal_date'];
					$info[$i]['date_posted'] = $data['date_posted'];
					$info[$i]['employer'] = $data['employer'];
					$info[$i]['domain_name'] = $data['domain_name'];
					$info[$i]['hours'] = $data['hours'];
					$i++;
				}
			
			}
			
	       
		return $info;
	}
	
   
	function getattributes(){
		global $background_image;
        global $forsale;
        global $showforsaledefault;
        global $forsaletext;
        global $additional_html;
        
		    	
		    	$info['background_image'] = $background_image;
    		    $info['forsale'] = $forsale;
    		    $info['forsaletext'] = $forsaletext;
    		    $info['showforsaledefault'] = $showforsaledefault;
    		    $info['additional_html'] = $additional_html;
    	
    		    if($info['forsaletext']=='') $info['forsaletext'] = 'This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.';
    
       return $info;
   }
   
	function getbanner(){
		global $footer_banner;
        return $footer_banner;
	}
   
	
	function getaffiliatelink(){
		global $domain_affiliate_link;
		return $domain_affiliate_link;
	}
	
    
	function getwidgets($type){
		global $data_widget_users;
        global $data_widget_jobs;
		$widgets = array();
		$widgets['users'] = $data_widget_users;
		$widgets['jobs'] = $data_widget_jobs;
		return $widgets[$type];
	}
	
	function getsignupformdata(){
		global $rolesarray ;
        global $countriesarray;
        global $industriesarray;
        
		$formdata = array();
	    $formdata['data']['roles'] = $rolesarray;
		$formdata['data']['countries'] = $countriesarray;
		$formdata['data']['industries'] = $industriesarray;
		
        return $formdata;
	}
   
	function getpartners(){
		global $partners;
        return $partners;
	}
	
	function getjobsperdomain(){
		global $domainjobs;
		
		$jobs = $domainjobs;
		
			if($jobs[0]['error']){
				return null;
			}else{
				$jobs = $jobs['data'];
			}

			return $jobs;
	}
	
	function getTeamPerDomain(){
		global $team;
		$team_members = array();
			if($team[0]['error']){
				return null;
			}else{
				$team_members = $team['data'];
			}
		
		return $team_members;
	}
	
	
	function getideasperdomain(){
		global $ideas;
		if($ideas[0]['error'] == true){
				return null;
			}else{
				$ideas = $ideas['data'];
		}
		return $ideas;
	}
	
	public function getotherideas(){
		global $other_ideas;
		
			if($other_ideas[0]['error'] == true){
				return null;
			}else{
				$other_ideas = $other_ideas['data'];
			}
		
		return $other_ideas;
	}
	
	
	function getleadscount(){
		    $url = $this->api_url.'getdomainleadscount?domain='.$this->getdomain().'&key='.$this->getkey();
		    $result = $this->createApiCall($url, 'GET', $this->headers, array());
		    $data_follow_count = json_decode($result,true);
			 if ($data_follow_count['success']){
			    	$leads = ($data_follow_count['data']['leads'] + 1 ) * 25;
			    }else {
			    	$leads = 1 * 25;
			}
	    return $leads;
	}
	
	function getnewsfeed(){
		global $newsfeeds;
		
		if($newsfeeds[0]['error']){
			return null;
		}else{
			return $newsfeeds['data'];
		}
	}
	
	
	
	
	
	
	
	function getdomainfollowcount(){
		global $follow_count;
		if($follow_count[0]['error'] == true){
			return null;
		}else{
			return $follow_count[0]['total'];
		}
	}
	
	
	function getboardid(){
		global $discussions;
		if($discussions[0]['error'] == true){
			return null;
		}else{
			return $discussions[0]['discussion_id'];
		}
	}
	
	function getofferscount(){
		global $offers;
		
		if($offers[0]['error'] == true){
			return null;
		}else{
			return $offers[0]['count'];
		}
	}
	
    function getmemberequity(){
		global  $mequity;
			if($mequity[0]['error'] == true){
				return null;
			}else{
				$mequity = $mequity['data'];
				
			}
		return $mequity;
	
	}
	
   function gettheoreticalvalue(){
		global $theoretical_value;
		
			if($theoretical_value[0]['error'] == true){
				return null;
			}else{
				$theoretical_value = $theoretical_value['data'];
		
			}
		return $theoretical_value;
	}
	
	
   function testfunc(){
		global $equity_url;
		return $equity_url;
	
	}
	
	function createrobots(){
		//	generate robots.txt if not exist
	$filename = ROOT_DIR .'/robots.txt';
	//if(!(file_exists($filename))) {
    $my_file = ROOT_DIR .'/robots.txt';
	$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
	$data = '---BEGIN ROBOTS.TXT ---
	User-Agent: *
	Disallow:
	
	Sitemap: http://'.$this->getdomain().'/sitemap
	--- END ROBOTS.TXT ----';
	fwrite($handle, $data);
	}
   
   
   
} //end of model
?>