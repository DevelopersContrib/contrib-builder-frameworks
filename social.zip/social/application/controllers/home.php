<?php

class Home extends Controller {
	
	function index(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$newsfeed = $api->getnewsfeed();
		$attr = $api->getattributes();
		$team = $api->getTeamPerDomain();
		$partners = $api->getpartners();
		$eservices = $api->geteservicesperdomain();
		$allcrowdtasks = $api->getallcrowdtask();
		$alleservices = $api->getalleservices();
		$equity_members = $api->getmemberequity();
		$testfunc =  $api->testfunc();
		$gettheovalue = $api->gettheoreticalvalue();
		
		$formdata = $api->getsignupformdata();
		if ($formdata['success']){
		     $roles = $formdata['data']['roles'];
	    	 $intentions = $formdata['data']['intentions'];
	    	 $industries = $formdata['data']['industries'];
	    	 $experiences = $formdata['data']['experiences'];
        }	
		$template = $this->loadView('index');
		$header = $this->loadView('header');
		$footer = $this->loadView('footer');
		
    if (count($gettheovalue)>0){ 
  		foreach($gettheovalue as $theoval){
  		
  		
  			$theovalues['price'] = $theoval['price'];
  			$theovalues['team'] = $theoval['team'];
  			$theovalues['user'] = $theoval['leads'];
  			$theovalues['social'] = $theoval['social'];
  			$theovalues['sengagement'] = $theoval['social_engagement'];
  			$theovalues['content'] = $theoval['content'];
  			$theovalues['partners'] = $theoval['partners'];
  			$theovalues['monetization'] = $theoval['monetization'];
  			$theovalues['total'] = $theoval['total'];
  		}
    }
		
		
		
		$tab_details = $this->loadView('tab-details');
		$tab_teams = $this->loadView('tab-teams');
		$tab_partners = $this->loadView('tab-partners');
		$tab_jobs = $this->loadView('tab-jobs');
		$tab_ideas = $this->loadView('tab-ideas');
		$tab_referrals = $this->loadView('tab-referrals');
		//$tab_discussions = $this->loadView('tab-discussions');
		$tab_earn = $this->loadView('tab-earn');
		
		
		
		$header->set('info', $info);
		$header->set('attr', $attr);
		
		$tab_details->set('theovalues',$theovalues);
		$tab_details->set('info', $info);
		$tab_details->set('newsfeed',$newsfeed);
		$tab_details->set('testfunc',$testfunc);
		$tab_details->set('equity_members',$equity_members);
		$tab_teams->set('team_members',$team);
		$tab_teams->set('info',$info);
		$tab_partners->set('partners',$partners);
		$tab_partners->set('info',$info);
		$tab_ideas->set('domain_name',$info['domain']);
		$tab_referrals->set('domain_affiliate_link',$api->getaffiliatelink());
		$tab_referrals->set('domain',$info['domain']);
		//$tab_discussions->set('newsfeed',$newsfeed);
		//$tab_discussions->set('discussionid',$api->getboardid());
		$tab_earn->set('domain_name',$info['domain']);
		$tab_earn->set('eservices',$eservices);
		$tab_earn->set('allcrowdtasks',$allcrowdtasks);
		$tab_earn->set('alleservices',$alleservices);
		
		
		$template->set('info', $info);
		$template->set('header',$header);
		$template->set('footer',$footer);
		$template->set('tab_details',$tab_details);
		$template->set('tab_teams',$tab_teams);
		$template->set('tab_partners',$tab_partners);
		$template->set('tab_jobs',$tab_jobs);
		$template->set('tab_ideas',$tab_ideas);
		$template->set('tab_referrals',$tab_referrals);
		$template->set('team_members',$team);		
		//$template->set('tab_discussions',$tab_discussions);	
		$template->set('tab_earn',$tab_earn);
		$template->set('attr',$attr);
		
		
		
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	public function loadjobs(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$jobs = $api->getjobsperdomain();
		$info = $api->getdomaininfo();
		
		$loadjobs = $this->loadView('jobs-content');
		$loadjobs->set('info', $info);
		$loadjobs->set('jobs', $jobs);
		
		$loadjobs->set('base_url',$helper->base_url());
		$loadjobs->render();
		
	}
	
	public function loadideas(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$ideas = $api->getideasperdomain();
		

 		$info = $api->getdomaininfo();
		
		
		if(sizeof($ideas) == 0){
			$ideas = $api->getotherideas();
		}
		
		$loadideas = $this->loadView('ideas-content');
		$loadideas->set('info', $info);
		$loadideas->set('ideas', $ideas);
		
		$loadideas->set('base_url',$helper->base_url());
		$loadideas->render();
		
	}
	
    
}

?>