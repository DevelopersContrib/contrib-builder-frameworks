<?php

class Statistics extends Controller {
	function getfollowers(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$total = $api->getdomainfollowcount();
		
		echo $total;
	}
	
	function getofferscount(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$total = $api->getofferscount();
		
		echo $total;
	}
	
	function getleadscount(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$total = $api->getleadscount();
		
		echo $total;
	}
}
?>