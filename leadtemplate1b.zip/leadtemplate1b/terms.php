
<? include_once 'header.php'; ?>

<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wrap-padtop-v1 clearfix">
						<div class="es-blck-rnd text-center">
							               <?php 
   $api_content_url = "http://api3.contrib.co/announcement/";                 //get terms
  $url = $api_content_url.'GetFooterContents?domain='.$domain.'&key=5c1bde69a9e783c7edc2e603d8b25023&page=terms';
  $result =  createApiCall($url, 'GET', $headers, array());
  $data_domain = json_decode($result,true);
  if (isset($data_domain['data']['content'])){
   $terms =   $data_domain['data']['content'];
  }else {
    $terms = "";
  }

  echo $terms;
                    ?>
					</div>
				</div>
			</div>
		</div>


<? include_once 'footer.php';?>