<? include_once 'header.php'; ?>
<div class="row">
				<div class="col-lg-12">
					<div class="wrap-padtop-v1 clearfix">
						<div class="row">
							<div class="col-lg-6">
								<p class="fnts-georgia">&nbsp;</p>
								<div class="exerpt-slide">
									<p>
										Join our exclusive community of like minded people on <?echo $domain?>
									</p>
								</div>
								<div class="col-lg-12 wrap-v1-counter">
									
								</div>
							</div>
							<div class="col-lg-6 text-center">
								<!-- <div class="es-blck-rnd text-center">
									
								</div> -->
								<iframe frameborder="0" style="width: 350px;background: whitesmoke;height: 500px;padding: 15px 0 0 15px;border-radius: 5px;margin:40px" scrolling="no" src="https://domaindirectory.com/servicepage/contactus2_form.php?domain=<?=$domain?>"></iframe>
							</div>
						</div>
					</div>
				</div>
</div>

<? include_once 'footer.php';?>