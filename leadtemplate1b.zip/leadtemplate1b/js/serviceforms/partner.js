$(function(){https://https://https://https://https://https://https://
	
	$('#partner_initialemail').focus();
	
	$('#partner_btn_1').click(function(){
            var initial_email = $('#partner_initialemail').val();
			var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			
			$('#partner_warning1').html('');
			
            if (initial_email == ""){
                $('#partner_warning1').html('* Please enter email*');
                $('#partner_initialemail').focus();
			}else if(!emailfilter.test(initial_email)){
                $('#partner_warning1').html('* Invalid Email *');
                $('#partner_initialemail').focus();
            }else {
				$("#partner_btn_1").attr('disabled', true); 
                $.post('https://www.api.contrib.com/forms/fullcontactdetails',
                       {initial_email:initial_email}
                       ,function(data){
                           $('#partner_firstname').val(data.fname);
                           $('#partner_lastname').val(data.lname);
                           $('#partner_email').val(initial_email);
                           $('#partner_step1').hide();
                           $('#partner_step2').show();
                       }
				);
            }		
	});
	
	$('#partner_btn_2').click(function(){            
            var firstname = $('#partner_firstname').val();	
            var lastname = $('#partner_lastname').val();	
            var email = $('#partner_email').val();		
            var country_id = $('#partner_country').val();
			var country = $("#partner_country option:selected").text();
            var city = $('#partner_city').val();	
            var password = $('#partner_password').val();	
            var password2 = $('#partner_password2').val();	            
			var website = $('#partner_website').val();		
            var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var letters = /^[a-zA-Z ]+$/;
            var alphanumeric = /^[0-9a-zA-Z ]+$/;
            						
            $('#partner_warning2').html('');
			
            if(firstname==''){
                $('#partner_firstname').focus();
				$('#partner_warning2').html('* First name is required *');                
            }else if(!letters.test(firstname)){
                $('#partner_firstname').focus();
                $('#partner_warning2').html('* Accepts letters only *');               
            }else if(firstname.length > 25){
                $('#partner_firstname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(firstname.length < 3 ){			
                $('#partner_firstname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname==''){
                $('#partner_lastname').focus();
				$('#partner_warning2').html('* Last name is required *');                
            }else if(!letters.test(lastname)){
                $('#partner_lastname').focus();
                $('#partner_warning2').html('* Accepts letters only *');                	
            }else if(lastname.length > 25){
                $('#partner_lastname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname.length < 3 ){			
                $('#partner_lastname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(email==''){
                $('#partner_email').focus();
				$('#partner_warning2').html('* Email is required *');                
            }else if(!emailfilter.test(email)){
                $('#partner_email').focus();
                $('#partner_warning2').html('* Invalid email *');      
			}else if(website != '' && validateURL(website)===false) {
                $('#partner_website').focus();
                $('#partner_warning2').html('* Enter a valid link for website*');
            }else if(country_id==''){
                $('#partner_country').focus();
				$('#partner_warning2').html('* Country is required *');                
            }else if(city==''){
                $('#partner_city').focus();
				$('#partner_warning2').html('* City is required *');                
            }else if(!alphanumeric.test(city)){
                $('#partner_city').focus();
                $('#partner_warning2').html('* Alphanumeric only *');                
            }else if(password==''){
                $('#partner_password').focus();
				$('#partner_warning2').html('* Password is required *');                
            }else if (password.length < 5){
                $('#partner_password').focus();
                $('#partner_warning2').html('* Password should have atleast 5 characters *');                
            }else if(password2==''){
                $('#partner_password2').focus();
				$('#partner_warning2').html('* Please confirm password *');                
            }else if(password!=password2){
                $('#partner_password2').focus();
                $('#partner_warning2').html('* Password not match *');                
            }else{ 
				$("#partner_btn_2").attr('disabled', true);
				$('#partner_step2').hide();
				$('#partner_step3').show();
			}
           
	});
				
	$('#partner_back_3').click(function(){            
            $('#partner_step3').hide();
			$('#partner_step2').show();
			$("#partner_btn_2").attr('disabled', false);
			
			$('#partner_warning3').html('');
	});
    
	
	$('#partner_btn_3').click(function(){
		var message = $('#partner_message').val();
		var partnertype = $('#partner_type').val();		
		
		
		if(partnertype == ""){
			$('#partner_warning3').html('<center>* Please choose partnership type. *</center>');
			$('#partner_type').focus();	
		}else if(message == ""){
			$('#partner_warning3').html('<center>* Message is required. *</center>');
			$('#partner_message').focus();
		}else{
			$('#partner_step4').show();
			$('#partner_step3').hide();
		}
	});
	
	$('button#partner_back_4').click(function(){
		$('#partner_step3').show();
		$('#partner_step4').hide();
	});
	
	$('#partner_btn_4').click(function(){	
			console.log("checking..");
			var domain = $('#partner_domain').val();	
			var firstname = $('#partner_firstname').val();	
            var lastname = $('#partner_lastname').val();	
            var email = $('#partner_email').val();		
            var country_id = $('#partner_country').val();	
            var country = $("#partner_country option:selected").text();
            var city = $('#partner_city').val();	
            var password = $('#partner_password').val();	
            var password2 = $('#partner_password2').val();	            
			var company = $('#partner_company').val();
			var website = $('#partner_website').val();		
            var partnertype = $('#partner_type').val();			
            var message = $('#partner_message').val();
			var companytitle = $('#partner_company').val();
            var companydesc = $('#partner_companydescription').val();
            var companyimage = $('#partner_companyimage').val();
            var companyurl = $('#partner_companyurl').val();
            var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var letters = /^[a-zA-Z ]+$/;
            var alphanumeric = /^[0-9a-zA-Z ]+$/;          
            			
            $('#partner_warning3').html('');
			
            if(partnertype==''){	                
				$('#partner_warning3').html('* Type of partnership is required *'); 
				$('#partner_step4').hide();$('#partner_step3').show();$("#partner_btn_3").attr('disabled', false);	
				$('#partner_type').focus();
				console.log('* Type of partnership *');            
            }else if(message==''){	
                $('#partner_message').focus();
                $('#partner_warning3').html('* Message is required *'); 
				$('#partner_step4').hide();$('#partner_step3').show();$("#partner_btn_3").attr('disabled', false);				
				console.log('* Message is required *');
			}else if(website != '' && validateURL(website)===false) {                
                $('#partner_warning2').html('* Enter a valid link for website*');
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
				$('#partner_website').focus();
				console.log('* Enter a valid link *');
			}else if(firstname==''){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_firstname').focus();
				$('#partner_warning2').html('* First name is required *');      
				console.log('* First name is required *');				
            }else if(!letters.test(firstname)){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_firstname').focus();
                $('#partner_warning2').html('* Accepts letters only *');      
				console.log('* Accepts letters only *');				
            }else if(firstname.length > 25){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_firstname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
				console.log('* Name should have 3 to 25 characters *');
			}else if(firstname.length < 3 ){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_firstname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
				console.log('* Name should have 3 to 25 characters *');
			}else if(lastname==''){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_lastname').focus();
				$('#partner_warning2').html('* Last name is required *');                
				console.log('* Last name is required *');
			}else if(!letters.test(lastname)){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_lastname').focus();
                $('#partner_warning2').html('* Accepts letters only *');                	
				console.log('* Accepts letters only *');
			}else if(lastname.length > 25){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_lastname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
				console.log('*  Name should have 3 to 25 characters *');
			}else if(lastname.length < 3 ){	
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_lastname').focus();
                $('#partner_warning2').html('* Name should have 3 to 25 characters *');                
				console.log('* Name should have 3 to 25 characters *');
			}else if(email==''){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_email').focus();
				$('#partner_warning2').html('* Email is required *');                
				console.log('* Email is required *');
			}else if(!emailfilter.test(email)){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_email').focus();
                $('#partner_warning2').html('* Invalid email *');                
				console.log('* Invalid email  *');			
		   }else if(country_id==''){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_country').focus();
				$('#partner_warning2').html('* Country is required *');                
				console.log('*  Country is required *');
			}else if(city==''){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_city').focus();
				$('#partner_warning2').html('* City is required *');                
				console.log('*  City is required *');
		   }else if(!alphanumeric.test(city)){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_city').focus();
                $('#partner_warning2').html('* Alphanumeric only *');                
				console.log('* Alphanumeric only *');
			}else if(password==''){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_password').focus();
				$('#partner_warning2').html('* Password is required *');                
				console.log('* Password is required *');
			}else if(password.length < 5){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_password').focus();
                $('#partner_warning2').html('* Password should have atleast 5 characters *');                
				console.log('* Password should have atleast 5 characters *');
			}else if(password2==''){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_password2').focus();
				$('#partner_warning2').html('* Please confirm password *');                
				console.log('* Please confirm password *');
			}else if(password!=password2){
				$('#partner_step4').hide();$('#partner_step3').hide();$('#partner_step2').show();$("#partner_btn_2").attr('disabled', false);
                $('#partner_password2').focus();
                $('#partner_warning2').html('* Password not match *'); 
				console.log('*  Password not match *');
			}else if(companytitle==''){	
				$('#partner_company').focus();
				$('#partner_warning4').html('* Company name is required *');
				console.log('* Company name is required *');
			}else if(!alphanumeric.test(companytitle)){
				$('#partner_company').focus();
				$('#partner_warning4').html('* Alphanumeric only *');
				console.log('* Alphanumeric only *');
			}else if(companydesc==''){	
				$('#partner_companydescription').focus();
				$('#partner_warning4').html('* Company description is required *'); 
				console.log('* Company description is required*');
			}else if(companyimage==''){	
				$('#partner_companyimage').focus();
				$('#partner_warning4').html('* Company image/logo is required *');
			}else if(validateURL(companyimage)===false){
				$('#partner_companyimage').focus();
				$('#partner_warning4').html('* Invalid URL/link for company image *'); 
			}else if(companyurl==''){	
				$('#partner_companyurl').focus();
				$('#partner_warning4').html('* Company link is required *'); 
				console.log('* Company link is required*');
			}else if(validateURL(companyurl)===false){
				$('#partner_companyurl').focus();
				$('#partner_warning4').html('* Invalid company link *'); 
				console.log('* Company link is required*');
			}else{
				$("#partner_btn_3").attr('disabled', true);
				$("#partner_back_3").attr('disabled', true);			
				
                $.post("https://www.api.contrib.com/forms/checkexist",{'field':'EmailAddress','value':email},function(data){

					$('#partner_warning4').html('* Please wait. Checking in progress. * ');	
				
					if (data.status == 0){
						$('#partner_warning4').html('* Please wait. Checking in progress. * ');	
						  
						$.post('https://www.api.contrib.com/forms/save_partner',
						   {
								domain:domain,
								firstname:firstname,
								lastname:lastname,
								email:email,
								country_id:country_id,
								country:country,
								city:city,
								password:password,
								website:website,
								companyurl:companyurl,
								partnertype:partnertype,
								message:message,
								company:companytitle,
								companydesc:companydesc,
								companyimage:companyimage,
								companyurl:companyurl								
						   }
						   ,function(data){
								if(data.success===true){
									$('div#viewcontriblink').text('Thank you!');
									$('div#viewcontriblink').html('<a href="https://www.contrib.com/account/autologinforms?email='+data.email+'&form=partnership"><button class="btn btn-success btn-lg">View your Contrib.com account now!</button></a>');
									$('#partner_step4').hide();
									$('#partner_final').show();
								}else{
									$('#partner_warning4').html('* '+data.result+' * ');
									console.log('* '+data.result+' * ');
									$("#partner_btn_3").attr('disabled', false);
									$("#partner_back_3").attr('disabled', false);									
								}
						   }
						);
						
						
                      
                        $.post("https://manage.vnoc.com/salesforce/addlead",
                               {
                                   'firstName':firstname,
                                   'lastName':lastname,
                                   'title':'',
                                   'email':email,
                                   'phone':'',
                                   'street':'',
                                   'city':city,
                                   'country':country,
                                   'state':'',
                                   'zip':'',
                                   'domain':domain,
                                   'partner_type':partnertype,
                                   'message':message,
                                   'form_type':'VNOC Partnership'
                               }
                               ,function(data2){
                                  // _gaq.push(['_trackEvent', 'Partnership', domain, 'Form Submission']);
                                  // _gaq.push(['_trackEvent', 'Domains', 'Signup', domain]);
                               }
                              );	
                        
                    }else{
                        $('#partner_warning4').html('* Email already have an account. * <a href="https://www.contrib.com" target="_top">Please LOGIN here.</a>');
						console.log('* Email already have an account. * <a href="https://www.contrib.com" target="_top">Please LOGIN here.</a>');
						$("#partner_btn_3").attr('disabled', false);
						$("#partner_back_3").attr('disabled', false);
                    }
                });
				
            }
		 
	});
	
});

function validateURL(url){
	return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
}