$(function(){https://https://https://https://https://https://https://
	
	$('#staffing2_initialemail').focus();

    $('#staffing2_resumeurl').click(function(){
        httpApppend('#staffing2_resumeurl');
    });


    function httpApppend(id){
        $(id).val('https://');
    }
	
	$('#staffing2_btn_1').click(function(){
            var initial_email = $('#staffing2_initialemail').val();
			var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			
			$('#staffing2_warning1').html('');
			
            if (initial_email == ""){
                $('#staffing2_warning1').html('* Please enter email*');
                $('#staffing2_initialemail').focus();
			}else if(!emailfilter.test(initial_email)){
                $('#staffing2_warning1').html('* Invalid Email *');
                $('#staffing2_initialemail').focus();
            }else {
				$("#staffing2_btn_1").attr('disabled', true); 
                $.post('https://www.api.contrib.com/forms/fullcontactdetails',
                       {initial_email:initial_email}
                       ,function(data){
                           $('#staffing2_firstname').val(data.fname);
                           $('#staffing2_lastname').val(data.lname);
                           $('#staffing2_website').val(data.website);
                           $('#staffing2_email').val(initial_email);
                           $('#staffing2_step1').hide();
                           $('#staffing2_step2').show();
                       }
				);
            }		
	});
	
	$('#staffing2_btn_2').click(function(){            
            var firstname = $('#staffing2_firstname').val();	
            var lastname = $('#staffing2_lastname').val();	
            var email = $('#staffing2_email').val();		
            var country_id = $('#staffing2_country').val();
			var country = $("#staffing2_country option:selected").text();
            var city = $('#staffing2_city').val();	
            var password = $('#staffing2_password').val();	
            var password2 = $('#staffing2_password2').val();	            
			var website = $('#staffing2_website').val();		
            var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var letters = /^[a-zA-Z ]+$/;
            var alphanumeric = /^[0-9a-zA-Z ]+$/;
            						
            $('#staffing2_warning2').html('');
			
            if(firstname==''){
                $('#staffing2_firstname').focus();
				$('#staffing2_warning2').html('* First name is required *');                
            }else if(!letters.test(firstname)){
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Accepts letters only *');               
            }else if(firstname.length > 25){
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(firstname.length < 3 ){			
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname==''){
                $('#staffing2_lastname').focus();
				$('#staffing2_warning2').html('* Last name is required *');                
            }else if(!letters.test(lastname)){
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Accepts letters only *');                	
            }else if(lastname.length > 25){
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname.length < 3 ){			
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(email==''){
                $('#staffing2_email').focus();
				$('#staffing2_warning2').html('* Email is required *');                
            }else if(!emailfilter.test(email)){
                $('#staffing2_email').focus();
                $('#staffing2_warning2').html('* Invalid email *');                               
            }else if(website != '' && validateURL(website)===false) {
                $('#staffing2_website').focus();
                $('#staffing2_warning2').html('* Enter a valid link *');              
            }else if(country_id==''){
                $('#staffing2_country').focus();
				$('#staffing2_warning2').html('* Country is required *');                
            }else if(city==''){
                $('#staffing2_city').focus();
				$('#staffing2_warning2').html('* City is required *');                
            }else if(!alphanumeric.test(city)){
                $('#staffing2_city').focus();
                $('#staffing2_warning2').html('* Alphanumeric only *');                
            }else if(password==''){
                $('#staffing2_password').focus();
				$('#staffing2_warning2').html('* Password is required *');                
            }else if (password.length < 5){
                $('#staffing2_password').focus();
                $('#staffing2_warning2').html('* Password should have atleast 5 characters *');                
            }else if(password2==''){
                $('#staffing2_password2').focus();
				$('#staffing2_warning2').html('* Please confirm password *');                
            }else if(password!=password2){
                $('#staffing2_password2').focus();
                $('#staffing2_warning2').html('* Password not match *');                
            }else{ 
				$("#staffing2_btn_2").attr('disabled', true);
				$('#staffing2_step2').hide();
				$('#staffing2_step3').show();
			}
           
	});
				
	$('#staffing2_back_3').click(function(){            
		$('#staffing2_warning3').html('');
		$('#staffing2_step3').hide();
		$('#staffing2_step2').show();
		$("#staffing2_btn_2").attr('disabled', false);		
	});	
	
	$('#staffing2_back_4').click(function(){  
		$('#staffing2_warning4').html('');
		$('#staffing2_step4').hide();
		$('#staffing2_step3').show();
		$("#staffing2_btn_3").attr('disabled', false);			
	});
        
	$('#staffing2_btn_3').click(function(){		 
			var domain = $('#staffing2_domain').val();	
			var firstname = $('#staffing2_firstname').val();	
            var lastname = $('#staffing2_lastname').val();	
            var email = $('#staffing2_email').val();		
            var country_id = $('#staffing2_country').val();	
            var country = $("#staffing2_country option:selected").text();
            var city = $('#staffing2_city').val();	
            var password = $('#staffing2_password').val();	
            var password2 = $('#staffing2_password2').val();	            
			var website = $('#staffing2_website').val();
			var resume = $('#staffing2_resume').val();	//add proper trapping for upload resume	
			var resumeurl = $('#staffing2_resumeurl').val();		
            var role = $('#staffing2_role').val();			
            var message = $('#staffing2_message').val();
            var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var letters = /^[a-zA-Z ]+$/;
            var alphanumeric = /^[0-9a-zA-Z ]+$/;          
            			
            $('#staffing2_warning3').html('');
			
            if(firstname==''){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
				$('#staffing2_warning2').html('* First name is required *');                
            }else if(!letters.test(firstname)){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Accepts letters only *');               
            }else if(firstname.length > 25){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(firstname.length < 3 ){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname==''){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
				$('#staffing2_warning2').html('* Last name is required *');                
            }else if(!letters.test(lastname)){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Accepts letters only *');                	
            }else if(lastname.length > 25){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname.length < 3 ){	
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(email==''){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_email').focus();
				$('#staffing2_warning2').html('* Email is required *');                
            }else if(!emailfilter.test(email)){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_email').focus();
                $('#staffing2_warning2').html('* Invalid email *');              
			}else if(website != '' && validateURL(website)===false) {
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_website').focus();
                $('#staffing2_warning2').html('* Enter a valid link *');               
            }else if(country_id==''){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_country').focus();
				$('#staffing2_warning2').html('* Country is required *');                
            }else if(city==''){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_city').focus();
				$('#staffing2_warning2').html('* City is required *');                
            }else if(!alphanumeric.test(city)){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_city').focus();
                $('#staffing2_warning2').html('* Alphanumeric only *');                
            }else if(password==''){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password').focus();
				$('#staffing2_warning2').html('* Password is required *');                
            }else if(password.length < 5){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password').focus();
                $('#staffing2_warning2').html('* Password should have atleast 5 characters *');                
            }else if(password2==''){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password2').focus();
				$('#staffing2_warning2').html('* Please confirm password *');                
            }else if(password!=password2){
				$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password2').focus();
                $('#staffing2_warning2').html('* Password not match *'); 
			}else  if(role==''){	
                $('#staffing2_role').focus();
				$('#staffing2_warning3').html('* Type of partnership is required *'); 
			//}else if(resume == '' && resumeurl == '') {
			}else if(resumeurl == '') {
				$('#staffing2_resumeurl').focus();
                $('#staffing2_warning3').html('* Please provide your resume *');
			}else if(resumeurl != '' && validateURL(resumeurl)===false) {
                $('#staffing2_resumeurl').focus();
                $('#staffing2_warning3').html('* Enter a valid link *');
            }else if(message==''){	
                $('#staffing2_message').focus();
                $('#staffing2_warning3').html('* Message is required *');            
            }else{				
				$('#staffing2_step3').hide();
				$('#staffing2_step4').show();
            }
		 
	});
        
	$('#staffing2_btn_4').click(function(){		 
			var domain = $('#staffing2_domain').val();	
			var firstname = $('#staffing2_firstname').val();	
            var lastname = $('#staffing2_lastname').val();	
            var email = $('#staffing2_email').val();		
            var country_id = $('#staffing2_country').val();	
            var country = $("#staffing2_country option:selected").text();
            var city = $('#staffing2_city').val();	
            var password = $('#staffing2_password').val();	
            var password2 = $('#staffing2_password2').val();	            
			var website = $('#staffing2_website').val();
			var resume = $('#staffing2_resume').val();	//add proper trapping for upload resume	
			var resumeurl = $('#staffing2_resumeurl').val();		
            var role = $('#staffing2_role').val();			
            var rolename = $("#staffing2_role option:selected").text();			
            var message = $('#staffing2_message').val();
            var facebook = $('#staffing2_facebook').val();
            var linkedin = $('#staffing2_linkedin').val();
            var github = $('#staffing2_github').val();
            var skype = $('#staffing2_skype').val();
            var yahoo = $('#staffing2_yahoo').val();
            var talk = $('#staffing2_talk').val();
            var aol = $('#staffing2_aol').val();
            var wlive = $('#staffing2_wlive').val();			
            var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var letters = /^[a-zA-Z ]+$/;
            var alphanumeric = /^[0-9a-zA-Z ]+$/;          
            						
            if(firstname==''){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
				$('#staffing2_warning2').html('* First name is required *');                
            }else if(!letters.test(firstname)){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Accepts letters only *');               
            }else if(firstname.length > 25){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(firstname.length < 3 ){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_firstname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname==''){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
				$('#staffing2_warning2').html('* Last name is required *');                
            }else if(!letters.test(lastname)){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Accepts letters only *');                	
            }else if(lastname.length > 25){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(lastname.length < 3 ){	
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_lastname').focus();
                $('#staffing2_warning2').html('* Name should have 3 to 25 characters *');                
            }else if(email==''){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_email').focus();
				$('#staffing2_warning2').html('* Email is required *');                
            }else if(!emailfilter.test(email)){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_email').focus();
                $('#staffing2_warning2').html('* Invalid email *');              
			}else if(website != '' && validateURL(website)===false) {
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_website').focus();
                $('#staffing2_warning2').html('* Enter a valid link *');               
            }else if(country_id==''){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_country').focus();
				$('#staffing2_warning2').html('* Country is required *');                
            }else if(city==''){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_city').focus();
				$('#staffing2_warning2').html('* City is required *');                
            }else if(!alphanumeric.test(city)){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_city').focus();
                $('#staffing2_warning2').html('* Alphanumeric only *');                
            }else if(password==''){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password').focus();
				$('#staffing2_warning2').html('* Password is required *');                
            }else if(password.length < 5){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password').focus();
                $('#staffing2_warning2').html('* Password should have atleast 5 characters *');                
            }else if(password2==''){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password2').focus();
				$('#staffing2_warning2').html('* Please confirm password *');                
            }else if(password!=password2){
				$('#staffing2_step4').hide();$('#staffing2_step3').hide();$('#staffing2_step2').show();$("#staffing2_btn_2").attr('disabled', false);
                $('#staffing2_password2').focus();
                $('#staffing2_warning2').html('* Password not match *'); 
			}else  if(role==''){	
				$('#staffing2_step4').hide();$('#staffing2_step3').show();$("#staffing2_btn_3").attr('disabled', false);
                $('#staffing2_role').focus();
				$('#staffing2_warning3').html('* Type of partnership is required *'); 
			//}else if(resume == '' && resumeurl == '') {
			}else if(resumeurl == '') {
				$('#staffing2_step4').hide();$('#staffing2_step3').show();$("#staffing2_btn_3").attr('disabled', false);
				$('#staffing2_resumeurl').focus();
                $('#staffing2_warning3').html('* Please provide your resume *');
			}else if(resumeurl != '' && validateURL(resumeurl)===false) {
				$('#staffing2_step4').hide();$('#staffing2_step3').show();$("#staffing2_btn_3").attr('disabled', false);
                $('#staffing2_resumeurl').focus();
                $('#staffing2_warning3').html('* Enter a valid link *');
            }else if(message==''){	
				$('#staffing2_step4').hide();$('#staffing2_step3').show();$("#staffing2_btn_3").attr('disabled', false);
                $('#staffing2_message').focus();
                $('#staffing2_warning3').html('* Message is required *');   
            }else{
				$("#staffing2_btn_4").attr('disabled', true);
				$("#staffing2_back_4").attr('disabled', true);			
				
                $.post("https://www.api.contrib.com/forms/checkexist",{'field':'EmailAddress','value':email},function(data){

					$('#staffing2_warning4').html('* Please wait. Checking in progress. * ');	
				
					if (data.status == 0){
						$('#staffing2_warning4').html('* Please wait. Checking in progress. * ');	
						  
						$.post('https://www.api.contrib.com/forms/save_staffing',
						   {
								domain:domain,
								firstname:firstname,
								lastname:lastname,
								email:email,
								country_id:country_id,
								country:country,
								city:city,
								password:password,
								website:website,
								resumeurl:resumeurl,
								role:role,
								message:message,
								facebook:facebook,
								linkedin:linkedin,
								github:github,
								skype:skype,
								yahoo:yahoo,
								talk:talk,
								aol:aol,
								wlive:wlive
						   }
						   ,function(data){
								if(data.success===true){
									$('div#viewcontriblink').text('Thank you!');
									$('div#viewcontriblink').html('<a href="https://www.contrib.com/account/autologinforms?email='+data.email+'&form=staffing"><button class="btn btn-success btn-lg">View your Contrib.com account now!</button></a>');
									$('#staffing2_step4').hide();
									$('#staffing2_final').show();
								}else{
									$('#staffing2_warning4').html('* '+data.result+' * ');
									$("#staffing2_btn_4").attr('disabled', false);
									$("#staffing2_back_4").attr('disabled', false);									
								}
						   }
						);
						
						
                      $.post("https://manage.vnoc.com/salesforce/addlead",
							{
                                   'firstName':firstname,
                                   'lastName':lastname,
                                   'title':'',
                                   'email':email,
                                   'phone':'',
                                   'street':'',
                                   'city':city,
                                   'country':country,
                                   'state':'',
                                   'zip':'',
                                   'domain':domain,
                                   'role':rolename,
                                   'message':message,
                                   'form_type':'VNOC Staffing'
							}
							,function(data2){
                                  // _gaq.push(['_trackEvent', 'Staffing', domain, 'Form Submission']);
                                  // _gaq.push(['_trackEvent', 'Domains', 'Signup', domain]);
							}
					);
					  
                        
                    }else{
                        $('#staffing2_warning4').html('* Email already have an account. * <a href="https://www.contrib.com" target="_top">Please LOGIN here.</a>');
						$("#staffing2_btn_4").attr('disabled', false);
						$("#staffing2_back_4").attr('disabled', false);
                    }
                });
				
            }
		 
	});
	
});

function validateURL(url){
	return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
}