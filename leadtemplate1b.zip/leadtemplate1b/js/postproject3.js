$(document).ready(function(){

	
	 $('#homeown_phone').mask("(999) 999-9999");

	 $("#zip_code").keypress(function (e) {
			 
			 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				
				$("#errmsg").html("Digits Only").show().fadeOut("slow");
					   return false;
			}
		});
		
		$("#homeown_phone").keypress(function (e) {
			 
			 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				
				$("#errmsg2").html("Digits Only").show().fadeOut("slow");
					   return false;
			}
		});

		$('#alreadyacc').click(function(){
			$('#content-register').hide();
			$('#content-login').show();
			$('#indicator').val("1");
		});
		
		$('#createnewacc').click(function(){
		
			$('#content-register').show();
			$('#content-login').hide();
			$('#indicator').val("2");
			
		
		});
		
		$('#continuetoprojectinof').click(function(){
		var projecttype = $('#projecttype').val();
		var projectdesc = $('#projectdesc').val();
		var projectstart = $('#projectstart').val();
		var projectstatus = $('#projectstatus').val();
		var projecttimeframe = $('#projecttimeframe').val();
		var projectbudget = $('#projectbudget').val();
		var projectaddress = $('#projectaddress').val();
		var projectstate = $('#projectstate').val();
		var type_name = $("#projecttype option:selected").text();
		var city = $('#city').val();
		var zip_code = $('#zip_code').val();
		var owned = $('input[name="won_pro"]:checked').val();
		var homeown_fname = $('#homeown_fname').val();
		var homeown_lname = $('#homeown_lname').val();
		var homeown_phone = $('#homeown_phone').val();
		var howeown_pname = $('#howeown_pname').val();
		
		
		
		
		if(projecttype == "" || projecttype == "Select Type"){
			$('.projecttype_message').html("Project Type is required");
		}else if(projectdesc == ""){
			$('.projectdesc_message').html("Project Description is required");
		}else if(projectstart == "" || projectstart == "Select"){
			$('.projectstart_message').html("Ideal Start Date is required");
		}else if(projectstatus == ""){
			$('.projectstatus_message').html('Project Status is required');
		}else if(projecttimeframe == "" || projecttimeframe == "Select"){
			$('.projecttimeframe_messafe').html('Project Status is required');
		}if(homeown_fname == ""){
			$('.homeown_fname').html('First name is required');
		}else if(homeown_lname == ""){
			$('.homeown_lname').html('Last name is required');
		}else if(homeown_phone == ""){
			$('.homeown_phone').html('phone number is required');
		}else if(howeown_pname == ""){
			$('.howeown_pname').html('public username is required');
		}else if(checks != 1){
			$("#errors3").html('<div class="alert alert-danger">Please agree to the terms and condition <button type="button" class="close" data-dismiss="alert">&times;</button></div>');
		}else if (homeown_phone.length < 10){
			$('.homeown_phone').html('Phone number should have 10 digits.');
		}else if(city == ""){
			$('.city').html('City is required');
			$('#city').focus();
		}else if(zip_code == ""){
				$('.zip_code').html('Zipcode is required');
				$('#zip_code').focus();
		}else{
		
			$("#tab2").addClass("active");
			$("#topli2").addClass("active");
			$("#topli1").removeClass("active");
			$("#tab1").removeClass("active");
			$("#topli3").removeClass("active");
			$("#topli1").addClass("done");
			$("#tab3").removeClass("active");
			$("#topli4").removeClass("active");
			$("#tab4").removeClass("active");
			$("#prog_bar").css('width','50%')
		}
		
			
			
		
		});
		
		$('#backtoprojectinfo').click(function(){

			
			//$("#tab2").addClass("active");
			//$("#topli2").addClass("active");
			$("#tab1").addClass("active");
			$("#topli1").addClass("active");
			$("#tab3").removeClass("active");
			$("#topli3").removeClass("active");
			$("#tab4").removeClass("active");
			$("#topli4").removeClass("active");
		
			
		});
		
		$('#continuetoprojectinof').click(function(){
			var projecttype = $('#projecttype').val();
			var projectdesc = $('#projectdesc').val();
			var projectstart = $('#projectstart').val();
			var projectstatus = $('#projectstatus').val();
			var projecttimeframe = $('#projecttimeframe').val();	
			var homeown_fname = $('#homeown_fname').val();
			var homeown_lname = $('#homeown_lname').val();
			var homeown_phone = $('#homeown_phone').val();
			var projectbudget = $('#projectbudget').val();
			var projectaddress = $('#projectaddress').val();
			var projectstate = $('#projectstate').val();
			var city = $('#city').val();
			var zip_code = $('#zip_code').val();
			var owned = $('input[name="won_pro"]:checked').val();
			
			$('.postProjErr').html('');
			
		
			if(projecttype == "" || projecttype == "Select Type"){
				$('.projecttype_message').html("Project Type is required");
				$('#projecttype').focus();
			}else if(homeown_fname == ""){
				$('.homeown_fname').html('First name is required');
				$('#homeown_fname').focus();
			}else if(homeown_lname == ""){
				$('.homeown_lname').html('Last name is required');
				$('#homeown_lname').focus();
			}else if(projectdesc == ""){
				$('.projectdesc_message').html("Project Description is required");
				$('#projectdesc').focus();
			}else if(projectstart == "" || projectstart == "Select"){
				$('.projectstart_message').html("Ideal Start Date is required");
				$('#projectstart').focus();
			}else if (homeown_phone.length < 10){
				$('.homeown_phone').html('Phone number should have 10 digits.');
				$('#homeown_phone').focus();
			}else if(homeown_phone == ""){
				$('.homeown_phone').html('phone number is required');
				$('#homeown_phone').focus();
			}else if(projectstatus == ""){
				$('.projectstatus_message').html('Project Status is required');
				$('#projectstatus').focus();
			}else if(projecttimeframe == "" || projecttimeframe == "Select"){
				$('.projecttimeframe_messafe').html('Project Status is required');
				$('#projecttimeframe').focus();
			}else if(projectbudget == ""){
				$('.projectbudget').html('Project Budget is required');
				$('#projectbudget').focus();
			}else if(projectaddress == ""){
				$('.projectaddress').html('Project Address is required');
				$('#projectaddress').focus();
			}else if(projectstate == "" || projectstate == "Please select"){
				$('.projectstate').html('State is required');
				$('#projectstate').focus();
			}else if(city == ""){
				$('.city').html('City is required');
				$('#city').focus();
			}else if(zip_code == ""){
				$('.zip_code').html('Zipcode is required');
				$('#zip_code').focus();
			}else{
				$("#tab3").addClass("active");
				$("#topli3").addClass("active");
				$("#topli1").removeClass("active");
				$("#tab1").removeClass("active");
				//$("#topli3").removeClass("active");
				$("#topli1").addClass("done");
				//$("#tab3").removeClass("active");
				$("#topli4").removeClass("active");
				$("#tab4").removeClass("active");
				$("#prog_bar").css('width','50%')
			}
		
			
			
		
		});
		
		$('#backtoprojectSetup').click(function(){
			$("#tab1").addClass("active");
			$("#topli1").addClass("active")
			$("#tab3").removeClass("active");
			$("#topli3").removeClass("active");
			$("#tab2").removeClass("active");
			$("#topli2").removeClass("active");
			$("#tab4").removeClass("active");
			$("#topli4").removeClass("active");
		
		});
		
		$('#continuetosuccess').click(function(){
		
			var indicator = $('#indicator').val();
			
			var base_url = $('#base_url').val();
			var projecttype = $('#projecttype').val();
			var projectdesc = $('#projectdesc').val();
			var projectstart = $('#projectstart').val();
			var projectstatus = $('#projectstatus').val();
			var projecttimeframe = $('#projecttimeframe').val();
			var projectbudget = $('#projectbudget').val();
			var projectaddress = $('#projectaddress').val();
			var projectstate = $('#projectstate').val();
			var type_name = $("#projecttype option:selected").text();
			var state_name = $("#projectstate option:selected").text();
			var city = $('#city').val();
			var zip_code = $('#zip_code').val();
			var owned = $('input[name="won_pro"]:checked').val();
			var homeown_fname = $('#homeown_fname').val();
			var homeown_lname = $('#homeown_lname').val();
			var homeown_phone = $('#homeown_phone').val();
			var howeown_pname = $('#howeown_pname').val();
			var homeown_email = $('#homeown_email').val();
			var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			var specialcharsfilter = /[^a-zA-Z 0-9]+/g;
			var home_loginEmail = $('#home_loginEmail').val();
			var home_loginPassword = $('#home_loginPassword').val();
			var checks = 0;
			if(jQuery('input[type="checkbox"][name="termscon"]').is(':checked')){
				checks = 1;
			}
			if(howeown_pname == ""){
				$('.howeown_pname').html('public username is required');
			}else if(homeown_email == ""){
				$('.homeown_email').html('email is required')
			}else if(!emailfilter.test(homeown_email)){
				$('.homeown_email').html('email is invalid');
			}else if(checks != 1){
				$("#errors3").html('<div class="alert alert-danger">Please agree to the terms and condition <button type="button" class="close" data-dismiss="alert">&times;</button></div>');
			}else{
					
					$("#errors2").html('<div class="alert alert-success"><img src="https://d2qcctj8epnr7y.cloudfront.net/images/jayson/gif-loading/macthrob-small.png"> Posting Project</div>');
					$.post(base_url+'postproject/addproject',
						{
							projecttype:projecttype,
							projectdesc:projectdesc,
							projectstart:projectstart,
							projectstatus:projectstatus,
							projecttimeframe:projecttimeframe,
							owned:owned,
							projectaddress:projectaddress,
							state_name:projectstate,
							city:city,
							zip_code:zip_code,
							projectbudget:projectbudget,
							homeown_fname:homeown_fname,
							homeown_lname:homeown_lname,
							homeown_number:homeown_phone,
							homeown_uname:howeown_pname,
							homeown_email:homeown_email
						},function(response){
							var obj = JSON.parse(response);
							if( obj.success == 'success'){
								
								$("#tab4").addClass("active");
								$("#topli4").addClass("active")
								$("#tab3").removeClass("active");
								$("#topli3").removeClass("active");
								$("#tab2").removeClass("active");
								$("#topli3").addClass("done");
								$("#topli2").removeClass("active");
								$("#tab1").removeClass("active");
								$("#topli1").removeClass("active");
								$("#prog_bar").css('width','100%');
								
								//alert("save");
								$("#errors2").html('<div class="alert alert-success">Registration Successful<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
								
								window.location.href = 'https://handyman.com/api/autologin/code/'+obj.emailencode+'/zip/'+zip_code+'/projecttype/'+projecttype;
								

								
							}else{
								$("#errors2").html('<div class="alert alert-danger">'+obj.exist+'<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
							
							}
						
						});
			}

		});
		
		$('#successid').click(function(){
		
			var projecttype = $('#projecttype').val();
			var projectdesc = $('#projectdesc').val();
			var projectstart = $('#projectstart').val();
			var projectstatus = $('#projectstatus').val();
			var projecttimeframe = $('#projecttimeframe').val();
			var projectbudget = $('#projectbudget').val();
			var projectaddress = $('#projectaddress').val();
			var projectstate = $('#projectstate').val();
			var type_name = $("#projecttype option:selected").text();
			var city = $('#city').val();
			var zip_code = $('#zip_code').val();
			var owned = $('input[name="won_pro"]:checked').val();
			var homeown_fname = $('#homeown_fname').val();
			var homeown_lname = $('#homeown_lname').val();
			var homeown_phone = $('#homeown_phone').val();
			var howeown_pname = $('#howeown_pname').val();
			var homeown_email = $('#homeown_email').val();
			var home_loginEmail = $('#home_loginEmail').val();
			var home_loginPassword = $('#home_loginPassword').val();
			
		
		
		});
		
		

});