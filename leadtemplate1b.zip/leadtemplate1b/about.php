<? include_once 'header.php'; ?>
	<div class="row">
				<div class="col-lg-8 col-xs-offset-2">
					<div class="wrap-padtop-v1 clearfix">
						<div class="es-blck-rnd text-center">
							<h1 class="xlg-title-slide xts-small">
								About <?=$domain?>
							</h1>
							<div class="exerpt-slide es-17 fnt-sans fnt-300">
								<p>About <?=ucfirst($domain)?> is a venture of of Global Ventures, LLC.</p>

								<p>Join our exclusive community of like minded people on <?=ucfirst($domain)?></p>

								<p>Global Ventures, LLC, established in 1996, is a Real Estate and Technology company focused on building and leveraging electronic corporations (eCorp) within the Domain Name System.  Premium domains and companies such as Referrals.com,Staffing.com, Mergers.com, Domain Holdings, VentureCamp, Handyman.com, DSL.com and over 20,000 others are the core digital asset and building blocks of Global Ventures.</p>

								<p>With over 1,000,000 targeted unique monthly visitors, Global Ventures utilizes both virtual and physical real estate with effective business models, streamlined policy and procedures with a balanced and optimal productivity and management platform for the global economy.</p>

								<p>Learn more about joining our team, becoming an iPartner, or leveraging one of our premium domain assets or companies to help grow your business.</p>

							</div>
						</div>
					</div>
				</div>
			</div>
			
<? include_once 'footer.php';?>