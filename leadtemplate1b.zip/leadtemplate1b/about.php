<? include_once 'header.php'; ?>
	<div class="row">
				<div class="col-lg-8 col-xs-offset-2">
					<div class="wrap-padtop-v1 clearfix">
						<div class="es-blck-rnd text-center">
							<h1 class="xlg-title-slide xts-small">
								About <?=$domain?>
							</h1>
							<div class="exerpt-slide es-17 fnt-sans fnt-300">
								<p>Hyperloop.org has recently launched to support Entrepreneurs around the world who want to create a better life and give back to fellow Entrepreneurs, locally and globally.  We provide opportunities for anyone in the world to join or launch a company with proven processes, resources and technology to create value.  Ventures of CONTRIB sign a commitment to give back 2% equity options to programs and charities making a difference.  Giving back and making a positive difference through the community commerce system is just the start with Entrepreneurs.org</p>

								<p>We are funded through a generous donation from Global Ventures along with 2% of the equity in Ventures created on the Contrib.com platform. If you have resources, connections or assets that could add value to other entrepreneurs, would be great to learn more.  We are working hard behind the scenes to build the ultimate entrepreneurial network system to revolutionize how business and entrepreneurs are created, operate and give back.</p>

								<p>Thanks for taking the time to check us out and stay tuned for more robust features, connections and resources being added monthly.  If you know any Entrepreneurs or friends who are exploring starting there own business or have a company, please help spread the word about Entrepreneurs.org. We’re a proud member of Global Ventures and the CONTRIB platform.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			
<? include_once 'footer.php';?>