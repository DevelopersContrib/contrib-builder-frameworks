<script type="text/javascript" charset="utf-8">
    $(document).ready(function(){
		$('.wrap-index2').css({'min-height': (($(window).height()))+'px'});
			$(window).resize(function(){
			$('.wrap-index2').css({'min-height': (($(window).height()))+'px'});
			});
		
		$('#email').click(function(){
			$(this).attr("placeholder","");
		});
		
	   var domain_name = $('#domain_name').val();
	
		getsocial(domain_name,'fb','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251686_facebook_circle_color.png');
		getsocial(domain_name,'twitter','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251704_twitter_circle_color.png');
		getsocial(domain_name,'gplus','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/gplus.png');
	
		
       $('#pagesubmit').hide();
       $('#pagesubmit').removeClass('hidden');
       $('#signupform').submit(function(){
			 
			var email = $('#email').val();
			var user_ip = $('#user_ip').val();
			var indexof = email.indexOf("@");
			var name = email.slice(0,indexof);
			var domain = $('#domain').val(); 
			
			
           if(email==''){
                alert('Email is Required.');
                $('#email').focus();
                return false;
            }else if(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test(email)==false){
                alert('Please enter a valid email address.');
                $('#email').focus();
                return false;
            }else{
		      
			
		   
			//DOMAINDI LEADS		
			jQuery.ajax({
                type: "post",url: "http://www.contrib.com/forms/saveleads",
                data: {'email':email, 'domain':domain,'user_ip':user_ip},
                success: function(res){
					console.log(res.success);
					$('#error_message_form').addClass('text-warning');
					$('#error_message_form').html("Processing, please wait..");
					console.log(res);
					  
					$("#loading").hide();
					
					if(res.success=='success'){
						$("#signupform").hide();	
						$('#response_wait').show();
						$("#pagesubmit").slideDown('normal');
						
						$('#pemail').val(email);
						$('#response').css('display','block');
						$('#error_message_form').hide();
					
					/*}else if(res.success=='false'){
						console.log("FALSE 1");
						$('#error_message_form').removeClass('text-warning');
						$('#error_message_form').addClass('text-danger');
						$('#error_message_form').html("An error occurred");
						
						$('#error_message_form').removeClass('text-warning');
						$('#error_message_form').addClass('text-danger');
						$('#error_message_form').html('<div class="span12 text-center" id="response">Something went wrong. Sorry for the inconvenience.</div>');
						$('#response').css('display','block');
						$('#response').html(res.success);
						$('#response').append('<div class="span12 text-center" id="response">Something went wrong. Sorry for the inconvenience.</div>');
					*/}else{
						
						//$('#response').css('display','block');
						//$('#response').html(res.success);
						console.log("FALSE 2");
						$('#error_message_form').removeClass('text-warning');
						$('#error_message_form').addClass('text-danger');
						$('#error_message_form').html(res.success+'<br><br>');
						
					}
                  
                }});	
								
				// SALESFORCE LEAD
				$.post("http://www.manage.vnoc.com/salesforce/addlead",
				{
					 'firstName':name,
					 'lastName':name,
					 'title':'',
					 'email':email,
					 'phone':'',
					 'street':'',
					 'city':'',
					 'country':'',
					 'state':'',
					 'zip':'',
					 'domain':domain,
					 'form_type':'Contrib Lead Template'
					 
				},function(data2){
						console.log(data2);
					}
				);
				
			
				return false;
			
			}
		
		return false;

       });

    });

	

function getsocial(domain_name,social,icon_src){
	
	$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
					var socialdata = data[0];
					if(socialdata.error == true){
						//do nothing
					}else if(socialdata.profile_url == ""){
						//do nothing
					}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
						//do nothing
					}else{
						$('#socials_container').append('&nbsp;<a href="'+socialdata.profile_url+'"><img src="'+icon_src+'" height="40px"></a>&nbsp;');
					}		
	});
}
	
</script>


</div>
		<div class="footer-v1">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="col-lg-4">
							
								&copy; <?php echo $domain?>
							
						</div>
						<div class="col-lg-8">
							<!-- Collect the nav links, forms, and other content for toggling -->
							<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
								<ul class="nav navbar-nav navbar-right">
									<li><a href="/fund">Fund our ventures</a></li>
									<li><a href="/developers">Developers</a></li>
									<li><a href="/terms">Terms</a></li>
									<li><a href="/privacy">Privacy</a></li>
								</ul>
							</div><!-- /.navbar-collapse -->
						</div>
					</div>
          	<div class="col-lg-12 text-center">
            <?php echo $footer_banner?>
            </div>
				</div>
			</div>
		</div>
	</div>
  

</body>
</html>