<? include_once 'header.php'; ?>
<style>
	.nav-pills.nav-pills-cust{
        background-color: #f8f8f8;
        border: 1px solid #e7e7e7;
        border-radius: 5px;
        padding: 5px 10px;
        margin-bottom: 5px;
    }
    .wrap-white-container{
        /* background-color: #fff;
        padding: 15px;
        color: #000; */
    }
</style>


<div class="row">
	<div class="col-lg-12">
		<div class="wrap-padtop-v1 clearfix">
			<div class="row">
				<div class="col-lg-10 col-lg-offset-1">
					<div class="form-group text-center">
					<script class="ctb-box" id='referral-script' src='https://www.referrals.com/extension/widget.js?key=356' type='text/javascript'></script>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<? include_once 'footer.php';?>