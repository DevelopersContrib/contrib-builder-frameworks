<? include 'header.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/masonry/3.3.1/masonry.pkgd.min.js"></script>
<script>
	jQuery(document).ready(function(){
		$ds = jQuery('ul.fadeDivUl li');
		$ds.hide().eq(0).show();
		setInterval(function(){
			$ds.filter(':visible').fadeOut(function(){
				var $div = jQuery(this).next('li');
				if ( $div.length == 0 ) {
					$ds.eq(0).fadeIn();
				} else {
					$div.fadeIn();
				}
			});
		}, 10000);
    });
</script>
	
		<div class="row">
				<div class="col-lg-12">
					<div class="wrap-padtop-v1 clearfix">
						<div class="row">
							<div class="col-lg-6">								
								<!-- tabs -->
								<div class="tabbable newtemptab">
									<ul class="nav nav-tabs">
										<li class="active"><a href="#one" data-toggle="tab"><i class="fa fa-cog"></i></a></li>
									</ul>
									<div class="tab-content">
										<div class="tab-pane active" id="one">
											<div class="exerpt-slide">
												<p>
													<?
													if(str_replace(' ','',$description)!='') echo '<div id="content"><p id="makea" style="color: whitesmoke;font-weight:600;">'.stripslashes($description).'</p>';
													?> 
												</p>
											</div>								
										</div>
									</div>
								</div>
								</div>
								<!-- /tabs -->
							</div>
							<div class="col-lg-6">
								<div class="arrw-rela"><div class="arrw-point-white"></div></div>
								<div class="modal-content form">
									<div class="modal-header">
										<h4 class="modal-title text-black text-center">
											Learn more about Joining our Partner Network.
										</h4>
									</div>
									<div class="modal-body">
										<div class="text-center" id="socials_container"></div>
										<div class="form-group">
											
											<form class="input-group" id="signupform" action="">
												<input type="text" id="email" class="input-lg form-control" placeholder="Your email...">
												<input type="text" id="secret" style="display:none;" value="">
												<input type="hidden" id="refid" value="0">
												<input type="hidden" id="domain" value="<?php echo $domain?>">
												<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
												<span class="input-group-btn">
													<button type="submit" class="btn btn-danger btn-lg">
														<i class="fa fa-edit"></i>
														Sign up now!
													</button>
												</span>
											</form><!-- /input-group -->
										</div>
										
								<div id="error_message_form">&nbsp;</div>
								  <div id="social" style="display:none">
											<table style="border:0px;width:100%;">
												<tr>
													<td valign='top' style='width:15%;'>
														<script src="http://platform.linkedin.com/in.js" type="text/javascript"></script>
														<script type="IN/Share" data-url="http://www.linked.com"></script>
													</td>
													<td valign='top' style='width:85%;'>

														<!-- AddThis Button BEGIN -->
														<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
														<a class="addthis_button_preferred_1"></a>
														<a class="addthis_button_preferred_2"></a>
														<a class="addthis_button_preferred_3"></a>
														<a class="addthis_button_preferred_4"></a>
														<a class="addthis_button_compact"></a>
														<a class="addthis_counter addthis_bubble_style"></a>
														</div>
														<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
														<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>
														<!-- AddThis Button END -->
													</td>    
												</tr>
											</table>
										  </div>
											<div class="pages hidden" id="pagesubmit">
												<div id="response_wait"><div class="span12" style="width:100%;text-align:center;margin:20px 0 35px 0;color:white;min-height:20px;font-size:18px;" id="loading">Processing . . . Please wait . . .</div></div>
												 <div class="row-fluid" id="response" style="color: rgb(12, 179, 32);display:none">																		
													<div class="span12 text-center"><h3>Thanks, your spot is reserved!</h3> Share <?php echo ucfirst($domain)?> with you friends to move up in line and reserve your username.
															<br><br>
															<?if($additional_html != ""):?>
																<?echo base64_decode($additional_html)?>
															<?endif;?>
															
																<form target="_blank" action="http://www.contrib.com/signup/follow/<?php echo ucfirst($domain)?>" method="post">
																<input type="hidden" id="pemail" name="email" value=""/>
															<button class="btn btn-warning">Continue to Follow <?php echo ucfirst($domain)?> Brand</button></form>
													</div>
												 </div><!-- response -->
												<div id="description" style="display:none;">
													<h3 id="header_text"></h3>
													<p id="paragraph_text"></p>
													<p style="color:#000">To share with your friends, click &ldquo;Share&rdquo; and &ldquo;Tweet&rdquo;:</p>
													<a href="http://twitter.com/share" class="twitter-share-button" data-count="none">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
													<br><br>
													<p> <iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.socialholdings.com%2F&amp;layout=standard&amp;show_faces=true&amp;width=450&amp;action=like&amp;font&amp;colorscheme=light&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>
													</p>
													<div id="sharebuttons"><span id="facebook" style="margin:0 0 10px 60px"></span><span id="twitter"></span></div>
												</div>
												<!--<p class="clear" style="text-align: left;">Or copy and paste the following link to share wherever you want!</p>
															<input id="shareurl" type="text" value="" />
													-->
												 <!-- <a class="cs_import">Email To Friends</a>-->

											</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>			
</div>
</div>




 <?php if (count($topsites)>0):?>
 <style>
	.section-3-carousel{
		background-color: #fbfbfb;
		padding: 60px 0 100px;
	}
	.sectionnew-2{
		padding: 80px 0px 90px;
		background-color: #EFF1F4;
	}
	.contribox {
		font-size: 16px;
		color: #333;
	}
	.contribox img {
		height: 85px;
		margin: 0 auto 10px;
	}	
	h3.iconbox_content_title {
		font-size: 20px;
		font-weight: 600;
		text-transform: uppercase;
		color: #333;
		margin-top: 0px;
	}
	/* h3#enter::before {
		content: url("http://domaindirectory.com/template/entrepreneurs/businessman-m.png");
		vertical-align: -10px;
	}
	h3#dev::before {
		content: url("http://domaindirectory.com/template/entrepreneurs/monitor-m.png");
		vertical-align: -10px;
	}
	h3#des::before {
		content: url("http://domaindirectory.com/template/entrepreneurs/paint-bucket-m.png");
		vertical-align: -10px;
	}
	h3#adv::before {
		content: url("http://domaindirectory.com/template/entrepreneurs/conference-m.png");
		vertical-align: -10px;
	} */

	.wrap-contribute-container{
		background-color: #fcfcfc;
		box-shadow: 0 2px 2px 0 rgba(0,0,0,.1),0 4px 10px 0 rgba(0,0,0,.1);
		margin:40px 0 15px;
		padding: 20px 30px;
		color: #808080;
	}	
</style>
<div class="sectionnew-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="row">
					<div class="col-md-3">
						<div class="contribox">
							<img class="img-responsive" src="https://d1p6j71028fbjm.cloudfront.net/icons/icon-entrepreneurs-2.png" alt="Entrepreneurs">
							<h3 id="enter" class="iconbox_content_title">
							Entrepreneurs</h3>
							<p>New entrepreneurs and experienced need a common ground to share their skills, resources and time.
							</p>
						</div>
					</div>
					<div class="col-md-3">
						<div class="contribox">
							<img class="img-responsive" src="https://d1p6j71028fbjm.cloudfront.net/icons/icon-developers-2.png" alt="Developers">
							<h3 id="dev" class="iconbox_content_title">
								Developers
							</h3>
							<p>
								Entrepreneurs need the help of technical people to be able to build valuable apps and websites in the www.
							</p>
						</div>
					</div>
					<div class="col-md-3">
						<div class="contribox">
							<img class="img-responsive" src="https://d1p6j71028fbjm.cloudfront.net/icons/icon-designers.png" alt="Designers">
							<h3 id="dev" class="iconbox_content_title">
								Designers
							</h3>
							<p>
								If you're a designer and need to get your services out there, then we can match you with entrepreneurs that are in need of your services. 						
							</p>
						</div>
					</div>
					<div class="col-md-3">
						<div class="contribox">
							<img class="img-responsive" src="https://d1p6j71028fbjm.cloudfront.net/icons/icon-advisors.png" alt="Advisors">
							<h3 id="des" class="iconbox_content_title">
								Advisors
							</h3>
							<p>
								Join as an advisor or mentor to new entrepreneurs and get more contacts for your business.
							</p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-12 hide">
				<div class="wrap-contribute-container">
					<a href="" class="pull-right btn btn-success">
						Learn More
					</a>
					<p>
						Contribute your skills, services, apps or capital, part-time. Help a team of other passionate people doing amazing things. Become an entrepreneur or work with other entrepreneurs. Amazing members, advisors, and investors.
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="section-3-carousel">
	<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 class="brdr-lead">Our Top Brands</h1>
					</div>
					<div class="col-md-12">
						<div class="owl-carousel">
						    <?php foreach ($topsites as $key=>$val):?>
								<div class="wrap-marketplace-box-item">
									<a href="http://<?php echo $val['domain_name']?>" target="_blank" class="wmbi-img-logo">
										<img src="<?php echo $val['logo']?>" alt="<?php echo $val['domain_name']?>" title="<?php echo $val['domain_name']; ?>" class="img-responsive">
									</a>
									<h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
										<?php echo $val['domain_name']?>                        
									</h3>
									<p class="p-marg-btm">
		                                <?php echo stripcslashes($val['description'])?>
		                            </p>
		                            <p>
		                                <a href="http://<?php echo $val['domain_name']?>" target="_blank"><?php echo $val['domain_name']?></a>
		                            </p>
		                            <ul class="list-inline ul-wmbi-zero">
		                                <li>
		                                    <a href="http://<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Visit</a>
		                                </li>
		                                <li>
		                                    <a href="https://contrib.com/brand/details/<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Details</a>
		                                </li>
		                            </ul>
								</div>
							<?php endforeach;?>
						</div>
					</div>
				</div>
	</div>
</div>
<script>
			$(document).ready(function(){
				$('.owl-carousel').owlCarousel({
					slideSpeed: 300,
					paginationSpeed: 400,
					items: 3,
					autoHeight:true,
					nav:true,
					onInitialized: setOwlStageHeight,
					onResized: setOwlStageHeight,
					onTranslated: setOwlStageHeight
				})
				function setOwlStageHeight(event) {
				    var maxHeight = 0;
				    $('.owl-item.active').each(function () { // LOOP THROUGH ACTIVE ITEMS
				        var thisHeight = parseInt( $(this).height() );
				        maxHeight=(maxHeight>=thisHeight?maxHeight:thisHeight);
				    });
				    $('.owl-carousel').css('height', maxHeight );
				    $('.owl-stage-outer').css('height', maxHeight ); // CORRECT DRAG-AREA SO BUTTONS ARE CLICKABLE
				};
			});
</script>  	
<?php endif?>		
		
<div class="wrap-referralprogram-container">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<div class="condis">
							<script src="http://tools.contrib.com/cwidget?d=<?echo $domain?>&p=ur&c=lc"></script>
						</div>
						
					</div>
					<div class="col-md-6">
						<div class="condis">
							<script type="text/javascript" src="http://tools.contrib.com/cwidget/forum?f=all&l=10"></script>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 text-center lead-ttle-top">
				<h1 class="brdr-lead">
					Referral Programs
				</h1>
			</div>
		</div>
		<div class="row ">
			<div class="col-md-12">
				<ul class="list-inline text-center fadeDivUl">
					<?php if (count($programs)>0):?>
				        <?php foreach ($programs as $key=>$val):?>
							<li>
								<div class="wrap-rp-bx-container">
									<?php echo $val['code']?>
								</div>
							</li>
						<?php endforeach;?>
					<?php endif?>	
				</ul>
			</div>
		</div>
	</div>
</div>


<div class="container-index-wrap">
<div>

<? include_once 'footer.php';?>

<script>

  $(document).ready(function() {

   var docHeight = $(window).height();
   var footerHeight = $('.footer-v1').height();
   var footerTop = $('.footer-v1').position().top + footerHeight;

   if (footerTop < docHeight) {
    $('.footer-v1').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>