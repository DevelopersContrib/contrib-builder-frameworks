<? include 'header.php'; ?>
	
		<div class="row">
				<div class="col-lg-12">
					<div class="wrap-padtop-v1 clearfix">
						<div class="row">
							<div class="col-lg-6">								
								<!-- tabs -->
								<div class="tabbable newtemptab">
								  <ul class="nav nav-tabs">
									<li class="active"><a href="#one" data-toggle="tab"><i class="fa fa-cog"></i></a></li>
									<li><a href="#two" data-toggle="tab"><i class="fa fa-bar-chart"></i>&nbsp;Latest Contribution</a></li>
									<li><a href="#twee" data-toggle="tab"><i class="fa fa-comments"></i>&nbsp;Discussions</a></li>
								  </ul>
								  <div class="tab-content">
									<div class="tab-pane active" id="one">
										<div class="exerpt-slide">
											<p>
												<?
													if(str_replace(' ','',$description)!='') echo '<div id="content"><p id="makea" style="color: whitesmoke;text-shadow: 1px 1px 5px black;">'.stripslashes($description).'</p>';
												?> 
											</p>
											</div>								
										</div>
									</div>
									<div class="tab-pane" id="two">
										<div class="condis">
										<script src="http://tools.contrib.com/cwidget?d=<?echo $domain?>&p=ur&c=lc"></script>
										</div>
									</div>
									<div class="tab-pane" id="twee">
										<div class="condis">
										<script type="text/javascript" src="http://tools.contrib.com/cwidget/forum?f=all&l=10"></script>
										</div>
									</div>
								   </div>
								</div>
								<!-- /tabs -->
							</div>
							<div class="col-lg-6">
								<div class="arrw-rela"><div class="arrw-point-white"></div></div>
								<div class="modal-content form">
									<div class="modal-header">
										<h4 class="modal-title text-black">
											Learn more about Joining our Partner Network.
										</h4>
									</div>
									<div class="modal-body">
										<div class="text-center" id="socials_container"></div>
										<div class="form-group">
											
											<form class="input-group" id="signupform" action="">
												<input type="text" id="email" class="input-lg form-control" placeholder="Your email...">
												<input type="hidden" id="refid" value="0">
												<input type="hidden" id="domain" value="<?php echo $domain?>">
												<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
												<span class="input-group-btn">
													<button type="submit" class="btn btn-danger btn-lg">
														<i class="fa fa-edit"></i>
														Sign up now!
													</button>
												</span>
											</form><!-- /input-group -->
											
										</div>
										
										
													<div id="error_message_form">&nbsp;</div>
													  <div id="social">
																<table style="border:0px;width:100%;">
																	<tr>
																		<td valign='top' style='width:15%;'>
																			<script src="http://platform.linkedin.com/in.js" type="text/javascript"></script>
																			<script type="IN/Share" data-url="http://www.linked.com"></script>
																		</td>
																		<td valign='top' style='width:85%;'>

																			<!-- AddThis Button BEGIN -->
																			<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
																			<a class="addthis_button_preferred_1"></a>
																			<a class="addthis_button_preferred_2"></a>
																			<a class="addthis_button_preferred_3"></a>
																			<a class="addthis_button_preferred_4"></a>
																			<a class="addthis_button_compact"></a>
																			<a class="addthis_counter addthis_bubble_style"></a>
																			</div>
																			<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
																			<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>
																			<!-- AddThis Button END -->
																		</td>    
																	</tr>
																</table>
															  </div>
																<div class="pages hidden" id="pagesubmit">
																
																	
																	<div id="response_wait"><div class="span12" style="width:100%;text-align:center;margin:20px 0 35px 0;color:white;min-height:20px;font-size:18px;" id="loading">Processing . . . Please wait . . .</div></div>
																	 <div class="row-fluid" id="response" style="color: rgb(12, 179, 32);display:none">
																		
																		<div class="span12 text-center"><h3>Thanks, your spot is reserved!</h3> Share <?php echo ucfirst($domain)?> with you friends to move up in line and reserve your username.
																				<br><br>
																				<?if($additional_html != ""):?>
																					<?echo base64_decode($additional_html)?>
																				<?endif;?>
																				
																					<form target="_blank" action="http://www.contrib.com/signup/follow/<?php echo ucfirst($domain)?>" method="post">
																					<input type="hidden" id="pemail" name="email" value=""/>
																				<button class="btn btn-warning">Continue to Follow <?php echo ucfirst($domain)?> Brand</button></form>
																		</div>
																		
																	 
																	 </div><!-- response -->
				
				
				
																					<div id="description">
																						<h3 id="header_text"></h3>
																						<p id="paragraph_text"></p>
																						<p style="color:#000">To share with your friends, click &ldquo;Share&rdquo; and &ldquo;Tweet&rdquo;:</p>
																						<a href="http://twitter.com/share" class="twitter-share-button" data-count="none">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
																						<br><br>
																						<p> <iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.socialholdings.com%2F&amp;layout=standard&amp;show_faces=true&amp;width=450&amp;action=like&amp;font&amp;colorscheme=light&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>
																						</p>
																						<div id="sharebuttons"><span id="facebook" style="margin:0 0 10px 60px"></span><span id="twitter"></span></div>
																					</div>
																					<!--<p class="clear" style="text-align: left;">Or copy and paste the following link to share wherever you want!</p>
																								<input id="shareurl" type="text" value="" />
																						-->
																					 <!-- <a class="cs_import">Email To Friends</a>-->

																				</div>
																												
										
										
										
									</div>
									<div class="modal-footer">
										<div class="text-left form-group">
											<a href="/privacy">Privacy Policy</a> 
											<span class="text-black">
												|
											</span> 
											<a href="/terms">Terms and Condition</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!-- verticals -->
			<?php if (count($related_domains)>0):?>
			<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
			<div class="row verb">
			  <div class="col-md-8 col-md-offset-2">
				<h2><i class="fa fa-globe"></i>&nbsp; Other Brands On <?php echo $vertical?> Vertical</h2>
					<div class="vertical-list">
					  <ul class="list-unstyled">
					  <?php foreach ($related_domains as $key=>$val):?>
						<li class="col-md-4 odd"><a href="http://<?php echo $val['domain_name']?>"><i class="fa fa-arrow-right"></i>&nbsp;<?php echo ucfirst($val['domain_name'])?></a></li>
					 <?php endforeach;?>	
					  </ul>
					  <div class="clearfix"></div>
					</div>
					<div class="col-md-12" style="text-align:center;"><a href="http://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" target="_blank" class="btn btn-success">View More</a></div>
			  </div>
			</div>
			<?php endif;?>
			
	
<? include_once 'footer.php';?>

<script>

  $(document).ready(function() {

   var docHeight = $(window).height();
   var footerHeight = $('.footer-v1').height();
   var footerTop = $('.footer-v1').position().top + footerHeight;

   if (footerTop < docHeight) {
    $('.footer-v1').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>