$(document).ready(function(){
	var time = $('#dotime').val();
	$('#btn-signup-'+time).click(function(){
		sregister();
	});
	
	 $('#reg_phone').mask("(999) 999-9999");
});

function sregister(){
	$('#reg_error').hide();
	var name = $('#reg_name').val();
	var email = $('#reg_email').val();
	var password = $('#reg_password').val();
	var password2 = $('#reg_cpassword').val();
	var keyword = $('#s_keyword').val();
	var zipcode = $('#s_zip').val();
	var city = $('#s_city').val();
	var state = $('#s_state').val();
	var category = $('#s_category').val();
	var domain = $('#reg_domain').val();
	var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var base_url = $('#base_url').val();
	var user_ip = $('#user_ip').val();
	var phone = $('#reg_phone').val();
	
	
	if (name == ""){
		$('#reg_error').fadeIn();
		$('#reg_error').html('<strong>Please enter your name</strong>');
		$('#reg_name').focus();
	}else if (email == ""){
		$('#reg_error').fadeIn();
		$('#reg_error').html('<strong>Please enter your email</strong>');
		$('#reg_email').focus();
	}else if(!emailfilter.test(email)){
		$('#reg_error').fadeIn();
		$('#reg_error').html('<strong>Invalid email address</strong>');
		$('#reg_email').focus();
	}else if (phone == ""){
		$('#reg_error').fadeIn();
		$('#reg_error').html('<strong>Please enter your 10 digit phone number</strong>');
		$('#reg_phone').focus();
	}else if (password == ""){
		$('#reg_error').fadeIn();
		$('#reg_error').html('<strong>Please enter your password</strong>');
		$('#reg_password').focus();
	}else if (password2 == ""){
		$('#reg_error').fadeIn();
		$('#reg_error').html('<strong>Please confirm password</strong>');
		$('#reg_cpassword').focus();
	}else if (password != password2){
		$('#reg_error').fadeIn();
		$('#reg_error').html('<strong>Password mismatch</strong>');
		$('#reg_cpassword').focus();
	}else {
		$.post('http://api1.contrib.co/search/signup',
				 {
				    'keyword':keyword,
				    'category':category,
				    'city':city,
				    'zipcode':zipcode,
				    'state':state,
				    'category':category,
				    'name':name,
				    'email':email,
				    'password':password,
				    'domain':domain,
				    'user_ip':user_ip,
				    'phone':phone
				    
				 }
				 ,function(data){
					 if (data.data.status){
						  window.location.href = base_url+'signin/autologin/?code='+data.data.member_id+'&group='+data.data.group_id;
					 }else {
						 $('#reg_error').fadeIn();
						 $('#reg_error').html('<strong>'+data.data.message+'</strong>');
						 $('#reg_cpassword').focus();
					 }
				 }
		   );
		
	}
	
}