$(document).ready(function(){

	var time = $('#dotime').val();
	$('#btn-search-'+time).click(function(){
		submitsearch();
	});
	
	$('#proj_city').keyup(function(){
		$('#tss').css('display','none');
		$('#proj_city').autocomplete({
			search  : function(){$(this).addClass('working');},
			open    : function(){$(this).removeClass('working');},
			source: 'http://handyman.com/projectnew/searchcity',
			minLength: 2,
			select: function (event, ui) {   
				var selectedObj = ui.item;   
				var city = selectedObj.value;
				$('#proj_city').text(city);
				$(this).removeClass('working');
			}
		});
	});

});

function submitsearch(){
	$('#m-error').hide();
	var keyword = "";
	var category = $('#proj_cat').val();
	if (category != ""){
	 	keyword = $("#proj_cat option:selected").text();
	}
	
	var city = $('#proj_city').val();
	var zipcode = $('#proj_zip').val();
	var state = $('#proj_state').val();
	var base_url = $('#base_url').val();
	
	
	if (zipcode == ""){
		$('#m-error').show();
		$('#m-error').html('Zipcode is required');
		$('#proj_zip').focus();
	}else {
		$.post(base_url+"search/prepost",
				 {
				    'keyword':keyword,
				    'category':category,
				    'city':city,
				    'zipcode':zipcode,
				    'state':state
				 }
				 ,function(data){
					 window.location.href = base_url+'signup';
				 }
		   );
	}
	
	
	
}