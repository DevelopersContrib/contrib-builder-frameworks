$(document).ready(function(){
	var time = $('#dotime').val();
	$('#btn-signin-'+time).click(function(){
		signinuser();
	});
	
	$('#sign_password').keypress(function(e){
		if(e.keyCode==13){
			signinuser();
		}
	});
	
	$('#btn-forget-password-'+time).click(function(){
		showforgotmodal();
	});
	
	$('#btn-send-password-'+time).click(function(){
		sendpassword();
	});
	
});


function showforgotmodal(){
	$('#forgotModal').modal('show');
	$('#forgot_email').val('');
	$('#m-error').hide();
	$('#m-success').hide();
}

function sendpassword(){
	$('#m-error').hide();
	$('#m-success').hide();
	
	var email = $('#forgot_email').val();
	var domain = $('#forgot_domain').val();
	var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	
	if (email == ""){
		$('#m-error').fadeIn();
		$('#m-error').html('Please enter your email');
		$('#forgot_email').focus();
	}else if(!emailfilter.test(email)){
		$('#m-error').fadeIn();
		$('#m-error').html('<strong>Invalid Email Address</strong>');
		$('#forgot_email').focus();
	}else {
		$.post('http://api1.contrib.co/search/sendpassword',
				 {
				    'email':email,
				    'domain':domain
				    
				 }
				 ,function(data){
					 if (data.data.status){
						 $('#m-success').fadeIn();
						 $('#m-success').html('The password has been successfully sent to your email.');
					 }else {
						 $('#m-error').fadeIn();
					 	 $('#m-error').html(data.data.message);
						 $('#forgot_email').focus();
					 }
				 }
		   );
	}
}

function signinuser(){
	var email = $('#sign_email').val();
	var password = $('#sign_password').val();
	var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var domain = $('#sign_domain').val();
	var base_url = $('#base_url').val();
	
	if (email == ""){
		$('#signin_error').fadeIn();
		$('#signin_error').html('<strong>Please enter your email</strong>');
		$('#sign_email').focus();
	}else if(!emailfilter.test(email)){
		$('#signin_error').fadeIn();
		$('#signin_error').html('<strong>Invalid Email Address</strong>');
		$('#sign_email').focus();
	}else if (password == ""){
		$('#signin_error').fadeIn();
		$('#signin_error').html('<strong>Please enter your password</strong>');
		$('#sign_password').focus();
	}else {
		$.post('http://api1.contrib.co/search/signin',
				 {
				    'email':email,
				    'password':password,
				    'domain':domain
				    
				 }
				 ,function(data){
					 if (data.data.status){
						 window.location.href = base_url+'signin/autologin/?code='+data.data.member_id+'&group='+data.data.group_id;
					 }else {
						 $('#signin_error').fadeIn();
						 $('#signin_error').html('<strong>'+data.data.message+'</strong>');
					 }
				 }
		   );
	}
}