$(document).ready(function(){
	var time = $('#dotime').val();
	$('#btn-settings-update'+time).click(function(){
		updatesettings();
	});
	
	$('#btn-password-update'+time).click(function(){
		updatepassword();
	});
	
	 $('#set_phone').mask("(999) 999-9999");
});


function updatepassword(){
	$('#m-success').hide();
	$('#m-error').hide();
	 
	var password = $('#set_password').val();
	var password2 = $('#set_password2').val();
	var member_id = $('#set_member').val();
	
	if (password == "" ){
		$('#m-error').fadeIn();
		$('#m-error').html('<span>Please enter your password</span>');
		$('#set_password').focus();
	}else if (password2 == ""){
		$('#m-error').fadeIn();
		$('#m-error').html('<span>Please confirm password</span>');
		$('#set_password2').focus();
	}else if (password != password2){
		$('#m-error').fadeIn();
		$('#m-error').html('<span>Password mismatch</span>');
		$('#set_password2').focus();
	}else {
		$.post('http://api1.contrib.co/search/updatepassword',
				 {
				    'password':password,
				    'member_id':member_id
				    
				 }
				 ,function(data){
					 if (data.data.status){
						 $('#m-success').fadeIn();
						 $('#m-success').html('<span>You successfully updated password.</span>');
					 }else {
						 $('#m-error').fadeIn();
						 $('#m-error').html('<span>Something went wrong while updating password.</span>');
					 }
					 setTimeout(function(){ $('#m-error').hide(); $('#m-success').hide(); }, 5000);
				 }
		   );
		
	}
}

function updatesettings(){
	 $('#m-success').hide();
	 $('#m-error').hide();
	 
	var name = $('#set_name').val();
	var phone = $('#set_phone').val();
	var member_id = $('#set_member').val();
	var base_url = $('#base_url').val();
	
	if (name == ""){
		$('#m-error').fadeIn();
		$('#m-error').html('<span>Please enter your name</span>');
		$('#set_name').focus();
	}else if (phone == ""){
		$('#m-error').fadeIn();
		$('#m-error').html('<span>Please enter your phone number</span>');
		$('#set_phone').focus();
	}else {
		$.post('http://api1.contrib.co/search/updatesettings',
				 {
				    'name':name,
				    'phone':phone,
				    'member_id':member_id
				    
				 }
				 ,function(data){
					 if (data.data.status){
						 $.post(base_url+'settings/updatesession',
								 {
							 		'name':name,
							 		'phone':phone,
								    
								 }
								 ,function(data){
									 $('#m-success').fadeIn();
									 $('#m-success').html('<span>You successfully updated settings.</span>');
								 }
						   );
						 
						
						 
					 }else {
						 $('#m-error').fadeIn();
						 $('#m-error').html('<span>Something went wrong while updating settings.</span>');
					 }
					 setTimeout(function(){ $('#m-error').hide(); $('#m-success').hide(); }, 5000);
				 }
		   );
	}
}