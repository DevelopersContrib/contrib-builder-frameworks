<?php

class Leads extends Controller {

	function showlist(){
	 	$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();

		$search = $_POST['search'];
		$status_id = $_POST['status'];
		$current_page = $_POST['current_page'];
		
		$limit = 12;
		
		if($current_page) 
		 $start = ($current_page - 1) * $limit; 			//first item to display on this page
	    else
		 $start = 0;
		 
		 
		$status = array(1=>'New',2=>'Not available',3=>'Too Far',4=>'Contacted',5=>'Assigned to Project');
		$member_id = $session->get('member_id');
		$template = $this->loadView('leads_list');
		$template->set('info', $info);
		$template->set('search', $search);
		$template->set('status', $status_id);
		$template->set('leads', $api->getleads($member_id,$search,$start,$limit,$status_id));
		
		$template->render();
	}
	
	function showpagination(){
		
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		
		$search = $_POST['search'];
		$status = $_POST['status'];
		if ($status != ""){
			$status = intval($status);
		}
		
		$page = $_POST['current_page'];
		$total_pages = intval($_POST['total_results']);
		$limit = 12;
	    if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//previous page is page - 1
		$next = $page + 1;							//next page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
		$lpm1 = $lastpage - 1;	;
		
		$template = $this->loadView('leads_pagination');
		$template->set('info', $info);
		$template->set('lastpage', $lastpage);
		$template->set('page', $page);
		$template->set('adjacents', 3);
		$template->set('lpm1', $lpm1);
		$template->set('prev', $prev);
		$template->set('next', $next);
		$template->set('search', $search);
		$template->set('status', $status);
		$template->render();
		
		
	}

	
	function showcount(){
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		
		$search = $_POST['search'];
		$status_id = $_POST['status'];
		$member_id = $session->get('member_id');
		echo $api->getleadscount($member_id,$search,$status_id);
	}



}