<?php

class Postproject extends Controller {



	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$zip = 0;
		$projecttype_id = 0;
		$projecttypes = $api->getprojecttypes();
		$template = $this->loadView('handyman/postprojectnew2');
		$template->set('projecttypes',$projecttypes);
		$template->set('zip',$zip);
		$template->set('projecttype_id',$projecttype_id);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function find(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$session = $this->loadHelper('Session_helper');
		$zip =  $helper->segment(3);
		$projecttype_id = $helper->segment(4);
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$template = $this->loadView('handyman/postprojectnew3');
		$template->set('projecttypes',$projecttypes);
		$template->set('zip',$session->get('zipcode'));
		$template->set('projecttype_id',$session->get('category'));
		$template->set('keyword',$session->get('keyword'));
		$template->set('city',$session->get('city'));
		$template->set('state',$session->get('state'));
		$template->set('info', $info);
		$template->set('questions', $api->getquestions());
		$template->render();
	
	}
  
	
	function prepost(){
		  $session = $this->loadHelper('Session_helper');
		   $keyword = $_POST['keyword'];
		   $category = $_POST['category'];
		   $city = $_POST['city'];
		   $zipcode = $_POST['zipcode'];
		   $state = intval($_POST['state']);
		   
		   $session->set('keyword', $keyword);
		   $session->set('category', $category);
		   $session->set('city', $city);
		   $session->set('zipcode', $zipcode);
		   $session->set('state', $state);
		   
		   
	}
	
	function addproject(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$input = $this->loadHelper('Input_helper');
		$session = $this->loadHelper('Session_helper');
	
		$projecttype = $input->post('projecttype');
		$proj_desc = $input->post('projectdesc');
		$idealstartdate = $input->post('projectstart');
		$projectstats = $input->post('projectstatus');
		$timeframe = $input->post('projecttimeframe');
		$address = $input->post('projectaddress');
		$state = $input->post('state_name');
		$city = $input->post('city');
		$zipcode = $input->post('zip_code');
		$budget = $input->post('projectbudget');
		$homeown_fname = $input->post('homeown_fname');
		$homeown_lname = $input->post('homeown_lname');
		$homeown_number = $input->post('homeown_number');
		$homeown_uname = $input->post('homeown_uname');
		$homeown_email = $input->post('homeown_email');
		$owned = $input->post('owned');
		$val = intval($owned);
		$code = base64_encode($homeown_email);
		
		
		
		
		$email = $api->checkexist('email',$homeown_email);
		$username = $api->checkexist('username',$homeown_uname);
		
		//var_dump($info['data']['exists']);
		//echo $info['data']['exists'];
		if($email['data']['exists'] == TRUE){
			$response['exist'] = "Email already exists";
			
			
		}else if($username['data']['exists'] == TRUE){
			$response['exist'] = "Username already exists";
			
		}else{
		
		  
			
			
			$info = array
				 ('email'=>$homeown_email,
				  'username'=>$homeown_uname,
				  'firstname'=>$homeown_fname,
				  'lastname'=>$homeown_lname,
				  'phone_number'=>$homeown_number,
				  'projecttype'=>$projecttype,
				  'projectdesc'=>$proj_desc,
				  'projectstart'=>$idealstartdate,
				  'projectstatus'=>$projectstats,
				  'projecttimeframe'=>$timeframe,
				  'won_pro'=>$val,
				  'projectaddress'=>$address,
				  'projectstate'=>$state,
				  'city'=>$city,
				  'zip_code'=>$zipcode,
				  'projectbudget'=>$budget,
				 );
			$save_project = $api->saveproject($info);
			$project_id = 0;
			if (isset($save_project['data']['proj_id'])){
				$project_id = $save_project['data']['proj_id'];
			}
		
			
			$session->set('keyword', '');
		   	$session->set('category', '');
		   	$session->set('city', '');
		   	$session->set('zipcode', '');
		   	$session->set('state', '');
			
			$response['emailencode'] =  base64_encode($homeown_email);
			$response['success'] = "success";
			$response['proj_id'] = $project_id;
			$response['proj'] = $save_project;
			
			
		}
		
		 echo json_encode($response);
		
		
		
		
	
	}


}