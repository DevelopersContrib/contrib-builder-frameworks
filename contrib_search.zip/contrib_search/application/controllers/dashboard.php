<?php

class Dashboard extends Controller {

	function index(){
	    $session = $this->loadHelper('Session_helper');
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$relatedsiteswithlogo = $api->relatedsiteswithlogo();
		$relatedsitesnologo = $api->relatedsitesnologo();
		
		if ($session->get('logged_in')===TRUE){
			$template = $this->loadView('dashboard');
			$template->set('projecttypes',$projecttypes);
			$template->set('info', $info);
			$template->set('logged_in',$session->get('logged_in'));
			$template->set('email',$session->get('email'));
			$template->set('user_name',$session->get('user_name'));
			$template->set('info', $info);
			$template->set('related_domains', $relatedsitesnologo);
			$template->set('searches',  $api->getsearches($session->get('member_id')));
			$template->set('total_results',  $api->getleadscount($session->get('member_id')));
			$template->set('time', time());
			$status = array(1=>'New',2=>'Not available',3=>'Too Far',4=>'Contacted',5=>'Assigned to Project');
			$template->set('status', $status);
			$template->render();
		}else {
			header('Location: '.BASE_URL);
			exit;
		}
	}




}