<?php

class Settings extends Controller {

	function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}
	
   function index(){
   		$headers = array('Accept: application/json');
	    $session = $this->loadHelper('Session_helper');
		$helper = $this->loadHelper('Url_helper');
		$api = $this->loadModel('ApiModel');
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$relatedsiteswithlogo = $api->relatedsiteswithlogo();
		$relatedsitesnologo = $api->relatedsitesnologo();
		
		if ($session->get('logged_in')===TRUE){
		$member_id = $session->get('member_id');
		
		$url = 'http://api1.contrib.co/search/Getuserinfo?field=member_id&value='.$member_id;
		$result = createApiCall($url, 'GET', $headers, array());
		$info_result = json_decode($result,true);
		$user = array();  
		if ($info_result['success']){
			$user = $info_result['data'];
		}else {
			$user = array();
		}	
		
			$template = $this->loadView('settings');
			$template->set('info', $info);
			$template->set('logged_in',$session->get('logged_in'));
			$template->set('email',$session->get('email'));
			$template->set('user_name',$session->get('user_name'));
			$template->set('info', $info);
			$template->set('time', time());
			$template->set('user', $user);
			$template->render();
		}else {
			header('Location: '.BASE_URL);
			exit;
		}
	}
	
	function updatesession(){
		$session = $this->loadHelper('Session_helper');
		$name = $_POST['name'];
		$phone = $_POST['phone'];
		$member_id = $session->get('member_id');
		$session->set('user_name', $name);
		$session->set('phone_number', $phone);
	}
	



}