<?php

class Search extends Controller {
	function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
       // curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}
	  function prepost(){
		  $session = $this->loadHelper('Session_helper');
		   $keyword = $_POST['keyword'];
		   $category = $_POST['category'];
		   $city = $_POST['city'];
		   $zipcode = $_POST['zipcode'];
		   $state = intval($_POST['state']);
		   $session->set('keyword', $keyword);
		   $session->set('category', $category);
		   $session->set('city', $city);
		   $session->set('zipcode', $zipcode);
		   $session->set('state', $state);
	   }
	   
	   function index(){
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$projecttypes = $api->getprojecttypes();
		$info = $api->getdomaininfo();
		if ($session->get('logged_in')===TRUE){
			$template = $this->loadView('search');
			$template->set('logged_in',$session->get('logged_in'));
			$template->set('email',$session->get('email'));
			$template->set('user_name',$session->get('user_name'));
			$template->set('info', $info);
			$phone = $session->get('phone_number');
			$phone = preg_replace("/\(/","",$phone);
			$phone = preg_replace("/\)/","",$phone);
			$phone = preg_replace("/-/","",$phone);
			$phone = preg_replace('/\s+/', '', $phone);
			$template->set('phone',$phone);
			
			$template->set('categories',$projecttypes);
			$states = $api->getstates();
			$template->set('states',$states);
			
			
			$template->set('category_id','');
			$template->set('city','');
			$template->set('state','');
			$template->set('zipcode','');
			$template->set('keyword','');
			
			$template->render();
		}else {
			header('Location: '.BASE_URL);
			exit;
		}
	 }
	 
function result(){
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$group_name = $helper->segment(3);
		
		if(empty($group_name)){
			header("Location: /search/");
			die();
		}
		
		$template = $this->loadView('search');
		if ($session->get('logged_in')===TRUE){
			$url="http://api1.contrib.co/search/getsoleocategories/";

			$categories = $this->createApiCall($url, 'GET', array('Accept: application/json'), array());
			$categories = json_decode($categories);
			$categories = $categories->data;
			
			$group_name = explode("-",$group_name);
			$group_id = $group_name[0];
			
			$url="http://api1.contrib.co/search/groupinfo/?field=group_id&value=$group_id";
			$groupinfo = $this->createApiCall($url, 'GET', array('Accept: application/json'), array());
			$groupinfo = json_decode($groupinfo);

			$template = $this->loadView('search');
			$states = $api->getstates();
			
			$state = '';
			foreach($states as $s){
				if($groupinfo->data->state==$s['id']){
					$state = $s['abbreviation'];
					
					break;
				}
			}
			
			$phone = $session->get('phone_number');
			$phone = preg_replace("/\(/","",$phone);
			$phone = preg_replace("/\)/","",$phone);
			$phone = preg_replace("/-/","",$phone);
			$phone = preg_replace('/\s+/', '', $phone);
			$template->set('phone',$phone);
			
			$template->set('categories',$categories);
			$template->set('states',$states);
		
			$template->set('logged_in',$session->get('logged_in'));
			$template->set('email',$session->get('email'));
			$template->set('user_name',$session->get('user_name'));

			$template->set('info', $info);
			$category_id = $groupinfo->data->category_id;
			$template->set('category_id',$category_id);
			$template->set('city',$groupinfo->data->city);
			$template->set('state',$groupinfo->data->state);
			$template->set('zipcode',$groupinfo->data->zipcode);
			$template->set('keyword',$groupinfo->data->keyword);
						
			$category_name = '';
			
			foreach($categories as $category){
				if($category->category_id == $category_id){
					$category_name = $category->name;
					break;
				}
				
				foreach($category->children as $children){
					if($children->category_id == $category_id){
						$category_name = $children->name;
						break;
					}
				}
			}

			$phone = $session->get('phone_number');
			$phone = preg_replace("/\(/","",$phone);
			$phone = preg_replace("/\)/","",$phone);
			$phone = preg_replace("/-/","",$phone);
			$phone = preg_replace('/\s+/', '', $phone);
			
			$result = $this->request(
				$category_name,
				$groupinfo->data->city,
				$state,
				$groupinfo->data->zipcode,
				$groupinfo->data->keyword,
				$phone,
				'value_distance'
			);
			$template->set('result',json_decode($result));
			$template->render();
		}else {
			header('Location: '.BASE_URL);
			exit;
		}
	 }
	 
	 function business(){
		header('Content-Type: application/json');
		$ANI = $_REQUEST['ANI'];
		$Category = $_REQUEST['Category'];
		$City = $_REQUEST['City'];
		$PostalCode = $_REQUEST['PostalCode'];
		$State = $_REQUEST['State'];
		$Keyword = $_REQUEST['Keyword'];

		$result = $this->request(
			$Category,
			$City,
			$State,
			$PostalCode,
			$Keyword,
			$ANI,
			'value_distance'
		);
		echo $result;
	 }
	 
	 
function request($category,$city,$state,$zipcode,$keyword='',$ANI='',$sort='value_distance')
{
		
	$Sort = $sort;
	$Latitude = '';
	$Longitude = '';
	$City = $city;
	$State = $state;
	$PostalCode = $zipcode;
	$Radius = '';
	$ANI = $ANI;
	
	$Keyword = $keyword;
	$Category = $category;
	
	$State = empty($State) ? '':$State ;
	$headers = array('Accept: application/vnd.api.soleo.com-v1+json');
	$url = "https://api.soleo.com/sponsored/"."?APIKey=gt23pscq8y3gzcv7g2yqrzd4".
	//$url = "https://trialapi.soleo.com/businesses/?&Sort=value_distance&APIKey="."?APIKey=jqu72w5hzxqaufepdpz3668q".
	"&Sort=$Sort".
	"&Latitude=$Latitude".
	"&Longitude=$Longitude".
	"&City=".rawurlencode($City).
	"&State=$State".
	"&PostalCode=$PostalCode".
	"&Radius=$Radius";
	//"&ANI=$ANI";
	if(!empty($Keyword))
		$url .="&Keyword=".rawurlencode($Keyword);
	if(!empty($Category))
		$url .="&Category=".rawurlencode($Category);
	
	$result	= $this->createApiCall($url, 'GET', $headers, array());
	
	return $result;
}
}
?>