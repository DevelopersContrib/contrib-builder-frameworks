<?php

class Signout extends Controller {

	function index(){
	    $session = $this->loadHelper('Session_helper');
		$session->destroy();
		header('Location: '.BASE_URL);
		exit;
	}




}