<?php

class Sitemap extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/sitemap');
		$template->set('info', $info);
		$template->render();
	
	
	
	}




}