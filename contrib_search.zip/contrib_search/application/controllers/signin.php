<?php

class Signin extends Controller {

function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}

	function index(){
	    $session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('signin');
		$template->set('info', $info);
		$template->set('time', time());
		$template->render();
	}
	
	function autologin(){
		$headers = array('Accept: application/json');
		$session = $this->loadHelper('Session_helper');
		$member_id = base64_decode($_GET['code']);
		$group_id = $_GET['group'];
		$url = 'http://api1.contrib.co/search/Getuserinfo?field=member_id&value='.$member_id;
		$result = createApiCall($url, 'GET', $headers, array());
		$info_result = json_decode($result,true);
		$info = array();  
		if ($info_result['success']){
			$info = $info_result['data'];
		}else {
			$info = array();
		}	
		
		if (count($info)>0){
			 $session->set('logged_in', TRUE);
			 $session->set('user_name', $info['name']);
			 $session->set('email', $info['email']);
			 $session->set('member_id', $info['member_id']);
			 $session->set('group_id', $group_id);
			 $session->set('phone_number', $info['phone_number']);
			 
			 if ($group_id != ""){
			 	$group_id = intval($group_id);
			 }
			
			 if ($group_id >0){
			 	header('Location: '.BASE_URL.'signup/success');
			 }else {
			 	header('Location: '.BASE_URL.'dashboard');
			 }
			 exit;
		}else {
			echo 'Error in Auto Login!';
			exit;
		}
		
	}




}