<?php

class Apps extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('apps');
		$template->set('info', $info);
		$template->render();
	
	
	
	}




}