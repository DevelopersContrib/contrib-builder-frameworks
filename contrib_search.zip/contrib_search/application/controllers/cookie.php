<?php

class Cookie extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$cookie = $api->getgdp('cookie');
		$template = $this->loadView('cookie');
		$template->set('cookies',$cookie);
		$template->set('info', $info);
		$template->render();
	
	
	
	}




}