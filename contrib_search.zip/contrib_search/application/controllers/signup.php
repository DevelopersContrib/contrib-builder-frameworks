<?php

class Signup extends Controller {

	function createApiCall($url, $method, $headers, $data = array(),$user=null,$pass=null)
{
        if (($method == 'PUT') || ($method=='DELETE'))
        {
            $headers[] = 'X-HTTP-Method-Override: '.$method;
        }

        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
        if ($user){
         curl_setopt($handle, CURLOPT_USERPWD, $user.':'.$pass);
        } 

        switch($method)
        {
            case 'GET':
                break;
            case 'POST':
                curl_setopt($handle, CURLOPT_POST, true);
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        $response = curl_exec($handle);
        return $response;
}
	

	function index(){
	    $session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('signup');
		$template->set('info', $info);
		$template->set('zip',$session->get('zipcode'));
		$template->set('projecttype_id',$session->get('category'));
		$template->set('keyword',$session->get('keyword'));
		$template->set('city',$session->get('city'));
		$template->set('state',$session->get('state'));
		$template->set('category',$session->get('category'));
		$template->set('info', $info);
		$template->set('time', time());
		$template->render();
	}
	
	function category(){
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$category = $helper->segment(3);
		$category_name = $api->getcatnamebyslug($category);
		$info = $api->getdomaininfo();
		$template = $this->loadView('signup');
		$template->set('info', $info);
		$template->set('zip','');
		$template->set('keyword',$category_name);
		$template->set('city','');
		$template->set('state','');
		$template->set('category',$category);
		$template->set('info', $info);
		$template->set('time', time());
		$template->render();
	}
	
	function state(){
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$state_slug = $helper->segment(3);
		$state = $api->getstateid($state_slug);
		$info = $api->getdomaininfo();
		$template = $this->loadView('signup');
		$template->set('info', $info);
		$template->set('zip','');
		$template->set('projecttype_id','');
		$template->set('keyword','');
		$template->set('city','');
		$template->set('state',$state);
		$template->set('category','');
		$template->set('info', $info);
		$template->set('time', time());
		$template->render();
	}
	function verify(){
		$headers = array('Accept: application/json');
		$session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		
		$code = $_GET['code'];
		$url = 'http://api1.contrib.co/search/Getuserinfo?field=email_code&value='.$code;
		$result = createApiCall($url, 'GET', $headers, array());
		$info_result = json_decode($result,true);
		$info = array();  
		if ($info_result['success']){
			$info = $info_result['data'];
		}else {
			$info = array();
		}	
		
		$status = false;
		$message = "";
		$member_id = 0;
		
		
		if (count($info)>0){
			if ($info['is_verified'] == 1){
			   $message = 'Your account has already been verified!';	
			}else {
				$member_id = $info['member_id'];
				$update_array = array('is_verified'=>1);
				$url = 'http://api1.contrib.co/search/Update?member_id='.$member_id.'&data='.json_encode($update_array);
				$result = createApiCall($url, 'GET', $headers, array());
				$result = json_decode($result,true);
				$response = $result['data'];
				if ($response['status'] === true){
					$status = true;
				}else {
					$message = "Something went wrong while verifying your account";
				}
					
			}
			
		}else {
			$message = "Email Code does not exist!";
		}
		
		$code = base64_encode($member_id);
		$template = $this->loadView('verify');
		$template->set('info', $api->getdomaininfo());
		$template->set('status', $status);
		$template->set('message', $message);
		$template->set('member_id', $member_id);
		$template->set('code', $code);
		$template->set('time', time());
		$template->render();
	}

	function success(){
		$headers = array('Accept: application/json');
	    $session = $this->loadHelper('Session_helper');
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$group_name = "";
		if ($session->get('logged_in')===TRUE){
			$group_id = $session->get('group_id');
			$url = 'http://api1.contrib.co/search/Groupinfo?field=group_id&value='.$group_id;
			$result = createApiCall($url, 'GET', $headers, array());
			$info_result = json_decode($result,true);
			$ginfo = array();  
			if ($info_result['success']){
				$ginfo = $info_result['data'];
			}else {
				$ginfo = array();
			}	
			if (count($ginfo)>0){
				$group_name = $ginfo['name'];
			}
			
			$template = $this->loadView('signup_success');
			$template->set('info', $info);
			$template->set('time', time());
			$template->set('group_name', $group_name);
			$template->set('logged_in',$session->get('logged_in'));
			$template->set('email',$session->get('email'));
			$template->set('user_name',$session->get('user_name'));
			$template->render();
		}else {
			header('Location: '.BASE_URL);
			exit;
		}
	}


}