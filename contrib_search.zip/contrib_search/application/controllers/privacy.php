<?php

class Privacy extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$privacy = $api->getgdp('privacy');
		$template = $this->loadView('privacy');
		$template->set('private',$privacy);
		$template->set('info', $info);
		$template->render();
	
	
	
	}




}