<?php

class Home extends Controller {
	
	
  
  	function index()
	{
	
		
		$session = $this->loadHelper('Session_helper');
		
		if (isset($_SESSION['logged_in'])){
			header('Location: '.BASE_URL.'dashboard');
			exit;
		}else {
			$api = $this->loadModel('ApiModel');
			$helper = $this->loadHelper('Url_helper');
			$info = $api->getdomaininfo();
			$projecttypes = $api->getprojecttypes();
			$relatedsiteswithlogo = $api->relatedsiteswithlogo();
			$relatedsitesnologo = $api->relatedsitesnologo();
			$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
			$template = $this->loadView('home');
			$template->set('parnershiptypes',$parnershiptypes);
			$template->set('relatedsiteswithlogo',$relatedsiteswithlogo);
			$template->set('relatedsitesnologo',$relatedsitesnologo);
			$template->set('info', $info);
			$template->set('projecttypes',$projecttypes);
			$template->set('states',$api->getstates());
			$template->set('programs',$api->getprograms());
			$template->set('time', time());
			$template->render();
		}
	}
	
	function terms(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/terms');
		$template->set('info', $info);
		$template->render();
	
	}
	
	function fund(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$fundsites = $api->getfund();
		$template = $this->loadView('handyman/fund');
		$template->set('info', $info);
		$template->set('fundsites', $fundsites);
		$template->render();
	
	}
	
	function developers(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/developers');
		$template->set('info', $info);
		$template->render();
	
	}
	
	function about(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/about');
		$template->set('title', $title);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function apps(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/apps');
		$template->set('title', $title);
		$template->set('info', $info);
		$template->render();
	
	}
	
	function sitemap(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('handyman/sitemap');
		$template->set('title', $title);
		$template->set('info', $info);
		$template->render();
	
	}
    
}

?>