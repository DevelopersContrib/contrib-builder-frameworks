<?php

class Terms extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$terms = $api->getgdp('terms');
		$template = $this->loadView('terms');
		$template->set('term',$terms);
		$template->set('info', $info);
		$template->render();
	
	
	
	}




}