 <?php include('header.php'); ?>
<script src="<?php echo BASE_URL; ?>js/jquery.maskedinput.js" type="text/javascript"></script>
	 
<style>
.signin-container .btn-warning {
	color:#fff;
}
.signin-container a {
	color:#999;
}
.signin-container a:hover {
	color:#fff;
}
.search-panel-outer {
    margin-top: 80px;
    margin-bottom: 140px;
    background: #0559B7;
    border-radius: 3px;
}
</style> 
      <div class="container">
        <?php include('navigation.php'); ?>
      <div class="row header-search">
          <div class="col-sm-6 col-sm-offset-3 text-center search-panel-outer">
            <h1 class="wow fadeIn">Sign Up</h1>
            <div class="search-panel">
				<div class="row">
					<div class="col-md-12 signin-container">
					<div class="alert alert-danger fade in" id="reg_error" style="display: none">
    					
					</div>
						
						<input type="text" id="reg_name" name="reg_name" class="form-control" placeholder="Name">
						<input type="text" id="reg_email" name="reg_email"  class="form-control" placeholder="Email">
						<input type="text" id="reg_phone" name="reg_phone"  class="form-control" placeholder="Phone Number">
						<input type="password" id="reg_password" name="reg_password"  class="form-control" placeholder="Password">
						<input type="password" id="reg_cpassword" name="reg_cpassword"  class="form-control" placeholder="Confirm Password">
						<input type="hidden" name="s_keyword" id="s_keyword" value="<?php echo $keyword?>">
						<input type="hidden" name="s_zip" id="s_zip" value="<?php echo $zip?>">
						<input type="hidden" name="s_city" id="s_city" value="<?php echo $city?>">
						<input type="hidden" name="s_state" id="s_state" value="<?php echo $state?>">
						<input type="hidden" name="s_category" id="s_category" value="<?php echo $category?>">
						<input type="hidden" name="reg_domain" id="reg_domain" value="<?php echo $info['domain']?>">
						<input type="hidden" name="user_ip" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
						<a class="btn btn-warning btn-lg btn-block" id="btn-signup-<?php echo $time?>">Sign Up</a>
						<hr>
						<a href="<?php echo BASE_URL?>signin">Already have an account? Sign In</a>
					</div>									
				</div>
			</div>
          </div>
        </div>
      </div>
 <input type="hidden" name="dotime" id="dotime" value="<?php echo $time?>">       
 <script src="<?php echo BASE_URL; ?>js/register.js"></script> 
 <?php include('footer.php'); ?>  