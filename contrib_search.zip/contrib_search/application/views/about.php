 <?php include('header.php'); ?>
 
 <style>
/* about us */
.about-year { border: 2px solid #6d6d6d; display: inline-block; font-size: 17px; height: 120px; margin-bottom: 40px; padding: 0px; width: 120px; }
.about-year span { font-size: 50px; font-weight: 600; left: -4px; letter-spacing: -5px; position: relative; top: 13px; display:block; }
.timeline-number { font-family: "Oswald",sans-serif; font-size: 25px; padding: 15px; line-height:25px;}
.timeline-year {font-size: 20px; font-weight: 600; line-height:60px;}
.text-uppercase {
    text-transform: uppercase;
    font-size: 25px;
}
.page-container {
	background:#fff;
	border: 1px solid rgb(222, 222, 222);
	margin-top: 10px;
	margin-bottom: 100px;
	padding: 80px 50px;
}
</style>  
      <div class="container">
        <?php include('navigation.php'); ?>
       <div class="row header-search">
		  <h2 class="text-center">About Us</h2>
          <div class="col-sm-6 col-sm-offset-3 text-center page-container">
            <p class="title-small text-uppercase letter-spacing-1 white-text font-weight-100" style="line-height: 30px;"><?php echo ucfirst($info['domain'])?> is a proud venture of Global Ventures, LLC.</p>
            <p class="title-small text-uppercase letter-spacing-1 white-text font-weight-100" style="line-height: 30px;">Global Ventures, LLC, established in 1996, invests in young innovators, entrepreneurs and professionals with a desire to solving big problems and help world. We combine our resources with a series of intense challenges, real-world skills development, amazing and flexible opportunities and a shared ownership and experience with the most talented young founders and professionals around the world.</p>
            <p class="title-small text-uppercase letter-spacing-1 white-text font-weight-100" style="line-height: 30px;">Join our network of performance based companies using <?php echo $info['domain']?></p>
          </div>
        </div>
      </div>
 <?php include('footer.php'); ?>  