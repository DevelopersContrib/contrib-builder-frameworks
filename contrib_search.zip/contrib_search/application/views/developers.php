 <?php include('header.php'); ?>
 
<style>
.page-container {
	background:#fff;
	border: 1px solid rgb(222, 222, 222);
	margin-top: 10px;
	margin-bottom: 100px;
	padding: 60px 50px 60px;
}
.page-container h2 {
	color: #333;
	font-size: 30px;
}
</style>  
      <div class="container">
        <?php include('navigation.php'); ?>
      <div class="row header-search">
		  <h2 class="text-center">Developers</h2>
			<div class="col-md-8 col-md-offset-2 page-container">
				<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Do you have code or an app that could run this brand? <?php echo ucfirst($info['domain'])?> is connected with Contrib. </h4>
				<p></p>
				<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?php echo ucfirst($info['domain'])?> </h4>
				<p class="text-center">
				<br>
				<a href="<?php echo BASE_URL?>contact" class="btn btn-primary btn-lg">Inquire Here</a>
			</div>
        </div>
      </div>
 <?php include('footer.php'); ?>  