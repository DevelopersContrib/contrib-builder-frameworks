<div class="row">
  <div class="col-xs-6">
     <?php if ($info['logo']!= ''):?>
	<a href="<?php echo BASE_URL?>home"><img class="search-logo" src="<?php echo $info['logo']?>" alt="<?php echo ucfirst($info['domain'])?> Logo" title="<?php echo ucfirst($info['domain'])?> Logo"></a>
		<?php else:?>
	<a href="<?php echo BASE_URL?>home"><h2 class="domain-title"><?php echo ucfirst($info['domain'])?></h2></a>
		
	<?php endif?>
  </div>
  <div class="col-xs-6 signin text-right navbar-nav">            
	<a href="<?php echo BASE_URL?>signin" class="btn btn-info btn-sm">Sign In</a>
	<a href="<?php echo BASE_URL?>signup" class="btn btn-primary btn-sm">Sign Up</a>
  </div>
</div>