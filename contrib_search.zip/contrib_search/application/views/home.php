 <?php include('header.php'); ?> 
<div class="hero-container">
<div class="container">
	<?php include('navigation.php'); ?>
	<div class="row header-search">
	  <div class="col-sm-10 col-sm-offset-1 text-center search-panel-outer">
		<h1 class="wow fadeIn"><span class="look">Look</span>ing For</h1>
		<!-- <img class="search-icon" src="<?php echo BASE_URL?>img/Search.png"> -->
		<div class="search-panel">
		<div class="m-alert-box m-error" id="m-error" style="display:none"><span>Error: </span>Write your error message here.</div>
			<div class="row">
				<div class="col-md-4">
					<div class="sbox scat">
						<select class="form-control" name="proj_cat" id="proj_cat">
						  <option>Select a Category</option>
						  <?php if (count($projecttypes)>0):?>
							  <?php for ($i=0;$i<count($projecttypes);$i++):?>
								   <?php if (count($projecttypes[$i]['children'])>0):?>
									<option class="parent" value="<?php echo $projecttypes[$i]['slug']?>"><?php echo $projecttypes[$i]['name']?></option>
									<?php $children = $projecttypes[$i]['children']?>
									 <?php for ($j=0;$j<count($children);$j++):?>
											<option class="child" value="<?php echo $children[$j]['slug']?>"><?php echo $children[$j]['name']?></option>
									 <?php endfor;?>
									<?php endif?>
							  <?php endfor;?>
						  <?php endif;?>
							
						</select>
						<span class="meta-orSpan"><i class="fa fa-search" aria-hidden="true"></i></span>
					</div>
				</div>					
				<div class="col-md-4">
					<div class="sbox">
						<input type="text" class="form-control ui-autocomplete-input" placeholder="City" name="proj_city" id="proj_city">
						<select class="form-control" name="proj_state" id="proj_state">
						  <option value="">Select Your State</option>
						  <?php if (count($states)>0):?>
							 <?php foreach ($states as $skey=>$sval):?>
								<option name="<?php echo $sval['name']?>" value="<?php echo $sval['id']?>"><?php echo $sval['name']?></option>
							 <?php endforeach;?>
						  <?php endif?>
						</select>
						<span class="meta-orSpan"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
					</div>
				</div>					
				<div class="col-md-4">
					<div class="sbox">
						<input type="text" class="form-control" placeholder="Zip Code" name="proj_zip" id="proj_zip">
						<a id="btn-search-<?php echo $time?>" class="btn btn-warning btn-lg btn-block">Submit</a>
					</div>
				</div>
				<div class="col-md-12">
					<h2 class="tborder">Find a local business or expert near you.</h2>
				</div>					
			</div>				
		</div>			
	  </div>
	</div>
  </div>
</div>
<div class="pro-container">
	<div class="container">
		<div class="search-panel sp2">
			<div class="row">
				<div class="col-md-12 text-left">
					<h2 class="b-section"><i class="fa fa-folder-open" aria-hidden="true"></i>&nbsp;Choose Your Projects</h2>						
					<ul class="pro-links">
						
						<?php if (count($projecttypes)>0):?>
							<?php for ($i=0;$i<count($projecttypes);$i++):?>
							           <?php if (count($projecttypes[$i]['children'])>0):?>
							               <li class="l-parent"><a href="<?php echo BASE_URL?>signup/category/<?php echo $projecttypes[$i]['slug']?>"><?php echo $projecttypes[$i]['name']?></a></li>
							               <?php $children = $projecttypes[$i]['children']?>
							               	 <?php for ($j=0;$j<count($children);$j++):?>
							               	    <?php if (count($children)>10){
							               	    	 if ($j==10) break;
							               	    }
							               	    
							               	    ?> 
							      		       	<li class="l-child"><a href="<?php echo BASE_URL?>signup/category/<?php echo $children[$j]['slug']?>"><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $children[$j]['name']?></a></li>
							      		       	
							      		 <?php endfor;?>
							           <?php endif;?>
									
									
									
						    <?php endfor;?>
						<?php endif?>
						
						
					</ul>
				</div>
				<div class="col-md-12 text-left">
					<h2 class="b-section"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;Choose Your State</h2>
					<ul class="list-unstyled s-a-links">
					<?php if (count($states)>0):?>
							     <?php foreach ($states as $skey=>$sval):?>
							     	<li class="col-md-3"><a href="<?php echo BASE_URL?>signup/state/<?php echo $sval['slug']?>" class="l-state text-capitalize"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;<?php echo $sval['name']?></a></li>
							     <?php endforeach;?>
							  <?php endif?>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
 <input type="hidden" name="dotime" id="dotime" value="<?php echo $time?>">     
<script src="<?php echo BASE_URL; ?>js/home.js"></script>      
 <?php include('footer.php'); ?>  