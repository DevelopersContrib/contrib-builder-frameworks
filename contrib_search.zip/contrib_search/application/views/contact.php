 <?php include('header.php'); ?>
 
<style>
.page-container {
	background:#fff;
	border: 1px solid rgb(222, 222, 222);
	margin-top: 10px;
	margin-bottom: 100px;
	padding: 60px 50px 60px;
}
.page-container h2 {
	color: #333;
	font-size: 30px;
}
</style>  
      <div class="container">
        <?php include('navigation.php'); ?>
        <?php global $domain;?>
      <div class="row header-search">
		  <h2 class="text-center">Contact Us</h2>
			<div class="col-md-8 col-md-offset-2 page-container">
				<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<? echo $info['domain']?>"></script>
			</div>
        </div>
      </div>
 <?php include('footer.php'); ?>  