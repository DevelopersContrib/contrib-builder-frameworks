<style>
#leads,#history {
font-size: 15px;
padding: 15px 0px;
}
</style>
<form action="javascript:loadSearch();" method="post" class="form-inline pull-right form-inliner">
  <div class="form-group">					
	<input type="text" id="lsearch" class="form-control" id="scategory" placeholder="Your Search">
  </div>
  <div class="form-group">
	<select class="form-control" id="filter-status">
	  <option value="">Select Status</option>
	   <?php foreach ($status as $key=>$v):?>
		  	<option value="<?php echo $key?>"><?php echo $v?></option>
		  <?php endforeach;?>
	</select>
  </div>				 
  <button  class="btn btn-info btn-psearch" id="btn-lead-search-<?echo $time?>" style="border:none;border-radius:3px !important;"><i class="fa fa-search" aria-hidden="true"></i></button>
</form>
<div class="clearfix"></div><br>		
		<ul class="list-unstyled s-a-links text-center" id="ul-leads-list">
							
							
		</ul>
		<div class="clearfix"></div>
		<div class="text-center tpagination">
							
		</div>
		<div class="clearfix"></div>
  <input type="hidden" name="total_results" id="total_results" value="<?echo $total_results?>" />	
  <input type="hidden" name="leads_time" id="leads_time" value="<?echo $time?>" />						
 <script>
 $(document).ready(function() {
	var current_page = 1;
	 loadPages(current_page,'','');
	$(".btn-pref .btn").click(function () {
	    $(".btn-pref .btn").removeClass("btn-primary").addClass("btn-default");
	    // $(".tab").addClass("active"); // instead of this do the below 
	    $(this).removeClass("btn-default").addClass("btn-primary");   
	});
	
});


 function loadSearch(){
	 var search = jQuery('#lsearch').val();
	 var status = $('#filter-status').val();
	 var base_url = $('#base_url').val();
	 $('#preloader').show();	
	 jQuery.post(base_url+'leads/showcount',{search:search,status:status},function(data_html){
				jQuery('#total_results').val(data_html);
				loadPages(1,search,status); 
			});
	 
 }
 
 function loadPages(current_page,search,status){
	 $('#preloader').show();
	 	var total_results = $('#total_results').val();
		var base_url = $('#base_url').val();
		getPagination(current_page,total_results);
		jQuery.post(base_url+'leads/showlist',{current_page:current_page,search:search,status:status},function(data_html){
			jQuery('#ul-leads-list').html(data_html);
			$('#preloader').fadeOut('slow');	
		});
	}

 function getPagination(current_page,total_results){
		var search = jQuery('#lsearch').val();
		var base_url = $('#base_url').val();
		 var status = $('#filter-status').val();
		jQuery.post(base_url+'leads/showpagination',{current_page:current_page,total_results:total_results,search:search,status:status},function(data_html){
			jQuery('.tpagination').html(data_html);
		});
	}
		
 </script>						