 </header>
    
<?php 
global $social_fb;
global $social_gplus;
global $social_twitter;
global $domain;
global $footer_html;
?>
<style>
.fnt-bold {
	color:#fff !important;
}
.footer-dark-1 {
    color: #fff;
    padding: 20px 0 15px;
    background-color: #333;
}
.footer-dark-1 h3 {
	font-size:19px;
}
.footer-dark-1 a {
	color:#ccc;
}
.footer-dark-1 a:hover {
	color:#666;
}
.footer-dark-2 {
    color: #fff;
    padding: 15px 0 10px;
    background-color: #222;
	font-size:12px;
}
.footer-dark-2 a {
	color:#ccc;
	font-size:12px;
}
.socials-ul .fa {
	font-size:35px;
}
.animated {
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
}
@-webkit-keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}

@keyframes rotateIn {
    0% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(-200deg);
        -ms-transform: rotate(-200deg);
        transform: rotate(-200deg);
        opacity: 0;
    }

    100% {
        -webkit-transform-origin: center center;
        -ms-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: rotate(0);
        -ms-transform: rotate(0);
        transform: rotate(0);
        opacity: 1;
    }
}
.rotateIn {
    -webkit-animation-name: rotateIn;
    animation-name: rotateIn;
}
.r-d{
    -webkit-animation-delay: 2.5s;
    -moz-animation-delay: 2.5s;
    -ms-animation-delay: 2.5s;
    -o-animation-delay: 2.5s;
    animation-delay: 2.5s;
}
.r-d.rotateIn{
    position: absolute; 
    z-index: 10; 
    top: -20px; 
    left: 190px;
}
.arrw-rela {
    position: relative;
}
.socials-ul img {
	height: 40px;
}
.socials-ul img:hover {
	opacity:.8;
}
.socials-ul > li {
    padding-right: 2px;
    padding-left: 2px;
}
.related-container {
	background: linear-gradient( rgba(0, 0, 0, 0.85), rgba(0, 0, 0, 0.85) ), 
	url(http://www.domaindirectory.com/images/slider/bg1.jpg);
	background-size: cover;
	padding: 30px 0px 60px;
	color:#fff;
}
.related-container h2 {
	font-size:27px;
}
.ul-verticals a:hover {
	color:#999;
}
.webicon {
    width: 35px;
}
</style>
<script type="text/javascript" src="//cdn.rawgit.com/icons8/bower-webicon/v0.10.7/jquery-webicon.min.js"></script>
<?php global $related_nologo;?>
<?php $related_domains = $related_nologo?>
<?php if (count($related_domains) >0):?>
<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
 <?php $count = count($related_domains)?>
<div class="related-container">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<h2>Other Brands on <?php echo $vertical?> Vertical</h2>
			</div>
			<div class="col-md-8 col-md-offset-2">
				<ul class="list-unstyled ul-verticals">
				  <?php for ($i=0;$i<$count;$i++):?>
					<li class="col-md-4">
						<a href="http://<?php echo $related_domains[$i]['domain_name']?>" class="text-capitalize" target="_blank">
							<i class="fa fa-angle-right"></i>
							<?php echo $related_domains[$i]['domain_name']?>
						</a>
					</li>
				<?php endfor;?>	
				</ul>
				<div class="row">
					<div class="col-md-12 text-center">
					<br>
						<a href="https://www.contrib.com/verticals/news" class="btn btn-warning" target="_blank">View More</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php endif;?>
<div class="footer-dark-1">
	<div style="position:relative;">
			<div class="animated rotateIn r-d">
				<a alt="Contrib" target="_blank" href="http://referrals.contrib.com/idevaffiliate.php?id=71952&url=http://www.contrib.com/signup/firststep?domain=<?php echo $domain?>">
					<img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-8.png" alt="Join Contrib.com" title="Join Contrib.com"> 
				</a>
			</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							<?php echo ucfirst($info['domain'])?>
						</h3>
						<p>
							We have thousands of contractors available for you that are experts.
						</p>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							get started
						</h3>
						<ul class="list-unstyled f-a-links">
							<li>
								<a href="<?php echo BASE_URL?>partners" class="text-capitalize">
									Partner with us
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>staffing" class="text-capitalize">
									Apply now
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>referral" class="text-capitalize">
									referral
								</a>
							</li>							
							<li>
								<a href="<?php echo BASE_URL?>developers" class="text-capitalize">
									developers
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							company
						</h3>
						<ul class="list-unstyled f-a-links f-a-links-mrgBtm">
							<li>
								<a href="<?php echo BASE_URL?>about" class="text-capitalize">
									About us
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>terms" class="text-capitalize">
									Terms
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>privacy" class="text-capitalize">
									Privacy
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>cookie" class="text-capitalize">
									Cookie Policy
								</a>
							</li>
							<li>
								<a href="http://www.domaindirectory.com/policypage/unsubscribe?domain=<?php echo ucfirst($info['domain'])?>" class="text-capitalize">
									Unsubscribe
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>contact" class="text-capitalize">
									Contact us
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>apps" class="text-capitalize">
									Apps
								</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3">
						<h3 class="fnt-bold text-uppercase">
							partners
						</h3>
						<p>
							<?if($footer_html != ""):?>
						<?echo base64_decode($footer_html)?>
					<?php else:?>
						<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
						<?endif;?>						
						</p>
						<h3 class="fnt-bold text-uppercase">
							Socials
						</h3>
						<ul class="list-inline socials-ul">							
							<li>
								<a title="facebook" class="icon-button facebook" href="<?php echo $social_fb?>" target="_blank">
									<i class="fa fa-facebook-square"></i>
								</a>
							</li>
							<li>
								<a title="google-plus" class="icon-button google-plus" href="<?php echo $social_gplus?>" target="_blank">
									<i class="fa fa-google-plus-square"></i>
								</a>

							</li>
							<li>
								<a title="twitter" class="icon-button twitter" href="<?php echo $social_twitter?>" target="_blank">
									<i class="fa fa-twitter-square"></i>
								</a>
							</li>
						</ul>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer-dark-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6 f-a-links">
						© <?=date("Y")?> <a href="/" class="text-capitalize "><?php echo ucfirst($info['domain'])?></a>. All Rights Reserved. 
					</div>
					<div class="col-md-6">
						<ul class="list-inline text-right f-a-links">
							<li>
								<a href="<?php echo BASE_URL?>about" class="text-capitalize">
									<i class="fa fa-bookmark-o"></i>
									About us
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>terms" class="text-capitalize">
									<i class="fa fa-book"></i>
									Terms
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>privacy" class="text-capitalize">
									<i class="fa fa-cube"></i>
									privacy
								</a>
							</li>
							<li>
								<a href="<?php echo BASE_URL?>contact" class="text-capitalize">
									<i class="fa fa-phone-square"></i>
									contact us
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>


    <!-- Javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  
    <script>window.jQuery || document.write('<script src="<?php echo BASE_URL?>js/jquery-1.11.0.min.js"><\/script>')</script>
    <script src="<?php echo BASE_URL?>js/wow.min.js"></script>
    <script src="<?php echo BASE_URL?>js/main.js"></script>

   
    </body>
</html>