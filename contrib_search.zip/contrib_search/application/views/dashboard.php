 <?php include('header.php'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 
<style>
.user .navbar-nav {
	float:right;
}
.nav .open > a, .nav .open > a:focus, .nav .open > a:hover {
    background: none !important;
}
.nav .open > a, .nav .open > a:focus, .nav .open > a:hover {
    background: none !important;
}
.user .nav > li > a:focus, .user .nav > li > a:hover {
    background: none !important;
	color:rgb(76,186,219);
}
.m-alert-box {
	color:#555;
	border-radius:5px;
	font-family:Tahoma,Geneva,Arial,sans-serif;font-size:13px;
	padding:10px 36px;
	margin:0px 0px 10px 0px;
}
.m-error {
	background:#ffecec url('<?php echo BASE_URL?>img/error.png') no-repeat 10px 50%;
	border:1px solid #f5aca6;
}
.m-success {
	background:#e9ffd9 url('<?php echo BASE_URL?>img/success.png') no-repeat 10px 50%;
	border:1px solid #a6ca8a;
}
.dashboard-container {
    margin-top: 20px;
}
.imgs {
	vertical-align:-5px;
	height:36px;
}
.hidden-xs {
	display:inline-block;
}
</style>  
<div id="preloader"></div>
      <div class="container">
        <?php include('navigation_login.php'); ?>
		<div class="row header-search">
          
        </div>
      </div>
<div class="dashboard-container">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="hdb"><img src="http://image.flaticon.com/icons/png/128/187/187474.png" class="imgs" alt="dashboard" title="dashboard">&nbsp;Dashboard</h2>
			</div>
			<div class="col-md-12">				
				<div class="btn-pref btn-group btn-group-lg" role="group" aria-label="...">
					<div class="btn-group" role="group">
						<button type="button" id="leads" class="btn btn-primary" href="#tab1" data-toggle="tab"><i class="fa fa-star" aria-hidden="true"></i>
							<div class="hidden-xs">My Leads</div>
						</button>
					</div>
					<div class="btn-group" role="group">
						<button type="button" id="history" class="btn btn-default" href="#tab2" data-toggle="tab"><i class="fa fa-th-list" aria-hidden="true"></i>
							<div class="hidden-xs">Search History</div>
						</button>
					</div>				
				</div>

				<div class="well">
				  <div class="tab-content">
					<div class="tab-pane fade in active" id="tab1">								
				     <?php include('leads.php'); ?>
					</div>
					<div class="tab-pane fade in" id="tab2">
				    <?php include('history.php'); ?>
					</div>
				  </div>
				</div>
			</div>
		</div>
	</div>
</div>


<script src="<?php echo BASE_URL; ?>js/dashboard.js"></script> 
 <?php include('footer.php'); ?>  