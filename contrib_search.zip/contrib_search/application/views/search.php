  <?php include('header.php'); ?>
 <style>
 header {   
    padding: 20px 10px 0px;
}
.zp {
	font-size: 19px;
}
.form-control {   
    height: 40px;
	margin-right: -2px;
	border: 1px solid #ccc;
}
.navbar-nav {
	float: right !important;
}
.nav > li > a:focus, .nav > li > a:hover {
    text-decoration: none;
    background: none !important;
}
.plsave {
	position: absolute;
	width: 320px;
	right: 29px;
	top: -5px;
}
.al-success {
	position: absolute;
	width: 97.5%;
	z-index: 999;
	padding: 0px 0px 8px 0px;
}
.al-success h3 {
	font-size: 19px;
}
.btn-dsave {
	margin-right: 14px;
}
.ui-autocomplete-loading {
		background: white url("http://jqueryui.com/resources/demos/autocomplete/images/ui-anim_basic_16x16.gif") right center no-repeat;
	}
	
.alert3 h3 a{
	color: brown;
    text-decoration: underline;
}
.offer-box {
	height: 225px;
	width:100%;
}
hr {
	border:none !important;
}
.imgs {
	height:30px;vertical-align: -5px;
}
 </style>
<div class="container">
	<?php include('navigation_login.php'); ?>
</div>
<div class="top-header-search">
  <div class="container">
   <div class="row header-search">
		<div class="col-md-6">
		  <h2 class="text-left"><img src="http://image.flaticon.com/icons/png/128/123/123376.png" class="imgs" alt="search business" title="search business">&nbsp;Search For Business / Expert</h2>
			<form class="form-inline">
				  <div class="form-group">
					<input id="keyword" type="text" class="form-control input-search" placeholder="Search" value="<?=$keyword?>">
				  </div>
				  <!--<button type="submit" class="btn btn-default btn-search"><i class="fa fa-search" aria-hidden="true"></i></button>-->
				  <div class="form-group">
					<select class="form-control select-search"  name="category" id="category">
					  <option value="">- Select Category -</option>
					  <?php
						foreach($categories as $category){
							$category = is_array($category) ? (object) $category:$category;
							$selected = $category->category_id == $category_id && !empty($category_id) ?'SELECTED' :'' ;
							?>
							<option <?=$selected?> class="parent" value="<?=$category->name?>"><?=$category->name?></option>
							<?php
							if(!empty($category->children)){
								foreach($category->children as $children){
									$children = is_array($children) ? (object) $children:$children;
									$selected = $children->category_id == $category_id && !empty($category_id) ?'SELECTED' :'' ;
							?>
							<option <?=$selected?> class="" value="<?=$children->name?>"><?=$children->name?></option>
							<?php
								}
							}
						}
					  ?>
					</select>
				  </div>				  
			</form>
			<div class="loc-alert alert1" style="display:none;"><i  aria-hidden="true" class="fa fa-exclamation-circle"></i>&nbsp;
				Please Enter A City/Zip 
			</div>
		</div>
		<div class="col-md-6">
		  <h2 class="text-right"><img src="http://image.flaticon.com/icons/png/128/179/179550.png" class="imgs" alt="Find Nearest Location" title="Find Nearest Location">&nbsp;Find Nearest Location</h2>
			<form class="form-inline pull-right">				
				  <div class="form-group">
					<input id="city" type="text" class="form-control input-city" placeholder="City" value="<?=$city?>">
				  </div>
				  <div class="form-group">
					<select class="form-control select-state" name="state" id="state">
					  <option value="">- Select A State -</option>
					  <?php if (count($states)>0):?>
							     <?php foreach ($states as $skey=>$sval):?>
								 <?php $selected = $sval['id'] == $state ?'SELECTED' :'' ;?>
							     	<option <?=$selected ?> name="<?php echo $sval['name']?>" value="<?php echo $sval['abbreviation']?>"><?php echo $sval['name']?></option>
							     <?php endforeach;?>
							  <?php endif?>
					</select>
				  </div>
				  <div class="form-group">
					<input name="zipcode" id="zipcode" type="text" class="form-control input-zip" placeholder="Zip Code" value="<?=$zipcode?>">
				  </div>
				  				  
				  
				<button type="button" class="btn btn-success btn-search" style="margin-left:0px;"><i class="fa fa-search" aria-hidden="true"></i></button>				  
			</form>
			<div class="loc-alert alert2" style="display:none;"><i class="fa fa-exclamation-circle" aria-hidden="true" ></i>&nbsp;
				Please Enter A City/Zip 
			</div>
		</div>
	</div>
  </div>
</div>
  <div class="top-search-container">
	<div class="container">
		<div class="row">
			<div class="col-md-8 text-left">
				<!--<a href="">Heating</a>
				<a href="">Plumbing</a>
				<a href="">Housecleaning</a>
				<a href="">Electrical</a>
				<a href="">Handymen</a>-->
			</div>
			<div class="col-md-4 text-right">
				<!--<b class="zp"><?=$zipcode?> <?=!empty($city)?$city.','.$state:''?></b>-->
			</div>
		</div>
	</div>
  </div>
  <div class="search-container">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center page-container">
				<div class="loading-div" style="display:none;">
					<img class="search-icon" style="margin:0 auto;position:inherit;" src="<?php echo BASE_URL?>img/loading-2.gif"><br>
					Loading...
				</div>
				<?php
				if(!empty($result)){
					if(count($result->businesses)>0){
					?>
					<h3 class="result-count text-left" style=""><i aria-hidden="true" class="fa fa-caret-right"></i>&nbsp;Showing <?=count($result->businesses);?> Results</h3>
					<?php
					}else{
					?>
					<h3 class="result-count text-left" style=""><i aria-hidden="true" class="fa fa-caret-right"></i>&nbsp; No results found.</h3>
					<?php						
					}
				}else{
				?>
				<h3 class="result-count text-left" style="display:none"><i aria-hidden="true" class="fa fa-caret-right"></i>&nbsp; No results found.</h3>
				<?php
				}
				?>
				<div class="alert alert-success al-success alert3" role="alert" style="display:none;">					
					<h3><i class="fa fa-check-square-o" aria-hidden="true"></i>&nbsp;
					You have successfully saved this search.
					</h3>
				</div>
				<div class="pull-right" style="margin-top:-35px;">
					<a id="btn-dsave" href="javascript:;" class="btn btn-warning btn-dsave" style="display:none">
						<i class="fa fa-floppy-o" aria-hidden="true"></i>&nbsp;
						Save This Search
					</a>
					<div class="alert alert-success plsave" role="alert" style="display:none;">
						<i class="fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;
						Please select one or more entries to save.
					</div>
				</div>
				<div class="clearfix"></div>
				<hr class="tbound">
				<ul id="search-result" class="list-unstyled s-a-links">
					<?php
						$x=0;
						if(!empty($result)){
							if(count($result->businesses)){
								
							}
							foreach($result->businesses as $item){
								$name = $item->name;
								$address = $item->address;
								$url = $item->_links[0]->href;
								$method = $item->_links[0]->method;
					?>
							<li class="col-md-3">
								<input class="chck" id="box<?=$x?>" type="checkbox" title="Save" />
								<label for="box<?=$x?>" class="offer-box">
									<div class="text-capitalize">
										<div class="pr"></div>
										<div class="clearfix cfstyle"></div>
										<h3 class="search-cat-box"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;
											<span class="item-name"><?=$name?></span>
										</h3>
										<h3 class="search-cat-address">
											<?php
												if(!empty($address)){
													echo '<i class="fa fa-location-arrow" aria-hidden="true"></i>&nbsp;<span class="item-name">'.$address.'</span>';
												}
											?>
										</h3>
										<a data-method="<?=$method?>" data-url="<?=$url?>" href="javascript:;" class="btn btn-info btn-block btn-lg callback"><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;
											Get Phone No.
										</a>
									</div>
								</label>
							</li>
					<?php
							$x++;
							}
						}
					?>
				</ul>
				<div class="clearfix"></div>
				<hr>
				<?php /*?>
				<ul class="pagination">
				  <li class="disabled"><a href="#">«</a></li>
				  <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
				  <li><a href="#">2</a></li>
				  <li><a href="#">3</a></li>
				  <li><a href="#">4</a></li>
				  <li><a href="#">5</a></li>
				  <li><a href="#">»</a></li>
				</ul>
				<?php */?>
			</div>
		</div>
	</div>
  </div>
  <script>
  jQuery(document).ready(function(){
	  jQuery( "#city" ).autocomplete({
		source: function (request, response) {
			jQuery.ajax({
				url: 'http://handyman.com/projectnew/searchcity',
				data: { term: request.term.trim() },
				type: "GET",
				cache: false,
				dataType: 'json',
				success: function (data) {							
					response( jQuery.map(data, function( item ) {
								  return {
									value: item.value,
									id: item.id
								}
					}));
					if(data.length<1) {
						$('#city').removeClass('ui-autocomplete-loading');
					}
				},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
				}
			});
		},
		minLength: 1,
		search  : function(event, ui ){ $('#city').addClass('ui-autocomplete-loading'); },	
		select: function(event, ui) {			
			event.preventDefault();
			jQuery('#city').removeClass('ui-autocomplete-loading');
			return false;
		},focus: function(event, ui) {
            jQuery("#city").val(ui.item.label);
            return false;
		}	  
    });
	  jQuery('#category').change(function(){
		  if(jQuery(this).val()!=''){
			  jQuery('.alert1').hide();
		  }
	  });
	  
	  jQuery('#keyword').keyup(function(){
		  if(jQuery(this).val()!=''){
			  jQuery('.alert1').hide();
		  }
	  });
	  
	  jQuery('#city, #zipcode').keyup(function(){
		  if(jQuery(this).val()!=''){
			  jQuery('.alert2').hide();
		  }
	  });
	  
	  jQuery('#state').change(function(){
		  if(jQuery(this).val()!=''){
			  jQuery('.alert2').hide();
		  }
	  });
	  
	  jQuery('#btn-dsave').click(function(){
		  var chck = jQuery('.chck:checked');
			if(chck.length>0){
				var items = [];
				jQuery(chck).each(function(){
					//if(!jQuery(this).hasClass('saved')){
						var name = jQuery(this).parents('li').find('.item-name').text();
						var address = jQuery(this).parents('li').find('.item-address').text();
						var phone = jQuery(this).parents('li').find('.item-phone').text();
						items.push({name:name,address:address,phone:phone});
						jQuery(this).addClass('saved');
					//}
				});
				
				
				jQuery('.chck').prop('checked',false);
				jQuery('#chck-all').prop('checked',false);
				var $btn = jQuery(this);
				
				$btn.attr('disabled', 'disabled').html("Saving...");
				jQuery('.plsave').hide();
				$.ajax({
					url: 'http://api1.contrib.co/search/savelead',
					type: 'POST',
					dataType : 'json',
					data: {i:JSON.stringify(items),u:encodeURIComponent('<?=base64_encode($email)?>'),d:'<?=$info['domain']?>'},
					success: function(response){
						$btn.hide();
						$btn.removeAttr('disabled').html('<i aria-hidden="true" class="fa fa-floppy-o"></i>&nbsp;Save This Search');
						jQuery('.plsave').show().html('Search results successfully saved');
						jQuery('.saved').parents('li').remove();
					},
					error: function(){
						$btn.hide();
						$btn.removeAttr('disabled').html('<i aria-hidden="true" class="fa fa-floppy-o"></i>&nbsp;Save This Search');
					}
				});
			}else{
				alert('Please select the checkbox.');
			}
	  });
	  
	 jQuery('.btn-search').click(function(){
		 jQuery('.result-count').hide();
		 jQuery('#btn-dsave').hide();
		 jQuery('.alert3').hide();
		 jQuery('.plsave').hide();
		 jQuery('#search-result').html('');
		var city = encodeURIComponent(document.getElementById("city").value);
		var state = jQuery("#state").val();
		var zip = document.getElementById("zipcode").value;
		
		jQuery('.loc-alert').hide();
		
		if(empty(document.getElementById("keyword").value) && empty(document.getElementById("category").value)){
			jQuery('.alert1').html('<i style="display:none;" aria-hidden="true" class="fa fa-exclamation-circle"></i>&nbsp;Please enter keyword or select category').show();
			return false;
		}
		if(zip == '' && (city=='' || state=='')){
			if(zip=='' && city=='' && state ==''){
				jQuery('.alert2').html('<i style="display:none;" aria-hidden="true" class="fa fa-exclamation-circle"></i>&nbsp;Please enter zipcode or city and state').show();
			}else if(city==''){
				jQuery('.alert2').html('<i style="display:none;" aria-hidden="true" class="fa fa-exclamation-circle"></i>&nbsp;Please enter city').show();
			}else if(state ==''){
				jQuery('.alert2').html('<i style="display:none;" aria-hidden="true" class="fa fa-exclamation-circle"></i>&nbsp;Please enter state').show();
			}
			return false;
		}
		
		var strRequest = "/search/business/?Sort=value_distance" + 
			"&Latitude=" + 
			"&Longitude=" +
			"&City=" + city +
			"&State=" + state +
			"&PostalCode=" + zip +
			"&Radius=";
			//"&ANI=<?=$phone?>";
	
		if (!empty(document.getElementById("keyword").value)){
		   strRequest += "&Keyword=" + encodeURIComponent(document.getElementById("keyword").value);
		}
		
		if (!empty(document.getElementById("category").value)){
		   strRequest += "&Category=" + encodeURIComponent(document.getElementById("category").value);
		}
		jQuery('.loading-div').show();
		jQuery.ajax({
			type:"POST",
			beforeSend: function (request)
			{
				request.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
			},
			url: strRequest,
			success: function(obj) {
				jQuery('#search-result').html('');
				fill(obj);
			},
			complete:function(){
				jQuery('.loading-div').hide();
			},
			error: function(xhr, status, error) {
				jQuery('.loading-div').hide();
				if(xhr.responseText.indexOf('The ANI parameter value')>=1){
					jQuery('.alert3 h3').html('Your phone number is not valid. The values must be 10 digits with an optional leading 1 or +1.<br>Please update your <a href="/settings/">Account Settings.</a>');
					jQuery('.alert3').show();
				}else{
					alert(xhr.responseText);
				}
			}
		});
		savegroup(
			document.getElementById("keyword").value,
			document.getElementById("category").value,
			document.getElementById("city").value,
			jQuery("#state").val(),
			document.getElementById("zipcode").value
		);
		return false;
	 });
	  
  });
  
  function savegroup(keyword,category,city,state,zipcode)
  {
	  $.ajax({
			url: 'http://api1.contrib.co/search/savesearchGroups',
			type: 'POST',
			dataType : 'json',
			data: {
				keyword:encodeURIComponent(keyword),
				category:encodeURIComponent(category),
				city:encodeURIComponent(city),
				state:state,
				zipcode:zipcode,
				u:encodeURIComponent('<?=base64_encode($email)?>'),
				d:'<?=$info['domain']?>'
			},
			success: function(response){
			},
			error: function(){
			}
		});
  }
  
  <?php if(!empty($result)){?>
	fill();
  <?php } ?>
  function fill(obj)
  {
	if(obj!=undefined){
		if(obj.businesses.length>0){
			jQuery('.result-count').html('<i aria-hidden="true" class="fa fa-caret-right"></i>&nbsp;Showing '+obj.businesses.length+' Results').show();
		}else{
			jQuery('.result-count').html('<i aria-hidden="true" class="fa fa-caret-right"></i>&nbsp; No results found.').show();
		}
			
		  for(var i=0;i<obj.businesses.length;i++){
			var name = obj.businesses[i].name;
			var address = '';
			var info = '';
			if (obj.businesses[i].address.length > 0) address = obj.businesses[i].address;
			if (obj.businesses[i].city.length > 0 || obj.businesses[i].state.length > 0 || obj.businesses[i].zip.length > 0)
				info = obj.businesses[i].city + ", " + obj.businesses[i].state + " " + obj.businesses[i].zip;
			
			var url = obj.businesses[i]._links[0].href;
			var method = obj.businesses[i]._links[0].method;
			
			var result = '<li class="col-md-3">'+
				'<input class="chck" id="box'+i+'" type="checkbox" />'+
				'<label for="box'+i+'" class="offer-box">'+
					'<div class="text-capitalize">'+
						'<div class="pr"></div>'+
						'<div class="clearfix cfstyle"></div>'+
						'<h3 class="search-cat-box"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;'+
							'<span class="item-name">'+name+'</span>'+
						'</h3>'+
						'<h3 class="search-cat-address"><span class="item-address">';
						
						if(address!='')
							result += address;
						if(info!='')
							result += info;
						
						result += '</span></h3>'+
						'<a data-method="'+method+'" data-url="'+url+'" href="javascript:;" class="btn btn-info btn-block btn-lg callback"><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;'+
							'Get Phone No.'+
						'</a>'+
					'</div>'+
				'</label>'+
			'</li>';
			
			jQuery('#search-result').append(result);
		}
		
		
	}
	
	jQuery('.chck').off('change').on('change',function(){
		jQuery('.plsave').hide();
		if(jQuery('.chck:checked').length>0){
			jQuery('#btn-dsave').show();
		}else{
			jQuery('#btn-dsave').hide();
		}
	});
	
	jQuery('.callback').off('click').on('click',function(){
		var btnCallback = jQuery(this);
		btnCallback.attr('disabled', 'disabled').html("Loading...");
		console.log('Presented Business');
		jQuery.ajax({
			type:jQuery(this).attr('data-method'),
			beforeSend: function (request)
			{
				request.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
			},
			url: jQuery(this).attr('data-url'),
			success: function(obj) {
				try {
					getPhoneNumber( btnCallback, obj.data[0]._links[0].href, obj.data[0]._links[0].method);
					//getSelectedWithDetails(btnCallback, obj.data[0]._links[1].href, obj.data[0]._links[1].method);
				}  
				catch(err) {
					alert("Error: " + sResponse + err);
				}
			},
			error: function(xhr, status, error) {
				btnCallback.removeAttr('disabled').html('<i class="fa fa-phone" aria-hidden="true"></i>&nbsp;Get Phone No.');
			}
		});
	});
  }
  
  function getPhoneNumber(btn, scaCallBack, scaMethod) 
{
	console.log('getPhoneNumber');
	jQuery.ajax({
		type:scaMethod,
		beforeSend: function (request)
		{
			request.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
		},
		url: scaCallBack,
		success: function(obj) {
			try{
				var method = obj.data[0]._links[1].method;
				var url = obj.data[0]._links[1].href;
				GetCompletionNumber(btn,url,method);
			}catch(e){
				btn.removeAttr('disabled').html('<i class="fa fa-phone"></i> Call now');
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			btn.removeAttr('disabled').html('<i class="fa fa-phone"></i> Call now');
			alert('An error occurred please try again later. '+xhr.responseText);
		}
	});
}
  
  // To get the phone number, do the Selected, GetCompletionNumber, and CalledCompletionNumber callbacks
  // https://developer.soleo.com/docs/callback_sequence_for_monetization
function getPhoneNumber2(btn, scaCallBack, scaMethod) 
{
	console.log('getPhoneNumber');
	var request2 = new XMLHttpRequest();
	request2.open(scaMethod, scaCallBack, true);
	request2.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
	request2.onload = function (e) {
		if (request2.readyState === 4) {
			if (request2.status === 200) {
				var sResponse = request2.responseText;
				obj = JSON.parse(sResponse);
												
				var request3 = new XMLHttpRequest();
				request3.open(obj.data[0]._links[1].method, obj.data[0]._links[1].href, true);
				request3.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
				
				console.log('Get Completion Number');
				
				request3.onload = function (e) {
					if (request3.readyState === 4) {
						if (request3.status === 200) {
							var sResponse = request3.responseText;
							obj = JSON.parse(sResponse);
							if (obj.data[0].displayPhoneNumber === obj.data[0].completionPhoneNumber) {
								btn.replaceWith("<a class='item-phone' href='tel:" + obj.data[0].displayPhoneNumber + "'>" + '<i class="fa fa-phone"></i> '+
								phoneFormat(obj.data[0].displayPhoneNumber) + "</a>");
							}
							else {
								btn.replaceWith("<a class='item-phone' href='tel:" + obj.data[0].completionPhoneNumber + "'>" + '<i class="fa fa-phone"></i> '+
								phoneFormat(obj.data[0].completionPhoneNumber) + "</a>");
							}
				
							//Called Display Number Callback----------------------------------------------------------------
							console.log('Called Display Number Callback Request');
							var request4a = new XMLHttpRequest();
							request4a.open(obj.data[0]._links[0].method, obj.data[0]._links[0].href, true);
							request4a.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
							
							request4a.onload = function (e) {
								if (request4a.readyState === 4) {
									if (!request4a.status === 201) {
										alert("Error recording call display number: " + request4a.readyState);
									}
								}
								
								/*
								setTimeout(function(){
								//Called Completion Number----------------------------------------------------------------
								console.log('Called Completion Number Callback');
								var request4 = new XMLHttpRequest();
								request4.open(obj.data[0]._links[1].method, obj.data[0]._links[1].href, true);
								request4.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
								
								request4.onload = function (e) {
									if (request4.readyState === 4) {
										if (!request4.status === 201) {
											alert("Error recording call completion: " + request4.readyState);
										}
									}
								}
								request4.send();
								//----------------------------------------------------------------------------------------
								},2000);
								*/
							}
							request4a.send();
							//----------------------------------------------------------------------------------------
							
							
						}
					}
				}
			}
		}
		try {
			request3.send();
		} catch(err) {}
	}
	request2.send();             
  }

function getSelectedWithDetails(btn, scaCallBack, scaMethod)
{
	jQuery.ajax({
		type:scaMethod,
		beforeSend: function (request)
		{
			request.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
		},
		url: scaCallBack,
		success: function(obj) {
			
		},
		error: function (xhr, ajaxOptions, thrownError) {
			
		}
	});
}	
  
function getPhoneNumberex(btn, scaCallBack, scaMethod) 
{
	console.log('getPhoneNumber');
	jQuery.ajax({
		type:scaMethod,
		beforeSend: function (request)
		{
			request.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
		},
		url: scaCallBack,
		success: function(obj) {
			try{
				if(obj.data[0]._links.length>1){
					var method = obj.data[0]._links[1].method;
					var url = obj.data[0]._links[1].href;
				}
				GetCompletionNumber(btn,url,method);
			}catch(e){
				//btn.removeAttr('disabled').html('Get Phone No.');
				btn.replaceWith('Phone number not available');
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			btn.removeAttr('disabled').html('<i class="fa fa-phone" aria-hidden="true"></i>&nbsp;Get Phone No.');
			alert('An error occurred please try again later. '+xhr.responseText);
		}
	});
}

function GetCompletionNumber(btn, scaCallBack, scaMethod) 
{
	console.log('GetCompletionNumber');
	jQuery.ajax({
		type:scaMethod,
		beforeSend: function (request)
		{
			request.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
		},
		url: scaCallBack,
		success: function(obj) {
			btn.removeAttr('disabled').html('<i class="fa fa-phone" aria-hidden="true"></i>&nbsp;Get Phone No.');
			if (obj.data[0].displayPhoneNumber === obj.data[0].completionPhoneNumber) {
				btn.replaceWith("<a class='item-phone' href='tel:" + obj.data[0].displayPhoneNumber + "'>" + '<i class="fa fa-phone"></i> '+
					phoneFormat(obj.data[0].displayPhoneNumber) + "</a>");
			}else {
				btn.replaceWith("<a class='item-phone' href='tel:" + obj.data[0].completionPhoneNumber + "'>" + '<i class="fa fa-phone"></i> '+
					phoneFormat(obj.data[0].completionPhoneNumber) + "</a>");
			}
			CalledCompletionNumber(obj.data[0]._links[1].href, obj.data[0]._links[1].method);
		},
		error: function (xhr, ajaxOptions, thrownError) {
			btn.removeAttr('disabled').html('<i class="fa fa-phone" aria-hidden="true"></i>&nbsp;Get Phone No.');
			alert('An error occurred please try again later. '+xhr.responseText);
		}
	});
}

function CalledCompletionNumber(scaCallBack, scaMethod)
{
	console.log('CalledCompletionNumber');
	var request4 = new XMLHttpRequest();
	request4.open(scaMethod, scaCallBack, true);
	request4.setRequestHeader("Accept","application/vnd.api.soleo.com-v1+json");
	request4.onload = function (e) {
		if (request4.readyState === 4) {
			if (!request4.status === 201) {
				alert("Error recording call completion: " + request4.readyState);
			}else{
				console.log('CalledCompletionNumber successful!');
			}
		}
	}
	request4.send();
}

function phoneFormat(phone) {
	phone = phone.replace(/[^0-9]/g, '');
	phone = phone.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3");
	return phone;
}

function empty(data)
{
  if(typeof(data) == 'number' || typeof(data) == 'boolean')
  { 
    return false; 
  }
  if(typeof(data) == 'undefined' || data === null)
  {
    return true; 
  }
  if(typeof(data.length) != 'undefined')
  {
    return data.length == 0;
  }
  var count = 0;
  for(var i in data)
  {
    if(data.hasOwnProperty(i))
    {
      count ++;
    }
  }
  return count == 0;
}
  </script>
 <?php include('footer.php'); ?>  