	<!-- -->
					<table id="shistory" class="table table-striped table-bordered" cellspacing="0" width="100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Category</th>
								<th>Keyword</th>
								<th>City</th>
								<th>State</th>
								<th>Zipcode</th>
								<th>Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
								<th>ID</th>
								<th>Category</th>
								<th>Keyword</th>
								<th>City</th>
								<th>State</th>
								<th>Zipcode</th>
								<th>Date</th>
								<th>Action</th>
							</tr>
						</tfoot>
						<tbody>
							<?php if (count($searches)>0):?>
								<?php foreach ($searches as $key=>$val):?>
									<tr>
										<td><?php echo $val['group_id']?></td>
										<td><?php echo $val['category']?></td>
										<td><?php echo $val['keyword']?></td>
										<td><?php echo $val['city']?></td>
										<td><?php echo $val['state']?></td>
										<td><?php echo $val['zipcode']?></td>
										<td>
										<?php 
											$phpdate = strtotime( $val['date'] );
											$mysqldate = date( 'm/d/Y', $phpdate );
										?>
										
										<?php echo $mysqldate?></td>
										<td>
											<a href="<?php echo BASE_URL?>search/result/<?php echo $val['name']?>" class="btn btn-info btn-sm sm2">												
												View
											</a>
											<a  data="<?php echo $val['group_id']?>" class="btn btn-danger btn-sm sm2 btn-hist-del">
												Delete
											</a>
										</td>
									</tr>
								<?php endforeach;?>
							<?php endif?>
														
						</tbody>
					</table>
					<!-- -->
<script>
$(document).ready(function() {
    $('#shistory').DataTable();

	jQuery('#shistory tbody').delegate("tr td:nth-child(8) .btn-hist-del ", "click", function() {
		var hid = $(this).attr('data');
		 var div = jQuery(this).parents('tr');
		$.post('http://api1.contrib.co/search/deletesearch',
				 {
				    'group_id':hid
				    
				 }
				 ,function(data){
					 div.fadeOut(); 
				 }
		   );
		 
	});
	
} );
</script>					