 <?php include('header.php'); ?>
<style>
.signin-container .btn-warning {
	color:#fff;
}
.signin-container a {
	color:#999;
}
.signin-container a:hover {
	color:#fff;
}

.m-alert-box {
	color:#555;
	border-radius:5px;
	font-family:Tahoma,Geneva,Arial,sans-serif;font-size:13px;
	padding:10px 36px;
	margin:0px 0px 10px 0px;
}
.m-error {
	background:#ffecec url('<?php echo BASE_URL?>img/error.png') no-repeat 10px 50%;
	border:1px solid #f5aca6;
}
.m-success {
	background:#e9ffd9 url('<?php echo BASE_URL?>img/success.png') no-repeat 10px 50%;
	border:1px solid #a6ca8a;
}
.search-panel-outer {
    margin-top: 80px;
    margin-bottom: 140px;
    background: #0559B7;
    border-radius: 3px;
}
</style>  
      <div class="container">
        <?php include('navigation.php'); ?>
      <div class="row header-search">
          <div class="col-sm-6 col-sm-offset-3 text-center search-panel-outer">
            <h1 class="wow fadeIn">Sign In</h1>
            <div class="search-panel">
				<div class="row">
					<div class="col-md-12 signin-container">
					<div class="alert alert-danger fade in" id="signin_error" style="display: none">
    					
					</div>
						
						<input type="text" class="form-control" id="sign_email" name="sign_email" placeholder="Email">
						<input type="password" class="form-control" id="sign_password" name="sign_password" placeholder="Password">
						<a id="btn-signin-<?php echo $time?>" class="btn btn-warning btn-lg btn-block">Sign In</a>
						<hr>
						<a href="<?php echo BASE_URL?>signup">Don't have an account? Sign Up</a><br>
						<a id="btn-forget-password-<?php echo $time?>" style="cursor:pointer">Forgot Password</a>
						
						<div id="forgotModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
						  <div class="modal-dialog" role="document">
							<div class="modal-content" style="padding: 30px;">
							  <h4>Enter your registered email and we will send you instructions to reset your password</h4>
							  <input type="text" class="form-control" id="forgot_email"  name="forgot_email" placeholder="Enter Your Registered Email Here">
							  <input type="hidden" class="form-control" id="forgot_domain"  name="forgot_domain" value="<?php echo $info['domain']?>">
							  <a id="btn-send-password-<?php echo $time?>" class="btn btn-warning btn-lg btn-block">Send My Login Details</a>
							  <div id="forgot-alert">
								  <div class="m-alert-box m-error" id="m-error" style="display:none"><span>Error: </span>Write your error message here.</div>
								  <div class="m-alert-box m-success" id="m-success" style="display:none"><span>Success: </span>Write your success message here.</div>
							  </div>
							</div>
						  </div>
						</div>
						<!-- -->
					</div>									
				</div>
			</div>
          </div>
        </div>
      </div>
 <input type="hidden" name="dotime" id="dotime" value="<?php echo $time?>">  
 <input type="hidden" name="sign_domain" id="sign_domain" value="<?php echo $info['domain']?>">  
 <script src="<?php echo BASE_URL; ?>js/signin.js"></script> 
 <?php include('footer.php'); ?>  