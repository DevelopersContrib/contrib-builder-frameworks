<div class="row">
		  <div class="col-xs-6">
           <?php if ($info['logo']!= ''):?>
		<a href="<?php echo BASE_URL?>home"><img class="search-logo" src="<?php echo $info['logo']?>" alt="<?php echo ucfirst($info['domain'])?> Logo" title="<?php echo ucfirst($info['domain'])?> Logo"></a>
			<?php else:?>
		<a href="<?php echo BASE_URL?>home"><h2><?php echo ucfirst($info['domain'])?></h2></a>
		
	<?php endif?>
  </div>
		  <div class="col-xs-6 signin text-right navbar-nav user"> 
			<a href="<?php echo BASE_URL?>home"><i class="fa fa-star" aria-hidden="true"></i>&nbsp;My Leads</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="<?php echo BASE_URL?>search" class="tsearch"><i class="fa fa-search" aria-hidden="true"></i>
				Search
			</a>
			<ul class="nav navbar-nav">				
				<li class="dropdown">				  
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Welcome, <b><?php echo $user_name?></b>&nbsp;<i class="fa fa-caret-down" aria-hidden="true"></i></a>
				  <ul class="dropdown-menu">
					<li><a href="<?php echo BASE_URL?>settings"><i class="fa fa-gear" aria-hidden="true"></i>&nbsp;Account Settings</a></li>					
					<li class="divider"></li>
					<li><a href="<?php echo BASE_URL?>signout"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;Sign Out</a></li>
				  </ul>
				</li>
			  </ul>

		  </div>
		</div>