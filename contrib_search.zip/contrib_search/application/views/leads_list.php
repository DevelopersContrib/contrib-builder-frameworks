<?php if (count($leads)>0):?>
 <?php foreach ($leads as $key=>$val):?>
	<li class="col-md-3" id="li-leads">		
		<div class="text-capitalize offer-box">	
			<small class="pull-left lstats"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;<span id="lead-status-<?php echo $val['id']?>"><?php echo $val['status']?></span></small>
			<a href="javascript:;" class="ldelete leaddelete" data="<?php echo $val['id']?>" data-placement="top" title="Delete Entry" >
				<i class="fa fa-trash-o" aria-hidden="true"></i>
			</a>
			<a href="javascript:;" data-placement="top" title="Update Status" class="lupdate leadupdate" id="tlupdate-<?php echo $val['id']?>" data="<?php echo $val['id']?>-<?php echo $val['status_id']?>" >
			<i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;
			</a>
			<hr>
			<h3 class="search-cat-box"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;
				<?php echo $val['name']?>
			</h3>
			<h3 class="search-cat-address"><i class="fa fa-location-arrow" aria-hidden="true"></i>&nbsp;
				<?php echo $val['address']?> 
			</h3>
				<h3 class="search-cat-phone"><i class="fa fa-phone-square" aria-hidden="true"></i>
				<?php if ($val['contact_number'] != ""):?>
					<?php echo $val['contact_number']?>
					<?php else:?>
					(no phone)
				<?php endif?>
		
				</h3>
			
		</div>
	</li>
	<?php endforeach;?>			
	<?php else:?>
	  <?php if ($search!=""):?>
	  	<div class="m-alert-box m-error" id="m-error" ><span></span>No leads found on search.</a></div>
	     <?php else:?>
	      <?php if ($status!=""):?>
	     	<div class="m-alert-box m-error" id="m-error" ><span></span>No leads found on search.</a></div>
	     	<?php else:?>
	         <div class="m-alert-box m-error" id="m-error" ><span></span>You don't have any leads saved. <a href="<?php echo BASE_URL?>search">Search Now!</a></div> 	
	     <?php endif?>
	       
	  <?php endif?>
	  		
<?php endif?>
<!-- Modal -->
<div class="modal fade" id="deleteLead" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">      
      <div class="modal-body">
        Are you sure you want to delete this lead?
      </div>
      <div class="modal-footer">
        <input type="hidden" name="lead-delete-id" id="lead-delete-id" value="">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" onclick="deleteLead();">Delete</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="updateStat" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">      
      <div class="modal-body">
        <select class="form-control" id="lead-update-status">
		  <?php foreach ($status as $key=>$v):?>
		  	<option value="<?php echo $key?>"><?php echo $v?></option>
		  <?php endforeach;?>
		</select>
      </div>
      <div class="modal-footer">
        <input type="hidden" name="lead-update-id" id="lead-update-id" value="">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" onclick="updateLead()">Update</button>
      </div>
    </div>
  </div>
</div>						

<script>
jQuery(document).ready(function(){
	$( "li#li-leads .offer-box .leaddelete" ).each(function( index ) {
		  $(this).click(function(){
			    var id = $(this).attr('data');
				$('#lead-delete-id').val(id);
				$('#deleteLead').modal('show');
			});
		});

	$( "li#li-leads .offer-box .leadupdate" ).each(function( index ) {
		  $(this).click(function(){
			  	var result = $(this).attr('data').split('-');
			    var id = result[0];
			    var s_id = result[1];
				$('#lead-update-id').val(id);
				$("#lead-update-status").val(s_id);
				$('#updateStat').modal('show');
				
			});
		});
});

function deleteLead(){
	$('#preloader').show();
	var lead_id = $('#lead-delete-id').val();
	$.post('http://api1.contrib.co/search/deletelead',
			 {
			    'lead_id':lead_id
			    
			 }
			 ,function(data){
				 $('#deleteLead').modal('hide');
				 if (data.data.status){
					 loadPages(1,'');
				 }else {
					
				 }
			 }
	   );
}


function updateLead(){
	var lead_id = $('#lead-update-id').val();
	var status_id = $('#lead-update-status').val();
    var status = $("#lead-update-status option:selected").text();
    $.post('http://api1.contrib.co/search/updatestatus',
			 {
			    'lead_id':lead_id,
			    'status_id':status_id
			    
			 }
			 ,function(data){
				 $('#lead-status-'+lead_id).text(status);
				 $('#tlupdate-'+lead_id).attr('data',lead_id+'-'+status_id);
				 $('#updateStat').modal('hide');
			 }
	   );
	
}
</script>	