 <?php include('header.php'); ?>
<script src="<?php echo BASE_URL; ?>js/jquery.maskedinput.js" type="text/javascript"></script> 
 <style>
.account-container .btn-warning {
	color:#fff;
}
.account-container a {
	color:#999;
}
.account-container a:hover {
	color:#fff;
}
.left-ac {
	border-left: 1px solid rgb(85, 85, 85);
}
.disabledInput {
	background: #bbb;
}
.navbar-nav {
	float: right !important;
}
.nav > li > a:focus, .nav > li > a:hover {
    text-decoration: none;
    background: none !important;
	color:rgb(76,186,219);
}
.m-alert-box {
	color:#555;
	border-radius:5px;
	font-family:Tahoma,Geneva,Arial,sans-serif;font-size:13px;
	padding:10px 36px;
	margin:0px 0px 10px 0px;
}
.m-error {
	background:#ffecec url('<?php echo BASE_URL?>img/error.png') no-repeat 10px 50%;
	border:1px solid #f5aca6;
}
.m-success {
	background:#e9ffd9 url('<?php echo BASE_URL?>img/success.png') no-repeat 10px 50%;
	border:1px solid #a6ca8a;
}
</style> 
      <div class="container">
        <?php include('navigation_login.php'); ?>
       <div class="row header-search">
          <div class="col-sm-8 col-sm-offset-2 text-center search-panel-outer">
            <h1 class="wow fadeIn"><i class="fa fa-cog" aria-hidden="true"></i>&nbsp;Account Settings</h1>
            <div class="search-panel">
				<div class="row">
					<div class="col-md-12">
						<div class="m-alert-box m-error" id="m-error" style="display:none"><span>Error: </span>Write your error message here.</div>
						<div class="m-alert-box m-success" id="m-success" style="display:none"><span>Success: </span>Write your success message here.</div>
					</div>
					<div class="col-md-6 account-container">
						<input type="text" id="set_name" name="set_name" class="form-control" value="<?php echo $user['name']?>">			
						<input type="text" class="form-control disabledInput" value="<?php echo $email?>" disabled>
						<input type="text" id="set_phone" name="set_phone" class="form-control" value="<?php echo $user['phone_number']?>">		
							
						<a id="btn-settings-update<?php echo $time?>" class="btn btn-warning btn-lg btn-block">Update</a>
					</div>
					<div class="col-md-6 account-container left-ac">
						<input type="password" id="set_password" name="set_password" class="form-control" value="<?php echo base64_decode($user['password'])?>">
						<input type="password" id="set_password2" name="set_password2" class="form-control" value="<?php echo base64_decode($user['password'])?>">
						<a id="btn-password-update<?php echo $time?>" class="btn btn-warning btn-lg btn-block">Change Password</a>						
					</div>					
				</div>
			</div>
          </div>
        </div>
      </div>
  <input type="hidden" name="dotime" id="dotime" value="<?php echo $time?>">    
  <input type="hidden" name="set_member" id="set_member" value="<?php echo $user['member_id']?>">       
 <script src="<?php echo BASE_URL; ?>js/settings.js"></script>     
 <?php include('footer.php'); ?>  