<!DOCTYPE html>
<html lang="en"><head>
  <meta charset="utf-8">
  <title><?php echo $info['title']?></title>
  <meta name="keywords" content="<?php echo $info['title']?>">
  <meta name="description" content="<?php echo $info['description']?>">
  <meta name="keywords" content="<?php echo $info['keywords']?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!-- Styles -->
  <link rel="stylesheet" href="<?php echo BASE_URL?>css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo BASE_URL?>css/animate.css">
  <link rel="stylesheet" href="<?php echo BASE_URL?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo BASE_URL?>css/main.css">
  <script src="<?php echo BASE_URL?>js/modernizr-2.7.1.js"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="<?php echo BASE_URL?>js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.1/themes/smoothness/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.11.1/jquery-ui.js"></script>
	
  	 
  <script>
			  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

			  ga('create', '<?php echo $info['account_ga']?>', '<?echo $info['domain']?>');
			  ga('send', 'pageview');
</script>
		
<script type="text/javascript">
	  var _paq = _paq || [];
	  _paq.push(['trackPageView']);
	  _paq.push(['enableLinkTracking']);
	  (function() {
		var u="//www.stats.numberchallenge.com/";
		_paq.push(['setTrackerUrl', u+'piwik.php']);
		_paq.push(['setSiteId', <?echo $info['piwik_id']?>]);
		var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
		g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
	  })();
	</script>
	<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?echo $info['piwik_id']?>" style="border:0;" alt="" /></p></noscript>	
  <style>
header {
	padding: 0px;
}
.search-logo {
	height: 65px;
}
.navbar-nav a {    
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
}
 .pro-links {
    columns: 4;
    -webkit-columns: 4;
    -moz-columns: 4;
	padding-left: 0px;
	list-style-type: none;
}
.m-alert-box {
	color:#555;
	border-radius:5px;
	font-family:Tahoma,Geneva,Arial,sans-serif;font-size:13px;
	padding:10px 36px;
	margin:0px 0px 10px 0px;
}
.m-error {
	background:#ffecec url('<?php echo BASE_URL?>img/error.png') no-repeat 10px 50%;
	border:1px solid #f5aca6;
}
.m-success {
	background:#e9ffd9 url('<?php echo BASE_URL?>img/success.png') no-repeat 10px 50%;
	border:1px solid #a6ca8a;
}
.hero-container {
    background: linear-gradient(rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.75)), rgba(0, 0, 0, 0.75) url("https://rdbuploads.s3.amazonaws.com/backgrounds/city-wallpaper.jpg") !important;
    background-repeat: no-repeat !important;
    background-size: cover !important;
    padding: 20px 0px 60px;
}
.search-panel .sbox {
    background: rgba(241, 242, 248, 0.3) !important;
	margin-bottom: 10px;
}
.search-panel .form-control {
    border: none;
    margin-bottom: 10px;
    box-shadow: none;
}
.hero-container .domain-title {
	color: #fff !important;
}
.b-section {
    background: linear-gradient(-90deg,#044389,#055bbb) !important;
}
.search-panel {
    padding: 0px 30px 10px;
}
.footer-dark-1 {
    background-color: #222 !important;
}
.footer-dark-2 {
    background-color: #111 !important;
}
  </style>
</head>
<body>
        
    <header>
    <input type="hidden" name="base_url" id="base_url" value="<?php echo BASE_URL?>">