 <?php include('header.php'); ?>
<style>
.page-container {
 background:#fff;
 padding: 30px 30px;
}
.header-search {
	padding: 70px 0px;
}
.r-success {
	font-size: 19px;
}
</style>
      <div class="container">
        <?php include('navigation.php'); ?>
       <div class="row header-search">
		  <h2 class="text-center">Congratulations!</h2>	
          <div class="col-sm-6 col-sm-offset-3 text-center page-container">
			  <h3 class="text-center r-success">You have successfully completed the registration. <br>Welcome to <?php echo ucfirst($info['domain'])?>.</h3>
			  <?php if ($group_name !=""):?>
			  <a href="<?php echo BASE_URL?>search/result/<?php echo $group_name?>" class="btn btn-warning btn-lg">Continue</a>
			  <?php else:?>
			  <a href="<?php echo BASE_URL?>search" class="btn btn-warning btn-lg">Continue</a>
			  <?php endif?>
			  <hr>
			  <h3 class="text-center">Please Check Your Email to Verify Your Account</h3>
		  </div>
        </div>
      </div>
 <?php include('footer.php'); ?>  