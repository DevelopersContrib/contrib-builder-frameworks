 <?php include('header.php'); ?>
 <style>
.page-container {
 background:#fff;
 padding: 30px 30px;
}
.header-search {
	padding: 70px 0px;
}
.r-success {
	font-size: 19px;
}
.u-email {
	color:blue;
}
</style>
      <div class="container">
        <?php include('navigation.php'); ?>
		<div class="row header-search">
		  <h2 class="text-center">Account Verification!</h2>	
          <div class="col-sm-6 col-sm-offset-3 text-center page-container">
			  <?php if ($status):?>
				  <h3 class="text-center r-success">You have successfully verified your account. <br>Welcome to <?php echo ucfirst($info['domain'])?>.</h3>
				  <a href="<?php echo BASE_URL?>signin/autologin/?code=<?php echo $code?>&group=0" class="btn btn-warning btn-lg">Continue</a>
			   <?php else:?>
			  	 <h3 class="text-center r-success"><?php echo $message?></h3>
				  <a href="<?php echo BASE_URL?>signin" class="btn btn-warning btn-lg">Signin</a>
			  <?php endif?>
			  <hr>
			
		  </div>
        </div>
      </div>
 <?php include('footer.php'); ?>  