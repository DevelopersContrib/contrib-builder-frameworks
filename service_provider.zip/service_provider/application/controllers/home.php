<?php

class Home extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$relatedsiteswithlogo = $api->relatedsiteswithlogo();
		$relatedsitesnologo = $api->relatedsitesnologo();
		$premiumcontractors = $api->getpremiumcontractors();
		$latestcontractors = $api->getlatestcontractors();
		$title = 'Home';
		$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
		$template = $this->loadView('index');
		$template->set('title',$title);
		$template->set('countriesarray',$countriesarray);
		$template->set('rolesarray',$rolesarray);
		$template->set('latestcontractors',$latestcontractors);
		$template->set('industriesarray',$industriesarray);
		$template->set('parnershiptypes',$parnershiptypes);
		$template->set('relatedsiteswithlogo',$relatedsiteswithlogo);
		$template->set('relatedsitesnologo',$relatedsitesnologo);
		$template->set('premiumcontractors',$premiumcontractors);
		$template->set('info', $info);
		$template->set('projecttypes',$projecttypes);
		$template->set('programs',$api->getprograms());
		$template->render();
	}
    
}

?>