<?php

class Referral extends Controller {



	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('referral');
		$template->set('title', 'Referral');
		$template->set('info', $info);
		$template->render();
	
	}


}