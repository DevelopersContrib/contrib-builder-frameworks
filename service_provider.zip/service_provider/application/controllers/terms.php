<?php

class Terms extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('terms');
		$template->set('info', $info);
		$template->set('title', 'Terms and Condition');
		$template->render();
	
	}

}