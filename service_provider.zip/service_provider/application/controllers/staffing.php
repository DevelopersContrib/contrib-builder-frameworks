<?php

class Staffing extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$template = $this->loadView('staffing');
		$template->set('title', 'Apply');
		$template->set('info', $info);
		$template->render();
	
	}

}