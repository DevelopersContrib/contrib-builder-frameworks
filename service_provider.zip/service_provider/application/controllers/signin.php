<?php

class Signin extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$projecttypes = $api->getprojecttypes();
		$relatedsiteswithlogo = $api->relatedsiteswithlogo();
		$relatedsitesnologo = $api->relatedsitesnologo();
		$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
		$template = $this->loadView('signin');
		$template->set('countriesarray',$countriesarray);
		$template->set('rolesarray',$rolesarray);
		$template->set('industriesarray',$industriesarray);
		$template->set('parnershiptypes',$parnershiptypes);
		$template->set('relatedsiteswithlogo',$relatedsiteswithlogo);
		$template->set('relatedsitesnologo',$relatedsitesnologo);
		$template->set('info', $info);
		$template->set('projecttypes',$projecttypes);
		$template->set('programs',$api->getprograms());
		$template->render();
	}

	    
}

?>