<?php

class Apps extends Controller {

	function index(){
	
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$title = 'Apps';
		$template = $this->loadView('apps');
		$template->set('title',$title);
		$template->set('info', $info);
		$template->render();
	
	}

}