<?php include('includes/header.php');?>
	<div class="sp-head-container">
		<div class="sp-color-bg">
			<div class="container">
			  <div class="row">
				<div class="col-md-12 text-center">
					<h1>
						Join as Handyman’s Premium Service Provider 
					</h1>
					<p>
						We give you customers, and tools to grow your business. Quote your price. Keep what you earn.
					   
					</p>
					 <?php foreach($projecttypes as $array):?>
						<?php foreach ($array as $key => $value): ?>
							 <form class="form-inline form-s1 formproject" role="form" action="http://www.handyman.com/serviceprovider/signup/pid/<?php echo $value['ProjectTypeId']?>/n/<?php echo $value['Name'] ?>" method="post" id="search-theme-form">
						<?php endforeach ?>
				 <?php endforeach;?>					
					<div class="form-inline2">
					  <div class="form-group">
						<div class="input-group">
							<select class="form-control comboproject" name="project" id="project">
								<option value="">Select Business Type</option>
									<?php
											foreach($projecttypes as $array)
											{
												foreach($array as $key => $info2)
												{
												  echo '<option value="'.$info2['ProjectTypeId'].'">'.$info2['Name'].'</option>';
												}
											}
										?>
							</select>
						</div>
					  </div>
					  <button type="submit" id="getstarted" class="btn btn-danger">Get Started</button>
					</div>
					</form>
				</div>
			  </div>
			</div>
		</div>
	</div>
	
	<div class="sp-mid-container">
		<div class="container">
			<div class="row">
				<div class="col-md-4 text-center">
					<div class="sp-mid-box">
						<span class="sp-mid-step">1</span>
						<div class="sp-mid-shot"></div>
						<h3>Create Your Service <br>Provider Page</h3>
						<p>Signup and create your service <br>provider page</p>
					</div>
				</div>
				<div class="col-md-4 text-center">
					<div class="sp-mid-box">
						<span class="sp-mid-step">2</span>
						<div class="sp-mid-shot"></div>
						<h3>Receive Daily Leads From <br>Your City</h3>
						<p>Get daily leads from home owners <br>in your city</p>
					</div>
				</div>
				<div class="col-md-4 text-center">
					<div class="sp-mid-box">
						<span class="sp-mid-step">3</span>
						<div class="sp-mid-shot"></div>
						<h3>Get Free Business <br>Tools</h3>
						<p>Ultimately add more revenue with our free <br>business and referral tools</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="sp-subfooter-container">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h2 class="sp-sub-title">Why Join Handyman.com?</h2>
					<p>We give contractors a voice and provide resources to help them grow. </p>
				</div>
				<div class="col-md-4 text-center">
					<div class="sp-foot-box">
						<div class="sp-foot-shot-one"></div>
						<p><b>Handyman.com</b> provides channel sales and management programs for home owners, contractors, builders, realtors, service providers, suppliers and entrepreneurs through its premium global platforms. By extending and integrating your product and service offerings, Handyman.com allows our members the hassle free ability to reach and service new customers.</p>
					</div>
				</div>
				<div class="col-md-4 text-center">
					<div class="sp-foot-box">
						<div class="sp-foot-shot-two"></div>
						<p><b>Handyman.com</b> succeeds on leveraging the strengths of our industry leading partnerships and simple yet powerful online tools. To deliver our solution to customers, we have forged alliances with some of the top technology and service companies in the business. </p>
					</div>
				</div>
				<div class="col-md-4 text-center">
					<div class="sp-foot-box">
						<div class="sp-foot-shot-three"></div>	
						<p><b>Handyman.com</b> program is free and open to qualified and select construction and home improvement service providers. Members of Handyman.com should be dedicated to offering a community of competitive prices, great product and service packages and superior customer service. We strive to help our members provide a great value to your current and future customer base.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="sp-handy-container">
		<div class="container">
			<div class="row">
				<div class="col-md-4">					
					<div class="sp-handy-box text-center">
						<div class="shc-title"><h3>Are you a contractor, architect, property manager or service provider?</h3></div>
						<div class="shc-desc">
							<p>Receive online ratings and reviews from satisfied customers to boost your company reputation. 
							Get your free contractor or homeowner webpage and manage your services with improved efficiency and in real time, anywhere in the world. A few examples include remodel, renovation, maintenance, management and “Before and After” images. Handyman.com offers you free, no obligation project tools and property management software.
							</p>
						</div>
						<div class="shc-btn"><a href="http://handyman.com/contractor/signup" class="btn btn-danger">Get Started Now!</a></div>
					</div>
				</div>
				<div class="col-md-4">
					<img class="img-responsive" src="http://rdbuploads.s3.amazonaws.com/photodune-472368-architect-and-contractor-xs.jpg">
				</div>
				<div class="col-md-4">
					<div class="sp-handy-box text-center">
						<div class="shc-title"><h3>Are you a Home Owner or Real Estate Investor?</h3></div>
						<div class="shc-desc">
							<p>
							Get your free Homeowner Webpage and build an interactive virtual version of your custom home on line or manage your property listings. You will be able to add service requests such as restoration, home repairs, rate developers, or consult with a real estate agent as well as “Before and After” images or show off special features on your property. Handyman.com will provide you with a full list of installers, hardwood floor professionals, electricians, painters, plumbers, just to name a few as well as home repair tips, home designs and new hometech products and services.
							</p>
						</div>
						<div class="shc-btn"><a href="http://handyman.com/contractor/signup" class="btn btn-danger">Find your local Handyman today!</a></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="sp-featured-contractors">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h2 class="sp-sub-title sst">Featured Contractors </h2>
				</div>				
				<div class="col-md-12">
					<ul class="list-inline text-center fadeDivUl">
					   <?php if ($premiumcontractors > 0): ?>
					   		<?php foreach ($premiumcontractors as $array): ?>
					   			 <?php foreach ($array as $key => $value): ?>
					   			<li class="item">
									<div class="fc-box">
										<div class="col-md-7 text-left">
											<div class="fc-desc-box">
												<h3><img src="http://image.flaticon.com/icons/png/128/33/33332.png" class="ct-icon2"><a href="http://www.handyman.com/contractor/profile/user/<?php echo $value['slug']?>"><?php echo $value['Name']; ?></a></h3>
												<p class="plimit"><?php echo $value['AboutBusiness']; ?> </p>
												<h4>Services</h4>
												<p class="plimit2"><?php echo $value['Services']; ?> </p>
											</div>
										</div>
										<div class="col-md-5">
											<img src="http://www.handyman.com//uploads/gallery/<?php echo $value['filename']; ?>" class="img-responsive fc-image-box">
										</div>
										<div class="clearfix"></div>
									</div>
							</li>
							  <?php endforeach ?>
					   		<?php endforeach ?>
					   <?php endif ?>
					</ul>					
				</div>
			</div>
		</div>
	</div>
	
	<div class="sp-latest-contractors">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h2 class="sp-sub-title sst sst2">Our Latest Contractors </h2>
					<p class="slc-desc">We have thousands of contractors available for you that are experts. Let us match you with a Handyman expert today.</p>
				</div>
				<div class="col-md-12">
					<div class="contractors-list">
						<div class="row">
							<div>
								<?php
									foreach($latestcontractors AS $array){?>
									<?php foreach ($array as $key => $value): ?>
								<li class="col-md-6">
									<div class="row rower">
										<div class="col-md-10">
											<h3 class="contractor-title">
											<img src="http://image.flaticon.com/icons/png/128/33/33332.png" class="ct-icon">
											&nbsp;<a data-id="<?php echo $value['ContractorId']?>" target="_blank" href="http://www.handyman.com/contractor/profile/user/<?php echo $value['slug']?>"><?php echo $value['Name'];?></a></h3>
											<p class="contractor-desc"><?php echo $value['AboutBusiness']?></p>
										</div>
										<div class="col-md-2 text-center">
											<div id="badgeRibbon">
											<h5 class="con-rating">
												Points<br>
											<b>
											<?php 
											    $points = $value['points'];
										     	echo $var_is_greater_than_two = ($points = 0 ?  '0' : $points); // returns true
											?></b>
											</h5>

											</div>
										</div>
									</div>
								</li>
									<?php endforeach ?>
									<?php 
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	
	
	<?php include('includes/footer.php');?>
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>	
	<script>
	
	</script>
  </body>
</html>
<script type="text/javascript">

		jQuery(document).ready(function(){
		$ds = jQuery('ul.fadeDivUl li');
		$ds.hide().eq(0).show();
		setInterval(function(){
			$ds.filter(':visible').fadeOut(function(){
				var $div = jQuery(this).next('li');
				if ( $div.length == 0 ) {
					$ds.eq(0).fadeIn();
				} else {
					$div.fadeIn();
				}
			});
		}, 10000);

		$( ".comboproject" ).change(function() {
			var id = $('.comboproject').val();
			//var value = $('.comboproject').text();
			var e = document.getElementById("project");
			var strUser = e.options[e.selectedIndex].text;
			var slug = convertToSlug(strUser);
			var base_url = 'http://www.handyman.com';
			document.getElementById("search-theme-form").action = base_url+"/serviceprovider/signup/pid/"+id+"/n/"+slug;
		});

			function convertToSlug(Text) {
    	return Text.toLowerCase()
			.replace(/[^\w ]+/g,'')
				.replace(/ +/g,'-');
	}	
    });

</script>