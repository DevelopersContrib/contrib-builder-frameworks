<?php include('includes/header.php');?>
<link rel="stylesheet" href="/static/css/forms.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<style>
.navbar {
    margin-bottom: 0px;
}
.sp-signup-container {
	background:linear-gradient(rgba(0, 0, 0, 0.65),rgba(0, 0, 0, 0.65)), url('http://rdbuploads.s3.amazonaws.com/sp-handyman.jpg');
	background-size: cover;
	background-attachment:fixed;
	padding: 50px 0px 180px;
}
.sp-signup-container .flora-container {
	border: 1px solid maroon;
	border-radius: 4px;
}
.sp-signup-container .floraforms .frm-header {
    background: #fff;
}
.sp-signup-container .floraforms .frm-footer {
    padding: 10px 0px 20px;
    background: #fafafa;
}
.sp-signup-container .progress-bar {
    line-height: 15px;
	background:#337ab7;
}
.copyrightContain {
    background: #222;
    margin-top: -20px;
    font-size: 11px;
    color: #ccc;
}
.sp-signup-container .floraforms .elem-group {
    margin-bottom: 15px;
}
.footer-dark-1 {
	background:#333;
	color:#fff;
}
.footer-dark-2 {
	background: #222;
	color: #fff;
	padding: 12px 0px 5px;
}
</style>
<div class="sp-signup-container">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3 theme-blue">
				<!-- signup-bein -->
				<div class="row">
					<div class="col-md-12">
						<div class="progress" id="progressbar">
						  <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:1%">
							<label>1%</label>
						  </div>
						</div>
					</div>
				</div>
				<div class="flora-wrap " id="firstform">
					<div class="floraforms">
						<div class="flora-container step4">
							<div class="frm-header">
									<h4>What Services Do You Provide?</h4>
								   <p>A brief summary of your business</p>
							</div>
							<div class="frm-body">
								<div id="errors1" class="alert-box hide frm-row">
									<div class="elem-group colm colm12">
										<div  class="flo-notification alert-error">
											<p id="details_errors1">Error Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
										<div class="flo-notification hide alert-success">
											<p>Success Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
									</div>
								</div>
								<div class="frm-row">
										<div class="frm-row">
											<div class="elem-group colm colm12">
												<label class="field flo-select">
													<select class="form-control flo" id="projecttype" name="projecttype">
														<option value="">Please Select</option>
														<?php 
														    $selecteds = $selected;
														 ?>
														<?php foreach($projects as $k=>$v): ?>
															<?php if ($v->ProjectTypeId == $selecteds): ?>
																<option selected="selected" value="<?php echo $v->ProjectTypeId ?>" name="<?php echo $v->Name ?>"><?php echo $v->Name ?></option>
															<?php else: ?>
																<option  value="<?php echo $v->ProjectTypeId ?>" name="<?php echo $v->Name ?>"><?php echo $v->Name ?></option>
															<?php endif ?>
														<?php endforeach; ?>
													</select>
													<i class="arrow double"></i>
												</label>
											</div>
										</div>
										<div class="frm-row">
											<div class="elem-group colm colm12">
												<label class="field">
													Tell us about your business (*)
													<textarea class="flo-textarea flo" id="about_business" name="about_business" placeholder="Tell us about your business"></textarea>
													<span class="flo-hint"><strong>Hint:</strong> Don't be negative or off topic</span>
												</label>
											</div>
										</div>
										<div class="frm-row">
											<div class="elem-group colm colm12">
												<label class="field">
													Your business’ primary services (*)
													<textarea class="flo-textarea flo" id="primary_services" name="primary_services" placeholder="Your business’ primary services"></textarea>
												</label>
											</div>
										</div>
										<div class="frm-row">
											<div class="elem-group colm colm12">
												<label class="field">
													Company Name (*)
													<input type="text" id="company_name" class="flo-input flo">
												</label>
											</div>
										</div>
										<div class="frm-row">
											<div class="elem-group colm colm12">
												<label class="field">
													Your Name (*)
													<input type="text" id="your_name" class="flo-input flo">
												</label>
											</div>
										</div>
										<div class="frm-row">
											<div class="elem-group colm colm6">
												<label class="field">
													Company Phone # (*)
													<input type="text" id="company_phone" class="flo-input flo">
												</label>
											</div>
											<div class="elem-group colm colm6">
												<label class="field">
													Company Fax # (*)
													<input type="text" id="company_fax" class="flo-input flo">
												</label>
											</div>
										</div>											
										<div class="frm-row">
											<div class="elem-group colm colm12">
												<label class="field">
													Company Address (*)
													<textarea class="flo-textarea flo" id="company_address" name="company_address" placeholder="Company Address"></textarea>
												</label>
											</div>
										</div>

									<div class="elem-group colm colm12">
										Already a member? Please&nbsp;<a href="http://handyman.com/serviceprovider/signin">Sign In</a>
									</div>
								</div>
								<div class="frm-footer">
									<button type="submit" id="FirstStep" class="flo-button btn-themed pull-right">Next</button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="flora-wrap hide" id="secondform">
					<div  class="floraforms">
						<div class="flora-container step2">
							<div class="frm-header">
								<h4>Enter your company details below</h4>
							</div>
							<div class="frm-body">
								<div class="frm-row">
								<div id="errors2" class="alert-box hide frm-row">
									<div class="elem-group colm colm12">
										<div  class="flo-notification alert-error">
											<p id="details_errors2">Error Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
										<div class="flo-notification hide alert-success">
											<p>Success Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
									</div>
								</div>
									<div class="frm-row">
										<div class="elem-group colm colm12">
											<label class="field">
												Email (*)
												<input type="text"  id="email" class="flo-input flo">
											</label>
										</div>
									</div>
									<div class="frm-row">
										<div class="elem-group colm colm12">
											<label class="field">
												Username (*)
												<input type="text" id="username" class="flo-input flo">
											</label>
										</div>
									</div>	
									<div class="frm-row">
										<div class="elem-group colm colm12">
											<label class="field">
												Password (*)
												<input type="password" id="password" class="flo-input flo">
											</label>
										</div>
									</div>	
									<div class="frm-row">	
										<div class="elem-group colm colm12">
											<label class="field">
												Confirm Password (*)
												<input type="password" id="password_confirm" class="flo-input flo">
											</label>
										</div>
									</div>	
									<div class="frm-row">	
										<div class="elem-group colm colm12">
											<label class="field">
												Website (*)	
												<input type="text" id="website" class="flo-input flo">
											</label>
										</div>
									</div>
									<div class="frm-row">
									<div class="elem-group colm colm12">
										<label class="field">
											Zip Code (*)
											<input type="text" id="zip_code" class="flo-input flo">
										</label>
									</div>									
								   </div>
									<div class="frm-row">									
										<div class="elem-group colm colm12">
											<label class="field">
												City (*)
												<input type="text" id="city" class="flo-input flo">
											</label>
										</div>
									</div>
								<div class="frm-row">
									<div class="elem-group colm colm12">
										<span>State(*)</span>
										<label class="field flo-select">									     	
											<select  class="form-control flo" id="state" name="state" >
												<option>Please Select</option>
												<?php foreach($state as $k=>$v): ?>
												<option data-abbreviation="<?=$v->Abbreviation?>" value="<?php echo $v->StateId ?>"  ><?php echo $v->Name ?></option>
												<?php endforeach; ?>
											</select>
											<i class="arrow double"></i>
										</label>
									</div>
								</div>
								
								</div>
							
								<div class="frm-footer">
									<button type="reset" id="BackatOne" class="flo-button">Back</button>
									<button type="submit" id="FinalStep" class="flo-button btn-themed pull-right">Create Your Free Contractor Profile</button>
									<input type="hidden" id="refer_id" name="refer_id" value="<?php echo $refer_id; ?>">
									<input type="hidden" name="idev_id" id="idev_id" value="<?php echo $_GET['idev_id']?>">								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- signup end -->
			</div>
		</div>
	</div>
</div>

<?php include('includes/footer.php');?>

<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/js/jquery.inputmask.js" type="text/javascript"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/js/jquery.maskedinput.js" type="text/javascript"></script>

<script type="text/javascript">

$(document).ready( function() {

	$('#company_phone').inputmask("(999) 999-9999");;
progress();
//FORMS

	var $firstform = $('#firstform');
	var $secondform = $('#secondform');
	var $thirdform = $('#thirdform');
	var $fourthform = $('#fourthform');

//  NEXT BUTTON

	$('#FirstStep').click(function(){

		var projecttype = $('#projecttype').val();
		var type_name = $("#projecttype option:selected").text();
		var about_business = $('#about_business').val();
		var primary_services = $('#primary_services').val();
		var company_name = $('#company_name').val();
		var your_name = $('#your_name').val();
		var company_phone = $('#company_phone').val();
		var company_fax = $('#company_fax').val();
		var company_address = $('#company_address').val();
		var count = 0;

		if(projecttype == "")
		{
			CheckError('projjectype', 'errors1', 'Project Type is Required');
			count++;
		}
		else if(about_business == "")
		{
			CheckError('about_business', 'errors1', 'Please Put what your Business is all About.');
			count++;
		}
		else if(primary_services == "")
		{
			CheckError('primary_services', 'errors1', 'Please Indicate your Company Primary Services!');
        	count++;
        }
        else if(company_name == "")
        {
			CheckError('company_name', 'errors1', 'Company is Required' );
			count++;
		}
		else if(your_name == "")
		{
			CheckError('your_name', 'errors1', 'Name is Required');
			count++;
		}
		else if(company_phone == "")
		{
			CheckError('company_phone', 'errors1', 'Company Phone is Required');
			count++;
		}
		else if(company_address == "")
		{
			CheckError('company_address', 'errors1', 'Company Address is Required');
			count++;
		}
		else if(company_fax == "")
		{
            CheckError('company_fax', 'errors1', 'Company Fax is Required');
            count++;
		}
		else
		{
        	FirstStepHide();
        	console.log(projecttype,about_business,primary_services,company_name);
        } 
		
	});

	$('#FinalStep').click(function(){

        var email = $('#email').val();
		var username = $('#username').val();
		var password = $('#password').val();
		var password_confirm = $('#password_confirm').val();
		var website = $('#website').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var websitefilter = /(http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/;
        var city = $('#city').val();
		var state = $('#state').val();
		var zip_code = $('#zip_code').val();
		var count = 0;

		    if(email == "")
		    {
				CheckError('Email','errors2','No Email');
	            count++;
			}
			else if(username == "")
			{
				CheckError('Username','errors2','No Username');
				count++;
			}
			else if(password == "")
			{
				CheckError('Password', 'errors2', 'Please Fill in Your Password');
				count++;
			}
			else if(password_confirm != password)
			{
			    CheckError('Password Confirm', 'errors2', 'Password does not Match');
			    count++;
			}
			else if(username.length < 5 || username.length > 10)
			{
			    CheckError('username', 'errors2', 'Username should be atleast 5 Character');
			    count++;
			}
			else if (!emailfilter.test(email))
			{
	            CheckError('email', 'errors2', 'Please Provide a Valid Email');
	            count++;
			}
			else if(website == "")
			{
	            CheckError('email', 'errors2', 'Please Provide a Website');
	            count++;
			}
			else if(!websitefilter.test(website))
			{
				CheckError('email', 'errors2', 'Please Provide a Valid Website Link');
	            count++;
			} 
			else if(city == "")
			{
				CheckError('city', 'errors2', 'Please Put where city are you from.');
				count++;
			}
			else if(state == "")
			{
				CheckError('state', 'errors2', 'Please Put where state are you from.');
				count++;
			}
			else if(zip_code == "")
			{
				CheckError('zip_code', 'errors2', 'Zip Code is Required');
				count++;
			}
			else
			{
				CheckEmailExist();
			}
	});

// BACK BUTTON
   
   $('#BackatOne').click(function(){
   		BackatOne();
   });

	function FirstStepHide()
	{
		$firstform.fadeOut('slow');
		$secondform.fadeIn('slow');
		$firstform.addClass('hide');
		$secondform.removeClass('hide');
		progress();
	}

	function FinalStep()
	{
		progress();
		var base_url = $('#base_url').val();
		var company_name = $('#company_name').val();
		var your_name = $('#your_name').val();
		var company_phone = $('#company_phone').val();
		var company_fax = $('#company_fax').val();
		var company_address = $('#company_address').val();
		var city = $('#city').val();
		var state = $('#state').val();
		var zip_code = $('#zip_code').val();
		var email = $('#email').val();
		var username = $('#username').val();
		var password = $('#password').val();
		var password_confirm = $('#password_confirm').val();
		var website = $('#website').val();
		var projecttype = $('#projecttype').val();
		var type_name = $("#projecttype option:selected").text();
		var about_business = $('#about_business').val();
		var primary_services = $('#primary_services').val();
		var refer_id = $('#refer_id').val();
		var idev_id = $('#idev_id').val();
		$('#FinalStep').html('Creating your Profile as Handyman Contractor .. ').attr('disabled','disabled');

		$.post(base_url+"/contractorajax/",
		{
        	t:'savecontractor',
			company_name:encodeURIComponent(company_name),
			your_name:your_name,
			username:username,
			company_phone:company_phone,
			company_fax:company_fax,
			company_address:company_address,
			city:city,
			state:state,
			zip_code:zip_code,
			projecttype:projecttype,
			email:email,
			password:password,
			website:website,
			about_business:about_business,
			primary_services:primary_services,
			refer_id:refer_id,
			idev_id:idev_id
		},
		function(data)
		{
		
			if (data.status) 
				{
                	ga('send', 'event', 'Signup Contractor', type_name, state);
					window.location.href = "/dashboard/contractor";
				}
				else
				{
				  CheckError('form', 'errors2', 'Something went Wrong with the details you Input.');	
				  $('#FinalStep').html('Create Your Free Contractor Profile').removeAttr('disabled','disabled');

				}

		});
	}

	function BackatOne()
	{
		$firstform.fadeIn('slow');
		$secondform.fadeOut('slow');
		$firstform.removeClass('hide');
		$secondform.addClass('hide');
		progress();
	}

	function BackatTwo()
	{
		$secondform.fadeIn('slow');
        $secondform.removeClass('hide');
        $thirdform.fadeOut('slow');
        $thirdform.addClass('hide');
        progress();
	}

	function BackatThree()
	{
		$thirdform.fadeIn('slow');
		$thirdform.removeClass('hide');
		$fourthform.fadeOut('slow');
		$fourthform.addClass('hide');
		progress();
	}

	function CheckEmailExist(email,username)
	{   
		var base_url = $('#base_url').val();
		$('#FirstStep').html('Checking your Email .. ').attr('disabled','disabled');
		$.post(base_url+'/contractorajax',
			{
				email:email,
				username:username,
				t:'checkUsernameEmail'

			},function(data)
			{
              if (data.exist) 
              	{
              		CheckError('email', 'errors2', 'Email Already Exist');
              		 $('#FirstStep').html('Next').removeAttr('disabled','disabled');

              	}else
              	{
                   FinalStep();
                  // $('#FirstStep').html('Next').removeAttr('disabled','disabled');
              	}
		    });
	}

	function CheckError(field,id,message)
	{
        $('#'+id).removeClass('hide');
        $('#'+id).fadeIn();
        $('#details_'+id).html(message);
        $('#'+id).focus();
        setTimeout(function(){  $('#'+id).fadeOut();  $('#'+id).add('hide'); }, 3000);
	}

    $("#company_phone").keypress(function (e) {
		 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			CheckError('company_phone', 'errors1', 'Digits Only');
			return false;
		 }
	});

    $('#primary_services').keypress(function(e){
      progress();
    });
	
	$("#company_fax").keypress(function (e) {
			 
		 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			CheckError('company_fax', 'errors1', 'Digits Only');
				   return false;
		 }
	});
	
	$("#zip_code").keypress(function (e) {
			 
			if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				
				CheckError('zip_code', 'errors2', 'Digits Only');
					   return false;
			}
	});

	$('#company_address').keypress(function(e){
		progress();
	});

	$('#password_confirm').keypress(function(e){
		progress();
	});

	$('#city').keypress(function(e){
		progress();
	});

	$('#zip_code').blur(function(){
			if(jQuery(this).val()!=''){
				showLoader1('Loading city and state');
				jQuery.ajax({
					url: '/projectnew/zipcode',
					type: 'POST',
					dataType:"json",
					data: {zipcode:jQuery(this).val()},
					success: function(data){
						hideLoader1();
						if(data!=""){
							$('#city').val(data.city);
							var val = $('option[data-abbreviation="'+data.state+'"]').attr('value');
							$('#state').val(val);
						}
					}
				}).done(function(){
					hideLoader1();
				});
			}
	});
		
	$( "#city" ).autocomplete({
			source: function (request, response) {
				$.ajax({
					url: '/projectnew/searchcity',
					data: { term: request.term.trim() },
					type: "GET",
					cache: false,
					dataType: 'json',
					success: function (data) {							
						response( $.map(data, function( item ) {
									  return {
										value: item.value,
										id: item.id
									}
						}));
						if(data.length<1) {
							//$('#empty-message').show();
							$('#city').removeClass('ui-autocomplete-loading');
						}else {
							//$('#empty-message').hide();
						}
					},
					error: function (XMLHttpRequest, textStatus, errorThrown) {
						//alert(textStatus);
					}
				});
			},
			minLength: 1,	
			select: function(event, ui) {			
				event.preventDefault();
				$('#city').removeClass('ui-autocomplete-loading');
				return false;
			},focus: function(event, ui) {
				$("#city").val(ui.item.label);
				return false;
			}	  
	});

	function progress()
	{
		var items = 0;
		$('.flo').each(function(){
			if($(this).val()!=''){
				items++;
			}
		});
		
		if(items==0){
			$('#progressbar label').html('0% Completed');
			$('#progressbar span').html('0% Completed');
			$('#progressbar .progress-bar').css('width','0%');
			return;
		}

		if(items>3)
		{
			$('#progressbar label').html('25% Completed');
			$('#progressbar span').html('25% Completed');
			$('#progressbar .progress-bar').css('width','25%');			
		}

		 if(items>6)
		{
			$('#progressbar label').html('60% Completed');
			$('#progressbar span').html('60% Completed');
			$('#progressbar .progress-bar').css('width','50%');
		}

		 if(items>10)
		{
			$('#progressbar label').html('65% Completed');
			$('#progressbar span').html('65% Completed');
			$('#progressbar .progress-bar').css('width','65%');
		}

		 if(items>=13)
		{
			$('#progressbar label').html('85% Completed');
			$('#progressbar span').html('85% Completed');
			$('#progressbar .progress-bar').css('width','85%');
		}

		 if(items>15)
		{
			$('#progressbar label').html('100% Completed');
			$('#progressbar span').html('100% Completed');
			$('#progressbar .progress-bar').css('width','100%');
		}
	}
	
});

</script>