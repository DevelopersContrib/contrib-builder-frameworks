<style>
.ss-footer-container .footer-top {
	background:#333;
	color:#fff;
	padding:30px 0px 50px;
}
.ss-footer-container .footer-top .footlinks {
	display:block;
	color:#ccc;
}
.ss-footer-container .footer-bottom {
	background:#222;
	color:#fff;
	padding:10px 0px 10px;
}
.follow-me-icons .fa {
	font-size:35px;
}
</style>
<footer class="ss-footer-container">
	<div class="footer-top">
		<div style="position:relative;">
			<div class="animated rotateIn r-d">
				<a alt="Contrib" target="_blank" href="http://referrals.contrib.com/idevaffiliate.php?id=71952&url=http://www.contrib.com/signup/firststep?domain=veteransrehab.com">
					<img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-8.png">
				</a>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<h3><?php echo ucfirst($info['domain']); ?></h3>
					<p>The easiest way to share news, manage multiple social networks, connect with people, and grow your brand on social media.</p>
				</div>
				<div class="col-md-3">
					<h3>Get Started</h3>
					<a href="/partner" class="footlinks">Partner with us</a>
					<a href="/staffing" class="footlinks">Apply now</a>
					<a href="/referral" class="footlinks">Referral</a>
					<a href="/developers" class="footlinks">Developers</a>
					<a href="#" class="footlinks"></a>
				</div>
				<div class="col-md-3">
					<h3>Company</h3>
					<a href="/about" class="footlinks">About us</a>
					<a href="/terms" class="footlinks">Terms</a>
					<a href="/privacy" class="footlinks">Privacy</a>
					<a href="/contact" class="footlinks">Contact us</a>
				</div>
				<div class="col-md-3">
					<h3>Socials</h3>
					<p class="follow-me-icons">
						<a href="<?php echo $info['socials']['twitter']; ?>"><i class="fa fa-twitter-square fa-2"></i></a>
						<a href="<?php echo $info['socials']['fb'] ?>"><i class="fa fa-facebook-square fa-2"></i></a>
						<a href="<?php echo $info['socials']['gplus'] ?>"><i class="fa fa-google-plus-square fa-2"></i></a>
					</p>
					<h3>Partners</h3>
					<p>
                   <?if($footer_html != ""):?>
					<?echo base64_decode($footer_html)?>
					<?php else:?>
					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
				 <?endif;?>
					</p>						
				</div>
			</div>
		</div>
	</div>
	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
				&copy; 2017 <?php echo ucfirst($info['domain']); ?>. All Rights Reserved. 
				</div>			
			</div>
		</div>
	</div>
</footer>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

