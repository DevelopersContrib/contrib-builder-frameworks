<style>
.ss-footer-container .footer-top {
	background:#333;
	color:#fff;
	padding:30px 0px 50px;
}
.ss-footer-container .footer-top .footlinks {
	display:block;
	color:#ccc;
}
.ss-footer-container .footer-bottom {
	background:#222;
	color:#fff;
	padding:10px 0px 10px;
}
.follow-me-icons .fa {
	font-size:35px;
}
</style>
<footer class="ss-footer-container">
	<div class="footer-top">
		<div style="position:relative;">
			<div class="animated rotateIn r-d">
				<a alt="Contrib" target="_blank" href="http://referrals.contrib.com/idevaffiliate.php?id=71952&url=http://www.contrib.com/signup/firststep?domain=veteransrehab.com">
					<img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-8.png">
				</a>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<h3><?php echo ucfirst($info['domain']); ?></h3>
					<p>The easiest way to share news, manage multiple social networks, connect with people, and grow your brand on social media.</p>
				</div>
				<div class="col-md-3">
					<h3>Get Started</h3>
					<a href="/partner" class="footlinks">Partner with us</a>
					<a href="/staffing" class="footlinks">Apply now</a>
					<a href="/referral" class="footlinks">Referral</a>
					<a href="/developers" class="footlinks">Developers</a>
					<a href="#" class="footlinks"></a>
				</div>
				<div class="col-md-3">
					<h3>Company</h3>
					<a href="/about" class="footlinks">About us</a>
					<a href="/terms" class="footlinks">Terms</a>
					<a href="/privacy" class="footlinks">Privacy</a>
					<a href="/contact" class="footlinks">Contact us</a>
				</div>
				<div class="col-md-3">
					<h3>Socials</h3>
					<p class="follow-me-icons">
						<a href="<?php echo $info['socials']['twitter']; ?>"><i class="fa fa-twitter-square fa-2"></i></a>
						<a href="<?php echo $info['socials']['fb'] ?>"><i class="fa fa-facebook-square fa-2"></i></a>
						<a href="<?php echo $info['socials']['gplus'] ?>"><i class="fa fa-google-plus-square fa-2"></i></a>
					</p>
					<h3>Partners</h3>
					<p>
                   <?if($footer_html != ""):?>
					<?echo base64_decode($footer_html)?>
					<?php else:?>
					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png"
							width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
					<br><br> <a href="https://goo.gl/H1gdhi" target="_blank"><img style="border:0px;height: 65px !important;width: ;width: 225px !important;"
							src="https://rdbuploads.s3.amazonaws.com/banners/banner-ctb%20earn%20ctb%20tokens.png" alt="Crypto Contrib"
							title="Crypto Contrib"></a>
					<link rel="stylesheet" type="text/css" href="http://tools.contrib.com/css/jquery.glue.css">
					<script src="http://tools.contrib.com/js/jquery.glue.min.js"></script>
					<script src="http://tools.contrib.com/js/glue.js"></script>
					<div id="beforeyougo" style="display:none;" class="glue_popup glue_container">
						<div class="glue_close" onclick="$.glue_close()">X</div>
						<div class="glue_content">
							<div class="wrap-exit-content text-center"><img class="logo-exit-ctb" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/icons/currency-ctb-4.png"
									alt="">
								<h1 class="bg-ttle-exit"> Hello!</h1>
								<p> We invite you to our First Movers Opportunity with our <br>CTB crypto token sale starting <b class="text-danger">October
										12, 2017</b>.<br>Amazing Opportunities with world leading digital assets like Streaming.com,
									Applications.com and
									others. Learn more and get updates.<br></p>
								<p> <a href="https://goo.gl/YNSjTg" class="btn btn-lg btn-warning" target="_blank"> <i class="fa fa-check"></i>
										Get
										Started</a></p>
								<p> <a href="javascript:;" onclick="$.glue_close()" class="help-block"> <small>No, thanks I am not
											interested to be
											part owner.</small></a></p>
							</div>
						</div>
					</div>
				 <?endif;?>
					</p>						
				</div>
			</div>
		</div>
	</div>
	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
				&copy; 2017 <?php echo ucfirst($info['domain']); ?>. All Rights Reserved. 
				</div>			
			</div>
		</div>
	</div> 
</footer>