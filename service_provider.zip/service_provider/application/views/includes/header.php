<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo ucfirst($info['description']); ?>">
	<meta property="og:title" content="<?php echo ucfirst($info['domain']); ?>" />
	<meta property="og:url" content="<?php echo ucfirst($info['domain']); ?>" />
	<meta property="og:image" content="https://contribupload.s3.amazonaws.com/logos/logo-contrib-174x35.png" />
	<meta name="author" content="<?php echo ucfirst($info['domain']); ?>">
	<meta name="copyright" content="<?php echo ucfirst($info['domain']); ?>">
    <link rel="icon" href="https://vnoclogos.s3.amazonaws.com/logo-handyman-1.png">
    <title> <?php echo $title; ?> - <?php echo ucfirst($info['domain']); ?></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="/static/css/custom.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    	<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
				(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
					m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
									})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

			ga('create', '<?=$info['account_ga'] ?>', '<?=$info['domain'] ?>');
			ga('send', 'pageview');

		</script>

		<script type="text/javascript">
	        var _paq = _paq || [];
	        _paq.push(['trackPageView']);
	        _paq.push(['enableLinkTracking']);
	        (function() {
	            var u="//www.stats.numberchallenge.com/";
	            _paq.push(['setTrackerUrl', u+'piwik.php']);
	            _paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
	            var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
	            g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
	        })();
	    </script>
	    
	<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>




	<?php
			if (!empty($info['attr']['background_image_url'])) {
				$background = $info['attr']['background_image_url'];
			}else{
				$background = 'http://rdbuploads.s3.amazonaws.com/sp-handyman.jpg';
			}
		 ?>

	<style>
	.hm-logo {
		height:60px;
	}
	.navbar-brand {
		color: #fff !important;
		font-size: 25px;
		text-transform: capitalize;
	}
	.navbar {
		margin-bottom:0px;
	}

	.sp-head-container {  
       background: url('<?php echo $background; ?>');
	   background-size:cover;
	   background-position:50% 50%;
		background-attachment:fixed;
     }
	 .corner-ribbon{
	  width: 230px;
	  background: #e43;
	  position: absolute;
	  top: -26px;
	  right: -81px;
	  text-align: center;
	  letter-spacing: 1px;
	  color: #f0f0f0;
	  transform: rotate(-45deg);
	  -webkit-transform: rotate(-45deg);
	  z-index:999;
	}
	.corner-ribbon.sticky{
	  position: fixed;
	}
	.corner-ribbon.top-right{
	  top: -26px;
	  right: -81px;
	  left: auto;
	  transform: rotate(45deg);
	  -webkit-transform: rotate(45deg);
	}
	.corner-ribbon.color{background: red;}
	.corner-ribbon a {
	 color:#fff;
	 font-weight:bold;
	 display:block;
	 padding: 50px 0px 12px;
	font-size: 15px;
	}
	.corner-ribbon a:hover {
	 text-decoration:none;
	}
	.corner-ribbon a:focus {
	 text-decoration:none;
	}
	.corner-ribbon img {
		height:35px;
	}
	</style>
  </head>
  <body>
  
<div class="corner-ribbon top-right sticky color">
	<a href="http://handyman.com/" target="_blank">
	<img src="https://image.flaticon.com/icons/png/128/222/222567.png"><br>
	Find A Handyman
	</a>
</div>
	<div class="sp-hero-container">		
		<nav class="navbar navbar-inverse">
		  <div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>				 	
			</div>
			<?php if (!empty($info['logo'])): ?>
				<a class="navbar-brand" href="http://www.<?php echo $info['domain']; ?>">
					<img class="hm-logo" src="<?php echo $info['logo']; ?>" alt="<?php echo $info['domain'] ?>" title="<?php echo $info['domain'] ?>">
				</a>
				<?php else: ?>
				<a class="navbar-brand" href="http://www.<?php echo $info['domain']; ?>" title="<?php echo ucfirst($info['domain']); ?>"> <?php echo ucfirst($info['domain']); ?> </a>
				<?php endif ?>
			<div id="navbar" class="collapse navbar-collapse pull-right">
			  <ul class="nav navbar-nav">
				<li class="btn-mrg"><a href="http://www.handyman.com/serviceprovider/signup" class="btn btn-warning">Sign Up</a>&nbsp;</li>
				<li><a href="http://www.handyman.com/serviceprovider/signin" class="btn btn-primary">Login</a></li>
			  </ul>
			</div><!--/.nav-collapse -->
			</div>
		</nav>	
	</div>
		