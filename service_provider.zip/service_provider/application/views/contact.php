
<?php include('includes/header.php');?>
<?php
      if (!empty($info['attr']['background_image_url'])) {
        $background = $info['attr']['background_image_url'];
      }else{
        $background = '';
      }
     ?>

<style>
.pc-box h3 {
   font-size: 33px;
   margin-top: 0px;
   color:#fff;
}
.breadcrumb {
    background:#eee;
	border-radius:0px;
}
.navbar-inverse {
    background: #121212 !important;
}
.navbar {
    margin-bottom: 10px;
}
.sfc-form-outer {
    background: #fff;
    color: #333;
    border: 1px solid #ddd;
    padding: 30px 30px 30px;
}
.sfc-head-title {
   border-bottom: 2px solid #ddd;
   padding-bottom: 10px;
   margin-bottom: 20px;
   margin-top:0px;
   font-size: 20px;
}
.company-container {
    background: none;
    padding: 10px 0px 100px;
    margin-bottom: 50px;
}
</style>

<body>

	<?php include('includes/navigation.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<header id="head" class="secondary"></header>

<div class="contact-container">
	<!-- container -->
	  <div class="container">
		  <ol class="breadcrumb">
				<li><a href="/">Home</a></li>
				<li class="active">Contact Us</li>
				</ol>
	      <div class="row">
				<div class="col-md-12 pc-box">
               <h3 class="text-center">Contact Us</h3>
				</div>
            <!-- -->
            <div class="col-md-6 col-md-offset-3 sfc-form-outer">
               <script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?=$info['domain']?>"></script>
            </div>
            <!-- -->
	      </div>
	  </div>
</div>
<div class="cc-carousel">
   <div class="container">
      <div class="company-container">
         <div class="container2">
            <?php if (count($company)>0):?>
             <div class="section-3-carousel">
               <div class="container2">
                     <div class="row">
                       <div class="col-md-12 text-center">
                         <h1>Top Brands</h1>
                       </div>
                       <div class="col-md-12">
                         <div class="owl-carousel">
                             <?php foreach ($company as $key=>$val):?>
                             <div class="wrap-marketplace-box-item">
                               <a href="http://<?php echo $val['domain_name']?>" target="_blank" class="wmbi-img-logo">
                                 <img src="<?php echo $val['logo']?>" alt="<?php echo $val['domain_name'];?>"  title="<?php echo $val['domain_name']; ?>" class="img-responsive">
                               </a>
                               <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
                                 <?php echo $val['domain_name']?>
                               </h3>
                               <p class="p-marg-btm">
                                 Join our exclusive community of like minded people on <?php echo ($val['domain_name'])?>.
                              </p>

                              <ul class="list-inline ul-wmbi-zero">
                                  <li>
                                      <a href="http://<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Visit</a>
                                  </li>
                                  <li>
                                      <a href="https://contrib.com/brand/details/<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Details</a>
                                  </li>
                              </ul>
                             </div>
                           <?php endforeach;?>
                         </div>
                       </div>
                     </div>
               </div>
             </div>
             <?php endif?>
         </div>
      </div>
   </div>
</div>
	 <?php include('includes/footer.php'); ?>
<script type="text/javascript">

      $(document).ready(function() {

           $("#contactno").keydown(function (e) {
           			restrict(e);
            });

          function restrict(e)
          {
          	  // Allow: backspace, delete, tab, escape, enter and .
              if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                   // Allow: Ctrl+A, Command+A
                  (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                   // Allow: home, end, left, right, down, up
                  (e.keyCode >= 35 && e.keyCode <= 40)) {
                       // let it happen, don't do anything
                       return;
              }
              // Ensure that it is a number and stop the keypress
              if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                  e.preventDefault();
              }

          }

      });

jQuery('#submit').click(function(){

	   var domain = jQuery('#domain').val();
	   var email = jQuery('#email').val();
	   var firstname = jQuery('#fname').val();
	   var lastname = jQuery('#lname').val();
	   var message = jQuery('#message').val();
	   var contact = jQuery('#contactno').val();
	   var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     var code = '<?=$_SESSION['captcha']['code']?>';
		 var captcha = $('#captcha').val();
	   var loading = jQuery('#submit');


	   if (email == '') {
	         error('Please Enter an Email');
	   }else if(!emailfilter.test(email)){
	   		 error('Please Enter a Valid Email Address!');
	   }else if(firstname == ''){
	         error('Please Enter your FirstName');
	   }else if(lastname == ''){
	         error('Please Enter Your Lastname!');
	   }else if(message == ''){
	         error('Please Enter Your Message!');
	   }else if(contact == ''){
	         error('Please Enter Your Contact Number!');
	   }else if(code !== captcha){
           error('Code not match!');
     }else{

	   	  loading.attr('disabled', 'disabled').html("Please wait for a while ");
	      jQuery.post('http://api.contrib.com/forms/save_inquiry_lv3',
	         {
	         	domain:domain,
	         	email:email,
	         	firstname:firstname,
	         	lastname:lastname,
	         	contact:contact,
	         	message:message

	         }
	         ,function(data)
	         {

	            if (data.success == true) { jQuery('#thankyou').removeClass('hide'); jQuery('#inquiry_form').addClass('hide'); } else{ error('Something Went Wrong'); };

	         });
	      console.log('success');
	   }
});

function error(param){
	jQuery('#str_error').removeClass('hide').html(param);
	setTimeout(function(){ jQuery('#str_error').addClass('hide');  }, 3000);
	return false;
}
//domain,firstname,lastname,email,contact,amount,message
</script>

  <script>
      $(document).ready(function(){
        $('.owl-carousel').owlCarousel({
          slideSpeed: 300,
          paginationSpeed: 400,
          items: 3,
          autoHeight:true,
          nav:true,
          onInitialized: setOwlStageHeight,
          onResized: setOwlStageHeight,
          onTranslated: setOwlStageHeight
        })
        function setOwlStageHeight(event) {
            var maxHeight = 0;
            $('.owl-item.active').each(function () { // LOOP THROUGH ACTIVE ITEMS
                var thisHeight = parseInt( $(this).height() );
                maxHeight=(maxHeight>=thisHeight?maxHeight:thisHeight);
            });
            $('.owl-carousel').css('height', maxHeight );
            $('.owl-stage-outer').css('height', maxHeight ); // CORRECT DRAG-AREA SO BUTTONS ARE CLICKABLE
        };
      });
    </script>
