<?php include('includes/header.php');?>
<link rel="stylesheet" href="/static/css/forms.css">
<style>
.navbar {
    margin-bottom: 0px;
}
.sp-signup-container {
	background:linear-gradient(rgba(0, 0, 0, 0.65),rgba(0, 0, 0, 0.65)), url('http://rdbuploads.s3.amazonaws.com/sp-handyman.jpg');
	background-size: cover;
	background-attachment:fixed;
	padding: 50px 0px 180px;
}
.sp-signup-container .flora-container {
	border: 1px solid maroon;
	border-radius: 4px;
}
.sp-signup-container .floraforms .frm-header {
    background: #fff;
}
.sp-signup-container .floraforms .frm-footer {
    padding: 10px 0px 20px;
    background: #fafafa;
}
.sp-signup-container .progress {
    height: 15px;
}
.sp-signup-container .progress-bar {
    line-height: 15px;
	background:#337ab7;
}
.copyrightContain {
    background: #222;
    margin-top: -20px;
    font-size: 11px;
    color: #ccc;
}
.footer-dark-1 {
	background:#333;
	color:#fff;
}
.footer-dark-2 {
	background: #222;
	color: #fff;
	padding: 12px 0px 5px;
}
</style>
<div class="sp-signup-container">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3 theme-blue">
				<!-- signin-begin -->				
				<div class="flora-wrap" id="loginform">
					<form method="post" id="contractorloginform" action="javascript:void(0);" class="floraforms">
						<div class="flora-container">
							<div class="frm-header">
								<h4>Service Provider Login</h4>
							</div>
							<div class="frm-body">								
								<div class="frm-row">
										<div id="errors1" class="alert-box hide frm-row">
									<div class="elem-group colm colm12">
										<div  class="flo-notification alert-error">
											<p id="details_errors1">Error Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
										<div class="flo-notification hide alert-success">
											<p>Success Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
									</div>
								</div>
									<div class="elem-group colm colm12">
										<label class="field">
											Email (*)
											<input type="text" id="contractor_email" class="flo-input">
										</label>
									</div>
									<div class="elem-group colm colm12">
										<label class="field">
											Password (*)
											<input type="password" id="contractor_password" class="flo-input">
										</label>
									</div>
									<div class="elem-group colm colm6">
										<label class="flo-option block">
											<input type="checkbox" name="" value="">
											<span class="flo-checkbox"></span> Remember Me
										</label>
									</div>
									<div class="elem-group colm colm6">
										<label class="flo-option block">
											<a href="/serviceprovider/forgotpassword" id="forgotpassword" class="pull-right">Forgot Password?</a>
										</label>
									</div>
								</div>								
								<div class="frm-footer">
									<button type="submit" id="contractor_sign_in" class="flo-button btn-themed pull-right">Sign In</button>
								</div>
							</div>
						</div>
					</form>
				</div>
				<!-- signin end -->
				
				<!-- forgot password-begin -->				
				<div class="flora-wrap hide" id="forgotform">
					<form method="post" action="javascript:void(0)" class="floraforms">
						<div class="flora-container">
							<div class="frm-header">
								<h4>Reset your password</h4>
							</div>
							<div class="frm-body">								
								<div class="frm-row">
											<div id="errors2" class="alert-box hide frm-row">
									<div class="elem-group colm colm12">
										<div  class="flo-notification hide alert-error">
											<p id="">Error Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
										<div class="flo-notification alert-success">
											<p id="details_errors2">Success Notification</p>
											<a href="#" class="close-btn">&times;</a>
										</div>
									</div>
								</div>
									<div class="elem-group colm colm12">
										<label class="field">
											What's your email address? (*)
											<input type="text" id="user_email" class="flo-input" placeholder="member@example.com">
										</label>
									</div>
									<div class="elem-group colm colm12">
										<p>
										When you click the button below, we'll send an email to the provided email address with instructions for choosing a new password. 
										</p>
									</div>									
								</div>																
								<div class="frm-footer">
									<button type="submit" id="forgotpasswordbutton" class="flo-button btn-themed pull-right">Reset Your Password</button>
								</div>
							</div>
						</div>
					</form>
				</div>
				<!-- forgot password end -->
			</div>
		</div>
	</div>
</div>

<?php include('includes/footer.php');?>

<script type="text/javascript">


$(document).ready( function() {

	$('#contractor_sign_in').click(function(){
     
		var contractor_email = $('#contractor_email').val();
		var contractor_password = $('#contractor_password').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var count = 0;
		
		if(contractor_email == ""){
			CheckError('contractor_email', 'errors1', 'Email is Required','3000');
	        count++;
		}
		else if(contractor_password == ""){
			 CheckError('contractor_password', 'errors1', 'Password is Required','3000');
	         count++;
		}
		else if(!emailfilter.test(contractor_email)){
			  CheckError('contractor_email', 'errors1', 'Email is Invalid','3000');
	          count++;
		}else{
           $(this).html('Logging in ..').attr('disabled','disabled');
			var cdata = {
				'contractor_email':contractor_email,
				'contractor_password':contractor_password,
				't':'logincontractor'
			};

			var base_url = $('#base_url').val();
			$.ajax({
		        url: base_url+'/loginajax',
		        type: 'POST',
		        dataType:"json",
		        data: cdata,
		        success: function(response){
		        	if (response.status)
		        	{
		   					window.location.href = base_url+'/dashboard/contractor';
		   					$('#contractor_sign_in').html('Please Wait . We Will Redirect you to your Dashborad').attr('disabled','disabled');
		   			}else 
		   			{
						CheckError('contractor_email', 'errors1', response.message,'3000');
						$('#contractor_sign_in').html('Sign in').removeAttr('disabled','disabled');
					}
	           },
		        error: function(){
		        		CheckError('contractor_email', 'errors1', 'Something went Wrong.','3000');
		        		$('#contractor_sign_in').html('Sign in').removeAttr('disabled','disabled');
		        }
		    });
		}
	});

	

	function CheckError(field,id,message,time)
	{
	    $('#'+id).removeClass('hide');
	    $('#'+id).fadeIn();
	    $('#details_'+id).html(message);
	    $('#'+id).focus();
	    setTimeout(function(){  $('#'+id).fadeOut();  $('#'+id).add('hide'); }, time);
	}


});

</script>