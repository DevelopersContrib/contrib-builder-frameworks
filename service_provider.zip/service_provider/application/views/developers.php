<?php include('includes/header.php');?>

<style>
.about-year {
	border: 2px solid #6d6d6d;
	display: inline-block;
	font-size: 40px !important;
	height: 178px;
	margin-bottom: 40px;
	padding: 10px;
	width: 180px;
}
.about-year span { font-size: 50px; font-weight: 600; left: -4px; letter-spacing: -5px; position: relative; top: 13px; }
.timeline-number { font-family: "Oswald",sans-serif; font-size: 25px; padding: 15px; line-height:25px;}
.timeline-year {font-size: 20px; font-weight: 600; line-height:60px;}
.text-uppercase {
	text-transform: uppercase;
	font-size: 25px;
}
.pc-box {
    background: #fafafa;
    padding: 20px 30px 30px 30px;
    margin-bottom: 180px;
	color:#222;
}
.breadcrumb {
    background:#eee;
	border-radius:0px;
}
.navbar-inverse {
    background: #121212 !important;
}
.navbar {
    margin-bottom: 10px;
}
</style>

<body>

	<?php include('includes/navigation.php'); ?>

	<header id="head" class="secondary"></header>

	<!-- container -->
	  <div class="container">
		  <ol class="breadcrumb">
				<li><a href="/">Home</a></li>
				<li class="active">About Us</li>
				</ol>
	      <div class="row">
			<div class="col-md-8 col-md-offset-2 pc-box">
			  <h3 class="text-center">Developers <? echo $info['domain']?></h3>
				<hr>
				<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Do you have code or an app that could run this brand? <? echo $info['domain']?> is connected with Contrib. </h4>
				<p></p>
				<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <? echo $info['domain']?> </h4>
				<p class="text-center">
				<br>
				<a href="/contact" class="btn btn-primary btn-lg">Inquire Here</a>
			</div>
	      </div>
	  </div>

	 <?php include('includes/footer.php'); ?>
