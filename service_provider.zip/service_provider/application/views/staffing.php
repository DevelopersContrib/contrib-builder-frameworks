<?php include('includes/header.php');?>

<style>
.pc-box {
    background: #fafafa;
    padding: 10px 30px 30px 30px;
    margin-bottom: 50px;
	color:#222;
}
.breadcrumb {
    background:#eee;
	border-radius:0px;
}
.navbar-inverse {
    background: #121212 !important;
}
.navbar {
    margin-bottom: 10px;
}
</style>
<body>
	<?php include('includes/navigation.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<header id="head" class="secondary"></header>
	<!-- container -->
	  <div class="container">
		  <ol class="breadcrumb">
				<li><a href="/">Home</a></li>
				<li class="active">staffing</li>
				</ol>
	      <div class="row">
				<div class="col-md-8 col-md-offset-2 pc-box">
               <h3 class="text-center">Our Staffing Needs at <? echo $info['domain']?></h3>
					<hr>
					<script type="text/javascript" src="http://tools.contrib.com/contactform?d=<? echo $info['domain']?>&f=staffing"></script>
				</div>
	      </div>
	  </div>

	 <?php include('includes/footer.php'); ?>
