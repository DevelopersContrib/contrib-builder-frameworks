       <footer class="f-l3">
            <div>
                <div class="footer-link">
                    <div class="row-fluid">
                        <ul class="inline" id="ul-l3">
							<li><a href="http://<?=$domain?>">Home</a></li>
							<li><a href="contact.html">Contact us</a></li>
							<li><a href="partner.html">Partner with us</a></li>
							<li><a href="apply.html">Apply now</a></li>
							<li><a href="terms.html">Terms</a></li>
							<li><a href="inquire.html">Inquire about this domain</a></li>
							<li><a href="fund.html">Fund our ventures</a></li>
							<li><a href="developer.html">Developers</a></li>
                        </ul>
                    </div>
                </div>
                <p class="copyright">
					All content &copy; 2013 - 2016 <?=ucwords($domain)?>. All rights reserved.<br><br>			
					<?=$footer_banner?>
				</p>
            </div>
        </footer>
        <script src="http://code.jquery.com/jquery.js"></script>
        <!--script src="js/bootstrap.min.js"></script-->
		<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.1/js/bootstrap.min.js"></script>
		<script src="js/lead.js" type="text/javascript"></script>
		
    </body>
</html>