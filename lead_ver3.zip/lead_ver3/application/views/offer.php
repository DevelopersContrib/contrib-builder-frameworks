<?php include('includes/header.php');?>
<?php var_dump($company); ?>
<style>
.pc-box h3 {
   font-size: 33px;
   margin-top: 0px;
}
.breadcrumb {
    margin: 60px 0 0px 0;
}
.navbar-inverse {
    background: #000 !important;
}
.sfc-form-outer {
    background: #fff;
    color: #333;
    border: 1px solid #ddd;
    padding: 15px 20px 30px;
    box-shadow: 0 1px 5px rgba(0,0,0,.45);
    margin-bottom: 100px;
}
.sfc-head-title {
   border-bottom: 2px solid #ddd;
   padding-bottom: 10px;
   margin-bottom: 20px;
   margin-top:0px;
   font-size: 20px;
}
</style>

<body>

	<?php include('includes/navigation.php'); ?>
	<header id="head" class="secondary"></header>

	<!-- container -->
	  <div class="container">
		  <ol class="breadcrumb">
				<li><a href="/">Home</a></li>
				<li class="active">Submit an Offer</li>
				</ol>
				<hr>

	      <div class="row">
				<div class="col-md-12 pc-box">
               <h3 class="text-center">Submit an Offer</h3>
				</div>
            <!-- -->
            <div class="col-md-6 col-md-offset-3 sfc-form-outer">
               <h3 class="sfc-head-title text-center hide">Fill up this form to submit for a founder application or be able to contribute to this startup.</h3>
               <div class="form-area">
                     <div class="alert alert-danger hide" role="alert" id="str_error" >Firstname is required!</div>
                     <div id="inquiry_form" class="sfc-step-one"><!-- STEP 1 -->
                        <div class="form-group">
                           <label>Firstname&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
                           <input type="text" class="form-control" id="fname" name="fname">
                        </div>
                        <div class="form-group">
                           <label>Lastname&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
                           <input type="text" class="form-control" id="lname" name="lname">
                        </div>
                        <div class="form-group">
                           <label>Email&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
                           <input type="text" class="form-control" id="email" name="email">
                        </div>
                         <div class="form-group">
                           <label>Bid Price (USD)&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
                           <input type="text" class="form-control" id="amount" name="amount">
                        </div>
                        <div class="form-group">
                           <label>Contact No:&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
                           <input type="text" class="form-control" id="contactno" name="contactno">
                        </div>
                        <div class="form-group">
                           <label>Your Message<i class="fa fa-asterisk" aria-hidden="true"></i></label>
                           <textarea id="message" class="form-control" rows="3" style="height:80px;"></textarea>
                        </div>
                        <a href="javascript:void(0);" id="submit" class="btn btn-primary pull-right">Submit&nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                       	<input type="hidden" id="domain" value="<?php echo $info['domain']; ?>">
                        <div class="clearfix"></div>
                     </div>
                     <div id="thankyou" class="sfc-step-final hide">
                        <div class="text-center">
                           <h3>Thank you for your submission.</h3>
                           <p class="hide">All you need to do right now is click the link in the Verification email that we have just sent you. If you still haven't received it, please check your spam inbox. Your verification link will redirect you to our Marketplace hub where you can login and check out your application status. </p>
                           <p> We will be replying once we take interest in your offer. In the meantime, check out our other related assets. </p>
                           <hr>
                           <a href="https://contrib.com/"  class="btn btn-primary hide">View Your Contrib Account Now!</a>
                           <div class="clearfix"></div>
                        </div>
                            <div class="company-container">
                              <div class="container">
                                 <?php if (count($company)>0):?>
                                  <div class="section-3-carousel">
                                    <div class="container">
                                          <div class="row">
                                            <div class="col-md-12 text-center">
                                              <h1 style="color:#000;">Top Brands</h1>
                                            </div>
                                            <div class="col-md-12">
                                              <div class="owl-carousel">
                                                  <?php foreach ($company as $key=>$val):?>
                                                  <div class="wrap-marketplace-box-item">
                                                    <a href="http://<?php echo $val['domain_name']?>" target="_blank" class="wmbi-img-logo">
                                                      <img src="<?php echo $val['logo']?>" alt="<?php echo $val['domain_name'];?>"  title="<?php echo $val['domain_name']; ?>" class="img-responsive">
                                                    </a>
                                                    <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
                                                      <?php echo $val['domain_name']?>                        
                                                    </h3>
                                                    <p class="p-marg-btm">
                                                                     Join our exclusive community of like minded people on <?php echo ($val['domain_name'])?>.
                                                                  </p>
                                                              
                                                                  <ul class="list-inline ul-wmbi-zero">
                                                                      <li>
                                                                          <a href="http://<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Visit</a>
                                                                      </li>
                                                                      <li>
                                                                          <a href="https://contrib.com/brand/details/<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Details</a>
                                                                      </li>
                                                                  </ul>
                                                  </div>
                                                <?php endforeach;?>
                                              </div>
                                            </div>
                                          </div>
                                    </div>
                                  </div>
                                  <?php endif?>
                              </div>
                            </div>  
                     </div>
               </div>
            </div>
            <!-- -->
	      </div>
	  </div>

	 <?php include('includes/footer.php'); ?>

<script type="text/javascript">

      $(document).ready(function() {

           $("#contactno").keydown(function (e) {
           			restrict(e);
            });
           $('#amount').keydown(function (e) {
           			restrict(e);
           });

           $('#amount').blur(function(){
           			var amount = $(this);
           			var amounts = $(this).val();
           			if (amounts == '') 
           			{
           				error('Please Enter Your Bid Amount!');
           				amount.val(parseInt(amount.val()).toFixed(2));
           				amount.focus();
           			} 
           			else if(amounts < 10000)
           			{
           				error('The Minimum Amount of Offer is 10000!');
           				amount.val(parseInt(amount.val()).toFixed(2));
           				amount.focus();
           			}
           		 	else
           			{
           				amount.val(parseInt(amount.val()).toFixed(2));
           			}
           });

          function restrict(e)
          {
          	  // Allow: backspace, delete, tab, escape, enter and .
              if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                   // Allow: Ctrl+A, Command+A
                  (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                   // Allow: home, end, left, right, down, up
                  (e.keyCode >= 35 && e.keyCode <= 40)) {
                       // let it happen, don't do anything
                       return;
              }
              // Ensure that it is a number and stop the keypress
              if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                  e.preventDefault();
              }

          }

      });

jQuery('#submit').click(function(){

	   var domain = jQuery('#domain').val();
	   var email = jQuery('#email').val();
	   var firstname = jQuery('#fname').val();
	   var lastname = jQuery('#lname').val();
	   var message = jQuery('#message').val();
	   var contact = jQuery('#contactno').val();
	   var amount = jQuery('#amount').val();
	   var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	   var loading = jQuery('#submit');


	   if (email == '') {
	         error('Please Enter an Email');
	   }else if(!emailfilter.test(email)){
	   		 error('Please Enter a Valid Email Address');
	   }else if(firstname == ''){
	         error('Please Enter your FirstName');
	   }else if(lastname == ''){
	         error('Please Enter Your Lastname!');
	   }else if(message == ''){
	         error('Please Enter Your Message!');
	   }else if(contact == ''){
	         error('Please Enter Your Contact Number!');
	   }else if(amount == ''){
	         error('Please Enter Your Bid Amount!');
	    }else if(amount < 10000){
	         error('The Minimum Amount is 10000');
	   }else{

	   	  loading.attr('disabled', 'disabled').html("Please wait for a while ");
	      jQuery.post('http://api.contrib.com/forms/save_offer_lv3',
	         {
	         	domain:domain,
	         	email:email,
	         	firstname:firstname,
	         	lastname:lastname,
	         	contact:contact,
	         	amount:amount,
	         	message:message

	         }
	         ,function(data)
	         {

	            if (data.success == true) { jQuery('#thankyou').removeClass('hide'); jQuery('#inquiry_form').addClass('hide'); } else{ error('Something Went Wrong'); };

	         });
	      console.log('success');
	   }
});

function error(param){
	jQuery('#str_error').removeClass('hide').html(param);
	setTimeout(function(){ jQuery('#str_error').addClass('hide');  }, 3000);
	return false;
}

</script>

<script type="text/javascript" src="static/js/owl.carousel.js"></script>
  <script>
      $(document).ready(function(){
        $('.owl-carousel').owlCarousel({
          slideSpeed: 300,
          paginationSpeed: 400,
          items: 1,
          autoHeight:true,
          nav:true,
          onInitialized: setOwlStageHeight,
          onResized: setOwlStageHeight,
          onTranslated: setOwlStageHeight
        })
        function setOwlStageHeight(event) {
            var maxHeight = 0;
            $('.owl-item.active').each(function () { // LOOP THROUGH ACTIVE ITEMS
                var thisHeight = parseInt( $(this).height() );
                maxHeight=(maxHeight>=thisHeight?maxHeight:thisHeight);
            });
            $('.owl-carousel').css('height', maxHeight );
            $('.owl-stage-outer').css('height', maxHeight ); // CORRECT DRAG-AREA SO BUTTONS ARE CLICKABLE
        };
      });
    </script> 

