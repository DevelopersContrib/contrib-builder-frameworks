<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php echo $info['description']; ?>">
	<meta name="keywords" content="<?php echo $info['keywords']; ?>">
	<meta name="author" content="<?php echo $info['domain']; ?>">
	<title><?php echo $title ?> - <?php echo ucfirst($info['domain']); ?> : <?php echo $info['description']; ?></title>
	<link rel="icon" type="image/icon" href="https://s3.amazonaws.com/assets.zipsite.net/images/2013/favicon-contrib-1.png">
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="https://www.contrib.com/css/home1/owl.carousel.css">
	
	<link rel="stylesheet" type="text/css" href="static/css/brand-carousel.css">
	<link rel="stylesheet" href="/static/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="/static/css/main.css">
  
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	
	<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
				(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
					m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
									})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

			ga('create', '<?=$info['account_ga'] ?>', '<?=$info['domain'] ?>');
			ga('send', 'pageview');

		</script>

		<script type="text/javascript">
	        var _paq = _paq || [];
	        _paq.push(['trackPageView']);
	        _paq.push(['enableLinkTracking']);
	        (function() {
	            var u="//www.stats.numberchallenge.com/";
	            _paq.push(['setTrackerUrl', u+'piwik.php']);
	            _paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
	            var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
	            g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
	        })();
	    </script>
	<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>

		<?php
			if (!empty($info['attr']['background_image_url'])) {
				$background = $info['attr']['background_image_url'];
			}else{
				$background = '';
			}
		 ?>

	<style type="text/css">
		#head {
			background: url("<?php echo $background; ?>");
			background-size: cover;
			min-height:820px;
			padding-top:280px;
			color:white;
			font-family:Arial;
			font-weight:300;
			position: relative;
		}
		.navbar-inverse {
			border-bottom: none;
		    padding-top: 0px !important;
			padding-bottom: 0px;
		}
		.tp-head {
			padding: 10px 0;
			margin: 0;
			margin-bottom: 10px;
			color: #fff;
			font-weight: bold;
			font-size: 13px;
			background: black;			
			}
		.tp-head a {
			color:gold;
		}
	</style>
      
</head>
