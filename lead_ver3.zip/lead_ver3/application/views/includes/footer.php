<?php global $footer_html,$domain?>
<footer id="footer" class="ts">
   <div class="footer1">
      <div class="container">
         <div class="row">
            <div class="col-md-3 widget">
               <h3 class="widget-title"><?php echo ucfirst($info['domain']); ?></h3>
               <div class="widget-body">
                  <p>
                     Is seeking talented people to help us build a great business. Join us today if your interested in leading and joining an awesome venture.
                  </p>
               </div>
            </div>

            <div class="col-md-3 widget">
               <h3 class="widget-title">Get Started</h3>
               <div class="widget-body">
                  <ul class="list-unstyled">
                     <li><a href="/partner">Partner With Us</a></li>
                     <li class="hide"><a href="/staffing">Apply Now</a></li>
                     <li><a href="/referral">Referral</a></li>
                     <li><a href="/developers">Developers</a></li>
                  </ul>
               </div>
            </div>

            <div class="col-md-3 widget">
               <h3 class="widget-title">Company</h3>
               <div class="widget-body">
                  <ul class="list-unstyled">
                     <li class="hide" ><a href="/about">About Us</a></li>
                     <li><a href="/terms">Terms</a></li>
                     <li><a href="/privacy">Privacy</a></li>
                     <li><a href="/contact">Contact Us</a></li>
                  </ul>
               </div>
            </div>

            <div class="col-md-3 widget">
               <h3 class="widget-title">Follow me</h3>
               <div class="widget-body">
                  <p class="follow-me-icons">
                     <a href="<?php echo $info['socials']['twitter']; ?>"><i class="fa fa-twitter fa-2"></i></a>
                     <a href="<?php echo $info['socials']['gplus'] ;?>"><i class="fa fa-google-plus fa-2"></i></a>
                     <a href="<?php echo $info['socials']['fb']; ?>"><i class="fa fa-facebook fa-2"></i></a>
                  </p>
               </div>
               <div class="clearfix"><br><br><br></div>
               <h3 class="widget-title">Partners</h3>
               <div class="widget-body">
                  <?if($footer_html != ""):?>
					<?echo base64_decode($footer_html)?>
					<?php else:?>
					<a href="http://goo.gl/WpfyJC" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/codero-logo-HostingOnDemand.png" width="205" height="58" alt="Dedicated Servers, Cloud and Hybrid Hosting Services " title="Dedicated Servers, Cloud and Hybrid Hosting Services "></a>
				<?endif;?>
               </div>
            </div>

         </div> <!-- /row of widgets -->
      </div>
   </div>

   <div class="footer2">
      <div class="container">
         <div class="row">

            <div class="col-md-6 widget">
               <div class="widget-body">
                  <p class="simplenav">
                     <b><a href="/contact">Contact Us</a></b> |
					 <a href="/terms">Terms</a> |
                     <a href="/privacy">Privacy</a> 
            
                  </p>
               </div>
            </div>
   
            <div class="col-md-6 widget">
               <div class="widget-body">
                  <p class="text-right">
                     Copyright &copy; <?=date("Y")?> <a href="/" rel="designer"><?php echo ucfirst($info['domain']); ?></a>
                  </p>
               </div>
            </div>

         </div> <!-- /row of widgets -->
      </div>
   </div>
</footer>

   <!-- JavaScript libs are placed at the end of the document so the pages load faster -->

   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
   <script type="text/javascript" src="https://www.contrib.com/js/home1/owl.carousel.js"></script>
      <script src="http://cdnjs.cloudflare.com/ajax/libs/headroom/0.4.0/headroom.min.js"></script>
   <script src="http://cdnjs.cloudflare.com/ajax/libs/headroom/0.4.0/jQuery.headroom.min.js"></script>
   
      <script>
      jQuery(document).ready(function($) {
       $(".headroom").headroom({
        "tolerance": 20,
        "offset": 50,
        "classes": {
         "initial": "animated",
         "pinned": "slideDown",
         "unpinned": "slideUp"
        }
       });
      });

      </script>

 </body>
 </html>

