<div class="navbar navbar-inverse navbar-fixed-top headroom landing-top" >
   <div class="tp-head">
      <div class="container">
         <div class="row">
            <div class="col-md-12 text-center">
               Now Seeking CEO's and Executive Team Leaders!  <a href="/contact" id="join">Connect Now!</a>
            </div>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="navbar-header landing-header">
         <!-- Button for smallest screens -->
         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
         <a class="navbar-brand" href="/">
            <?php if (!empty($info['logo'])): ?>
                   <img src="<?php echo $info['logo']; ?>" alt="<?php echo $info['domain']; ?>" title="<?php echo $info['description']; ?>">
              <?php else: ?>
                   <h1><?php echo ucfirst($info['domain']) ?></h1>
            <?php endif ?>
         </a>
      </div>
      <div class="navbar-collapse collapse">
         <ul class="nav navbar-nav pull-right">
           <li <?php if ($title == 'Home') { echo 'class="active"';  } ?> ><a href="/">Home</a></li>
            <li <?php if ($title == 'Contact Us') { echo 'class="active"';  } ?> ><a href="/contact">Contact Us</a></li>
         </ul>
      </div><!--/.nav-collapse -->
   </div>
</div>
