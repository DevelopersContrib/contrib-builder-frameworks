<?php include('includes/header.php');?>

<style>
.pc-box {
    background: #fafafa;
    padding: 10px 30px 30px 30px;
    margin-bottom: 50px;
}
.breadcrumb {
    margin: 60px 0 0px 0;
}
.navbar-inverse {
    background: #000 !important;
}
</style>

<body>

	<?php include('includes/navigation.php'); ?>

	<header id="head" class="secondary"></header>

	<!-- container -->
	  <div class="container">
		  <ol class="breadcrumb">
				<li><a href="/">Home</a></li>
				<li class="active">Cookie Policy</li>
				</ol>
				<hr>

	      <div class="row">
				<div class="col-md-8 col-md-offset-2 pc-box">
               <h3 class="text-center"></h3>
			   	<?php echo $content; ?>
				</div>
	      </div>
	  </div>

	 <?php include('includes/footer.php'); ?>
