<?php include('includes/header.php');?>

<link rel="stylesheet" href="/static/css/forms.css">
<style>
.pc-box {
    background: #fafafa;
    padding: 10px 30px 30px 30px;
    margin-bottom: 50px;
}
.flora-wrap {
   margin:50px 0px 130px;
}
</style>

<body>

	<?php include('includes/navigation.php'); ?>

	<header id="head" class="secondary"></header>

	<!-- container -->
	  <div class="container">
		  <div class="row">
          <!-- signup -->
          <div class="flora-wrap">
          	<form method="post" action="" class="floraforms theme-blue">
              	<div class="flora-container wrap3">
                  	<div class="frm-header">
                      	<h4>Sign in to your account</h4>
                        <p>Don't have account yet?, please <a href="/signup">Register</a></p>
                      </div><!-- end .frm-header section -->
                      <div class="frm-body">
                           <div class="elem-group flo-ui" style="display:none;">
                               <div class="flo-notification alert-info">
                                   <p>Info Notification </p>
                                   <a href="#" class="close-btn">&times;</a>
                               </div><!-- end .notification section -->

                               <div class="flo-notification alert-success">
                                   <p>Success Notification</p>
                                   <a href="#" class="close-btn">&times;</a>
                               </div><!-- end .notification section -->

                               <div class="flo-notification alert-warning">
                                   <p>Warning Notification</p>
                                   <a href="#" class="close-btn">&times;</a>
                               </div><!-- end .notification section -->

                               <div class="flo-notification alert-error">
                                   <p>Error Notification</p>
                                   <a href="#" class="close-btn">&times;</a>
                               </div><!-- end .notification section -->
                           </div><!-- end .section section -->

                          <div class="frm-row">
                              <div class="elem-group colm colm12">
                                  <label class="field">
                                      <input type="email" class="flo-input" placeholder="Input email">
                                  </label>
                              </div><!-- end .colm section section -->
                          </div><!-- end .frm-row section -->
                          <div class="frm-row">
                              <div class="elem-group colm colm12">
                                  <label class="field">
                                      <input type="password" class="flo-input" placeholder="Input password">
                                  </label>
                              </div><!-- end .colm section section -->
                          </div><!-- end .frm-row section -->

                          <div class="frm-row">
                              <div class="elem-group colm colm12">
                                  <div class="option-group field">
                                      <label class="flo-option block">
                                          <a href="/terms">Forgot Password?</a>
                                      </label>
                                  </div><!-- end .option-group section -->
                              </div><!-- end .colm section -->
                          </div> <!-- end .frm-row section -->

                      </div><!-- end .frm-body section -->
                      <div class="frm-footer">
                      	<button type="reset" class="flo-button">Cancel</button>
                          <button type="submit" class="flo-button btn-themed">Sign In</button>
                      </div><!-- end .frm-footer section -->
                  </div><!-- end .flora-container section -->
              </form>
          </div><!-- end .flora-wrap section -->
          <!-- end signup-->
        </div>
	  </div>

	 <?php include('includes/footer.php'); ?>

 	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
 	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
 	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
 	<script src="assets/js/headroom.min.js"></script>
 	<script src="assets/js/jQuery.headroom.min.js"></script>
 	<script src="assets/js/template.js"></script>
 </body>
 </html>
