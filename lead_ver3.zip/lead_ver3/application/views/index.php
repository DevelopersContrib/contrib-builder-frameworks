<?php
	session_start();
	$_SESSION = array();

	include("includes/simple-php-captcha.php");
	$_SESSION['captcha'] = simple_php_captcha();
?>
<?php include('includes/header.php'); ?>
<body class="home">
	<!-- Fixed navbar -->
	<?php include('includes/navigation.php'); ?>
	<!-- /.navbar -->
	<!-- Landing Head -->
<style type="text/css">
	.working{background: #fff url('static/images/loader1.gif') no-repeat right center;}
	.ui-autocomplete{z-index: 9999;}
	.addhtml {
		padding: 30px;
		background: #eeeeee;
	}
	.addhtml a {
		cursor: pointer !important;
	}
</style>


<header id="head">
	<div class="bg-overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-md-7">
				<h1 class="lead">
					<?php echo $info['description']; ?>
				</h1>
				<p class="tagline hide"> Join the executive team shaping the Cannabis industry.</p>
				<p>
					<a href="/contact" class="btn btn-action btn-lg" role="button">Get Started Now</a>
					<a href="https://contrib.com/brand/details/<?php echo $info['domain']; ?>" class="btn btn-default btn-lg" role="button">Discover More</a>
				</p>
			</div>
			<div class="col-md-5">
				<form role="form" class="landing-head-form">
					<div id="begin-form" class="begin-form text-center">
						<h3><span class="rt">Apply Now!</span><br> We have interesting opportunities for work, sponsors and partnerships.</h3>
						<fieldset>
							<div class="alert alert-danger hide" role="alert" id="str1_error">Firstname is required!</div>
							<div class="form-group">
								<input class="form-control" placeholder="E-mail" name="initial_email" id="initial_email" type="text">
							</div>							
							<div class="form-group hide">
								<input class="form-control" placeholder="Password" name="password" type="password" value="">
							</div>
							<a href="javascript:void(0);" id="reg_button" onclick="step1()" class="btn btn-lg btn-success btn-block">Apply</a>
						</fieldset>
					</div>
					<!-- staffing form-->
					<div id="staffing-form-container" class="hide">
						<div class="container2">
							<div class="row">
								<div class="col-md-12 sfc-form-outer">
									<h3 class="sfc-head-title text-center">Fill up this form to submit for a founder application or be able to contribute to this startup.</h3>
									<p class="sfc-sub-head-title text-center"><b>Founders Needed:</b> When you submit your registration, you can quickly join the
										<?php echo $info['domain']; ?> team and take part in tasks and be paid in services fees, equity or performance equities.</p>
									<div class="form-area">
										<div class="alert alert-danger hide" role="alert" id="str_error">Firstname is required!</div>
										<div id="step1" class="sfc-step-one hide">
											<!-- STEP 1 -->
											<div class="form-group">
												<label>Firstname&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<input type="text" class="form-control" id="fname" name="fname">
											</div>
											<div class="form-group">
												<label>Lastname&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<input type="text" class="form-control" id="lname" name="lname">
											</div>
											<div class="form-group">
												<label>Email&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<input type="text" class="form-control" id="email" name="email">
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-md-6">
														<label>Password&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
														<input type="password" class="form-control" id="password" name="password">
													</div>
													<div class="col-md-6">
														<label>Confirm Password&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
														<input type="password" class="form-control" id="confirm_password" name="confirm_password">
													</div>
												</div>
											</div>
											<a href="javascript:void(0);" onclick="Step2();" class="btn btn-primary pull-right">Next&nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i></a>
											<a href="javascript:void(0);" onclick="" class="btn btn-primary pull-left hide"><i class="fa fa-chevron-left" aria-hidden="true"></i>&nbsp;Back</a>
											<div class="clearfix"></div>
										</div>
										<div id="step2" class="sfc-step-two hide">
											<!-- STEP 2 -->
											<div class="form-group">
												<label>Team Role&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<?php if (!empty($roles)): ?>
												<select id="role" class="form-control">
									                        <?php foreach ($roles as $role): ?>
									                         <?php if (!($role['role_id'] == 29 || $role['role_id'] == 11 )) { ?>
									                        	 <option id="<?php echo $role['role_name'] ?>" value="<?php echo $role['role_id'] ?>" ><?php echo $role['role_name'] ?></option>
									                         <?php } ?>
									                          <?php endforeach ?>
									                        </select>
												<?php endif ?>
											</div>
											<div class="form-group">
												<label>Country&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<?php if (!empty($countries)): ?>
												<select id="country" class="form-control">
									                        <?php foreach ($countries as $country): ?>
									                          <option id="" value="<?php echo $country['country_id'] ?>" ><?php echo $country['name'] ?></option>
									                          <?php endforeach ?>
									                        </select>
												<?php endif ?>
											</div>
											<div class="form-group">
												<label>City&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<input type="text" class="form-control" id="city" name="city">
											</div>
											<div class="form-group">
												<label>Resume URL&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<input type="text" class="form-control" id="resume" name="resume">
											</div>
											<div class="form-group">
												<label>Why join <?php echo $info['domain']; ?> team as [role]&nbsp;<i class="fa fa-asterisk" aria-hidden="true"></i></label>
												<textarea id="message" class="form-control" rows="3" style="height:100px;"></textarea>
											</div>
											<a href="javascript:void(0);" onclick="step3();" class="btn btn-primary pull-right">Next&nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i></a>
											<a href="javascript:void(0);" class="btn btn-primary pull-left"><i class="fa fa-chevron-left" aria-hidden="true"></i>&nbsp;Back</a>
											<div class="clearfix"></div>
										</div>
										<div id="step3" class="sfc-step-two hide">
											<div class="alert alert-danger" role="alert" id="captcha-error" style="display:none;">Code not match!</div>
											<!-- STEP 3 -->
											<div class="form-group">
												<p class="hide">This is optional...</p>
											</div>
											<div class="form-group">
												<label>Link to your Facebook profile&nbsp;<i class="fa fa-facebook-square" aria-hidden="true"></i></label>
												<input type="text" class="form-control" id="facebook" name="resume" placeholder="https://www.facebook.com/sampleprofile">
											</div>
											<div class="form-group">
												<label>Link to your Linkedin profile&nbsp;<i class="fa fa-linkedin-square" aria-hidden="true"></i></label>
												<input type="text" class="form-control" id="linkedin" name="resume" placeholder="https://www.linkedin.com/sampleprofile">
											</div>
											<div class="form-group">
												<label>Enter the code below</label>												
												<input type="text" class="form-control" id="captcha" name="captcha">
												<div class="text-center">
													<?php echo '<img src="'.$_SESSION['captcha']['image_src'].'" alt="CAPTCHA code" style="margin-top:15px;">'; ?>
												</div>
											</div>
											<div class="text-center"><a href="javascript:step4();" onclick="step4();" id="final_button" class="btn btn-primary">Apply Today</a></div>
											<input type="hidden" id="domain" value="<?php echo $info['domain']; ?>">
											<input type="hidden" id="secret" value="">
											<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR'] ?>">
											<div class="clearfix"></div>
										</div>
										<div id="step4" class="sfc-step-final hide">
											<div class="text-center">
												<h3>Thank you for your Staffing application.</h3>
												<p>You are now minutes away to joining a team. All you need to do right now is click the link in the Verification
													email that we have just sent you. If you still haven't received it, please check your spam inbox. Your verification
													link will redirect you to our Marketplace hub where you can login and check out your application status. </p>
												<p>You can now take part in actually building out an asset by sending proposals, partnering with brands, joining
													teams. </p>
												<hr>
												<a href="https://contrib.com/" class="btn btn-primary">View Your Contrib Account Now!</a>
												<div class="clearfix"></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- end staffing form-->
				</form>
			</div>
		</div>
	</div>
</header>
<!-- /Landing Head -->
<!-- About/Intro -->
<div class="about-container hide">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h3>About Our Company</h3>
				<p>Founded in 1998, we have build a reputation for great customer service and unique idea execution. Our model is unique
					in terms of a distributed managed and owned asset pool in which anyone can contribute to value creation and stakeholder
					ownership.</p>
				<div class="media">
					<div class="media-left pull-left">
						<a href="#">
							<img class="media-object" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-8.png">
						</a>
					</div>
					<div class="media-body">
						<h4 class="media-heading">Howdy stranger!</h4>
						<p>We are a proud member of the Contrib Network. The venture was formed through a partnership with Global Ventures and
							ZCapital. We look forward to meeting other great people and companies in the space.</p>
						<a href="http://contrib.com/" class="btn btn-warning">Visit Contrib</a>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<h3>Client Testimonials</h3>
				<div class="testimonial-box">
					<div class="test-avatar">
						<img src="https://www.contrib.com/uploads/profile/1415842753.jpg">
					</div>
					<div class="test-content">
						<p>Contrib is a great way for people with skills and talents to connect together to build online startups like what we
							are building right now in Cookboard.com</p>
						<b>Maai Floirendo</b>
					</div>
				</div>
				<div class="testimonial-box">
					<div class="test-avatar">
						<img src="https://www.contrib.com/uploads/profile/18705.jpg">
					</div>
					<div class="test-content">
						<p>To be able to co-found a student -centric internship programme is a great experience. Thank you Contrib for making
							me a part of it.</p>
						<b>Jack Paton</b>
					</div>
				</div>
				<div class="testimonial-box">
					<div class="test-avatar">
						<img src="https://www.contrib.com/uploads/profile/1404885194.jpg">
					</div>
					<div class="test-content">
						<p>To be a saxophonist and an online co-founder of Music Channel is a great honor and venture for me! Thanks Contrib!</p>
						<b>Rennie R.</b>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /Intro-->

<!-- Stats Container -->
<div class="stats-container">
	<div class="container text-center">
		<div class="row">
			<div class="col-md-12">
				<h3 class="intros">We envision people around the world with complementary skills, passion, time and resources.</h3>
			</div>
			<div class="col-md-4">
				<img class="img-responsive" alt="Contributors" src="https://d1p6j71028fbjm.cloudfront.net/icons/icon-people-connect.png">
				<h2>300+</h2>
				<h4>Contributors</h4>
			</div>
			<div class="col-md-4">
				<img class="img-responsive" alt="Domains" src="https://d1p6j71028fbjm.cloudfront.net/icons/icon-rocket.png">
				<h2>1009</h2>
				<h4>Domains</h4>
			</div>
			<div class="col-md-4">
				<img class="img-responsive" alt="Members" src="https://d1p6j71028fbjm.cloudfront.net/icons/icon-people-group.png">
				<h2>6437</h2>
				<h4>Members</h4>
			</div>
		</div>
	</div>
</div>
<!-- /Stats Container -->

<div class="company-container" style="display:none;">
	<div class="container">
		<?php if (count($company)>0):?>
		<?php $count = 0; ?>
		<div class="section-3-carousel">
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 style="color:#000;font-weight:600;">Top Brands</h1>
					</div>
					<div class="col-md-12">
						<div class="owl-carousel">
							<?php foreach ($company as $key=>$val):?>
							<?php if(!empty($val['domain_name'])) {
								$count++;
							} ?>
							<div class="wrap-marketplace-box-item <?php echo empty($val['domain_name']) ? 'hide':''?>">
								<a href="http://<?php echo $val['domain_name']?>" target="_blank" class="wmbi-img-logo">
														<img src="<?php echo $val['logo']?>" alt="<?php echo $val['domain_name'];?>"  title="<?php echo $val['domain_name']; ?>" class="img-responsive">
													</a>
								<h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
									<?php echo $val['domain_name']?>
								</h3>
								<p class="p-marg-btm">
									Join our exclusive community of like minded people on
									<?php echo ($val['domain_name'])?>.
								</p>
								<ul class="list-inline ul-wmbi-zero">
									<li>
										<a href="http://<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Visit</a>
									</li>
									<li>
										<a href="https://contrib.com/brand/details/<?php echo $val['domain_name']?>" target="_blank" class="btn btn-success btn-lg">Details</a>
									</li>
								</ul>
							</div>
							<?php endforeach;?>
						</div>
					</div>
				</div>
			</div>
			<input type="hidden" id="company_count" value="<?php echo $count?>">
		</div>
		<?php endif?>
	</div>
</div>
<!-- Partners -->
<div class="partner-container hide">
	<div class="container">
		<div class="row">
			<ul class="list-inline simply-scroll-list" id="scrollerLogo">
				<li class="col-md-2">
					<a target="_blank" title="applications.net" href="https://applications.net">
						<img alt="applications.net" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-mono-applicatioins1.png">
					</a>
				</li>
				<li class="col-md-2">
					<a target="_blank" title="photostream.com" href="https://photostream.com">
						<img alt="photostream.com" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-mono-photo-stream.png">
					</a>
				</li>
				<li class="col-md-2">
					<a target="_blank" title="handyman.com" href="https://handyman.com">
						<img alt="handyman.com" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/contrib/bg/logo-mono-handy-min.png">
					</a>
				</li>
				<li class="col-md-2">
					<a target="_blank" title="musicchallenge.com" href="https://musicchallenge.com">
						<img alt="musicchallenge.com" src="https://s3.amazonaws.com/assets.zipsite.net/images/jayson/contrib/bg/logo-mono-musicC-min.png">
					</a>
				</li>
				<li class="col-md-2">
					<a target="_blank" title="acting.com" href="https://acting.com">
						<img alt="acting.com" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-mono-acting.png">
					</a>
				</li>
				<li class="col-md-2">
					<a target="_blank" title="virtualinterns.com" href="https://virtualinterns.com">
						<img alt="virtualinterns.com" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-mono-virtualI.png">
					</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<!-- /Partners -->

<!-- Newsletter Container -->
<div class="newsletter-container" style="display:none;">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="row">
					<div class="col-md-4">
						<img src="static/images/email.png">
					</div>
					<div class="col-md-8">
						<div id="newsletter-input">
							<h3>Get in touch with us. Learn more about how you can help
								<?php echo $info['domain']; ?>
							</h3>
							<p>Our network of Contributors power our domains but it is through our Contrib apps - Ideas, Challenges, Tasks, eServices,
								Partnerships and Brands and find your next great opportunity.</p>
							<div class="alert alert-success hide text-center" role="alert" id="str_success"> Your Email has Been Submitted !</div>
							<div class="input-group col-md-12" id="content_input">
								<input type="text" id="lead_email" class="form-control input-lg" placeholder="Enter Your Email Address" />
								<span class="input-group-btn">
			                        <button class="btn btn-info btn-lg" id="button_lead" type="button" onclick="save_leads();">
			                            Submit
			                        </button>
			                    </span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /Newsletter Container -->
<?php if (!empty($info['additional_html'])) { ?>
<div class="addhtml">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<?php echo base64_decode($info['additional_html']);  ?>
			</div>
		</div>
	</div>
</div>
<?php } ?>


<?php include('includes/footer.php'); ?>
<!-- JavaScript libs are placed at the end of the document so the pages load faster -->

<script type="text/javascript">
	$('#city').keyup(function () {
		var country_name = $('#country option:selected').text();
		$('#city').autocomplete({
			search: function () {
				$(this).addClass('working');
			},
			open: function () {
				$(this).removeClass('working');
				$('ul.ui-menu').css({
					'z-index': '1000',
					'border-radius': '0',
					'border-color': '#fff',
					'background-color': '#fff'
				});
			},
			source: 'https://www.contrib.com/network/autocompleteCity/' + country_name,
			minLength: 2,
			select: function (event, ui) {
				var selectedObj = ui.item;
				var cityname = selectedObj.value;
				$('#city').text(cityname);
				$(this).removeClass('working');
			}
		});
	});

	function step1() {
		var email = jQuery('#initial_email').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var loading = $('#reg_button');

		if (email == "") {
			jQuery('#str1_error').removeClass('hide');
			jQuery('#str1_error').html('Email is Required');
			setTimeout(function () {
				jQuery('#str1_error').addClass('hide');
			}, 3000);
		} else if (!emailfilter.test(email)) {
			jQuery('#str1_error').removeClass('hide');
			jQuery('#str1_error').html('Email is Invalid');
			setTimeout(function () {
				jQuery('#str1_error').addClass('hide');
			}, 3000);
		} else {

			loading.attr('disabled', 'disabled').html("Please wait ...");
			jQuery.post('http://www.contrib.com/signup2/checkemailexists', {
				email: email
			}, function (data) {
				if (data.exists == true) {
					jQuery('#str1_error').removeClass('hide');
					jQuery('#str1_error').html('Email has Existing Contrib Account');
					loading.removeAttr('disabled', 'disabled').html("Apply");
					setTimeout(function () {
						jQuery('#str1_error').addClass('hide');
					}, 3000);
				} else {
					jQuery('#email').val(email);
					jQuery('#begin-form').addClass('hide');
					jQuery('#staffing-form-container').removeClass('hide');
					jQuery('#step1').removeClass('hide');
				}
			})
		}
	}

	function error(str) {
		jQuery('#str_error').removeClass('hide');
		jQuery('#str_error').html(str);
		setTimeout(function () {
			jQuery('#str_error').addClass('hide');
		}, 3000);
	}

	function Step2() {
		var firstname = jQuery('#fname').val();
		var lastname = jQuery('#lname').val();
		var email = jQuery('#email').val();
		var password = jQuery('#password').val();
		var confirm_password = jQuery('#confirm_password').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if (firstname == '') {

			error('Firstname is Required');

		} else if (lastname == '') {

			error('Lastname is Required');

		} else if (email == '') {

			error('Email is Required');

		} else if (!emailfilter.test(email)) {

			error('Invalid Email');

		} else if (password == '') {

			error('Password is Required');

		} else if (email.length <= 8) {

			error('Email is too Short');

		} else if (confirm_password == '') {

			error('Confim  Password is Required');

		} else if (password != confirm_password) {

			error('Mis Match Password');

		} else {

			jQuery('#step1').addClass('hide');
			jQuery('#step2').removeClass('hide');

		}


	}

	function step3() {
		var city = jQuery('#city').val();
		var resume = jQuery('#resume').val();
		var message = jQuery('#message').val();

		if (city == '') {
			error('City is Required');
		} else if (resume == '') {
			error('Resume is Required');
		} else if (validateURL(resume) === false) {
			error('Invalid Resume url');
		} else if (message == '') {
			error('Message is Required');
		} else {
			jQuery('#step2').addClass('hide');
			jQuery('#step3').removeClass('hide');
		}
	}

	function step4() {
		var code = '<?=$_SESSION['captcha']['code']?>';
		var captcha = $('#captcha').val();

		if(code == captcha){
			save_staffing_lv3();
		}	else {
			$('#captcha-error').fadeIn('slow');;

			setTimeout(function(){
				$('#captcha-error').fadeOut('slow');;
			},3000);
		}	
	}

	function validateURL(url) {
		return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
	}

	function save_staffing_lv3() {
		var button = jQuery('#final_button');
		button.attr('disabled', 'disabled').html('Saving .. ');
		var domain = jQuery('#domain').val();
		var email = jQuery('#email').val();
		var password = jQuery('#password').val();
		var firstname = jQuery('#fname').val();
		var lastname = jQuery('#lname').val();
		var role = jQuery('#role').children('option').filter(':selected').val();
		var country_id = jQuery('#country').children('option').filter(':selected').val();
		var country = jQuery('#country').children('option').filter(':selected').text();
		var city = jQuery('#city').val();
		var message = jQuery('#message').val();
		var resumeurl = jQuery('#resume').val();
		var facebook = jQuery('#facebook').val();
		var linkedin = jQuery('#linkedin').val();
		var secret = jQuery('#secret').val();
		var user_ip = jQuery('#user_ip').val();

		jQuery.post('http://api.contrib.com/forms/save_staffing_lv3', {
			domain: domain,
			firstname: firstname,
			lastname: lastname,
			email: email,
			country_id: country_id,
			country: country,
			city: city,
			password: password,
			resumeurl,
			resumeurl,
			role: role,
			message: message,
			facebook: facebook,
			linkedin: linkedin

		}, function (data) {
			if (data.success == true) {
				button.removeAttr('disabled', 'disabled').html('Apply Today ');
				jQuery('#step3').addClass('hide');
				jQuery('#step4').removeClass('hide');
			};
		})

	}

	function save_leads() {
		var email = jQuery('#lead_email').val();
		var secret = jQuery('#secret').val();
		var user_ip = jQuery('#user_ip').val();
		var domain = jQuery('#domain').val();
		var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var button_lead = jQuery('#button_lead');
		if (email == '') {
			alert('Pleaase enter an Email');
		} else if (!emailfilter.test(email)) {
			alert('please enter a valid email add')
		} else {
			button_lead.attr('disabled', 'disabled').html("Please wait ...");
			jQuery.post('http://www.api.contrib.com/forms/saveleads', {
				domain: domain,
				email: email,
				secret: secret,
				user_ip: user_ip

			}, function (data) {
				if (data.success == 'success') {
					jQuery('#content_input').addClass('hide');
					jQuery('#str_success').removeClass('hide');
				};
			})
		}

	}

</script>

  
<script>
	$(document).ready(function () {
		var company_count = $('#company_count').val();

		if(parseInt(company_count) > 0) {
			$('.company-container').show();
		}

		$('.owl-carousel').owlCarousel({
			slideSpeed: 300,
			paginationSpeed: 400,
			items: 3,
			autoHeight: true,
			nav: true,
			onInitialized: setOwlStageHeight,
			onResized: setOwlStageHeight,
			onTranslated: setOwlStageHeight
		})

		function setOwlStageHeight(event) {
			var maxHeight = 0;
			$('.owl-item.active').each(function () { // LOOP THROUGH ACTIVE ITEMS
				var thisHeight = parseInt($(this).height());
				maxHeight = (maxHeight >= thisHeight ? maxHeight : thisHeight);
			});
			$('.owl-carousel').css('height', maxHeight);
			$('.owl-stage-outer').css('height', maxHeight); // CORRECT DRAG-AREA SO BUTTONS ARE CLICKABLE
		};
	});
</script> 


</body>
</html>
