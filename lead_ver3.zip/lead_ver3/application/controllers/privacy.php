<?php
/**
 *
 */
class Privacy extends Controller {
  
  function index() 
  {
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();

		$template = $this->loadView('privacy');
		$template->set('title','Privacy Policy');
		$template->set('info', $info);
		$template->set('content', $api->getcontent($info['domain'],'privacy'));
		$template->render();
	}
} //end of class

?>
