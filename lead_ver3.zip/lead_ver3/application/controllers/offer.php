<?php
/**
 *
 */
class Offer extends Controller {
  
  function index() 
  {
   		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');	
		$title = 'Offer';
		$info = $api->getdomaininfo();
		$company = $api->getcompany_listI();	
		$template = $this->loadView('offer');
		$template->set('title',$title);	
		$template->set('info',$info);
		$template->set('company',$company);
		$template->render();
	}
} //end of class

?>
