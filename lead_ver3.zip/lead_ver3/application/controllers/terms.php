<?php
/**
 *
 */
class Terms extends Controller {
  
  function index() 
  {
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();

		$template = $this->loadView('terms');
		$template->set('title','Terms of Service');
		$template->set('info', $info);
		$template->set('content', $api->getcontent($info['domain'],'terms'));
		$template->render();
	}
} //end of class

?>
