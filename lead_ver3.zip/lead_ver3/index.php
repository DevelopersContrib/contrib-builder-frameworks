<?php include('header.php'); ?>
<link href="css/YTPlayer.css" media="all" rel="stylesheet" type="text/css">

<div class="container bg g-d">
    <div class="row-fluid">
        <div class="row-fluid">
            <h1 class="head-ttle-h1 text-center" style="">
                <a href="http://<?=$domain?>">
                    <? if($logo!=''){ ?>
                    <img src="<?=$logo?>" alt="<?=$title?>" title="<?=$domain?>" style="height:80px;"/>			
                    <? }else{ ?>
                    <h1><?=ucwords($domain)?></h1>
                    <? } ?>
                </a>
            </h1>
        </div>
        <div class="row-fluid">
            <div class="span12">
                <div class="span6">
                    <div class="wrap-box-15">
                        <div class="media">
                            <a href="#" class="pull-left">
                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/icon-50x50-contrib-contribute2.png" alt="Contribute" class="media-object">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">Contribute</h4>
                                <p>Contribute using your skills, services, apps and/or capital.</p>
                            </div>
                        </div>
                        
                        <div class="media">
                            <a class="pull-left" href="">
                                <img class="media-object" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/icon-50x50-contrib-market2.png">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">The Marketplace</h4>
                                <p>Browse our opportunities and talent marketplace. </p>
                            </div>
                        </div>
                        
                        <div class="media">
                            <a href="#" class="pull-left">
                                <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/icon-50x50-contrib-money2.png" alt="Make Money through Contribution" class="media-object">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">Make Money</h4>
                                <p>Finish service requests, team tasks, and share in the opporunity.</p>
                                
                            </div>
                        </div>
                        <hr />
                        <div class="well">
                            <h4>Great  reasons why you should join us</h4>
                            <p>
                                Cowork with other like-minded, Talented people.
                                Part-time, Remote with great perks.
                                Be A member of a founding Team 
                                Access to Amazing members, advisors and sponsors.
                                Network of over a million potential customers monthly
                            </p>
                        </div>
                    </div>
                </div>
                <div class="span6" style="">
                    <div class="row-fluid">
                        <div class="wrap-box-l3">
                            <p class="d-l3-p">
                                <?=$description ?>
                            </p>
                            <p>&nbsp;</p>
							<div class="row-fluid" id="leadcontent">
								<form class="form-inline" id="leadform" style="margin: 0;">
									<div class="wrap-email-box">
										<div class="input-append control-group success glow-wrap g-i">
											<input class="" id="email" type="text" placeholder="your@email.com">
											<input type="hidden" id="refid" value="0">
											<input type="hidden" id="domain" value="<?php echo $domain?>">
											<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
											<button class="btn btn-lg btn-success" id="submitLead" type="button">Go!</button>
										</div>
									</div>
								</form>
							</div>
                            <div class="row-fluid" >
                                <div id="social">
                                    <table style="border:0px;width: 350px;margin: 0 auto;">
                                        <tr>
                                            <td valign='top' style='width:15%;'>
                                                <script src="http://platform.linkedin.com/in.js" type="text/javascript"></script>
                                                <script type="IN/Share" data-url="http://www.linked.com"></script>
                                            </td>
                                            <td valign='top' style='width:85%;'>
                                                
                                                <!-- AddThis Button BEGIN -->
                                                <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
                                                    <a class="addthis_button_preferred_1"></a>
                                                    <a class="addthis_button_preferred_2"></a>
                                                    <a class="addthis_button_preferred_3"></a>
                                                    <a class="addthis_button_preferred_4"></a>
                                                    <a class="addthis_button_compact"></a>
                                                    <a class="addthis_counter addthis_bubble_style"></a>
                                                </div>
                                                <script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
                                                <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>
                                                <!-- AddThis Button END -->
                                            </td>    
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <center style="margin: 15px 30px 20px 30px;">
                                <span class="counter counter-analog" data-direction="up" data-interval="1" data-format="9999999" data-stop="<?=$follow_count?>">
                                    <span class="part part0">
                                        <?
    $count = 7;
$digits = strlen($follow_count);
$splittedString = str_split($follow_count);
for($i=$count; $i>0; $i--){
    if($i==$digits){
        for($j=0;$j<$digits;$j++){						
            echo '<span class="digit digit'.$splittedString[$j].'"></span>';
        }	
        break;					
    }else{
        echo '<span class="digit digit0"></span>';
    }
}
                                        ?>
                                    </span>	
                                </span>
								
								<div id="socials_container" style="text-align:center;margin-top:20px">&nbsp;</div>
								
                            </center>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<a id="P2" class="player" data-property="{videoURL:'BsekcY04xvQ',containment:'body',autoPlay:true, mute:true, startAt:0, opacity:1}">My video</a>
<style>
#response { margin-bottom: 30px; }
#response h2 { font-size: 21.5px; }
</style>
<?php include('footer.php'); ?>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>

<script>
	
    jQuery(function(){
        jQuery(".player").mb_YTPlayer();
		
		var domain_name = $('#domain').val();
	
		getsocial(domain_name,'fb','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251686_facebook_circle_color.png');
		getsocial(domain_name,'twitter','http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251704_twitter_circle_color.png');
	
    });
    
	function getsocial(domain_name,social,icon_src){
	
		$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
						var socialdata = data[0];
						if(socialdata.error == true){
							//do nothing
						}else if(socialdata.profile_url == ""){
							//do nothing
						}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
							//do nothing
						}else{
							$('#socials_container').append('&nbsp;<a href="'+socialdata.profile_url+'"><img src="'+icon_src+'" height="40px"></a>&nbsp;');
						}		
		});
	}
	
</script>


