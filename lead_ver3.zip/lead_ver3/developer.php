<? include('header.php'); ?>

<link rel="stylesheet" media="screen" type="text/css" href="css/custom-lead.css"/>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

<div class="container-fluid lead-reset-padd" style="background: url('/img/bg-socialholdings.jpg') repeat;">
	<div class="row-fluid">
		<div class="wrap-ad" style="background: none repeat scroll 0 0 rgba(0, 0, 0, 0.8);margin-bottom: -20px;">
			<div class="container overflow-ad">
				<div class="row-fluid">
					<div class="content-ad">
						<div style="margin: -40px 0 30px 0;">
							<? if($logo!=''){ ?>
								<a href="http://<?=$domain?>"><img src="<?=$logo?>" alt="<?=$title?>" title="<?=$domain?>" style="height:90px" border="0" /></a>
							<? }else{ ?>
								<h1><?=ucwords($domain)?></h1>
							<? } ?>
							<h4>Learn more about Joining our Partner Network</h4>
						</div>
						
						<div class="section-heading-ttle text-left">
							<h2 style="padding-left:0;"><span id="_title">ARE YOU A DEVELOPER?</span></h2>	<br><br>						
						</div>
						
						<div class="row-fluid">
							<div class="span12">
								
								<br>
								
								<h3 class="text-left" style="font-size: 20px;">
									<i class="fa fa-arrows"></i> Do you have code or an app that could run this brand? <?=ucwords($info['domain'])?> is connected with Contrib.
								</h3>
								
								<br> 
								
								<h3 class="text-left" style="font-size: 20px;">
									<i class="fa fa-arrows"></i> Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?=ucwords($info['domain'])?>?
								</h3>	
									
								<br>

								<h4><a href="/contact.html" target="_blank" class="btn btn-success">Inquire here!</a></h4>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--3rd section-->

<? include('footer.php'); ?>