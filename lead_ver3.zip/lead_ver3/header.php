<? include 'includes/config.php';?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="canonical" href="http://<?=$domain?>/<?=basename($_SERVER['PHP_SELF'])?>/" />
<meta name="robots" content="index, follow" />
<title><?=$title?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="title" content="<?=ucwords($domain)?> - <?=$title?> " />
<meta name="description" content="<?=ucwords($domain)?> - <?=$description?>" />
<link rel="icon" href="favicon.ico" />
<!-- Bootstrap -->
<!--link href="css/bootstrap.css" rel="stylesheet" media="screen"-->
<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.1/css/bootstrap-combined.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.css" rel="stylesheet" media="screen">
<link href="css/lead_ver3.css" rel="stylesheet" media="screen">  
<link href="css/jquery.counter-analog.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/jquery.counter-analog2.css" media="screen" rel="stylesheet" type="text/css" />
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?=$account_ga?>']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<style type="text/css">	
<? if($background_image != ""){ ?>
	html {background: url(<?=$background_image?>);color: #A0A0A0;
<? }else{ ?>
	html { background: url(http://www.domaindirectory.com/template/lead2/images/bg-socialholdings.jpg) repeat center center fixed; color: #A0A0A0;}
<? } ?>
</style>

<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stats.numberchallenge.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', <?=$piwik_id;?>]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=1" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->


</head>

<body>


<? if($forsale=='1' || $showdefault=='1'){ ?>
	<div style="padding:10px 0 10px 0; margin:0; color: #fff; background:url(http://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/top-bg.png) repeat-x; font-size:13px; text-align:center;  font-family:Arial, Helvetica, Tahoma, sans-serif; font-weight:bold; height:auto;">
	<?=$forsaletext?> <a href="http://domaindirectory.com/servicepage/?domain=<?=$domain?>" target="_blank" style="color:blue;">Inquire now</a>.
	</div>
<? } ?>	
		
		