<?php
    $sitename =   "{{DOMAIN}}";
    $siteurl =   "{{SITEURL}}";
    $domain =   "{{DOMAIN}}";
    $domainUrl =  "{{SITEURL}}";
    $domainid =   "{{DOMAINID}}";
    $domain_title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $keywords =  "{{KEYWORDS}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $piwik_id = "{{PIWIK_ID}}";
    $domain_affiliate_link = "{{AFF_LINK}}";
	  $description = stripslashes(str_replace('\n','<br>',$description));
    $color = "{{COLOR}}";
    $intro_title = "{{INTRO_TITLE}}";
    $small_description = "{{SMALL_DESCRIPTION}}";
    $categoryid = "{{CATEGORYID}}";
    $background_url = "{{BACKGROUND_URL}}";
    $featured_challenge = "{{FEATURED_CHALLENGE}}";
    $footer_banner = "{{FOOTER_BANNER}}" ;
    $affiliate_id = "{{AFFILIATE_ID}}";
	  $not_featured = {{NOT_FEATURED_SITES}};
	  $related_sites = {{RELATED_SITES}};
	  $partners = {{PARTNERS}};
	  $jobs = {{JOBS}};
	  $related_domains = {{RELATED_DOMAINS}};
    $fund_campaigns = {{FUND_CAMPAIGNS}};
    $micronews = {{MICRONEWS}};
    $featuredc = {{FEATUREDC}};
    $cdiscussions = {{CDISCUSSIONS}};
    $clinks = {{CLINKS}};
    $crequirements = {{CREQUIREMENTS}};
    $challengers = {{CHALLENGERS}};
	    
?>