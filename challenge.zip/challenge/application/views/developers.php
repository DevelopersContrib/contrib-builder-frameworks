<?	include('header_index.php'); ?>
<div class="container devpage">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h2><i class="fa fa-code"></i>&nbsp;Are you a Developer?</h2>
			<div class="devbox">
				<p class="devdesc"><i class="fa fa-rocket"></i>&nbsp;Do you have code or an app that could run this brand? <?=ucwords($info['domain'])?> is connected with Contrib. </p>
				<p class="devdesc"><i class="fa fa-rocket"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?=ucwords($info['domain'])?>? </p>
				<p class="proceedto"><a id="show_contactus_dialog" data-target="#form-container" data-toggle="modal" href="#top">Inquire</a></p>
			</div>
		</div>
	</div>
</div>
<?	include('index_footer.php');?>