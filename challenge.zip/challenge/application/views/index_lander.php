<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<style>
    .badge-postn{
    	position: absolute;
    	right: 90px;
    	top: 3px;
    	z-index: 10;
    }
    .r-d{
    	animation-delay: 2.5s;
    }
    .rotateIn{
    	animation-name: rotateIn;
    }
    .animated{
    	animation-duration: 1s;
        animation-fill-mode: both;
    }
    .inputBgCstm{
        height:46px !important;
    }
    /* Landscape phones and down */
    @media (max-width: 480px) { 
        .badge-postn{
            right: 5px;
        }
        .animated.rotateIn.r-d.badge-postn img {
            width: 100px;
        }
        .img-index-2{
            max-width: 100%;
        }
        .h1-index2{
            font-size: 27px;
        }
        .aMoreInfo span{
            font-size: 24px;
        }
        .alreadyIn {
            font-size: 27px;
        }
    }
.h1-index2 {
	color: #5af582;
	text-shadow: none;
	font-weight: 600;
}
.h2-desc {
    color: #fff;
    font-weight: 600;
}
.wrap-header-text-index2 {
    padding: 250px 0 30px;
}
.section-half-1 {	
	padding: 60px 0 90px;
	background: #046612;
}
.sh-intro {
	color: #fff;
	font-size: 35px;
	font-weight: 600;
	margin-bottom: 20px;
}
.sh-intro h3 {
	font-family: 'Montserrat', sans-serif;
	font-size: 35px;
	font-weight: 600;
}
.leadform-container {
	margin-bottom: 40px;
}
.aMoreInfo span {
    font-size: 23px;
    text-shadow: none;
    font-weight: 600;
}
.aMoreInfo .fa {
    font-size: 50px;
    background: #295704;
    padding: 10px;
    border-radius: 50%;
    height: 70px;
    width: 70px;
}
.bg-overlay {
	background-color: rgba(8, 11, 1, 0.7);
	bottom: 0;
	left: 0;
	position: absolute;
	right: 0;
	top: 0;
}
#leadform .form-control {
	border: none;
}
.media-body, .media-left, .media-right {
	display: table-cell;
	vertical-align: top;
}
.media-left, .media > .pull-left {
	padding-right: 10px;
}
.media-right, .media > .pull-right {
	padding-left: 10px;
}
.contrib-task-container .media-heading {
	margin: 10px;
}
.contrib-task-container .media-right .btn-danger {
	margin-top: 5px;
}
</style>

<div style="position:relative;">
	<div class="animated rotateIn r-d badge-postn">
		<a alt="Contrib Brand" target="_blank" href="http://referrals.contrib.com/idevaffiliate.php?id=15959&url=http://www.contrib.com/signup/firststep?domain=<?php echo $info['domain']?>">
		<img alt="<?=ucwords($info['domain'])?> - A Contrib Brand" title="<?php echo ucwords($info['domain']) ?>" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/badge-contrib-3.png">
		</a>
	</div>
</div>

<div class="wrap-index2">
			<div class="bg-overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="wrap-header-text-index2">
                            <p class="text-center">
								<? if($info['logo']!=''){ ?>
									 <h1 class="text-center"> <a href="http://<?=$info['domain']?>"><img alt="<?=ucwords($info['domain'])?> " title="<?=ucwords($info['domain'])?>" class="img-responsive img-index-2" src="<?=$info['logo']?>"></a></h1>
								<? }else{ ?>
									<h1 class="h1-index2 text-center" style="color: #5af582;"><?=ucwords($info['domain'])?></h1>
								<? } ?>
                            </p>
                            <h2 class="h2-desc text-center">
								<? if($info['description']!=''){
										echo stripslashes(str_replace('\n','<br>',$info['description']));
									}else{
										echo 'Learn more about Joining our Partner Network.';
								} ?>
                            </h2>
                        </div>
						<div id="socials_container" style="text-align:center;margin-bottom:10px">&nbsp;</div>
                        <!-- -->
                    </div>
                </div>
            </div>
        </div>
        <div class="section-half-1 bjw-con">
            <div class="container">
                <div class="row text-center">
					<div class="col-lg-12 sh-intro">
						<h3>Join Now And Play Some Amazing Challenges</h3>
					</div>
					<div class="leadform-container col-lg-6 col-lg-offset-3" id="leadcontent">
						<form id="leadform">
							<div class="input-group">
								<input type="text" class="form-control input-lg" id="email" name="email" placeholder="Enter your email address">
								<input type="text" class="form-control input-lg" id="secret" name="secret" value="" style="display:none;">
								<input type="hidden" id="refid" value="0">
								<input type="hidden" id="domain" value="<?php echo preg_replace("/www./","",$_SERVER['HTTP_HOST'])?>">
								<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
								<span class="input-group-btn">
									<button class="btn btn-warning btn-lg email-ftre inputBgCstm" id="submitLead">
										<i class="fa fa-edit"></i>
										Join Us
									</button>
								</span>
							</div><!-- /input-group -->
						</form>						
					</div>
					<div class="col-lg-4">
						<div class="aMoreInfo" href="">
							<span>
								<i class="fa fa-search"></i><br>
								Browse <?=ucwords($info['domain'])?> 
							</span>
							<p>
								Check out our newest challenges today.
							</p>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="aMoreInfo" href="">
							<span>
								<i class="fa fa-thumbs-o-up"></i><br>
								Join Challenges
							</span>
							<p>
								Are you the type a challenge wrangler? Come and Join us at <?=ucwords($info['domain'])?>. It'll be fun.
							</p>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="aMoreInfo" href="">
							<span>
								<i class="fa fa-gift"></i><br>
								Win Prizes and Equity Points 
							</span>
							<p>
								Great Free Prizes or <?=ucwords($info['domain'])?> Equity awaits our challenge winners.
							</p>
						</div>
					</div>
                </div>
            </div>
        </div>
<!--   -->
<script>
$(function() {
var domain_name = $('#domain').val();

			getsocial(domain_name,'fb','https://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251686_facebook_circle_color.png');
			getsocial(domain_name,'twitter','https://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/1396251704_twitter_circle_color.png');
			getsocial(domain_name,'gplus','https://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/gplus.png');
			getsocial(domain_name,'linkedin','https://d2qcctj8epnr7y.cloudfront.net/sheina/contrib/social_icons/linkedin.png');
			
});
function getsocial(domain_name,social,icon_src){
	
			$.getJSON('http://manage.vnoc.com/socialmedia/getDomainSocialsAPI/'+domain_name+'/'+social,function(data){
							var socialdata = data[0];
							if(socialdata.error == true){
								//do nothing
							}else if(socialdata.profile_url == ""){
								//do nothing
									getsocial('ichallenge.com',social,icon_src);
							}else if(socialdata.profile_url == "null" || socialdata.profile_url == null){
								//do nothing
							}else{
								$('#socials_container').append('&nbsp;<a href="'+socialdata.profile_url+'"><img src="'+icon_src+'" alt="'+social+'" title="'+social+'" height="40px"></a>&nbsp;');
								if (socialdata.request_social=='twitter'){
									 $('a.twitter').attr('href',socialdata.profile_url);
								}else if (socialdata.request_social=='fb'){
									 $('a.facebook').attr('href',socialdata.profile_url);
								}else if (socialdata.request_social=='linkedin'){
									 $('a.linkedin').attr('href',socialdata.profile_url);
								}
							}		
			});
		}






		
</script>
