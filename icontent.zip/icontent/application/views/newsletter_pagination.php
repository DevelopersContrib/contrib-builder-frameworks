<?php 
	$pagination = "<ul>";
	if($lastpage > 1)
	{	
		
		//previous button
		if ($page > 1) 
			$pagination.= "<li class='pagination-prev'><a href=\"javascript:loadPages($prev)\"  class=\"tpage\"><span class='pagenav'> <i class='fa fa-backward'></i></span></a></li>";
		else
			$pagination.= "<li class='pagination-prev'> <span class='pagenav'> <i class='fa fa-backward'></i></span></li>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<li><span class='pagenav'>$counter</span></li>";
				else
					$pagination.= " <li> <a title='".$counter."' href=\"javascript:loadPages($counter)\"  class='pagenav'>$counter</a></li>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<li><span class='pagenav'>$counter</span></li>";
					else
						$pagination.= "<li> <a title='".$counter."' href=\"javascript:loadPages($counter)\"  class='pagenav'>$counter</a></li>";					
				}
					
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<li> <a title='1' href=\"javascript:loadPages(1)\"  class='pagenav'>1</a></li>";
				$pagination.= "<li> <a title='2' href=\"javascript:loadPages(2)\"  class='pagenav'>2</a></li>";
						
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<li> <a title='1' href=\"javascript:loadPages(1)\"  class='pagenav'>1</a></li>";
				$pagination.= "<li> <a title='2' href=\"javascript:loadPages(2)\"  class='pagenav'>2</a></li>";
				
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<li class='pagination-next'> <a title='' href=\"javascript:loadPages($next)\" class='pagenav'><i class='fa fa-forward'></i></a></li>";
		else
			$pagination.= "<li class='pagination-next'><i class='fa fa-forward'></i></li>";
			
	}
	$pagination .= "</ul>"
?>

	
<?php echo $pagination?>






