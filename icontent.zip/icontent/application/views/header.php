<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?=$info['description']?>">
	<meta name="keywords" content="<?=$info['keywords']?>"/>
    <meta name="author" content="<?php echo $info['domain']; ?>"/>
    <link rel="icon" href="../../favicon.ico">
    <title><?=$info['title']?></title>	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="custom.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	
	
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
				m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
								})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
		
		ga('create', '<?=$info['account_ga'] ?>', '<?=$info['domain'] ?>');
		ga('send', 'pageview');
		
	</script>
	
	<script type="text/javascript">
        var _paq = _paq || [];
        _paq.push(['trackPageView']);
        _paq.push(['enableLinkTracking']);
        (function() {
            var u="//www.stats.numberchallenge.com/";
            _paq.push(['setTrackerUrl', u+'piwik.php']);
            _paq.push(['setSiteId', <?=$info['piwik_id'] ?>]);
            var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
            g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
        })();
    </script>
<noscript><p><img src="//www.stats.numberchallenge.com/piwik.php?idsite=<?=$info['piwik_id'] ?>" style="border:0;" alt="" /></p></noscript>
<style>
    body{
        padding-top: 76px;
    }
    .hr {
      border: none;
      border-bottom: rgba(255, 255, 255, 0.3) 1px solid;
    }
    #main-section {
      <?php if($attr['background_image'] != ""): ?> 
        background-image: url("<?php echo $attr['background_image']?>");
      <?php else: ?> 
        background-image: url("https://rdbuploads.s3.amazonaws.com/backgrounds/writing.jpg");
      <?php endif?> 
      display: block;
      position: relative;
      padding: 0px 0px 0px;
      -webkit-transition: all .400s;
      -moz-transition: all .400s;
      -o-transition: all .400s;
      transition: all .400s;
      background-attachment: fixed;
      background-position: center center;
      background-repeat: no-repeat;
      -webkit-background-size: cover !important;
      -moz-background-size: cover !important;
      -o-background-size: cover !important;
      -webkit-box-sizing: border-box !important;
      -moz-box-sizing: border-box !important;
      background-size: cover !important;
      box-sizing: border-box !important;
    }
  .main-top-title {
      background: none repeat scroll 0px 0px rgba(0, 0, 0, 0.8);
      padding: 30px 0px 40px;
  }
  .main-lander {
      padding: 10px 0px 15px;
  }
  .main-lander h1 {
      color: #fff;
      text-shadow: rgba(33, 33, 33, 0.5) 1px 1px 3px;
      font-size: 70px;
      line-height: 70px;
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
  }
  .main-lander h2 {
      text-shadow: #333 1px 1px 3px;
      font-size: 25px;
      line-height: 30px;
      color: #fff;
  }
  .main-lander-2 {
      padding: 10px 0px 15px;
  }
  .main-lander-2 h1 {
      color: #fff;
      text-shadow: rgba(33, 33, 33, 0.5) 1px 1px 3px;
      font-size: 50px;
      line-height: 50px;
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
  }
  .main-lander-2 h2 {
      text-shadow: #333 1px 1px 3px;
      font-size: 25px;
      line-height: 30px;
      color: #fff;
  }
  #main-section .nlogo {
      height: 40px;
      vertical-align: middle;
      position: relative;
  }
  #main-section .navbar-inverse {
      padding-bottom: 10px;
  }
  #main-section .navbar {
      margin-bottom: 0px;
  }
  #main-section .nmenus {
      margin-top: 15px;
  }
  #main-section .nmenus a {
      text-transform: uppercase;
      color: #fff;
  }
  #main-section .nmenus a:hover {
      color: #fff;
  }
  .content-wrapper .btn-danger {
      margin-bottom: 5px;
  }
  *,
  *:before,
  *:after {
      box-sizing: border-box !important;
  }
  .news-panel .row {
      -moz-column-width: 18em;
      -webkit-column-width: 18em;
      -moz-column-gap: .5em;
      -webkit-column-gap: .5em;
  }
  .news-panel a {
      text-decoration: none;
  }
  .news-panel .panel {
      display: inline-block;
      margin: .5em;
      padding: 0;
      width: 98%;
      border: none;
  }
  .news-panel .cat-name-title {
      color: #333;
  }
  .news-panel .panel-heading {
      border-bottom: none;
  }
  .news-panel .btn-danger {
      margin-bottom: 5px;
  }
  .news-panel .btn {
      font-size: 12px;
      padding: 3px 6px;
  }
  .news-panel h4 {
      margin-top: 0px;
  }
  .news-panel .news-img {
      width: 100%;
  }
  .news-panel .news-img-holder {
      margin: 10px auto 10px;
      text-align: center;
      background: #dedede;
  }
  .news-panel .news-date {
      font-size: 11px;
  }
  .news-panel .news-header-personality {
      background: #FDD017;
      color: white;
  }
  .news-panel .news-header-polls {
      background: red;
      color: white;
  }
  .news-panel .news-header-trivia {
      background: orange;
      color: white;
  }
  .news-panel .news-header-article {
      background: #E6A326;
      color: white;
  }
  .news-panel .news-header-meme {
      background: blue;
      color: white;
  }
  .news-panel .news-header-video {
      background: purple;
      color: white;
  }
  .news-panel .news-header-image {
      background: orange;
      color: white;
  }
  .news-panel .panel-heading {
      padding: 10px 0px;
      color: #fff;
      text-transform: capitalize;
  }
  .news-panel .panel-heading a {
      color: #fff;
  }
  #nverticals {
      padding: 50px 0px;
  }
  #nverticals .nv-title {
      border-bottom: 1px solid #dedede;
      padding: 0px 0px 15px 0px;
      margin-bottom: 20px;
      margin-top: 0px;
  }
  #nverticals img {
      padding: 10px;
  }
  .n-page-box {
      background: rgb(255, 255, 255) none repeat scroll 0% 0%;
      padding: 40px;
      border-radius: 4px;
  }
  /*loader*/

  .dizzy-gillespie {
      -webkit-filter: saturate(3);
      filter: saturate(3);
      margin-top: 10%;
      width: 0.1px;
      height: 0.1px;
      border: 40px solid transparent;
      border-radius: 5px;
      -webkit-animation: loader 3s ease-in infinite, spin 1s linear infinite;
      animation: loader 3s ease-in infinite, spin 1s linear infinite;
  }
  .dizzy-gillespie::before {
      -webkit-filter: saturate(0.3);
      filter: saturate(0.3);
      display: block;
      position: absolute;
      z-index: -1;
      margin-left: -40px;
      margin-top: -40px;
      content: '';
      height: 0.1;
      width: 0.1;
      border: 40px solid transparent;
      border-radius: 5px;
      -webkit-animation: loader 2s ease-in infinite reverse, spin 0.8s linear infinite reverse;
      animation: loader 2s ease-in infinite reverse, spin 0.8s linear infinite reverse;
  }
  .dizzy-gillespie::after {
      display: block;
      position: absolute;
      z-index: 2;
      margin-left: -10px;
      margin-top: -10px;
      content: '';
      height: 20px;
      width: 20px;
      border-radius: 20px;
      background-color: white;
  }
  @-webkit-keyframes loader {
      0% {
          border-bottom-color: transparent;
          border-top-color: #114357;
      }
      25% {
          border-left-color: transparent;
          border-right-color: #826C75;
      }
      50% {
          border-top-color: transparent;
          border-bottom-color: #F29492;
      }
      75% {
          border-right-color: transparent;
          border-left-color: #826C75;
      }
      100% {
          border-bottom-color: transparent;
          border-top-color: #114357;
      }
  }
  @keyframes loader {
      0% {
          border-bottom-color: transparent;
          border-top-color: #114357;
      }
      25% {
          border-left-color: transparent;
          border-right-color: #826C75;
      }
      50% {
          border-top-color: transparent;
          border-bottom-color: #F29492;
      }
      75% {
          border-right-color: transparent;
          border-left-color: #826C75;
      }
      100% {
          border-bottom-color: transparent;
          border-top-color: #114357;
      }
  }
  @-webkit-keyframes spin {
      0% {
          -webkit-transform: rotate(0deg);
          transform: rotate(0deg);
      }
      100% {
          -webkit-transform: rotate(-360deg);
          transform: rotate(-360deg);
      }
  }
  @keyframes spin {
      0% {
          -webkit-transform: rotate(0deg);
          transform: rotate(0deg);
      }
      100% {
          -webkit-transform: rotate(-360deg);
          transform: rotate(-360deg);
      }
  }
  .navbar-inverse .navbar-nav {
      padding-left: 25px;
  }
  .navbar-header h1 {
      font-size: 25px;
  }
  .nav-r-menus{
    margin-top: 7px;
  } 

</style>
  </head>

  <body>