<?php include'header.php';?>
<style>
.main-top-title {   
    margin-bottom: 30px !important;
}
</style>
	<section id="main-section">
		<?php include'navigation.php';?>
		<div class="main-top-title">
			<div class="container">
			  <div class="row">
				<div class="main-lander-2">
					<div class="col-md-6 col-md-offset-3 text-center">
						<h1>Terms</h1>
					</div>
				</div>	
			  </div>
			</div>
		</div>
		<div class="n-page" style="padding-bottom:100px;">
			<div class="container">
			  <div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="n-page-box">
						<div class="col-md-12">
							<?php echo $terms_content; ?>					
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>	
			  </div>
			</div>
		</div>
	</section>
	
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
  </body>
</html>
