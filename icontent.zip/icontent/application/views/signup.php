<?php include'header.php';?>
<?php global $additional_html ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
<style>
.panel-login {
	border-color: #ccc;
	-webkit-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);
	-moz-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);
	box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);	
}
.panel-login>.panel-heading {
	color: #00415d;
	background-color: #fff;
	border-color: #fff;
	text-align:center;
}
.panel-login>.panel-heading a{
	text-decoration: none;
	background-color:#f5f5f5;
	color: #bbb;
	font-weight: bold;
	font-size: 22px;
	padding:5px 10px;
	border-radius:15px;
	-webkit-transition: all 0.1s linear;
	-moz-transition: all 0.1s linear;
	transition: all 0.1s linear;
}
.panel-login>.panel-heading a.active{
	background-color:#029f5b;
	color: #fff;
	font-size: 22px;
	padding:5px 10px;
	border-radius:15px;
}
.panel-login>.panel-heading hr{
	margin-top: 10px;
	margin-bottom: 0px;
	clear: both;
	border: 0;
	height: 1px;
	background-image: -webkit-linear-gradient(left,rgba(0, 0, 0, 0),rgba(0, 0, 0, 0.15),rgba(0, 0, 0, 0));
	background-image: -moz-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
	background-image: -ms-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
	background-image: -o-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
}
.panel-login input[type="text"],.panel-login input[type="email"],.panel-login input[type="password"] {
	height: 45px;
	border: 1px solid #ddd;
	font-size: 16px;
	-webkit-transition: all 0.1s linear;
	-moz-transition: all 0.1s linear;
	transition: all 0.1s linear;
}
.panel-login select {
	height:45px;
}
.panel-login input:hover,
.panel-login input:focus {
	outline:none;
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
	box-shadow: none;
	border-color: #ccc;
}
.btn-login {
	background-color: #59B2E0;
	outline: none;
	color: #fff;
	font-size: 14px;
	height: auto;
	font-weight: normal;
	padding: 14px 0;
	text-transform: uppercase;
	border-color: #59B2E6;
}
.btn-login:hover,
.btn-login:focus {
	color: #fff;
	background-color: #53A3CD;
	border-color: #53A3CD;
}
.forgot-password {
	text-decoration: underline;
	color: #888;
}
.forgot-password:hover,
.forgot-password:focus {
	text-decoration: underline;
	color: #666;
}

.btn-register {
	background-color: #1CB94E;
	outline: none;
	color: #fff;
	font-size: 14px;
	height: auto;
	font-weight: normal;
	padding: 14px 0;
	text-transform: uppercase;
	border-color: #1CB94A;
}
.btn-register:hover,
.btn-register:focus {
	color: #fff;
	background-color: #1CA347;
	border-color: #1CA347;
}
.n-page {
	padding:50px 0px 150px
}
.btn-facebook {
	background-color:#24365C;
	border-color:#24365C;
}
.c-alert {
position: absolute;
z-index: 999;
margin-top: -53px;
left: 232px;
width: 300px;
font-size: 13px;
}
.c-alert2 {
	position: absolute;
z-index: 999;
margin-top: -155px;
left: 14px;
width: 95%;
font-size: 13px;
}
.c-alert .alert {
    padding: 6px 30px 6px 10px;
}
.c-alert2 .alert {
    padding: 6px 30px 6px 10px;
}
.working {
	background: #FFF url("js/ajax-loader-trans.gif") no-repeat scroll right center !important;
	padding-right: 2px;
}

.thankyou .fa {
	font-size:70px;
}
.thankyou .btn {
	margin-top:15px;
}
.thankyou {
	padding: 10px 0px 40px;
}

.loading {
  position: absolute;
  border: 1px solid transparent;
  left: 50%;
  top: 30%;
  border-radius: 100%;
  box-shadow: -50px 0 0 8px #aef, -25px 25px 0 8px #fea, 0px 50px 0 8px #afa, 25px 25px 0 8px #faf, 50px 0 0 8px #aaa, 25px -25px 0 8px #dda, 0px -50px 0 8px #dfa, -25px -25px 0 8px #99a;
  -webkit-animation: myanim 0.4s ease-in-out infinite;
          animation: myanim 0.4s ease-in-out infinite;
}

@-webkit-keyframes myanim {
  100% {
    box-shadow: -25px 25px 0 8px #fea, 0px 50px 0 8px #afa, 25px 25px 0 8px #faf, 50px 0 0 8px #aaa, 25px -25px 0 8px #dda, 0px -50px 0 8px #dfa, -25px -25px 0 8px #99a, -50px 0 0 8px #aef;
  }
}

@keyframes myanim {
  100% {
    box-shadow: -25px 25px 0 8px #fea, 0px 50px 0 8px #afa, 25px 25px 0 8px #faf, 50px 0 0 8px #aaa, 25px -25px 0 8px #dda, 0px -50px 0 8px #dfa, -25px -25px 0 8px #99a, -50px 0 0 8px #aef;
  }
}

</style>
	<section id="main-section">
		<?php include'navigation.php';?>
		<div class="main-top-title">
			<div class="container">
			  <div class="row">
				<div class="main-lander-2">
					<div class="col-md-6 col-md-offset-3 text-center">
						<h1>User Account</h1>
					</div>
				</div>	
			  </div>
			</div>
		</div>
		<div class="n-page">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<div class="panel panel-login" id="form" style="padding-top:20px;">
							<div class="panel-heading">
								<div class="row">
									<div class="col-xs-6">
										<a href="#" class="active" id="login-form-link">Login</a>
									</div>
									<div class="col-xs-6">
										<a href="#" id="register-form-link">Register</a>
									</div>
								</div>
								<hr>
							</div>
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-12">
										<form id="login-form" action="#" method="post" role="form" style="display: block;">
										<div class="form-group" style="margin-bottom: 30px;" style="display:none" id="loader-login">
												<div class="btn btn-lg btn-warning btn-wide col-sm-12">
													<div class="loading"></div>
													Processing .....												
												</div>
												<div class="clearfix"><br></div>
										</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
												<input type="text" name="username" id="login-username" tabindex="1" class="form-control" placeholder="Username" value="">
											</div>
											<div class="clearfix c-alert" id="alert-username-login" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												 Please Input Username
												</div>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
												<input type="password" name="password" id="login-password" tabindex="2" class="form-control" placeholder="Password">
											</div>
											<div class="clearfix c-alert" id="alert-password-login" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												 Please Input Password
												</div>
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-lg-12">
														<div class="text-center">
															<a href="" tabindex="5" class="forgot-password">Forgot Password?</a>
														</div>
													</div>
												</div>
											</div>
											<div class="form-group text-center">
												<input type="checkbox" tabindex="3" class="" name="remember" id="remember">
												<label for="remember"> Remember Me</label>
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-sm-12">
														<button id="login-submit" class="form-control btn btn-login"><i class="glyphicon glyphicon-user"></i> Log In</button>
													</div>
												</div>
											</div>
											<div class="clearfix c-alert2" id="alert-matched-login" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												 Username and Password did not Match.
												</div>
											</div>											
										</form>

										<form id="register-form" action="#" method="post" role="form" style="display: none;">
											<div class="form-group" style="margin-bottom: 30px;" style="display:none" id="loader">
												<div class="btn btn-lg btn-warning btn-wide col-sm-12">
													<div class="loading"></div>
													We're submitting your data, please wait for a moment ...												
												</div>
												<div class="clearfix"><br></div>
											</div>
											<div class="form-group input-group">												
												<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
												<input type="text" name="username" id="signupusername" tabindex="1" class="form-control" placeholder="Username" value="">												
											</div>
											<div class="clearfix c-alert" id="alert-username" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  Please input username.
												</div>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
												<input type="email" name="email" id="email" tabindex="2" class="form-control" placeholder="Email Address" value="">
											</div>
											<div class="clearfix c-alert" id="alert-email" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  Please input email address.
												</div>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
												<input type="password" name="password" id="signuppassword" tabindex="3" class="form-control" placeholder="Password">
											</div>
											<div class="clearfix c-alert" id="alert-password1" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  Please input password.
												</div>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
												<input type="password" name="confirm-password" id="confirm-password" tabindex="4" class="form-control" placeholder="Confirm Password">
											</div>
											<div class="clearfix c-alert" id="alert-password2" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  Please input confirm password.
												</div>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-pushpin"></i></span>
												<select type="text" name="country" id="country" tabindex="5" class="form-control" placeholder="Country" value="-- Select Country --">													
													<option value="">Select Country *</option>
													<?php foreach($formdata['data']['countries'] as $country):?>
															<option value="<?php echo $country['country_id'];?>"><?php echo $country['name'];?></option>
													<?php endforeach;?>

												</select>
											</div>
											<div class="clearfix c-alert" id="alert-country" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  Please input country.
												</div>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-tower"></i></span>
												<input type="text" name="city" id="city" tabindex="6" class="form-control" placeholder="Enter City" value="" style="border-radius: 0px 4px 4px 0px;">
											</div>
											<div class="clearfix c-alert" id="alert-city" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  Please input city.
												</div>
											</div>											
											<div class="form-group text-center">
												<input type="checkbox" checked="checked" tabindex="7" class="" name="remember" id="agree">
												<label for="remember"> I agree to the <a href="/terms" target="_blank">terms of service.</a></label>
											</div>
											<div class="clearfix c-alert" id="alert-agreement" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  Please Check Terms Agreement.
												</div>
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-sm-12">
														<button id="signup" class="form-control btn btn-login"><i class="glyphicon glyphicon-plus"></i> Register Now</button>
													</div>
												</div>
											</div>
												<div class="clearfix c-alert" id="alert-username-invalid" style="display: none;">
												<div class="alert alert-warning alert-dismissible" role="alert">
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												  	The Username is Invalid, Only Alpha Numerical are Accepted.
												</div>
											</div>
											
										<!-- 	<div class="form-group">
												<div class="row">
													<div class="col-sm-12 text-center">
													<hr>
														<b class="text-center" style="display: block; margin-top: -31px;"><span style="background-color:#fff;">OR</span></b>
													</div>
												</div>
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-sm-12">
														<button id="facebook" class="form-control btn btn-login btn-facebook"><i class="fa fa-facebook" aria-hidden="true"></i> Register With Facebook</button>
														
													</div>
												</div>
											</div> -->
											
										</form>
									</div>
								</div>
							</div>
						</div>
						<div class="row text-center" id="thank" style="display:none;">
								<div class="col-sm-12">
								<div class="thankyou alert alert-success">
								<h3><i class="fa fa-thumbs-up" aria-hidden="true"></i></h3>
								<h3>Thank you for signing up <span class="name"></span> !</h3>
								<div class="addhtml">
										<?if($additional_html != ""):?>
										<?echo base64_decode($additional_html)?>
										<?endif;?>
								</div>
								<a href="/create" id="create" class="btn btn-warning btn-lg">Post your content now.</a>
							</div>
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	 <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
	<script type="text/javascript" src="js/nprogress/nprogress.js"></script>
	<link rel="stylesheet" type="text/css" href="js/nprogress/nprogress.css">
	<!--<script src="bootstrap-portfilter.min.js"></script>-->
	<script>
	$(function() {
	$('#loader').hide();
	$('#loader-login').hide();
	$('#city').keyup(function(){
		var country_name = $('#country').children('option').filter(':selected').text();
		$('#city').autocomplete({
					search  : function(){$(this).addClass('working');},
					open    : function(){	
					$(this).removeClass('working');
					$('ul.ui-menu').css({'z-index':'1000','border-radius':'0','background-color':'#fafafa','class':'form-control','width':'485px','padding':'20px','border':'1px solid #dedede','list-style-type':'circle','pointer':'cursor'});
					},
					source: 'http://www.contrib.com/network/autocompleteCity/'+country_name,
					minLength: 2,
					select: function (event, ui) {   
					var selectedObj = ui.item;
					var cityname = selectedObj.value;
					$('#city').text(cityname);	
					$(this).removeClass('working');
				}
			});
		});
    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

		$('#signup').click(function(e){	

			validation();
			e.preventDefault();
		});

		$('#login-submit').click(function(e){
			login();
			e.preventDefault();
		});

});
	
	function validation(){

			var username = $('#signupusername').val();
			var email = $('#email').val();
			var password = $('#signuppassword').val();
			var password2 = $('#confirm-password').val();
			var country_id = $('#country').children('option').filter(':selected').val();
		    var country = $('#country').children('option').filter(':selected').text();
			var city = $('#city').val();
			var emailfilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			var namefilter = /^[a-z ,-]+$/i;
			var flag = false;

			if (username == "") {
				$('#alert-username').show();
					setTimeout(function() {
							    $('#alert-username').fadeOut('fast');
					}, 2000); 
				$('#signupusername').focus();
			}else if (username.length < 1) {
				$('#alert-username').show();
					setTimeout(function() {
							    $('#alert-username').fadeOut('fast');
					}, 2000); 
				$('#signupusername').focus();
			}else if (username > 25) {
				$('#alert-username').show();
					setTimeout(function() {
							    $('#alert-username').fadeOut('fast');
					}, 2000); 
				$('#signupusername').focus();
			}else if(email == ""){
				$('#alert-email').show();
					setTimeout(function() {
							    $('#alert-email').fadeOut('fast');
					}, 2000); 
				 $('#email').focus();
			}else if (!emailfilter.test(email)) {
				$('#alert-email').show();
					setTimeout(function() {
							    $('#alert-email').fadeOut('fast');
					}, 2000); 
				  $('#email').focus();
			}else if(password == ""){
				$('#alert-password1').show();
					setTimeout(function() {
							    $('#alert-password1').fadeOut('fast');
					}, 2000); 
				 $('#signuppassword').focus();
			}else if (password.length < 6) {
				$('#alert-password1').show();
					setTimeout(function() {
							    $('#alert-password1').fadeOut('fast');
					}, 2000); 
				$('#signuppassword').focus();
			}else if (password2 == "") {
				$('#alert-password2').show();
					setTimeout(function() {
							    $('#alert-password2').fadeOut('fast');
					}, 2000); 
				$('#confirm-password').focus();
			}else if (password != password2) {
				$('#alert-password2').show();
					setTimeout(function() {
							    $('#alert-password2').fadeOut('fast');
					}, 2000); 
				$('#confirm-password').focus();
			}else if(city == ""){
				$('#alert-city').show();
					setTimeout(function() {
							    $('#alert-city').fadeOut('fast');
					}, 2000); 
				 $('#city').focus();
			}else{

				if ($('#agree').is(':checked')) {
						flag = true;
						save();
					}else{
						$('#alert-agreement').show();
						setTimeout(function() {
									    $('#alert-agreement').fadeOut('fast');
							}, 2000); 
						$('#agree').focus();
					}				
			}

			return flag;
	}

	function save(){

			$('#loader').show();
			NProgress.set(0.5);
			var username = $('#signupusername').val();
			var email = $('#email').val();
			var pass1 = $('#signuppassword').val();
			var pass2 = $('#confirm-password').val();
			var country_id = $('#country').children('option').filter(':selected').val();
		    var country = $('#country').children('option').filter(':selected').text();
			var city = $('#city').val();
			var session_userid;
			var session_username;
			var session_loggedin;

			var formdata = {

				username:username,
				email:email,
				pass1:pass1,
				pass2:pass2,
				country:country,
				country_id:country_id,
				city:city
			}

			$.post('http://icontent.com/api/users/register.php',
			{
				email:email,
				username:username,
				pass1:pass1,
				pass2,pass2
			}
			,function(data)
			 {
			 
			 	var session = {

			 			session_userid:data.uid,
						session_username:username,
						session_loggedin:'true'
			 	}

				if (!data.status) {

						$('#alert-username-invalid').show();
						setTimeout(function() {
								 $('#alert-username-invalid').fadeOut('fast');
						}, 2000); 
						NProgress.done();
						$('#loader').hide();
						$('#signupusername').focus();

					}else{
						
						$.post('http://www.contrib.com/signup/saveall',				
							{
								'email':email,
								'password':pass1,
								'country':country,
								'country_id':country_id,
								'city':city,
								'from_framework':true

							},function(data2) {
								
								$.post('/signup/loggedin',

									{
										
										userid:data.uid,
										username:username
									
									}, function (data3)
									{
										if (data3.loggedin===true) {

											$('#form').hide();
												setTimeout(function() {
												    $('#form').fadeOut('fast');
												}, 2000); 
												$('#thank').show();
													setTimeout(function() {
													    $('#thank').fadeIn('slow');
												}, 2000); 
												$('.name').html(username);
												NProgress.done();
												$('#loader').show();	
										}		
									}
								)
							}
						)
					}
				}
			)
		}

	function login(){
		var username = $('#login-username').val();
		var password = $('#login-password').val();

		var formdata = {
			username:username,
			password:password
		}

		if (username == "")
		{
			$('#alert-username-login').show();
			setTimeout(function() {
						 $('#alert-username-login').fadeOut('fast');
					}, 2000); 
			$('#login-username').focus();
		}
		else if(password == "")
		{
			$('#alert-password-login').show();
			setTimeout(function() {
					 $('#alert-username-login').fadeOut('fast');
			}, 2000); 
			$('#login-password').focus();

		}
		else
		{
			NProgress.set(0.5);
			$('#loader-login').show();
			console.log(formdata);
			$.post('http://api1.contrib.co/icontent/CheckUserExist',
			{
				username:username,
				password:password
			},
			function(data){
							if (!data.data.exist)
							{
								$('#alert-matched-login').show();
								setTimeout(function() {
									$('#alert-matched-login').fadeOut('fast');
								}, 2000); 
								$('#loader-login').hide();
								$('#login-username').focus();
								NProgress.done();
							}
							else
							{
								$.post('/signup/loggedin',
										{
											username:username,
											userid:data.data.uid

										},
										function(data2){
											NProgress.done();
											$('#loader-login').hide();
											window.location.href = "/create";
										}
								  )
							}
						}
					)
				}
			}

</script>




  </body>
</html>
