<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<style>
body {
	background:#fff;
}
#main-section-page {
	margin-top: 30px;
}
#main-section-page .article-container {
	background: #F5F6F1;
	padding: 35px 35px 25px 35px;
	border-radius:4px;
}
#main-section-page .panel-heading {
    background-color: #D6EDF5;
}
#main-section-page .panel {
    border: none;
}
#main-section-page .navbar-brand .btn-info {
	color:#fff !important;
}
#main-section-page .main-art-img-box {
	background:#fafafa;
	margin-bottom:15px;
}
#main-section-page .main-art-desc {
	font-size:14px;
}
#main-section-page .vername {
	margin: 0px;
}
#main-section-page .email-input {
	margin-bottom:10px;
}
#main-section-page .form-control {
	margin-bottom:10px;
}
#main-section-page .lnws {
	margin-bottom: 10px;
}
#main-section-page .lnws-desc {
	font-size:12px;
}
#main-section-page hr {
    margin-top: 10px;
    margin-bottom: 10px;
    border: 0;
    border-top: 3px solid #eee;
}
#main-section-page .art-credits {
	font-size:11px;
}
#main-section-page .lvn-title {
	font-size: 16px;
}
#main-section-page .rcv-box {
	border-top: 1px solid #ccc;
	color:#333;
	padding:10px 0px;
}
#main-section-page .rcv-title {
	font-size: 15px;
	font-weight:bold;
}
#main-section-page .rcv-title-top {
	color:#333;
}
#main-section-page .rcv-box .rcv-img {
	width:80px;
	float:left;
	margin:10px;
	margin-bottom:0px;
}
#main-section-page .rcv-box .btn:hover {
	color:#999;
}
#main-section-page .rcv-title2 {
	font-size: 15px;
	font-weight:bold;
}

#main-section-page .rcv-box2 .rcv-img2 {
	width:120px;
	float:left;
	margin:10px;
	margin-bottom:0px;
}
#main-section-page .rcv-body {
	
}
.hide  {
	display: none;
}
</style>
<div class="msp-bg">
	<section id="main-section-page">
		<div class="container article-container">
		  <div class="row">
			<div class="col-md-9">
				<section class="panel panel-default">
					<header class="panel-heading text-right">
						<h3 class="panel-title">
							<a class="navbar-brand" href="#">
								<img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-newsletter1.png" class="nlogo" style="height:30px;">
							</a>
							<a href="<?php echo $base_url; ?>home" class="btn btn-info"><i class="fa fa-home"></i> Home</a>
							<a href="" class="btn btn-info"><i class="fa fa-external-link-square"></i> Ads</a>
						</h3>
					</header>
					<div class="panel-body">
						<?php foreach($newsletter as $key=>$val): ?>
						<h3 class="text-center vername"><?php echo $val['title']; ?></h3>
						<hr>						
						<i class="art-credits">Submitted by <?php echo $val['username']; ?> <?php echo $val['date_posted']; ?></i>
						<h4><?php echo $val['title']; ?></h4>
						<div class="row">
							<div class="col-md-8">
								<div class="main-art-img-box"><img src="<?php echo $val['thumbnail']; ?>" class="img-responsive main-art-img"></div>
								<p class="main-art-desc"><?php echo ($val['description']=="0") ? "": $val['description']; ?>
								<a href="#" class="btn" data-toggle="collapse" data-target="#collapseExample"><i class="fa fa-angle-double-right"></i></a>
								</p>
								
								<div class="collapse" id="collapseExample">
									The following is pretty neat, fun, and very accurate. And it only takes 2 minutes.
								</div>
								<div class="clearfix"><br></div>
								<p class="text-center">
									<button type="button" class="btn btn-warning">Like Us On <i class="fa fa-facebook"></i></button>
									<button type="button" class="btn btn-warning">Subscribe On <i class="fa fa-youtube"></i></button>
								</p>
							</div>
							<div class="col-md-4">
								<div class="alert alert-success text-center hide" id="success-msg" role="alert">
								Thank You!<br>for subscribing to our newsletter.
								<hr>
								<a href="http://www.contrib.com/signup/follow/<?php echo ucfirst($info['domain'])?>" target="_blank" class="btn btn-primary"><i class="fa fa-hand-o-right"></i>&nbsp;Please Follow Our Brands</a>
								</div>
								<select class="form-control input-lg" id="select-form">
									<option>Select Verticals</option>
									<option>Agriculture</option>
									<option>Business</option>
									<option>Cannabis</option>
									<option>Center</option>
									<option>Challenge</option>
								</select>								
								<form id="subscribe-form">
									<div class="alert alert-danger hide" role="alert" id="error-msg">* Please Type a Valid Email!</div>
									<input type="text" id="email" class="form-control email-input" placeholder="Your Email Here">
									<input type="hidden" id="domain" value="<?php echo $info['domain']?>">
									<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
									<a href="#" class="btn btn-danger btn-lg btn-block" id="subscribe"><i class="fa fa-pencil-square"></i> Subscribe Now</a>
								</form>
								<hr>
								<h4><i class="fa fa-newspaper-o"></i> Latest Vertical News</h4>
								<div class="rcv-box2">
									<?php foreach($latest_news as $key=>$val ): ?>
									<h4 class="rcv-title2"><a href="/newsletter/details/<?php echo $val['id']?>/<?php echo $val['slug']?>"><?php echo stripcslashes($val['title'])?>"><?php echo $val['title']; ?></a></h4>
									<img src="<?php echo $val['thumbnail']; ?>" class="rcv-img2">
									<p class="lnws-desc"><?php echo ($val['description']=="0") ? "": $val['description']; ?></p>
									<a href="<?php echo $base_url; ?>home" class="btn btn-primary btn-sm pull-right"><i class="fa fa-search"></i> View More</a>
									<div class="clearfix"></div>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
						<?php endforeach; ?>
					</div>
				</section>
			</div>
			<div class="col-md-3">				
				<h4 class="rcv-title-top"><i class="fa fa-newspaper-o"></i> Recent News</h4>
				<div class="rcv-body">
					<?php foreach($recent_news as $key=>$val ): ?>
					<div class="rcv-box">
						<h4 class="rcv-title"><a href="/newsletter/details/<?php echo $val['id']?>/<?php echo $val['slug']?>"><?php echo stripcslashes($val['title'])?>"><?php echo $val['title']; ?></a></h4>
						<img src="<?php echo $val['thumbnail']; ?>" class="rcv-img">
						<p class="lnws-desc"><?php echo ($val['description']=="0") ? "": $val['description']; ?></p>
						<a href="<?php echo $base_url; ?>home" class="btn btn-sm pull-right"><i class="fa fa-search"></i> View More</a>
						<div class="clearfix"></div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		  </div>
		</div>
	</section>
</div>

<!-- Bootstrap core JavaScript
================================================== -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="bootstrap-portfilter.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
				
		$('#subscribe').on('click', function(e){
			var domain = $('#domain').val();
			var email = $('#email').val();
			var user_ip = $('#user_ip').val();
			var base_url = '<?php echo $base_url; ?>';
			var error_msg = $('#error-msg');
			
			if(validateEmail(email)){
				$.ajax({
					method: 'POST',
					url: 'http://www.api.contrib.com/forms/saveleads',
					data: {domain: domain, email: email, user_ip: user_ip},
					dataType: 'json',
					success: function(data){
						if(data.success){
							$.ajax({
								method: 'POST',
								url: 'http://www.manage.vnoc.com/salesforce/addlead',
								data: {domain: domain, email: email},
								success: function(){
									$('#success-msg').removeClass('hide');
									$('#select-form').addClass('hide');
									$('#subscribe-form').addClass('hide');
								}
							});
						}
					}
				});
				error_msg.addClass('hide');
			} else {
				error_msg.removeClass('hide');
			}
			
			e.preventDefault();
		});
	});
	function validateEmail(email) {
		var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}
</script>