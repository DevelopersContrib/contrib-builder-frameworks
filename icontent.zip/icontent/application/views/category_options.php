<div class="main-top-title">
	<div class="container">
	  <div class="row">
		<div class="main-lander">
			<div class="col-md-9 col-md-offset-1 text-center">
				<h1><?php echo ucfirst($info['domain'])?></h1>
						<?php if ($info['description']!=''):?>
						     <h2 class="lead"><?php echo stripcslashes($info['description'])?></h2>
							<?php else:?>
				             <h2 class="lead"><?php echo ucfirst($info['domain'])?> is a top ranking progressive media and publication, we focus on innovation in technology, economics, leadership, and design. </h2>			
						<?php endif?>
			</div>
			<div class="col-md-12 news-panel">
				<div class="pull-right">
					<a href="/"><button class="btn btn-small btn-danger" data-toggle="portfilter" data-target="all">
						All
					</button></a>	
				 <input type="hidden" name="total_results" id="total_results" value="<?echo $total_results?>" />
			
					<?php if (count($categories) > 0):?>
						<?php foreach ($categories as $key=>$val):?>
							<a href="/category/categories/<?php echo $val['id']?>/<?php echo strtolower(preg_replace('/[^A-Za-z0-9-]+/', '-', $val['name']));?>">			
							<button class="btn btn-small btn-danger" data-toggle="portfilter" data-target="brand">
								<?php echo $val['name']?>
							</button></a>
						<?php endforeach;?>
					<?php endif?>
					
				</div>
			</div>
		</div>	
	  </div>
	</div>
</div>