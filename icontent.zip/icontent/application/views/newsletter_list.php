<?
 function canlike($media_id,$ip){
 
   	    $api_url = "http://api1.contrib.co/request/";
	    $api_url_icontent = "http://api1.contrib.co/icontent/";
	    $headers = array('Accept: application/json');
		$url = $api_url_icontent.'canlike?media_id='.$media_id.'&ip='.$ip;
		$result = createApiCall($url, 'GET', $headers, array());
     	$result_array = json_decode($result,true);
		return $result_array['data']['can_like'];
	}
  
?>

<?php if (count($newsletters) > 0):?>
	<?php foreach ($newsletters as $key=>$val):?>
	<div id="wrapper-container">	
		<div class="panel panel-default">
			<?php 
			switch ($val['media_type']){
				case 'video':
					$header_class="news-header-article";
				break;	
				case 'image':
					$header_class="news-header-image";
				break;
				case 'quiz':
					$header_class="news-header-trivia";
				break;
				case 'poll':
					$header_class="news-header-polls";
				break;
				default:
					$header_class="news-header-article";
				break;	
			}		
			?>

				<div class="panel-heading <?php echo $header_class?>">
				   <div class="col-md-6 item text-left"><?php echo stripcslashes($val['media_type'])?></div>
					<div class="col-md-6 item text-right">

						 <input type="hidden" id="user_ip_<?php echo $val['id']?>" name="user_ip" value="<?php $user_ip = $_SERVER['REMOTE_ADDR']; echo $user_ip;?>">
				 	     <input type="hidden" id="media_id_<?php echo $val['id']?>" name="media_id" value="<?php echo $val['id']?>">
					     <input type="hidden" id="media_title_<?php echo $val['id']?>" name="media_title" value="<?php echo $val['title']?>">
					     <input type="hidden" id="media_likes_<?php echo $val['id']?>" name="media_likes" value="<?php echo $val['likes']?>">

						<?php if (canlike($val['id'],$_SERVER['REMOTE_ADDR'])===true):?>
										<a href="javascript:void(0);"  onclick="javascript:addlike(<?php echo $val['id']?>);" class="like" id="like_<?php echo $val['id']?>"  title="Like <?php echo stripcslashes($val['title'])?>"><i id="likeit_<?php echo $val['id']?>" class="fa fa-thumbs-up likeit"></i>&nbsp;&nbsp;<span id="total_likes_<?php echo $val['id']?>" class="total_likes"><?php echo $val['likes']?></span></a>&nbsp;&nbsp;
							 	<?php else:?>
							 			<a href="javascript:void(0);" style="color:gray" class="like" id="like_<?php echo $val['id']?>"  title="Done Like <?php echo stripcslashes($val['title'])?>"><i id="likeit_<?php echo $val['id']?>" class="fa fa-thumbs-up likeit"></i>&nbsp;&nbsp;<span id="total_likes_<?php echo $val['id']?>" class="total_likes"><?php echo $val['likes']?></span></a>&nbsp;&nbsp;
						<?php endif;?>  	

					</div> 
					 <div class="clearfix"></div>
				</div>
				<div class="panel-body likes">
					<p class="text-right"><i class="news-date">Submitted by <a href=""><?php echo $val['username']?></a> <?php echo $val['date_posted']?> </i></p>
					<h4>
						<a href="http://icontent.com/article/<?php echo $val['slug']?>-<?php echo $val['id']?>" target="_blank"><?php echo stripcslashes($val['title'])?></a>
					</h4>
					<div class="news-img-holder">
						<?php $result = substr($val['thumbnail'], 0, 4);?>
						<?php if ($result == "http"):?>
						<?php $image = $val['thumbnail']?>
						<?php else:?>
						<?php $image = "http://icontent.com/uploads/".$val['thumbnail']?>
						<?php endif;?>
						<img src="<?php echo $image?>" alt="<?php echo stripcslashes($val['title'])?>" title="<?php echo stripcslashes($val['title'])?>" class="img-responsive news-img" class="img-responsive"></a>
					</div>
					<?php if ($val['description'] !='0'):?>
						<p><?php echo stripcslashes($val['description'])?></p>
					<?php endif?>
					<a href="http://icontent.com/article/<?php echo $val['slug']?>-<?php echo $val['id']?>" target="_blank" class="btn btn-danger btn-sm">Read More</a>
				</div>

			</div> <!--end of the panel default-->
	</div>		
	<?php endforeach;?>			
<?php endif;?>
   
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/masonry/3.1.5/masonry.pkgd.min.js"></script>
	<script type="text/javascript">

		jQuery(document).ready(function(){
			jQuery('#wrapper-container').masonry({
				columnWidth: '.col-md-6',
				transitionDuration: '0.4s',
				itemSelector : '.panel'
			});
		});

		function addlike(like_id) {

				var addlikes = 1;
				var user_ip = $('#user_ip_'+like_id).val();
				var media_id = $('#media_id_'+like_id).val();
				var total_likes = $('#media_likes_'+like_id).val();
				var final_likes = $('#total_likes_'+like_id).val();
				var data = { user_ip:user_ip, media_id:media_id };

			        $.post("/newsletter/addlike",
			   			 {
			  		      user_ip:user_ip, 
			            media_id:media_id
			   			 }
			   			 ,function(data){
			           if (data.status) 
			           	{
			  							var final_likes = parseInt(total_likes) + parseInt(addlikes); 
			  							$('#total_likes_'+like_id).html(final_likes);
			  							$('#likeit_'+like_id).css({'color':'gray'});
			  							$('#like_'+like_id).prop('disabled', true);	
			              }else 
			              {
			             				$('#likeit_'+like_id).css({'color':'gray'});
			  							$('#like_'+like_id).prop('disabled', true);	
			             			    alert('You already liked this media');
			              }
			   			}
			   	   );	
				
				console.log(data);
		}	

 </script>
