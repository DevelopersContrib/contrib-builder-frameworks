<?php include'header.php';?>
<style>
.pcontent {
	background: #000;
padding: 60px 50px;
margin-bottom: 100px;
margin-top: 100px;
color:#fff;
}
.pcontent h3 {
	text-transform:uppercase;
}
.about-year {
    border: 2px solid #6d6d6d;
    display: inline-block;
    font-size: 17px;
    height: 160px;
    margin-bottom: 40px;
    padding: 25px;
    width: 120px;
    color: #fff;
}
.about-year span {
    font-size: 50px;
    font-weight: 600;
    left: -4px;
    letter-spacing: -5px;
    position: relative;
    top: 13px;
}
</style>
	<section id="main-section">
		<?php include'navigation.php';?>
		<div class="main-top-title">
			<div class="container">
			  <div class="row">
				<div class="main-lander-2">
					<div class="col-md-8 col-md-offset-2 text-center">
						<h1>About</h1>
					</div>
				</div>	
			  </div>
			</div>
		</div>
		<div class="n-page">
			<div class="container">
			  <div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="pcontent">
						<div class="about-year text-uppercase white-text"><span>20</span> Years</div>
						<h3>We have been in the forefront of domain development and technologies since 1996</h3>
						<p style="clear:both"></p>
					</div>
					<div class="clearfix"></div>
				</div>	
			  </div>
			</div>
		</div>
	</section>
	
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<!--<script src="bootstrap-portfilter.min.js"></script>-->
  </body>
</html>
