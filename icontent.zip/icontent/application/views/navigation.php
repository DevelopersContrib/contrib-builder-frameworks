<style type="text/css">
	.nav-sign li a:focus,
	.nav-sign li a:hover {
	    text-decoration: none;
	    background: none !important;
	}
	.btn-signl {
	    margin-top: 1px;
	    padding-top: 5px !important;
	    padding-bottom: 5px !important;
	    border: 1px solid #EC971F !important;
	    border-radius: 4px;
	    color: #EC971F;
	    font-size: 15px;
	}
	.btn-signl:hover {
	    color: #EC971F;
	    opacity: .8;
	}
	.header-title.navbar-brand {
		color: #fff;
		font-size: 33px;
		text-shadow: 0 0 5px #000;
		line-height: 43px;
	}
	.header-title.navbar-brand:hover {
	    text-decoration: none;
		color: #fff;
	}

	.multi-level{
		background:#222222;
		color: #fff;
	}

	.dropdown-menu .multi-level .nav-r-menus a:hover{
		background:#fff;
		color: #222222;
	}



</style>
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
	            <span class="sr-only">Toggle navigation</span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
            </button>
            <? if($info['logo']!=''): ?>
	            <a class="navbar-brand" href="/">
	            <img src="<?php echo $info['logo']?>" class="nlogo">
	            </a>
            <?php else:?>
            	<a href="/" class="header-title navbar-brand"><?php echo ucfirst($info['domain'])?></a>
            <?php endif?>
        </div>
        <div id="navbar" class="collapse navbar-collapse nmenus">
            <ul class="nav navbar-nav">
                <li><a href="/">Home</a></li>
                <li><a href="/about">About</a></li>
                <li><a href="/contact">Join Us</a></li>
                <li><a href="/fund">Fund</a></li>
                <li><a href="/developers">Developers</a></li>
                <li><a href="/partners">Partners</a></li>
                 <li><a href="/apps">Apps</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right nav-r-menus">
                <?php if ($_SESSION['loggedin']===true):?>
                <li class="dropdown pull-right">
                    <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-warning" data-target="#" href="#">
                    Welcome, <?php echo $_SESSION['username']?> <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
                        <li><a href="/create"><i class="glyphicon glyphicon-plus"></i> Post Content</a></li>
                        <li><a href="/signout"><i class="glyphicon glyphicon-off"></i> Logout</a></li>
                    </ul>
                </li>
	            <?php else:?>
	            	<li class="nav-sign">
	            		<a href="/signup" class="btn-signl">
	            			<i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Sign-Up&nbsp;|&nbsp;Log-In
	            		</a>
	            	</li>
	            <?php endif?> 
            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
</nav>