<style type="text/css">
	.main-lander-2 h4 {
		color: #fff;		
	}
	.blckBckgrnd {
		background: rgba(0,0,0,0.5);
		padding: 20px 15px;
		margin-bottom: 10px;
		box-shadow: 0 0 3px rgba(255, 255, 255, 0.4)
	}
	.blckBckgrnd a img {
		width: 244px;
	}
	.blckBckgrnd h3 {
		font-weight: bold;
		margin-top: 0;
		text-align: left;
	}
	.blckBckgrnd p {
		color: #fff;
		text-align: left;
	}
</style>
<style>
.main-top-title {   
    margin-bottom: 30px !important;
}
</style>
<?php include'header.php';?>
	<section id="main-section">
		<?php include'navigation.php';?>
		<div class="main-top-title">
			<div class="container">
			  <div class="row">
				<div class="main-lander-2">
					<div class="col-md-6 col-md-offset-3 text-center">
						<h1><?php echo ucwords($info['domain']); ?></h1>
						<h4>Learn more about Joining our Partner Network</h4>
						<div class="row-fluid text-center">
                        	<a href="/contact" class="btn btn-large btn-primary">
                        		Join Our Partner Network
                        	</a>
                        	<br/>
                        </div>
					</div>
				</div>	
			  </div>
			</div>
		</div>
		<div class="n-page" style="padding-bottom:100px;">
			<div class="container">
			  <div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">			
					<div class="padd-banner">
							<div class="col-md-2">&nbsp;</div>
                            <div class="row blckBckgrnd"><!-- blckBckgrnd -->
								<div class="col-md-5">
									<a href="http://contrib.com">
										<img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-green13.png" alt="Contrib.com" title="contrib.com" />
                                    </a>
								</div>
								<div class="col-md-7">
									<h3><a href="http://contrib.com">Contrib.com</a></h3>
									<p>
										Our network of Contributors power our domains. Browse through our Marketplace of People, Partnerships,Proposals and Brands and find your next great opportunity. Join Free Today.
									</p>
								</div>
                            </div><!-- end blckBckgrnd -->
						    <div class="row blckBckgrnd"><!-- blckBckgrnd -->
								<div class="col-md-5">
									<a href="http://globalventures.com">
                                        <img src="http://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png" alt="GlobalVentures.com" title="GlobalVentures.com" />
                                    </a>
								</div>
								<div class="col-md-7">
									<h3><a href="http://globalventures.com">GlobalVentures.com</a></h3>
                                    <p>
                                        Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly.
                                        Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.
                                    </p>
                                    <p>
                                        With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.
                                    </p>
								</div>
                            </div><!-- end blckBckgrnd -->
						    <div class="row blckBckgrnd"><!-- blckBckgrnd -->
								<div class="col-md-5">
									<a href="http://ifund.com">
                                        <img src="http://www.contrib.com/uploads/logo/ifund.png" alt="iFund.com" title="Ifund.com" />
                                    </a>
								</div>
								<div class="col-md-7">
									<h3><a href="http://ifund.com">iFund.com</a></h3>
                                    <p>
                                        iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
                                        advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
                                        investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
                                        iFund receives no compensation in connection with the purchase or sale of securities.
                                    </p>
								</div>
                            </div><!-- end blckBckgrnd -->
						    <div class="row blckBckgrnd"><!-- blckBckgrnd -->
								<div class="col-md-5">
									<a href="http://ichallenge.com">
                                        <img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png" alt="iChallenge.com" title="iChallenge.com" />
                                    </a>
								</div>
								<div class="col-md-7">
									<h3><a href="http://ichallenge.com">iChallenge.com</a></h3>
                                    <p>
										The best internet challenges. Solve and win online prizes.
                                    </p>
								</div>
                            </div><!-- end blckBckgrnd -->
							<!-- start dynmic partners -->

							<!-- end dynmic partners -->
							<div class="col-md-2">&nbsp;</div>
                    </div><!-- padd-banner -->					
					<div class="clearfix"></div>
				</div>	
			  </div>
			</div>
		</div>		
	</section>	
	
	<?php include 'footer.php'; ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<!--<script src="bootstrap-portfilter.min.js"></script>-->
  </body>
</html>
