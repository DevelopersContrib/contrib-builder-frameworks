
<?php include'header.php';?>
<style type="text/css">
	.block-box2 {
	background-color: rgba(0, 0, 0, 0.8);
	border-radius: 5px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
    margin-bottom: 25px;
    margin-top: 10px;
  	padding: 15px 30px;
    text-align: left;
    color: white;
	}
	.nav-pills.nav-pills-cust {
    background-color: #f8f8f8;
    border: 1px solid #e7e7e7;
    border-radius: 5px;
    margin-bottom: 5px;
    padding: 5px 10px;
	}
	.es-blck-rnd {
		word-wrap: break-word;
		text-transform: uppercase;
	}
	.banner-main textarea {
    color: #000;
    width: 100%;
    margin: 10px 0px;
    height: 110px;
}
	.wrap-allbanner {
    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-728x90-1.png") no-repeat scroll 0 0;
    box-sizing: border-box;
    height: 90px;
    position: relative;
    width: 728px;
}
	.wrap-bannerLeft, .wrap-bannerRight {
	    display: inline-block;
	    float: left;
	}
	.wrap-bannerLeft {
	    box-sizing: border-box;
	    height: 90px;
	    overflow: hidden;
	    padding: 15px 5px 20px 10px;
	    vertical-align: top;
	    width: 245px;
	}
	.blck2-box .ellipsis {
	    overflow: hidden;
	    text-overflow: ellipsis;
	    white-space: nowrap;
	}
	.aBnnrP {
	    box-sizing: border-box;
	    color: #0088cc;
	    display: block;
	    font-size: 22px;
	    font-weight: bold;
	    line-height: normal;
	    margin: 0;
	    text-align: center;
	    text-decoration: none;
	    text-transform: capitalize;
	}
	.logo-banners1 {
	    box-sizing: border-box;
	    max-height: 58px;
	    max-width: 100%;
	}
	.wrap-bannerRight {
	    color: #ffffff;
	    height: 90px;
	    margin-left: 84px;
	    width: 397px;
	}
	.content-rightText {
	    box-sizing: border-box;
	    margin: auto;
	    padding-top: 16px;
	    width: 350px;
	}
	.content-rightText span {
	    box-sizing: border-box;
	    display: block;
	}
	.content-rightText span, .content-rightText p {
	    font-size: 25px;
	    text-align: center;
	    text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
	}
	.block-group{
	    border-bottom: 1px solid #fff;
	    margin-bottom: 25px;
	    padding-bottom: 30px;
	}
	.block-group:last-child{
	    margin-bottom: 0;
	    border-bottom: none;
	}
	.wrapBanner-2 {
	    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/jayson/180x150-1.png") no-repeat scroll 0 0;
	    box-sizing: border-box;
	    height: 150px;
	    margin: auto;
	    overflow: hidden;
	    position: relative;
	    width: 180px;
	}
	.wrap-topBanner {
	    box-sizing: border-box;
	    display: block;
	    margin: 37px auto 0;
	    position: relative;
	    width: 118px;
	}
	.wrap-contentTop {
	    box-sizing: border-box;
	    color: #fff;
	    font-size: 20px;
	    letter-spacing: 0.01em;
	    line-height: 1.1em;
	    text-align: center;
	    text-shadow: 2px 1px 1px rgba(0, 0, 0, 0.5);
	}

	.wrap-contentTop span {
	    display: block;
	}
	.wrap-downBanner {
	    box-sizing: border-box;
	    display: block;
	    height: 37px;
	    margin: 5px 0 0;
	    overflow: hidden;
	}
	.wrap-contentDown {
	    box-sizing: border-box;
	    height: 35px;
	    margin: auto;
	    padding: 1px 0;
	    width: 125px;
	}
	.wrap-contentDown img {
	    max-height: 32px;
	    max-width: 100%;
	    text-align: center;
	}
	.wrap-contentDown p {
	    box-sizing: border-box;
	    color: #0088cc;
	    display: block;
	    margin: 0;
	}
	.wrapBanner-3 {
	    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-160x600-1.png") no-repeat scroll 0 0;
	    box-sizing: border-box;
	    height: 600px;
	    margin: auto;
	    overflow: hidden;
	    position: relative;
	    width: 180px;
	}
	.wrap-topBanner3 {
	    box-sizing: border-box;
	    display: block;
	    margin: 130px 18px 0;
	    position: relative;
	    width: 120px;
	}


	.wrapBanner-4 {
	    background: rgba(0, 0, 0, 0) url("http://d2qcctj8epnr7y.cloudfront.net/images/2013/banner-contrib-250x250-1.png") no-repeat scroll 0 0;
	    box-sizing: border-box;
	    height: 250px;
	    margin: auto;
	    overflow: hidden;
	    position: relative;
	    width: 250px
	}
	.wrap-topBanner4 {
	    box-sizing: border-box;
	    display: block;
	    margin: 76px 18px 0;
	    position: relative;
	    
	}
	.floating {
	    animation-duration: 1.5s;
	    animation-iteration-count: infinite;
	    animation-name: floating;
	}
	@keyframes floating {
	0% {
	    transform: translateY(0%);
	}
	50% {
	    transform: translateY(8%);
	}
	100% {
	    transform: translateY(0%);
	}
	}
	
	img[Social Id Banners]{
		width:100%;
	}
</style>
<style>
.main-top-title {   
    margin-bottom: 30px !important;
}
</style>
	<section id="main-section">
		<?php include'navigation.php';?>
		<div class="main-top-title">
			<div class="container">
				<div class="row">
					<div class="main-lander-2">
						<div class="col-md-6 col-md-offset-3 text-center">
							<h1>Referral</h1>
						</div>
					</div>	
				</div>
			</div>
		</div>
		<div class="n-page" style="padding-bottom:100px;">
			<div class="container">
			  <div class="row">
				<div class="col-md-9 col-md-offset-1 text-center">
					<!-- iframe -->
					<div class="block-group">
							<iframe width="850px" height="800px" frameborder="0" seamless="" scrolling="auto" src="http://referrals.contrib.com/aff_index.php?affiliate=<?php echo $info['domain']?>"></iframe>
							<div class="clearfix"></div>
					</div>
					<!-- end of  iframe -->
					<div class="clearfix"></div>
					<ul class="nav nav-pills nav-pills-cust" role="tablist"><!-- nav tab -->
						<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Featured Programs</a></li>
						<li role="presentation"><a href="#bannerCode" aria-controls="bannerCode" role="tab" data-toggle="tab">Featured Banner</a></li>
					</ul><!-- nav tab -->
					<div class="block-box2">	
							<div class="tab-content tab-content-cust"><!-- tab content -->
								<div role="tabpanel" class="tab-pane active" id="home">
									<div class="wrap-white-container">
										<h3 class="banner-header">Referral Programs</h3>
										<?php if (count($programs)>0):?>
											<?php foreach ($programs as $key=>$val):?>
												<div class="banner-main">
													<dl class="dl-horizontal banner-info">
														<dt>Referral Program</dt><dd><?php echo $val['title']?></dd>					                                       
													</dl>
													<div class="text-center">
														<?php echo $val['code']?>
													</div>
													<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
														<textarea class="text-left input-block-level" rows="3" onclick="this.focus();this.select()" readonly="readonly">
															<?php echo $val['code']?>
														</textarea>
												</div>
											<?php endforeach;?>
										 <?php endif?>
									</div>
								</div>			
								<div role="tabpanel" class="tab-pane" id="bannerCode">								
									
									<div class="block-group">
										<dl class="dl-horizontal">
											<dt>Marketing Group</dt><dd>Contrib</dd>
											<dt>Banner Size</dt><dd>728 x 90</dd>
											<dt>Banner Description</dt><dd><?php echo $info['domain']; ?> Banner</dd>
											<dt>Target URL</dt><dd>http://<?php echo $info['domain']; ?></dd>
										</dl>
										<div class="floating text-center banner-img-cont">
											<div class="wrap-allbanner">
												<div class="wrap-bannerLeft">
													 <p class="aBnnrP ellipsis" href="">
														  <img class="logo-banners1" alt="<?php echo $info['domain']; ?>" title="<?php echo $info['domain']; ?>" src="<?php echo $info['logo']; ?>" width="214" heigth="58">
													 </p>
												</div>
												<div class="wrap-bannerRight ">
													<div class="content-rightText ">
														<span class="">Follow , Join and</span>
														<p class="ellipsis">Partner with Contrib.com</p>
													</div>
												</div>
											</div>
										</div>
										<br />
										<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
										<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/leadbanner/<?php echo $info['domain']; ?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
										<div class="clearfix"></div>
									</div>
									<div class="block-group">
										<dl class="dl-horizontal">
											<dt>Marketing Group</dt><dd>Contrib</dd>
											<dt>Banner Size</dt><dd>180 x 150</dd>
											<dt>Banner Description</dt><dd><?php echo $info['domain']; ?> Banner</dd>
											<dt>Target URL</dt><dd>http://<?php echo $info['domain']; ?></dd>
										</dl>
										<div class="floating text-center banner-img-cont">
											<div class="wrapBanner-2">
												<div class="wrap-topBanner ">
													<div class="wrap-contentTop">
														<span>Follow, Join</span>
														<span>and Partner with</span>
													</div>
												</div>
												<div class="wrap-downBanner">
													<div class="wrap-contentDown">
														<p class="ellipsis" href="">
															<img alt="<?php echo $info['domain']; ?>" title="<?php echo $info['domain']; ?>" src="<?php echo $info['logo']; ?>">
														</p>
													</div>
												</div>
											</div>
										</div>
										<br />
										<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
										<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/roundleadbanner/<?php echo $info['domain']; ?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
										<div class="clearfix"></div>
									</div>
									<div class="block-group">
										<dl class="dl-horizontal">
											<dt>Marketing Group</dt><dd>Contrib</dd>
											<dt>Banner Size</dt><dd>728 x 90</dd>
											<dt>Banner Description</dt><dd><?php echo $info['domain']; ?> Banner</dd>
											<dt>Target URL</dt><dd>http://<?php echo $info['domain']; ?></dd>
										</dl>
										<div class="floating text-center banner-img-cont">
											<div class="wrapBanner-3">
												<div class="wrap-topBanner3 ">
													<div class="wrap-contentTop">
														<span>Follow, Join</span>
														<span>and Partner with</span>
													</div>
												</div>
												<div class="wrap-downBanner">
													<div class="wrap-contentDown">
														<p class="ellipsis" href="">
															<img alt="<?php echo $info['domain']; ?>" title="<?php echo $info['domain']; ?>" src="<?php echo $info['logo']; ?>">
													</div>
												</div>
											</div>
										</div>
										<br />
										<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
										<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/verticalbanner<?php echo $info['domain']; ?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
									</div>						
									<div class="block-group">
										<dl class="dl-horizontal">
										  <dt>Marketing Group</dt><dd>Contrib</dd>
										  <dt>Banner Size</dt><dd>250 x 250</dd>
										  <dt>Banner Description</dt><dd><?php echo $info['domain']; ?> Banner</dd>
										  <dt>Target URL</dt><dd>http://<?php echo $info['domain']; ?></dd>
										</dl>
										<div class="floating text-center banner-img-cont">
										  <div class="wrapBanner-4">
												<div class="wrap-topBanner4 ">
													 <div class="wrap-contentTop">
														  <span>Follow, Join</span>
														  <span>and Partner with</span>
													 </div>
												</div>
												<div class="wrap-downBanner">
													 <div class="wrap-contentDown">
														  <p class="ellipsis" href="">
																<img src="<?php echo $info['logo']; ?>" title="<?php echo $info['domain']; ?>" alt="<?php echo $info['domain']; ?>" src="">
													 </div>
												</div>
										  </div>
										</div>
										<br />
										<p class="text-center banner-source">Source Code - Copy/Paste Into Your Website</p>
										<textarea readonly="readonly" onclick="this.focus();this.select()" rows="3" class="text-left form-control">&lt;script type="text/javascript" src="http://www.contrib.com/widgets/squarebanner/<?php echo $info['domain']; ?>/<?echo $domainid?>"&gt;&lt;/script&gt;</textarea>
									</div>
								</div>
							</div><!-- end tab content -->
						</div>
					</div>
				</div>
			</div>
		</section>		
				</div>	
			  </div>
			</div>
		</div>
	</section>
	
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
  </body>
</html>
