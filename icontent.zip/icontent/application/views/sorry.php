<style>
.alert {
padding: 40px 0px 60px;
}
.btn {
    font-size: 19px !important;
    padding: 10px 15px !important;
}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12 text-center">
			<div class="alert alert-info" role="alert">
				<h3>"Nothing Found Sorry, no posts available as of this moment."</h3>
				<hr>
				<a href="" class="btn btn-warning btn-lg" target="_blank">Go To iContent to Create, publish and make your content viral</a>
			</div>			
		</div>
	</div>
</div>