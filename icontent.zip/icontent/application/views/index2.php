<?php include'header.php';?>
 <link rel="stylesheet" type="text/css" href="http://presstrackers.com/css/owl.carousel.css">
<style>
	.counter {
	    display: none;
	}
	.pagination {
	    margin: 0px 0px;
	}
	.pagination > ul > li,
	.pagination span.pagenav,
	.pagination a.pagenav {
	    display: inline-block;
	    width: 30px;
	    text-align: center;
	    font-weight: bold;
	}
	.pagination a.pagenav {
	    color: #555;
	    text-decoration: none;
	}
	.pagination a.pagenav:hover {
	    background-color: #999;
	    border: none;
	    color: white;
	    text-decoration: none;
	}
	.pagination span.pagenav {
	    color: #333;
	}
	#news-container {
	    background: #e9e9e9;
	    padding-top: 20px;
	    padding-bottom: 80px;
	}
	.hide {
	    display: none;
	}
	#ntopbrands {
	    background-color: #F2F2F2;
	    padding: 50px 0;
	}
	/* carousel css here */

	.wrap-marketplace-box-item {
	    background-color: #fff;
	    border-radius: 2px;
	    border-top: 1px solid #d9d9d9;
	    box-shadow: 0 1px 0 1px #d9d9d9;
	    display: block;
	    padding: 15px;
	    text-align: center;
	    word-wrap: break-word;
	    color: #000;
	    text-shadow: none;
	    margin-bottom: 25px;
	}
	/* Logo Found */

	.wmbi-img-logo {
	    display: block;
	    margin-bottom: 15px;
	}
	.wmbi-img-logo img {
	    display: inline-block;
	    max-height: 60px;
	}
	/* Title Brand */

	.wmbi-ttle {
	    background-color: #f5f5f5;
	    color: #2e9f3e;
	    font-size: 1.3em;
	    font-weight: bold;
	    padding: 10px 5px;
	}
	.marg-m-ttlTop {
	    margin-top: 0;
	}
	.p-marg-btm {
	    margin-bottom: 0;
	}
	.ul-wmbi-zero li {
	    list-style: outside none none;
	    padding: 0;
	}
	.ul-wmbi-zero li .btn {
	    margin: 0;
	}
	/* Carousel Custom Brands */

	#brandsCarousel .owl-item {
	    padding: 15px;
	}
	#brandsCarousel .owl-prev::before,
	#brandsCarousel .owl-next::before {
	    background-color: #e1e1e1;
	}
	/* ===================================
	Owl carousel
	====================================== */

	.owl-carousel {
	    overflow: hidden;
	}
	.owl-buttons {
	    position: static;
	}
	.owl-prev,
	.owl-next {
	    color: #111;
	    display: block;
	    font-size: 16px;
	    height: 105px;
	    line-height: 105px;
	    margin-top: -35px;
	    opacity: 0;
	    position: absolute;
	    text-align: center;
	    top: 50%;
	    width: 105px;
	    z-index: 6;
	}
	.owl-prev {
	    left: -70px;
	}
	.owl-next {
	    right: -70px;
	}
	.owl-prev:before,
	.owl-next:before {
	    background-color: #fff;
	    border-radius: 2px;
	    box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1);
	    content: "";
	    display: block;
	    height: 66%;
	    left: 0;
	    position: absolute;
	    width: 66%;
	}
	.owl-next:before {
	    left: auto;
	    right: 0;
	}
	.owl-prev .fa,
	.owl-next .fa {
	    color: #000;
	    font-size: 24px;
	    position: relative;
	    top: -15%;
	}
	.owl-prev .fa {
	    right: 4%
	}
	.owl-next .fa {
	    left: 4%;
	}
	.owl-carousel:hover .owl-prev {
	    left: -35px;
	    opacity: 1;
	}
	.owl-carousel:hover .owl-next {
	    opacity: 1;
	    right: -35px;
	}
	.owl-pagination {
	    bottom: 30px;
	    display: block;
	    left: 0;
	    position: absolute;
	    text-align: center;
	    width: 100%;
	    z-index: 100 !important;
	}
	.owl-page {
	    display: inline-block;
	    padding: 6px 5px;
	}
	.owl-page span {
	    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.7);
	    border-radius: 4px;
	    box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.1);
	    display: block;
	    height: 7px;
	    transition: all 0.27s cubic-bezier(0, 0, 0.58, 1) 0s;
	    width: 7px;
	}
	.owl-page:hover span {
	    background: none repeat scroll 0 0 rgba(255, 255, 255, 1);
	}
	.owl-page.active span {
	    background: none repeat scroll 0 0 transparent;
	    border: 1px solid rgba(255, 255, 255, 0.8);
	    transform: scale(1.33333);
	}
	.owl-bg-img {
	    background-position: center center;
	    background-repeat: no-repeat;
	    background-size: cover;
	    display: block;
	    overflow: hidden;
	    position: relative;
	    width: 100%;
	}
	.owl-subtitle {
	    font-size: 14px;
	    letter-spacing: 10px;
	    text-transform: uppercase;
	    font-weight: 400;
	    line-height: 80px;
	    display: block
	}
	.owl-title {
	    font-size: 35px;
	    font-weight: 600;
	    text-transform: uppercase;
	    display: block;
	    letter-spacing: 7px;
	}
	.owl-title-big {
	    background: rgba(0, 0, 0, 0.5);
	    display: inline-block;
	    font-size: 25px;
	    font-weight: 600;
	    letter-spacing: 7px;
	    line-height: 40px;
	    padding: 35px 50px;
	    text-transform: uppercase;
	    width: 60%
	}
	.dark-pagination .owl-page span {
	    background: none repeat scroll 0 0 rgba(0, 0, 0, 1);
	    box-shadow: none
	}
	.dark-pagination .owl-page.active span {
	    background: transparent;
	    border: 1px solid rgba(0, 0, 0, 1);
	}
	.dark-pagination .owl-prev,
	.owl-next {
	    opacity: 1;
	}
	.dark-pagination .owl-next:before {
	    left: auto;
	    right: 0;
	}
	.dark-pagination .owl-prev {
	    left: -35px;
	    opacity: 1;
	}
	.dark-pagination .owl-next {
	    opacity: 1;
	    right: -35px;
	}
	.light-pagination .owl-page.active span {
	    background: transparent;
	    border: 1px solid rgba(255, 255, 255, 1);
	}
	#ntopbrands .nv-title {
	    border-bottom: 1px solid #f2f2f2;
	    margin-bottom: 20px;
	    margin-top: 0;
	    padding: 0 0 15px;
	}

	.main-top-title.category-top-title{
		padding:50px 0;
	}
	#news-container{
		background: #e9e9e9;
	}
</style>
<section id="main-section">
	<?php include'navigation.php';?>
	<div class="main-top-title category-top-title">
		<div class="container">
		  <div class="row">
			<div class="main-lander">
				<div class="col-md-9 col-md-offset-1 text-center">
					<!-- Dynamic Category here -->
					<h1 class="text-capitalize">Agriculture Category</h1>
				</div>
			</div>	
		  </div>
		</div>
	</div>
	<!-- news panel -->
	<div id="news-container">
		<div class="wrap-breadcrumbs-container">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<ol class="breadcrumb">
							<li><a href="#">Home</a></li>
							<li class="active text-capitalize">Agriculture Category</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
		<div class="container news-panel">				
			<div class="clearfix"></div>
			<h3 class="cat-name-title text-center"></h3>
			<div class="pull-right">
				<div class="pagination">
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="text-center" id="loading-area">
			</div>
			<div class="clearfix"></div>
			<div class="row" id="newsletter_list">
			</div>
		</div>
	</div>
	<!-- end news panel-->
</section>
	
<section id="nverticals">
	<div class="container">
		<h2 class="nv-title text-center text-uppercase">Top Vertical News Site</h2>
		<div class="row">
			<ul class="list-unstyled">
				<li class="col-md-4">
					<a href="http://domainbuild.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-domainbuild-7.png" class="img-responsive"></a>
				</li>
				<li class="col-md-4">
					<a href="http://davaonews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-davaonews1.png" class="img-responsive"></a>
				</li>
				<li class="col-md-4">
					<a href="http://bondnews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-bondnews1.png" class="img-responsive"></a>
				</li>
				<li class="col-md-4">
					<a href="http://currencynews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Currencynews1.png" class="img-responsive"></a>
				</li>
				<li class="col-md-4">
					<a href="http://agentnews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-agentnews.png" class="img-responsive"></a>
				</li>
				<li class="col-md-4">
					<a href="http://channeltv.com" target="_blank"><img src="https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-ChannelTv.png" class="img-responsive"></a>
				</li>
			</ul>
		</div>
	</div>
</section>	 
    
    <section id="ntopbrands">
    	<div class="container">
  		<!-- <?php var_dump($featuredsites);?> -->
    <div class="row">
	      <div class="col-md-12 text-center">
	        <h2 class="nv-title text-center text-uppercase">Our Top Brands</h2>
	        <div class="col-md-12">
	          <div id="brandsCarousel" class="owl-carousel">
	          <?php foreach($featuredsites as $featuredsites): ?>
	                 <div>
	                      <div class="wrap-marketplace-box-item">
	                              <a class="wmbi-img-logo" href="http://<?php echo $featuredsites['domain_name']; ?>">
	                                  <?php if(!empty($featuredsites['logo'])):?>
	                              <img src="<?php echo $featuredsites['logo']; ?>" class="img-responsive" alt="<?php echo $featuredsites['domain_name']; ?>">
	                            <?php else: ?>
	                              <img src="https://d2qcctj8epnr7y.cloudfront.net/contrib/logo-contrib-brand2.png" class="img-responsive">
	                            <?php endif; ?>
	                                        </a>
	                              <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
	                                  <?php echo $featuredsites['domain_name']; ?>
	                              </h3>
	                              <p class="p-marg-btm">
	                                  Join our exclusive community of like minded people on 
	                              </p>
	                              <p>
	                                  <a target="_blank" href="http://<?php echo $featuredsites['domain_name']; ?>"><?php echo $featuredsites['domain_name']; ?></a>
	                              </p>
	                              <ul class="list-inline ul-wmbi-zero">
	                                  <li>
	                                      <a class="btn btn-success btn" target="_blank" href="http://<?php echo $featuredsites['domain_name']; ?>">Visit</a>
	                                  </li>
	                                  <li>
	                                      <a class="btn btn-success btn" target="_blank" href="https://contrib.com/brand/details/<?php echo $featuredsites['domain_name']; ?>">Details</a>
	                                  </li>
	                              </ul>
	                          </div>
	                      </div>
	          <?php endforeach; ?>
	         </div>
	        </div>
	      </div>
	    </div>
		</div>
    	</div>
    </section>



    <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-517895f814f07260"></script>
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/masonry/3.1.5/masonry.pkgd.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  </body>
  <script>
  jQuery(document).ready(function() {
		var total_results = jQuery('#total_results').val();
		var current_page = 1;
		loadPages(current_page);

			
	});

	function loadPages(current_page){
		var total_results = jQuery('#total_results').val();
		var loading_area = $('#loading-area');
		getPagination(current_page,total_results);
		loading_area.html("<img src='/img/loadingAnimation.gif' alt='Loading...' />");
		//jQuery('#newsletter_list').html('<center><img class="tloader" alt="Loading Contents.." src="/images/loaders/loader10.gif"></center>');
		jQuery.post('/newsletter/ajaxlist',{current_page:current_page},function(data_html){
			loading_area.html('');
			jQuery('#newsletter_list').html(data_html);			
		});
	}

	function getPagination(current_page,total_results){
		jQuery.post('/newsletter/ajaxpagination',{current_page:current_page,total_results:total_results},function(data_html){
			jQuery('.pagination').html(data_html);
		});
	}
	  
  </script>
  <script type="text/javascript" src="http://presstrackers.com/js/owl.carousel.js"></script>
<script>
    jQuery(document).ready(function(){
        jQuery("#brandsCarousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            items: 3,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        });
    }); 
</script>
</html>
