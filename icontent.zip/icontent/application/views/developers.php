<?php include'header.php';?>
<style>
.main-top-title {   
    margin-bottom: 30px !important;
}
</style>
	<section id="main-section">
		<?php include'navigation.php';?>
		<div class="main-top-title">
			<div class="container">
			  <div class="row">
				<div class="main-lander-2">
					<div class="col-md-6 col-md-offset-3 text-center">
						<h1>Developers</h1>
					</div>
				</div>	
			  </div>
			</div>
		</div>
		<div class="n-page" style="padding-bottom:100px;">
			<div class="container">
			  <div class="row">
				<div class="col-md-6 col-md-offset-3 text-center">
					<div class="n-page-box" style="margin-top:50px;margin-bottom:50px;">
						<h2>Are You A Developer?</h2>
						<p class="fnt-300 fnt-lato text-left">
							Do you have code or an app that could run this brand? <?=ucwords($info['domain'])?> is connected with Contrib.
						</p>
						<p class="fnt-300 fnt-lato text-left">
							Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world’s best brands on them. Do you have an app, or code that could help run<?=ucwords($info['domain'])?>?
						</p>
						<p><a href="/contact" class="btn btn-default">Contact Us</a></p>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>	
			  </div>
			</div>
		</div>
	</section>
	
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

  </body>
</html>
