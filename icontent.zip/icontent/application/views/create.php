<?php include'header.php';?>
<link rel="stylesheet" type="text/css" href="http://bootstrap-wysiwyg.github.io/bootstrap3-wysiwyg/dist/bootstrap3-wysihtml5.min.css" />
<style>
}
.panel-create {
	border-color: #ccc;
	-webkit-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);
	-moz-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);
	box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);	
}
.panel-create>.panel-heading {
	color: #00415d;
	background-color: #fff;
	border-color: #fff;
	text-align:center;
}
.panel-create>.panel-heading a{
	text-decoration: none;
	background-color:#f5f5f5;
	color: #bbb;
	font-weight: bold;
	font-size: 22px;
	padding:5px 10px;
	border-radius:15px;
	-webkit-transition: all 0.1s linear;
	-moz-transition: all 0.1s linear;
	transition: all 0.1s linear;
}
.panel-create>.panel-heading a.active{
	background-color:#029f5b;
	color: #fff;
	font-size: 22px;
	padding:5px 10px;
	border-radius:15px;
}
.panel-create>.panel-heading hr{
	margin-top: 10px;
	margin-bottom: 0px;
	clear: both;
	border: 0;
	height: 1px;
	background-image: -webkit-linear-gradient(left,rgba(0, 0, 0, 0),rgba(0, 0, 0, 0.15),rgba(0, 0, 0, 0));
	background-image: -moz-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
	background-image: -ms-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
	background-image: -o-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
}
.panel-create input[type="text"],.panel-create input[type="email"],.panel-create input[type="password"] {
	height: 45px;
	border: 1px solid #ddd;
	font-size: 16px;
	-webkit-transition: all 0.1s linear;
	-moz-transition: all 0.1s linear;
	transition: all 0.1s linear;
}
.panel-create input:hover,
.panel-create input:focus {
	outline:none;
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
	box-shadow: none;
	border-color: #ccc;
}
.btn-create {
	background-color: #59B2E0;
	outline: none;
	color: #fff;
	font-size: 14px;
	height: auto;
	font-weight: normal;
	padding: 14px 0;
	text-transform: uppercase;
	border-color: #59B2E6;
}
.btn-create:hover,
.btn-create:focus {
	color: #fff;
	background-color: #53A3CD;
	border-color: #53A3CD;
}
.forgot-password {
	text-decoration: underline;
	color: #888;
}
.forgot-password:hover,
.forgot-password:focus {
	text-decoration: underline;
	color: #666;
}

.btn-register {
	background-color: #1CB94E;
	outline: none;
	color: #fff;
	font-size: 14px;
	height: auto;
	font-weight: normal;
	padding: 14px 0;
	text-transform: uppercase;
	border-color: #1CB94A;
}
.btn-register:hover,
.btn-register:focus {
	color: #fff;
	background-color: #1CA347;
	border-color: #1CA347;
}
.n-page {
	padding:50px 0px 150px
}
.btn-facebook {
	background-color:#24365C;
	border-color:#24365C;
}
.panel-create select {
	height:45px;
}

/*** laoder ****/
.loader-box {
	border: 1px solid #999;
border-radius: 4px;
padding: 0px 20px 20px;
margin-top: 30px;
}
.load-wrapper {
  position: relative;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #fff;
}

.rubik-loader {
  width: 64px;
  height: 64px;
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  background-image: url(http://smallenvelop.com/wp-content/uploads/2014/08/Preloader_3.gif);
  background-repeat: no-repeat;
  background-position: center;
}
.loader-image-container {
	margin-top: 35px;
}
.loader-box .loader-image-container img {
	width: 80px;
	float: left;
	margin-right: 0px;
margin-top: -15px;
}
.loader-image-container b {
	color:#FF1D25;
}
</style>
	<section id="main-section">
		<?php include'navigation.php';?>
		<div class="main-top-title">
			<div class="container">
			  <div class="row">
				<div class="main-lander-2">
					<div class="col-md-6 col-md-offset-3 text-center">
						<h1>Create Article</h1>
					</div>
				</div>	
			  </div>
			</div>
		</div>
		<div class="n-page">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<div class="panel panel-create" style="padding-top:20px;">							
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-12">
									    <div role="alert" id="noty_error" class="alert alert-danger alert-dismissible" style="display: none"> 
										       <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button> 
										       <span id="error_message"></span> 
										 </div>
										 <div role="alert" id="noty_success" class="alert alert-success alert-dismissible" style="display: none"> 
										       <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button> 
										       <span id="success_message"></span> 
										 </div>
										 <div id="form-loader" style="text-align: center;display:none">Saving content  <img src="/img/loadingAnimation.gif" alt="Saving..." title="Saving...." /></div>
										 <div class="loader-box form-group" id="loader" style="display:none;">
												<div class="row">
													<div class="col-sm-12 text-center">
														<div class="load-wrapper">
															<div class="rubik-loader"></div>
														</div>
														<div class="loader-image-container text-center">
															<img src="https://rdbuploads.s3.amazonaws.com/icons/edit-text.png" alt="edit" title="edit">
															<h3>We are now sending your article to <b>icontent.com</b> ...</h3>
														</div>
													</div>
												</div>
										</div>
										<div class="clearfix"></div>
										    
										<form id="submit-form-content" action="javascript:submitcontent()" method="post" role="form" style="display: block;">
										    
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-align-justify"></i></span>
												<input type="text" name="c_title" id="c_title" tabindex="1" class="form-control" placeholder="Title" value="">
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
												<textarea type="text" name="c_description" id="c_description" tabindex="1" class="form-control" placeholder="Description" value=""></textarea>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
												<select type="text" name="c_category" id="c_category" tabindex="1" class="form-control" placeholder="Category" value="">
													<option value="">-- Select Category --</option>
													<?php foreach ($categories as $key=>$val):?>
													<option value="<?php echo $val['id']?>"><?php echo $val['name']?></option>
													<?php endforeach;?>
												</select>
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="glyphicon glyphicon-align-justify"></i></span>
												<input type="text" name="c_image" id="c_image" tabindex="1" class="form-control" placeholder="Image URL" value="">
											</div>
											<!-- <div class="form-group">
												 <div class="row">
												  <div class="col-xs-12">
												   <a href="#" class="thumbnail">
												        <div class="img-responsive" id="image-preview"> </div>  
												   </a>
												  </div>
												 </div>
											</div> -->
											  <div class="liveurl">
										            <div class="close" id="closes" title="Close Image"></div>
										            <div class="liveurl-loader" id="liveurl-loader" title="Loading"></div>
										            <div class="inner">
										                <div class="image img-responsive" > </div>  
										                <div class="details" style="display:none;">
										                    <div class="info">
										                        <div class="title"> </div>
										                        <div class="description"> </div> 
										                        <div class="url"> </div>
										                    </div>

										                    <div class="thumbnail">
										                        <div class="pictures">
										                            <div class="controls">
										                                <div class="prev button inactive"></div>
										                                <div class="next button inactive"></div>
										                                <div class="count">
										                                    <span class="current">0</span><span> von </span><span class="max">0</span>
										                                </div>
										                            </div>
										                        </div>
										                    </div>
										                    <div class="video"></div>
										                </div>

										            </div>
										        </div>
											<div class="form-group">
											<h4>Page Content</h4>
											<textarea class="textarea form-control" placeholder="Enter text ..." style="height: 200px" id="c_content" name="c_content"></textarea>			
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-sm-12">
													     <input type="hidden" id="c_uid" value="<?php echo $_SESSION['userid']?>">
														 <button id="login-submit-facebook" class="form-control btn btn-create"><i class="fa fa-plus" aria-hidden="true"></i> Submit Article</button>
													</div>
												</div>
											</div>											
										</form>										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
	<script src="http://bootstrap-wysiwyg.github.io/bootstrap3-wysiwyg/components/wysihtml5x/dist/wysihtml5x-toolbar.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<script src="http://bootstrap-wysiwyg.github.io/bootstrap3-wysiwyg/components/handlebars/handlebars.runtime.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js" > </script>
	<script src="js/jquery_liveurl/jquery.liveurl.js"></script>	
	<link rel="stylesheet" type="text/css" href="js/jquery_liveurl/liveurl.css">
	<script src="js/jquery_liveurl/liveurl.js"></script>
	<!--<script src="bootstrap-portfilter.min.js"></script>-->	
	<script src="http://bootstrap-wysiwyg.github.io/bootstrap3-wysiwyg/dist/bootstrap3-wysihtml5.min.js"></script>	
	<script>

	  $('#closes').click(function(){
	  		$('#c_image').val('');
	  		$('#c_image').focus();
	  });	

	  $('#c_image').keyup(function(){
	  		var url_validate = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
	  		var image = $('#c_image').val();
	  		if (!url_validate.test(image)) {
	  		 $('#noty_error').show();
	          $('#noty_error #error_message').html('<strong>Please enter image url for this content.</strong>');
	         $('#c_image').focus();
	  		}
	  });

	  $('.textarea').wysihtml5({
		toolbar: {
		  fa: true
		}
	  });
	  
	  function submitcontent(){
	      $('#noty_error').hide();
	      $('#noty_success').hide();
	      $('#form-loader').hide();
	      $('#loader').hide();

		  var title = $('#c_title').val();
	      var description = $('#c_description').val();
	      var category = $('#c_category').val();
	      var image = $('#c_image').val();
	      var content = $('#c_content').val();
	      var uid = $('#c_uid').val();
	      var url_validate = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
	      
	      
	      if (title == ""){
	         $('#noty_error').show();
	         $('#noty_error #error_message').html('<strong>Please enter content title.</strong>');
	         $('#c_title').focus();
	      }else if (description == ""){
	         $('#noty_error').show();
	         $('#noty_error #error_message').html('<strong>Please enter brief description.</strong>');
	         $('#c_description').focus();
	      }else if (category == ""){
	          $('#noty_error').show();
	          $('#noty_error #error_message').html('<strong>Please choose content category.</strong>');
	      }else if (image == ""){
	          $('#noty_error').show();
	          $('#noty_error #error_message').html('<strong>Please enter image url for this content.</strong>');
	          $('#c_image').focus();
	      }else if (content == ""){
	          $('#noty_error').show();
	          $('#noty_error #error_message').html('<strong>Please enter page content.</strong>');
	          $('#c_content').focus();
	      }else if(!url_validate.test(image)){
	          $('#noty_error').show();
	          $('#noty_error #error_message').html('<strong>Invalid image url.</strong>');
	          $('#c_image').focus();
	       } else {
	          // $('#form-loader').show();
	          $('#loader').show();
	          $.post("http://api1.contrib.co/icontent/postcontent",
	  			 {
				       title:title,
			             description:description,
			             category:category,
			             image:image,
			             content:content,
			             uid:uid
	  			 }
	  			 ,function(data){
	  			
	  				 if(data.data.status){
	                $('#noty_success').show();
	                $('#noty_success #success_message').html("You successfully posted content. View your content <a href='"+data.data.url+"' target='_blank'>here</a>");
	                $('#submit-form-content').fadeOut();
	              
	            }else {
	                $('#noty_error').show();
	                $('#noty_error #error_message').html('<strong>An error occured while saving content...</strong>');
	            } 
	  				 // $('#form-loader').hide();
	  				 $('#loader').hide();
	  			 }
	  	   );	
	          
	      }
	}
		  
	</script>

  </body>
</html>
