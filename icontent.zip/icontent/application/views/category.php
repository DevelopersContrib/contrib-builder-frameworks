<?php include'header.php';?>
<style>
.counter {
  display: none;
}
.pagination {
	margin: 0px 0px;
	
}
.pagination > ul > li, .pagination span.pagenav, .pagination a.pagenav {
  display: inline-block;
  width: 30px;
  text-align: center;
  font-weight: bold;
}
.pagination a.pagenav {
  color: #555;
  text-decoration: none;
}
.pagination a.pagenav:hover {
  background-color: #999;
  border: none;
  color: white;
  text-decoration: none;
}
.pagination span.pagenav {
  color: #333;
}
#news-container {
	background:#f2f2f2;
	padding-top: 20px;
	padding-bottom: 80px;
}
.alert {
padding: 40px 0px 60px;
}
.hide {
	display: none;
}
.alert-info .btn {
	font-size: 20px;
padding: 5px 10px;
}
.hide {
    display: none;
}
</style>
	<section id="main-section">
		<?php include'navigation.php';?>
			<div class="main-top-title category-top-title">
			<div class="container">
			  <div class="row">
				<div class="main-lander">
					<div class="col-md-9 col-md-offset-1 text-center">
						<!-- Dynamic Category here -->
						<h1 class="text-capitalize"><?php $name = ucwords($category_name);  $name1 = stripcslashes($name); echo $name1?></h1>
					</div>
				</div>	
			  </div>
			</div>
		</div>
		<!-- end news panel-->
		<input type="hidden" name="total_results" id="total_results" value="<?echo $total_results?>" />
		<input type="hidden" name="category_id" id="category_id" value="<?echo $category_id?>">	
		<div id="news-container">
		<div class="wrap-breadcrumbs-container">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<ol class="breadcrumb">
							<li><a href="/">Home</a></li>
										<li class="active text-capitalize"><?php $name = ucwords($category_name);  $name1 = stripcslashes($name); echo $name1?></li>
							<div class="pull-right">
								<div class="pagination">
								     
								</div>
							</div>
						</ol>

					</div>
				</div>
			</div>
		</div>
			<div class="container news-panel">				
				<div class="clearfix"></div>
				<h3 class="cat-name-title text-center"></h3>
			
				<div class="clearfix"></div>
				<div class="text-center" id="loading-area">
					
				</div>
				<div class="clearfix"></div>
				<div class="row" id="newsletter_list">
					
				</div>
				<?php if($total_results < 1 ): ?>
					<div class="col-md-12 text-center">
						<div class="alert alert-info" role="alert">
							<h3>"Nothing Found Sorry, no posts available as of this moment."</h3>
							<hr>
							<a href="http://icontent.com/" class="btn btn-lg btn-warning" target="_blank">Go To iContent to Create, publish and make your content viral</a>
						</div>			
					</div>
				<?php endif;?>
			</div>
		</div>
	</section>
<!-- 	<section id="nverticals">
		<div class="container">
			<h2 class="nv-title text-center">Top Vertical News Site</h2>
			<div class="row">
				<ul class="list-unstyled">
					<li class="col-md-4">
						<a href="http://domainbuild.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-domainbuild-7.png" class="img-responsive"></a>
					</li>
					<li class="col-md-4">
						<a href="http://davaonews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-davaonews1.png" class="img-responsive"></a>
					</li>
					<li class="col-md-4">
						<a href="http://bondnews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-bondnews1.png" class="img-responsive"></a>
					</li>
					<li class="col-md-4">
						<a href="http://currencynews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Currencynews1.png" class="img-responsive"></a>
					</li>
					<li class="col-md-4">
						<a href="http://agentnews.com" target="_blank"><img src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-agentnews.png" class="img-responsive"></a>
					</li>
					<li class="col-md-4">
						<a href="http://channeltv.com" target="_blank"><img src="https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-ChannelTv.png" class="img-responsive"></a>
					</li>
				</ul>
			</div>
		</div>
	</section> -->
	<?php include'footer.php';?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/masonry/3.1.5/masonry.pkgd.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  </body>
  <script>
  jQuery(document).ready(function() {
		var total_results = jQuery('#total_results').val();
		var category_id = jQuery('#category_id').val();
		var current_page = 1;
		if(total_results > 0){
			loadPages(current_page);
		} 		
	});

	function loadPages(current_page,category_id){
		var total_results = jQuery('#total_results').val();
		var category_id = jQuery('#category_id').val();
		var loading_area = $('#loading-area');
		getPagination(current_page,total_results);
		loading_area.html("<img src='/img/loadingAnimation.gif' alt='Loading...' />");
		// jQuery('#newsletter_list').html('<center><img class="tloader" alt="Loading Contents.." src="/images/loaders/loader10.gif"></center>');
		jQuery.post('/newsletter/ajaxlist',{current_page:current_page,category_id:category_id},function(data_html){
			loading_area.html('');
			jQuery('#newsletter_list').html(data_html);			
		});
	}

	function getPagination(current_page,total_results,category_id){
		var category_id = jQuery('#category_id').val();
		jQuery.post('/newsletter/ajaxpagination',{current_page:current_page,total_results:total_results,category_id:category_id},function(data_html){
			jQuery('.pagination').html(data_html);
		});
	}
	  
  </script>
</html>
