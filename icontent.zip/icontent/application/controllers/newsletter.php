<?php

class Newsletter extends Controller {
	
	function ajaxlist()
	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$input = $this->loadHelper('Input_helper');
		$search = $input->post('search');
		$category_id = $input->post('category_id');
		$media_id = $input->post('media_id');
		$current_page = $input->post('current_page');
		$limit = 10;
		
		if($current_page) 
			$start = ($current_page - 1) * $limit; 			//first item to display on this page
	    else
			$start = 0;
		
		$template = $this->loadView('newsletter_list');
		$template->set('newsletters', $api->getnewsletters($start,$limit,$category_id,$media_id,$search));
		$template->set('base_url',$helper->base_url());
		$template->render();
	}
	
	function ajaxpagination(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$input = $this->loadHelper('Input_helper');
		
		$search = $input->post('search');
		$category_id = $input->post('category_id');
		$media_id = $input->post('media_id');
		$page =$input->post('current_page');
		$total_pages = intval($input->post('total_results'));
		$limit = 10;
	    if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//previous page is page - 1
		$next = $page + 1;							//next page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
		$lpm1 = $lastpage - 1;	
			
	    $template = $this->loadView('newsletter_pagination');
		$template->set('lastpage',$lastpage);
	    $template->set('page',$page);
	    $template->set('adjacents',3);
		$template->set('lpm1',$lpm1);
	    $template->set('prev',$prev);
	    $template->set('next',$next);
	    $template->render();
	}
	
    function details(){
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$uri = $_SERVER['REQUEST_URI'];
		$segment = explode("/", $uri);
		$start = 0;
		$limit = 3;
		$media_id = $segment[3];
		
		$template = $this->loadView('page');
		$template->set('info', $api->getdomaininfo());
		$template->set('newsletter', $api->getnewsletters(null,null,null,$media_id,null));
		$template->set('recent_news', $api->getnewsletters($start,$limit,null,null,null));
		$template->set('latest_news', $api->getnewsletters(0,1,null,null,null));
		$template->set('base_url',$helper->base_url());
		$template->render();
	}

	function canlike(){
		header('Content-Type: application/json');
		$status = false;

		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$input = $this->loadHelper('Input_helper');

		$media_id = $input->post('media_id');
		$user_ip = $input->post('user_ip');

		if ($api->canlike($media_id, $user_ip)) {
			$status = true;
		}

		$result = array('status'=>$status); 
	    echo json_encode($result); 
	}

	function addlike()
	{
	  	header('Content-Type: application/json');
	    $status = false;
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$input = $this->loadHelper('Input_helper');

		$media_id = $input->post('media_id');
		$user_ip = $input->post('user_ip');

    	if ($api->addlike($media_id,$user_ip) ===true){
	         $status = true; 
	    }
	    
	    $result = array('status'=>$status); 
	    echo json_encode($result);  

	}

}

?>
