<?php

class Category extends Controller {
	
	function categories()

	{
		
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$api->createrobots();
		$info = $api->getdomaininfo();
		$attr = $api->getattributes();
		$formdata = $api->getsignupformdata();
		
		$metatitle = 'Category';
		$template = $this->loadView('category');
		$uri = $_SERVER['REQUEST_URI'];
		$segment = explode("/", $uri);
	  	$category_id = $segment[3];
	  	$category_name = $segment[4];


	  	$template->set('categories', $api->getcategories());
		$template->set('total_results', $api->getnewslettercount($category_id, null, null));
	  	$template->set('info', $info);
		$template->set('attr', $attr);
	  	$template->set('category_id', $category_id);
	  	$template->set('category_name', $category_name);
	  	$template->set('metatitle', $metatitle);
		$template->set('base_url',$helper->base_url());
		$template->render();


	}
}

?>
