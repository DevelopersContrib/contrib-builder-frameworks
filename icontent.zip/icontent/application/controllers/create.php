<?php

class Create extends Controller {
	
	function index()
	{
		if ($_SESSION['loggedin']===true){
			$api = $this->loadModel('ApiModel');
			$helper = $this->loadHelper('Url_helper');
			$api->createrobots();
			$info = $api->getdomaininfo();
			$attr = $api->getattributes();
			
			$template = $this->loadView('create');
			$template->set('info', $info);
			$template->set('attr', $attr);
			$template->set('categories', $api->getcategories());
			$template->set('domain_affiliate_link',$api->getaffiliatelink());
			$template->set('base_url',$helper->base_url());
			
			$template->render();
		}else {
			header('Location: /signup');
		}
	}
    
}

?>
