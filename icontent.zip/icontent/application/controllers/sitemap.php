<?php

class Sitemap extends Controller {
	
	function index()
	{
		$api = $this->loadModel('ApiModel');
		$helper = $this->loadHelper('Url_helper');
		$info = $api->getdomaininfo();
		$mycategories = $api->getcategories();

		$template = $this->loadView('sitemap');
		$template->set('domain', $info['domain']);
		$template->set('categories', $mycategories);
		$template->render();
		
	}
    
}

?>
