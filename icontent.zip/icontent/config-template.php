<?php
    $domain =   "{{DOMAIN}}";
    $domainid = "{{DOMAIN_ID}}";
    $memberid = "{{MEMBER_ID}}";
    $title = "{{TITLE}}";
    $logo =  "{{LOGO}}";
    $description = "{{DESCRIPTION}}";
    $account_ga = "{{ACCOUNT_GA}}";
    $description = stripslashes(str_replace('\n','<br>',$description));
    
    $background_image = "{{BACKGROUND_IMAGE}}";
    $top_description =  "{{TOP_DESCRIPTION}}";
    $top_description = stripslashes(str_replace('\n','<br>',$top_description));
    $forsale = "{{SHOW_FOR_SALE}}";
    $forsaledefault = "{{SHOW_FOR_SALE_DEFAULT}}";
	$forsaletext = "{{FOR_SALE_TEXT}}";
	$additional_html = "{{ADDITIONAL_HTML}}";
	$footer_html = "{{FOOTER_HTML}}";
	$keywords = "{{KEYWORDS}}";
	$piwik_id = "{{PIWIK_ID}}";
    
    $footer_banner = "{{FOOTER_BANNER}}";
    
    $social_fb = '{{SOCIAL_FB}}';
    $social_gplus = '{{SOCIAL_GPLUS}}';
    $social_twitter = '{{SOCIAL_TWITTER}}';
    $social_linkedin = '{{SOCIAL_LINKEDIN}}';
    $social_gtube = '{{SOCIAL_GTUBE}}';
    $featuredsites = {{FEATUREDSITES}};
    
    
    $domain_affiliate_link = "{{AFF_LINK}}";
    $data_widget_users = {{WIDGETS}};
    $data_widget_jobs = {{JOBS}};
    
    
    $related_domains = {{RELATED_DOMAINS}};
    $vertical_domains = {{VERTICAL_DOMAINS}};
    $vertical_domains_nologo = {{VERTICAL_DOMAINS_NOLOGO}};
    $fundcampaigns = {{FUND_CAMPAIGNS}};
	
    $rolesarray = {{ROLES}};
	$countriesarray = {{COUNTRIES}};
	$industriesarray = {{INDUSTRIES}};
	$parnershiptypes = array('Sponsorship Marketing Partnerships','Distribution Marketing Partnerships','Affiliate Marketing Partnerships','Added Value Marketing Partnerships');
    
    
    
?>